var recordData = [
 {
  "length": 399741,
  "seq_id": "scaffold_1",
  "regions": []
 },
 {
  "length": 390943,
  "seq_id": "scaffold_2",
  "regions": []
 },
 {
  "length": 321343,
  "seq_id": "scaffold_3",
  "regions": []
 },
 {
  "length": 271755,
  "seq_id": "scaffold_4",
  "regions": []
 },
 {
  "length": 242290,
  "seq_id": "scaffold_5",
  "regions": []
 },
 {
  "length": 200265,
  "seq_id": "scaffold_6",
  "regions": []
 },
 {
  "length": 178115,
  "seq_id": "scaffold_7",
  "regions": []
 },
 {
  "length": 177008,
  "seq_id": "scaffold_8",
  "regions": []
 },
 {
  "length": 166919,
  "seq_id": "scaffold_9",
  "regions": []
 },
 {
  "length": 160499,
  "seq_id": "scaffold_10",
  "regions": []
 },
 {
  "length": 152560,
  "seq_id": "scaffold_11",
  "regions": []
 },
 {
  "length": 143524,
  "seq_id": "scaffold_12",
  "regions": []
 },
 {
  "length": 142259,
  "seq_id": "scaffold_13",
  "regions": []
 },
 {
  "length": 142219,
  "seq_id": "scaffold_14",
  "regions": []
 },
 {
  "length": 141894,
  "seq_id": "scaffold_15",
  "regions": [
   {
    "start": 7422,
    "end": 28723,
    "idx": 1,
    "orfs": [
     {
      "start": 9046,
      "end": 9552,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001680",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001680</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001680</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001680-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,046 - 9,552,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001680 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04588.16 (Hypoxia induced protein conserved region): [59:111](score: 71.4, e-value: 5.3e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001680\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACATCTCCAGGGAGGAGTGACGACGGTGACGCCTCTCCAAAAGCCAACAGGATGGAGAGATTTGACGATAACTCAATCATTCGGATGCCCTCGTCTTTTGATTTTGGAGATGAAGGAATGACAGGCCAAAAACCTGAGCCGCAAGGTCTAAACAAAATCTTACAGCGTTGCAAAGAGGAACCGCTTGTGCCCATTGGGTGCCTACTAACATGCGGAGCCCTGTTTGGATCTGCAGTTGGGCTAAGAAAGGGAAATAAAGATATGGCTCAGCGGATGTTTCGTTATAGAATTGGTTTTCAATTCGCGACTCTGGGATTTGTTATCGCTGGTGCACTGTACTATGGCAATGATCGAGCATCGCGGAAGCAGGAAGATCAAGCAGTACAGCAGCAGAAAGCAATGGATCGTCGGGCAGCCTGGCTACGGGAGCTAGACAGTCGTGACCGATTGCTCAAGGAACGAAGTCGACGGTTGGCAGAGAAGAAGGAACAGCCGCACCAGTAA",
      "translation": "MTSPGRSDDGDASPKANRMERFDDNSIIRMPSSFDFGDEGMTGQKPEPQGLNKILQRCKEEPLVPIGCLLTCGALFGSAVGLRKGNKDMAQRMFRYRIGFQFATLGFVIAGALYYGNDRASRKQEDQAVQQQKAMDRRAAWLRELDSRDRLLKERSRRLAEKKEQPHQ",
      "product": "hypothetical protein"
     },
     {
      "start": 9786,
      "end": 10385,
      "strand": 1,
      "locus_tag": "MARS52BIN25_001681",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001681</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001681</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001681-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,786 - 10,385,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001681 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00581.23 (Rhodanese-like domain): [11:123](score: 22.8, e-value: 0.00011)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001681\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCAATTGCCAACGCTTCGATCATAACTTCCGAGCAATTGAGTACAAGATTAAAGCAAGGCAGAATTCTACCTGTAGATGCAACATGGTACTTGCCAAACGTTCAGAGGAACGCTCGGGCCGAGTTCATACAGAAAAGGCTGCCAGGAGCGCGCTTTTTTGATCTGGATAAAATCAAAGACACAGAGTCATCACTCCCACATATGCTCCCATCAGGCGAGCTCTTTTCTACGGAAATGCGTAAAATGGGTATTTCTCGCAGTGATGAGATCGTTGTTTACGACACCTCAGCTCTGGGTATATTTAGCGCTGCACGCGCTTATTGGATGTTTAAAATCTTCGGTCACTCTAGTGTGATGCTTTTGAATTCGCTTTCACATTACAGCGGCCCATATGAAGAGGGTATTCCTAATGGTGTTACCCCAACGAAATATCCAGTTGTGGATGCAGATCAAAATCGAGTAGCCACATACGAAGAGGTCCTCGAAAACATTCAGAGACACGACGACGTACAGATTCTGGATGCTCGCCCATCCGGTCGTTTCGAAGGCGTCGATCCTGAACTTCGACCTGGTGAGCCCAACTACCGAATTTTCTAA",
      "translation": "MSIANASIITSEQLSTRLKQGRILPVDATWYLPNVQRNARAEFIQKRLPGARFFDLDKIKDTESSLPHMLPSGELFSTEMRKMGISRSDEIVVYDTSALGIFSAARAYWMFKIFGHSSVMLLNSLSHYSGPYEEGIPNGVTPTKYPVVDADQNRVATYEEVLENIQRHDDVQILDARPSGRFEGVDPELRPGEPNYRIF",
      "product": "hypothetical protein"
     },
     {
      "start": 10790,
      "end": 13483,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001682",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001682</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001682</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001682-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,790 - 13,483,\n (total: 2694 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001682\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTGGATCAAAGTACGCTTGATGAATACGGTACCATTAGTGGCGTCCTTCGACTGAGTGCGATATTAAATCCAAGGGTAATTAAAAAAGAGAGGAGTCGGAAATTCGAGGTTGCAAGCGCAAACTTCGGTCAGATTAGCTTTCTTTCTGAGGAGGTGACTATCATAAGACCACAACTGCAAAGATCCTGCACCTGGATACCTGTTCCTGATGGCGCTCGAACCTTGTTCTTCACTTGCACAATTACCCTTCCTACTGGTTATCAGTGGTCCAAACTTGTTCTTTCCGATGAGATCGTGAGAGGAAACGCCACCTTTGTCAGCGCTACATTCATAGAAGAAGAGATAGCCAATCAACACAAGCCAAAGCTTGTGTCATTGAGTTTGTACGACGAAAATACTAGCAAGAACTATGAGTTACGTATGCGAAGTCTCACTTTAGATGGGTCGAGAAACCGATACCATCTCGAAATCACGTACCAATCACACCTGGATCCTGATAAACCTAGAAGTTTTGTGGGAATAGCAAAAGTCACAAGTACACATTACAGATTCCATCGAGAATCTTACCTGCATCCGTATACGGCGAGAATTCCTTTAATAACCCAAGAAGAATTACTGAATCAAACAAAATGGGCCCCGTCTGAGCATCTCCCAATACCGGCGTATATAATAATGGACGCAGATCACGAAGGCCTTGCACCAAGACCACTATTAGTTGGTCCGGAGGATCAAAGTAATGGAACAAATAACTCAATCCCGGTAGGGTCAGCAGAAGAACATCTCCAAAATTCCAAGAGTAAGCATACTTTCTCTCCTCTATACCATCATGTCGACATAATAACGTTGCATGAGTCCACGAATGAAACAAAAGCGACAGATTCATCCAGAAATGAATTGCACACGGATTCGATCACGACGCCATTTACGGAGAAGACTTTTACGGTAAACACAACAACCAGGGACGTCGAGCCTCCTCATTCTGTGCTTCCTATACCAGGCTTCCTAACTTCGAACCAAACGGCTTATAACCTTCAAAACGCAGAGGAACGTAGTAATATGATCAACACGATGCTACCTATAAGTGGTGCAAATGAAACGCGTACCATGAAAGAGACTATTGAGTCGACGACTTCTGTGAATTCTGGCAGTGGGGTGCGTAACACCCATCATTCTTCAGATCTTTTTGTATTGTCTCCTACAACTCGATTTCACTCCGGTACTACACCAAATTCTGACTTCCCGTCAACGAATTTTGGCGCCCCTACTCTATCAGTATTTGCCCATAGCACAGATTCTGCTAATTATCCACTTCATATTCCTTCAAGTAAGTGGATATCTTCACTCACGGCGCAACCGTCTCCAGGACCGGTAGGTCTTCCAATATCTACGTCCACATCTTTGCAATTCGAGTCAAGATCTGCAAAACAGTCAATATATGACCCACAGTCACAAAAATTGGACTCTATCGCCTCACAAAGCACTGGGAGTGGCACATCTGAGAGTTTTGAAGCCATGTTCGAGACAGCTAGGAGTGAGGAGACTCCCGCTTATCTGGAAAAAATCGGCCACTCATCCGACACTACTACCAAGTCATCCCGCGGGGTAGCCCACAGAGAAACACTGGTCATCACAGGTATGCGTGGTAGACTTGTTGATCAGAATGTCGTCATAAGAACGAGTCAGGTTGAAGATGGAAAAGGGCCAGACGCAACATTCTCCCCGATCTACAGAGTCCAAAATTCTGAGGACTATACGACAAGCAAAATGAAGACTAGCATTTTGACGAACAAAGGGTTTCCACAAGTAATGAGAACAGACGCAACTCTAAGAGAGACCAAAGAAACTGAAACAATATGGGGACTCAAGCCGACCAATACGATCCGACAGCGTCCTGCACAAATTTCCCACCTGAGCGCGGAGCCTGCACTGCCTTCACTTCCTACTTCATCTCAAAGCATCCCATGGAATGAAGAACAAAGTGAAAGTTCAACAGGGCATACACCGCAATTGGCAATGTTTTCTAACGATACCCTCTCTATTTTTTATGCAGAGCCGCAAAGCGCTTATAAGGCTTCAACAGACAAAGATAAACATGCCAAAGGTATAGCCGCAATAATTCGATCTGTTCAGTTGAGTTTAATCACCGAGTCAAATTTTGCACCTGGCAGGTATAGCCAAAAACCTAGAACTGCAGCAAGCATAGATGGTGATTTGAAATCTGATTTTGATCTTATTGATTGGCAAGCTTCTCGACACGGCAAAGTTGACGTCGGCCATAAGTGTGATATGAATTCGACAGTCTGTACAGCAAACGCGAGTATCGAAGCCGACGTCAATATTGGACTCCTCGGCGCTCCGTCTGACGCGTCTACTGCTGCTGCAGGCAATCGTTCTGTGGAGGACATAAATACCCCAGCCATAGAAGACTCATATAGTACAACCTCAATCTTTGTAAAAGTACACAATGAATTCACCGCGGCATCAATGCCGGTAGAAAGCGCAAAGCCACAGAAAACTGGTCATGTCGAGTCAGCGATTCACATGTCTCATACACGATCCAAAAACTCGATTTTTCTTCCACAACCAACATCACAGCCATCGGGACTGCAGCACAGCATCGCTGCTCAAGCACCACCGGCTATACGGCAAACCCTAGTGCTGCTTCTAACTTTATTTGTATTCTTTAACTAA",
      "translation": "MVDQSTLDEYGTISGVLRLSAILNPRVIKKERSRKFEVASANFGQISFLSEEVTIIRPQLQRSCTWIPVPDGARTLFFTCTITLPTGYQWSKLVLSDEIVRGNATFVSATFIEEEIANQHKPKLVSLSLYDENTSKNYELRMRSLTLDGSRNRYHLEITYQSHLDPDKPRSFVGIAKVTSTHYRFHRESYLHPYTARIPLITQEELLNQTKWAPSEHLPIPAYIIMDADHEGLAPRPLLVGPEDQSNGTNNSIPVGSAEEHLQNSKSKHTFSPLYHHVDIITLHESTNETKATDSSRNELHTDSITTPFTEKTFTVNTTTRDVEPPHSVLPIPGFLTSNQTAYNLQNAEERSNMINTMLPISGANETRTMKETIESTTSVNSGSGVRNTHHSSDLFVLSPTTRFHSGTTPNSDFPSTNFGAPTLSVFAHSTDSANYPLHIPSSKWISSLTAQPSPGPVGLPISTSTSLQFESRSAKQSIYDPQSQKLDSIASQSTGSGTSESFEAMFETARSEETPAYLEKIGHSSDTTTKSSRGVAHRETLVITGMRGRLVDQNVVIRTSQVEDGKGPDATFSPIYRVQNSEDYTTSKMKTSILTNKGFPQVMRTDATLRETKETETIWGLKPTNTIRQRPAQISHLSAEPALPSLPTSSQSIPWNEEQSESSTGHTPQLAMFSNDTLSIFYAEPQSAYKASTDKDKHAKGIAAIIRSVQLSLITESNFAPGRYSQKPRTAASIDGDLKSDFDLIDWQASRHGKVDVGHKCDMNSTVCTANASIEADVNIGLLGAPSDASTAAAGNRSVEDINTPAIEDSYSTTSIFVKVHNEFTAASMPVESAKPQKTGHVESAIHMSHTRSKNSIFLPQPTSQPSGLQHSIAAQAPPAIRQTLVLLLTLFVFFN",
      "product": "hypothetical protein"
     },
     {
      "start": 15430,
      "end": 16848,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001683",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001683</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001683</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001683-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,430 - 16,848,\n (total: 1419 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001683\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTGTTTTGACCTTGGGTTTATGGGTCTTCATACAAAGCGCTTTCGCGCAAAGTAGTTACCCTGCTAATTTTTCAATTGAGAGGGCTGAAATATATAAGCATCCAAAACAAGATAATAATCATACCTCACCAATCCACATTAGTGATATTCTTACAGTGAAACTTCACTGGAGTCTCTACAATGCGACATTGGACAACTATGTCGCATTACAACTTGATCGAGCTCTGCAAATAATTCAGCCCCAAACACTTGAAATAATTGGTAGAAGTGGGGATCAAAAACCTGTTTTAAAGCTTGCGACATGCAACGAATTTCAATTAAGTGCAGGGGTGATTTTTTGCCCGCTCGATGAAGTCCCGCAGAAAATATTGAATGAGTACGGCACCTTGAACGGTTTCATTCATGTGGAGGCGACGCTGAACTCAAACTTCATCGGTGATGGCGCCCATAGAGTTTTTGAATTCGCAAACGCGAATTTCGATCAGGAATACGCTTATTCTGCGGATATAGCTATCGCTAGACCAGAGAATTATGAGAAAGTCACTATACCTGAATCGAAAATGCAGAGAACTTGCTCCTGGGGACTTCCGGCCGATGGCTACTACGACAAGGTTTTCGTTTGCACAATTAGCTTTCCTATCGGATATAATCTGTCCCGAGTCTTGGTTTCCGACAACATTCTGAGAGGAAACGCTAGACCTGTCGGCGCCGTATTCATACAAGAAGATGTGAATGATCTTAAAAAGCAAACCTTTGTGTCGATTGCGCGGTACAAAGAGACCTATGCACGTCGTGGTTACGAATTACGTATGCGGCCCCTCGTTGACGAGACTTTAGATGGATCGAAATACCGATATCGCCTTGCTATAACATACGAGTCACATCACGGTACTGATGATGTCAAAGGTTTTGTGGGAATAGCGAAAATCAGAAGTAAGGATTACGGCTTTGAGCAAAAATCTTATCTGCCTCCATTTTCAACGTGGAAGCGAATTTTCCCCCACATATGCAAGAATGATCATGAAGAATGGTTGTCTGCCTCCATTCAATATCCTTTGATCCCATCCGAACAAATTCAATTGCCGGCATATTCAGTCATGGCTGGGTCTCATAGGGACCAGCTATCATTTCCACTCTCAATTGGTTCAGAGGAGCAAGGTGAGTGGACCACCCCTAAATCAACGACGAATTCGTCGGACAGAGACCCACAAAGTATCGAGATCAAGCATAGTCTGTCCCCTCTACATTTCCACATGAATCGTACAATGTTGTATGAAGCCCCAAAAGGTAAAATAACAGCCACGACCCACTCCAGAATGGAGTTTTCACATGTGCGGTCTCGGCGTTCACAGGTGACACAAGGCCGACAAGCACGACACCAAAAGCTCAAAACAGTCAATCTCAATCTTTCTTGA",
      "translation": "MGVLTLGLWVFIQSAFAQSSYPANFSIERAEIYKHPKQDNNHTSPIHISDILTVKLHWSLYNATLDNYVALQLDRALQIIQPQTLEIIGRSGDQKPVLKLATCNEFQLSAGVIFCPLDEVPQKILNEYGTLNGFIHVEATLNSNFIGDGAHRVFEFANANFDQEYAYSADIAIARPENYEKVTIPESKMQRTCSWGLPADGYYDKVFVCTISFPIGYNLSRVLVSDNILRGNARPVGAVFIQEDVNDLKKQTFVSIARYKETYARRGYELRMRPLVDETLDGSKYRYRLAITYESHHGTDDVKGFVGIAKIRSKDYGFEQKSYLPPFSTWKRIFPHICKNDHEEWLSASIQYPLIPSEQIQLPAYSVMAGSHRDQLSFPLSIGSEEQGEWTTPKSTTNSSDRDPQSIEIKHSLSPLHFHMNRTMLYEAPKGKITATTHSRMEFSHVRSRRSQVTQGRQARHQKLKTVNLNLS",
      "product": "hypothetical protein"
     },
     {
      "start": 17422,
      "end": 18723,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001684",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001684</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001684</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001684-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,422 - 18,723,\n (total: 1302 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 159.8, e-value: 9.4e-47)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.3, e-value: 7e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001684\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGAAGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACCATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGGACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGCAACTCCTAGGTCCATTGCTCCTGAGCAGTAA",
      "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWEGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDHDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLDLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKATPRSIAPEQ",
      "product": "hypothetical protein"
     },
     {
      "start": 19407,
      "end": 21044,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001685",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001685</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001685</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001685-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,407 - 21,044,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001685 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 64.0, e-value: 1.8e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001685\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATCTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGCTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAGAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACGCAGAGGGAGCCATGGGTGAAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTATTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACTACATGGAAACATACTACACAAGGTACATTTGGCGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGGCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATATTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
      "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLLVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFRTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHAEGAMGESVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTTWKHTTQGTFGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
      "product": "hypothetical protein"
     },
     {
      "start": 21958,
      "end": 23710,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001686",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001686</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001686</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001686-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,958 - 23,710,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75.6; E-value: 5.2e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001686 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.2e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.9e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001686 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 667.1, e-value: 3.4e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001686\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_001686-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATTGCAGCATACGTGAAACGTATTGCACCGCAAGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTGGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCGCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
      "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPQVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSASDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
      "product": "hypothetical protein"
     },
     {
      "start": 25815,
      "end": 26123,
      "strand": -1,
      "locus_tag": "MARS52BIN25_001687",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001687</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001687</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001687-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,815 - 26,123,\n (total: 309 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001687\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGTGCAGAGGCTGCAACACAGTGGGAGCCTTCCCCGGCCGTTACAGGCCAACCTTCGTCCAGCAATGTGCGAAAACGAAAGCTGAAGGAAGCGGAAGAGGAAGAAAGGGAGAGGAAAGAGCTTCGAAGGAATGGAGCCGATGCGAAGCTGGAGTTTGCCAGAAGTCGTCGCATCATGCAAGAAAATCAGAGAGACATGCAGAGCAGATTGCTGCAAATGCTGGAAACTCGATTCCCTCCCCTGACGACCTCGACCGCCGAAGCAGCTGACAAACAGGGTGAACGCGATTCGCCTTCCGACCAATAG",
      "translation": "MRAEAATQWEPSPAVTGQPSSSNVRKRKLKEAEEEERERKELRRNGADAKLEFARSRRIMQENQRDMQSRLLQMLETRFPPLTTSTAEAADKQGERDSPSDQ",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 17421,
      "end": 18723,
      "tool": "rule-based-clusters",
      "neighbouring_start": 7421,
      "neighbouring_end": 28723,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r15c1"
   }
  ]
 },
 {
  "length": 136683,
  "seq_id": "scaffold_16",
  "regions": []
 },
 {
  "length": 131949,
  "seq_id": "scaffold_17",
  "regions": []
 },
 {
  "length": 129046,
  "seq_id": "scaffold_18",
  "regions": []
 },
 {
  "length": 127598,
  "seq_id": "scaffold_19",
  "regions": []
 },
 {
  "length": 113982,
  "seq_id": "scaffold_20",
  "regions": []
 },
 {
  "length": 112499,
  "seq_id": "scaffold_21",
  "regions": []
 },
 {
  "length": 106478,
  "seq_id": "scaffold_22",
  "regions": []
 },
 {
  "length": 103867,
  "seq_id": "scaffold_23",
  "regions": []
 },
 {
  "length": 101212,
  "seq_id": "scaffold_24",
  "regions": []
 },
 {
  "length": 101101,
  "seq_id": "scaffold_25",
  "regions": []
 },
 {
  "length": 100262,
  "seq_id": "scaffold_26",
  "regions": []
 },
 {
  "length": 99410,
  "seq_id": "scaffold_27",
  "regions": []
 },
 {
  "length": 98210,
  "seq_id": "scaffold_28",
  "regions": []
 },
 {
  "length": 91831,
  "seq_id": "scaffold_29",
  "regions": []
 },
 {
  "length": 91694,
  "seq_id": "scaffold_30",
  "regions": []
 },
 {
  "length": 91582,
  "seq_id": "scaffold_31",
  "regions": []
 },
 {
  "length": 85272,
  "seq_id": "scaffold_32",
  "regions": []
 },
 {
  "length": 85075,
  "seq_id": "scaffold_33",
  "regions": []
 },
 {
  "length": 77129,
  "seq_id": "scaffold_34",
  "regions": []
 },
 {
  "length": 74513,
  "seq_id": "scaffold_35",
  "regions": []
 },
 {
  "length": 73321,
  "seq_id": "scaffold_36",
  "regions": []
 },
 {
  "length": 72909,
  "seq_id": "scaffold_37",
  "regions": []
 },
 {
  "length": 71605,
  "seq_id": "scaffold_38",
  "regions": []
 },
 {
  "length": 71560,
  "seq_id": "scaffold_39",
  "regions": []
 },
 {
  "length": 70793,
  "seq_id": "scaffold_40",
  "regions": [
   {
    "start": 15010,
    "end": 36945,
    "idx": 1,
    "orfs": [
     {
      "start": 16655,
      "end": 18205,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003073",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003073</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003073</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003073-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,655 - 18,205,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003073\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACCGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAAGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACAATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATGCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
      "translation": "MNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRPRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYKNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIQWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIACCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
      "product": "hypothetical protein"
     },
     {
      "start": 18215,
      "end": 18889,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003074",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003074</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003074</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003074-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,215 - 18,889,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003074\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCTATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
      "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
      "product": "hypothetical protein"
     },
     {
      "start": 18961,
      "end": 19866,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003075",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003075</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003075</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003075-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,961 - 19,866,\n (total: 906 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003075 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [1:109](score: 50.5, e-value: 1.8e-13)<br>\n \n  PF03473.20 (MOSC domain): [159:288](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003075 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003075\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATAGCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGCGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAAAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTGGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTGGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
      "translation": "MHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDSEELVLAFDGIAQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
      "product": "hypothetical protein"
     },
     {
      "start": 20079,
      "end": 21383,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003076",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003076</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003076</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003076-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,079 - 21,383,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003076 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003076\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATCGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTGCGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
      "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGIGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLATPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
      "product": "hypothetical protein"
     },
     {
      "start": 21653,
      "end": 22684,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003077",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003077</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003077</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003077-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,653 - 22,684,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003077 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [27:235](score: 122.2, e-value: 2.5e-35)<br>\n \n  PF03129.23 (Anticodon binding domain): [255:302](score: 21.1, e-value: 0.00029)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003077 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003077\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCGTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
      "translation": "MTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
      "product": "hypothetical protein"
     },
     {
      "start": 22947,
      "end": 24926,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003078",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003078</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003078</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003078-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,947 - 24,926,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003078 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003078 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003078\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTCCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
      "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
      "product": "hypothetical protein"
     },
     {
      "start": 25010,
      "end": 26945,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003079",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003079</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003079</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003079-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,010 - 26,945,\n (total: 1407 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [65:356](score: 129.0, e-value: 2.5e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [56:406](score: 425.1, e-value: 4.4e-128)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003079\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_003079-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCCCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTACAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAACGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTTTGATGATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
      "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPATFQRNVKITKGEACALMMQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
      "product": "hypothetical protein"
     },
     {
      "start": 27406,
      "end": 29298,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003080",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003080</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003080</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003080-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,406 - 29,298,\n (total: 1893 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 56.4; E-value: 3.8e-17)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003080 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [124:159](score: 23.4, e-value: 8.4e-05)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003080 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003080\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGGGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGAGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGTTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGTGAATAG",
      "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKGRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQSE",
      "product": "hypothetical protein"
     },
     {
      "start": 30399,
      "end": 31238,
      "strand": 1,
      "locus_tag": "MARS52BIN25_003081",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003081</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003081</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003081-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,399 - 31,238,\n (total: 774 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003081 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [99:223](score: 118.9, e-value: 1.6e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003081 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003081\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTGAACTAATGAAAGCGAACGCCACGTCACTAATGCCAGTGGGAGCTCCTGGCATGCCCACTAATTTCGACAACTCAAACCTTCACAAAAGTCAAGCTTCTTTCCCCCCGTCTTCGCCTGCTGGCTCTCTGCAAGGCAACAATACGAGCATATCGGTCCAAGACCGATATGGGTTGCGTGGCCTCTTAAGTATCATTCGCATGGACAATCCGGATGCGAGCATGCTGTCTCTAGGCAGCGACCTGACTAGCCTTGGCCTGAATTTGAATCAGCCCGACGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAGCAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
      "translation": "MSELMKANATSLMPVGAPGMPTNFDNSNLHKSQASFPPSSPAGSLQGNNTSISVQDRYGLRGLLSIIRMDNPDASMLSLGSDLTSLGLNLNQPDDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
      "product": "hypothetical protein"
     },
     {
      "start": 31337,
      "end": 32085,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003082",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003082</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003082</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003082-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,337 - 32,085,\n (total: 711 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003082 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [30:233](score: 294.3, e-value: 4.8e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003082 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003082\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGGGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGACATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
      "translation": "MKTLATTSLALSLCLVCGVVGQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
      "product": "hypothetical protein"
     },
     {
      "start": 32200,
      "end": 33447,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003083",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003083</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003083</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003083-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,200 - 33,447,\n (total: 1173 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003083 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:353](score: 70.0, e-value: 2.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003083 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003083\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCGGTCTCGCCTGAAATCGCCAAACGTGCCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACATTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTTGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAATTCTCTACGTCGAACCACGCTCGAGACTTTCGGGAGAAGGTTGTGTCTCTTGTACCCAAGGAGCCCAGAGCATCCAGCAGCCCGGCCAAACAAGGCCCGCCATCCCCAACCACCAACCCCACCACCACGGCGCAGGAGGACGCGTCGAGCAAAGACTAA",
      "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRAEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKFSTSNHARDFREKVVSLVPKEPRASSSPAKQGPPSPTTNPTTTAQEDASSKD",
      "product": "hypothetical protein"
     },
     {
      "start": 33559,
      "end": 36274,
      "strand": -1,
      "locus_tag": "MARS52BIN25_003084",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003084</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003084</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003084-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,559 - 36,274,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003084 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [8:195](score: 131.1, e-value: 3.6e-38)<br>\n \n  PF00106.28 (short chain dehydrogenase): [313:496](score: 146.2, e-value: 8.9e-43)<br>\n \n  PF01575.22 (MaoC like domain): [769:879](score: 113.0, e-value: 6.8e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003084\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_003084-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCGATCTACGGTTCGATGACCAGGTAGTCGTAGTCACTGGTGCTGGTGGAGGCTTGGGCAAGGCGTACGCGCTTTTCTTCGCCAGCCGAGGTGCGAACGTGGTTGTTAATGATTTGGGTGGCAGCTTTCACGGAGAAGGACAGAGCTCAAAGGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCATGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGAATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGTAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCACTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAAAAGACTCAGAAAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTATTGAAAATATAAGTAATCGTACCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTATTTGAAGTCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTAAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
      "translation": "MPDLRFDDQVVVVTGAGGGLGKAYALFFASRGANVVVNDLGGSFHGEGQSSKAADLVVDEIKKAGGHAVADYNNVQNGDQIIETAVKEFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQKMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIIENISNRTGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEVSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 25009,
      "end": 26945,
      "tool": "rule-based-clusters",
      "neighbouring_start": 15009,
      "neighbouring_end": 36945,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r40c1"
   }
  ]
 },
 {
  "length": 69089,
  "seq_id": "scaffold_41",
  "regions": []
 },
 {
  "length": 66115,
  "seq_id": "scaffold_42",
  "regions": []
 },
 {
  "length": 65778,
  "seq_id": "scaffold_43",
  "regions": []
 },
 {
  "length": 64996,
  "seq_id": "scaffold_44",
  "regions": []
 },
 {
  "length": 63932,
  "seq_id": "scaffold_45",
  "regions": []
 },
 {
  "length": 61645,
  "seq_id": "scaffold_46",
  "regions": []
 },
 {
  "length": 61437,
  "seq_id": "scaffold_47",
  "regions": []
 },
 {
  "length": 61109,
  "seq_id": "scaffold_48",
  "regions": []
 },
 {
  "length": 60284,
  "seq_id": "scaffold_49",
  "regions": []
 },
 {
  "length": 59264,
  "seq_id": "scaffold_50",
  "regions": []
 },
 {
  "length": 58310,
  "seq_id": "scaffold_51",
  "regions": []
 },
 {
  "length": 58288,
  "seq_id": "scaffold_52",
  "regions": []
 },
 {
  "length": 57917,
  "seq_id": "scaffold_53",
  "regions": []
 },
 {
  "length": 57816,
  "seq_id": "scaffold_54",
  "regions": []
 },
 {
  "length": 53483,
  "seq_id": "scaffold_55",
  "regions": []
 },
 {
  "length": 52897,
  "seq_id": "scaffold_56",
  "regions": []
 },
 {
  "length": 52516,
  "seq_id": "scaffold_57",
  "regions": []
 },
 {
  "length": 51488,
  "seq_id": "scaffold_58",
  "regions": []
 },
 {
  "length": 49771,
  "seq_id": "scaffold_59",
  "regions": []
 },
 {
  "length": 48173,
  "seq_id": "scaffold_60",
  "regions": []
 },
 {
  "length": 46875,
  "seq_id": "scaffold_61",
  "regions": []
 },
 {
  "length": 46617,
  "seq_id": "scaffold_62",
  "regions": []
 },
 {
  "length": 46177,
  "seq_id": "scaffold_63",
  "regions": []
 },
 {
  "length": 45190,
  "seq_id": "scaffold_64",
  "regions": []
 },
 {
  "length": 45035,
  "seq_id": "scaffold_65",
  "regions": []
 },
 {
  "length": 44703,
  "seq_id": "scaffold_66",
  "regions": []
 },
 {
  "length": 44425,
  "seq_id": "scaffold_67",
  "regions": []
 },
 {
  "length": 44110,
  "seq_id": "scaffold_68",
  "regions": []
 },
 {
  "length": 43899,
  "seq_id": "scaffold_69",
  "regions": []
 },
 {
  "length": 43713,
  "seq_id": "scaffold_70",
  "regions": []
 },
 {
  "length": 43470,
  "seq_id": "scaffold_71",
  "regions": []
 },
 {
  "length": 43159,
  "seq_id": "scaffold_72",
  "regions": []
 },
 {
  "length": 42744,
  "seq_id": "scaffold_73",
  "regions": []
 },
 {
  "length": 42389,
  "seq_id": "scaffold_74",
  "regions": []
 },
 {
  "length": 42376,
  "seq_id": "scaffold_75",
  "regions": []
 },
 {
  "length": 41839,
  "seq_id": "scaffold_76",
  "regions": []
 },
 {
  "length": 41412,
  "seq_id": "scaffold_77",
  "regions": []
 },
 {
  "length": 40622,
  "seq_id": "scaffold_78",
  "regions": []
 },
 {
  "length": 40539,
  "seq_id": "scaffold_79",
  "regions": []
 },
 {
  "length": 40267,
  "seq_id": "scaffold_80",
  "regions": []
 },
 {
  "length": 40251,
  "seq_id": "scaffold_81",
  "regions": []
 },
 {
  "length": 40222,
  "seq_id": "scaffold_82",
  "regions": []
 },
 {
  "length": 38761,
  "seq_id": "scaffold_83",
  "regions": []
 },
 {
  "length": 38700,
  "seq_id": "scaffold_84",
  "regions": []
 },
 {
  "length": 38397,
  "seq_id": "scaffold_85",
  "regions": [
   {
    "start": 1,
    "end": 38397,
    "idx": 1,
    "orfs": [
     {
      "start": 42,
      "end": 2081,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004291",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004291</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004291</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004291-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42 - 2,081,\n (total: 1938 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 273.3; E-value: 5.9e-83)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00083.27 (Sugar (and other) transporter): [139:593](score: 291.3, e-value: 1.4e-86)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00879 (SP: MFS transporter, sugar porter (SP) family): [135:589](score: 280.5, e-value: 5.5e-84)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004291\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMFTDGSFPYFVSQLRVSFHNMSTKMYTSLSTQEIGTSSKSEVEHAPITSTTTLLNSSTGTRIENPLADVSRDELMRQVAEFAGENGLLHALPLLQKGALVAQRPTEWDAIPELDEDDRAALEYEFLHKWRQTKDLYITILVCSVGAAVQGWDQTGSNGANLSFPLEFGINPVAGEPNYERNSWLVGLVNCAPYIAAALLGCWLSDPLNHYFGRRGTIFFSAVFCCFSVIGSGFARNWEELVFCRVLLGIGLGSKASIVPVFAAENSPAAIRGGLTMGWQLWTGVGIWLGYSANLAVFNTGAIAWRLQLGSAFIPTIPLLFGVYLCPESPRWYLKKGRYVDAYKSLCRLRKTQLQAARDLYYIHAQLMEESKITRGAGYVARFIELFSIPRNRRASAAAFTVMVAQQLCGINIISFYSSTIFVTAGASDFKALCIAFGTGIIGPVAALLAVYTIDTFGRRNLLLITFPNMAWQLLAVAFSFYIPKENDAHLIVVSVFIFLFSTTYSIGGGPVPFAYSAEAFPLSHREIGMSFAVATNNLFAAILSLTFFRISAVFGISGAFFFYAGLNVLAFIMIFFLVPETKQRTLEELDYVFGPTTVHIKYQVTQAVPYFIRRWVCFDKSAKLEPLLQLHSDMDAENLREKLRN\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTCACGGATGGGAGCTTTCCCTACTTCGTGTCGCAGCTACGGGTATCCTTTCACAACATGTCCACCAAGATGTACACGTCTCTTTCGACCCAGGAGATAGGGACGAGCAGCAAAAGCGAGGTCGAGCATGCACCCATCACGTCCACCACCACCCTCCTCAACTCAAGTACAGGCACAAGGATAGAAAATCCGCTTGCAGATGTTTCTCGAGACGAGCTGATGCGACAAGTGGCGGAATTTGCAGGGGAAAATGGTCTACTACATGCCTTGCCATTGCTGCAAAAAGGCGCGCTTGTCGCGCAAAGACCTACGGAATGGGATGCAATCCCTGAACTTGATGAGGATGATAGAGCTGCCTTGGAGTATGAATTCCTGCACAAATGGCGCCAAACAAAGGACCTGTACATCACTATATTGGTCTGCTCGGTTGGAGCAGCTGTTCAGGGCTGGGACCAAACAGGATCCAACGGTGCGAATCTTTCTTTCCCGCTGGAGTTTGGAATTAATCCTGTTGCTGGAGAGCCAAATTACGAAAGGAACAGCTGGCTAGTGGGACTCGTGAACTGTGCACCTTATATCGCCGCTGCACTTCTCGGCTGCTGGCTGTCAGACCCCCTGAATCACTACTTTGGCCGTCGTGGGACGATATTTTTTTCTGCTGTCTTTTGCTGTTTCTCCGTGATTGGTTCTGGGTTCGCAAGAAACTGGGAGGAACTTGTTTTCTGTCGGGTGCTTCTTGGAATCGGACTGGGCTCAAAGGCTTCTATTGTTCCTGTCTTTGCTGCGGAAAATTCGCCGGCTGCTATCCGGGGTGGCCTTACGATGGGCTGGCAGCTGTGGACGGGAGTGGGAATCTGGCTTGGCTATTCTGCAAATTTGGCTGTTTTCAATACTGGAGCCATCGCTTGGCGGCTTCAACTAGGGTCTGCATTCATACCTACGATCCCTTTGCTGTTCGGAGTCTACCTTTGCCCAGAATCTCCACGATGGTATCTTAAAAAGGGTAGATATGTGGATGCGTACAAGTCTCTGTGTAGATTGCGAAAGACACAACTACAAGCTGCTCGGGATCTATATTACATCCATGCCCAACTCATGGAGGAGTCAAAAATTACAAGAGGAGCAGGTTATGTGGCGCGATTCATCGAACTCTTCTCCATTCCCCGAAATCGACGAGCGTCTGCTGCCGCATTCACAGTGATGGTGGCTCAGCAACTATGCGGCATCAATATCATTTCCTTCTACTCGTCAACAATATTTGTGACGGCAGGAGCCAGTGACTTCAAAGCTCTATGTATTGCGTTTGGCACAGGTATTATTGGGCCAGTTGCTGCATTACTTGCGGTATATACGATCGACACCTTTGGTCGCAGAAACTTGCTTCTCATCACCTTCCCAAACATGGCTTGGCAGCTGCTTGCGGTAGCTTTTAGCTTCTATATTCCAAAGGAGAACGACGCGCATCTCATAGTGGTATCTGTGTTTATCTTCCTCTTCTCTACCACATACAGTATTGGCGGGGGCCCAGTTCCTTTTGCTTATTCAGCAGAGGCGTTTCCGCTGTCGCATCGTGAAATCGGAATGAGCTTTGCAGTGGCGACAAACAACCTTTTCGCGGCAATCTTATCGCTCACTTTTTTTCGCATATCTGCTGTATTTGGCATAAGTGGTGCTTTTTTCTTTTACGCCGGACTGAACGTGCTTGCTTTCATCATGATATTCTTCCTGGTGCCCGAGACAAAGCAACGTACATTAGAGGAGCTTGATTACGTTTTTGGCCCTACCACAGTCCACATCAAGTATCAGGTTACGCAAGCAGTCCCATACTTTATCAGACGCTGGGTATGCTTTGACAAGTCGGCAAAACTGGAACCGCTGTTGCAGCTCCACAGCGACATGGACGCTGAAAATTTACGAGAGAAACTGCGAAATTGA",
      "translation": "MFTDGSFPYFVSQLRVSFHNMSTKMYTSLSTQEIGTSSKSEVEHAPITSTTTLLNSSTGTRIENPLADVSRDELMRQVAEFAGENGLLHALPLLQKGALVAQRPTEWDAIPELDEDDRAALEYEFLHKWRQTKDLYITILVCSVGAAVQGWDQTGSNGANLSFPLEFGINPVAGEPNYERNSWLVGLVNCAPYIAAALLGCWLSDPLNHYFGRRGTIFFSAVFCCFSVIGSGFARNWEELVFCRVLLGIGLGSKASIVPVFAAENSPAAIRGGLTMGWQLWTGVGIWLGYSANLAVFNTGAIAWRLQLGSAFIPTIPLLFGVYLCPESPRWYLKKGRYVDAYKSLCRLRKTQLQAARDLYYIHAQLMEESKITRGAGYVARFIELFSIPRNRRASAAAFTVMVAQQLCGINIISFYSSTIFVTAGASDFKALCIAFGTGIIGPVAALLAVYTIDTFGRRNLLLITFPNMAWQLLAVAFSFYIPKENDAHLIVVSVFIFLFSTTYSIGGGPVPFAYSAEAFPLSHREIGMSFAVATNNLFAAILSLTFFRISAVFGISGAFFFYAGLNVLAFIMIFFLVPETKQRTLEELDYVFGPTTVHIKYQVTQAVPYFIRRWVCFDKSAKLEPLLQLHSDMDAENLREKLRN",
      "product": "hypothetical protein"
     },
     {
      "start": 2167,
      "end": 2412,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004292",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004292</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004292</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004292-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,167 - 2,412,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004292\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTTGGAAAGCCGTACATGGTGGATATTGTGGAGAAGCCCGGTGGTCAAGGAAATGACGACCCCGTCTTGCTGGAGGATATCCTGGGAGAACCCAAGCCCGACCGCTTCAAACGCGCATCATTCATCCGCGAAGGTGCCATATCAGTGCTCGTTGGCGCAGGTGGCAACCTTTCGATGCGGACTGGTGAAGCCGTCAATCTGACCGACCTCGTCAAGTTTTTGGTTGCATTCGTTACACCATAG",
      "translation": "MFGKPYMVDIVEKPGGQGNDDPVLLEDILGEPKPDRFKRASFIREGAISVLVGAGGNLSMRTGEAVNLTDLVKFLVAFVTP",
      "product": "hypothetical protein"
     },
     {
      "start": 3065,
      "end": 4389,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004293",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004293</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004293</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004293-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,065 - 4,389,\n (total: 1161 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 225; E-value: 2.8e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00083.27 (Sugar (and other) transporter): [0:347](score: 211.4, e-value: 2.5e-62)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00879 (SP: MFS transporter, sugar porter (SP) family): [0:343](score: 247.3, e-value: 6.3e-74)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004293\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004293-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSPSYASEVCPVALRGYLTTFVNICWLIGQFIASGVLDGMVGVTSGWGYRIPFAIQWIWPIPLFIIVLYAPESPWWLVRKGRLREAERSVERLSAKNSKISARQTVAMMVHTNDLEKELQTGHSYADCFKGSDRRRTEICCMAWTVQYLSGFGIQGYTTYFFEQAGLAAENAYKMTLAYFAIGFVGTVLAWFLMMNFGRRTIYVSGLAILTTIMFIIGFLSLAPESNKGAQWAVGVMLIIWVFFYDFTIGPVGYAIFGETSSTRLRTKSIALARILYALVSIVGSIVTPYVSLPPCLYRYMLNPGEGNWKGKAAFLSGGISLCCFAWGFFRLPECKGRTYEEIDILFERKVPARQFKGYKVDAYEHTNLLKEDSIKKEATLSTTLS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCCCTCGTATGCTAGCGAGGTTTGTCCAGTCGCGCTTCGAGGGTACTTGACTACTTTTGTGAATATTTGCTGGCTCATTGGCCAATTCATAGCTTCTGGAGTGCTGGACGGCATGGTGGGTGTCACCAGTGGATGGGGCTATCGCATTCCATTCGCTATTCAATGGATCTGGCCGATCCCTTTGTTCATTATTGTCTTATATGCTCCCGAATCCCCTTGGTGGCTTGTACGGAAAGGCCGACTTCGTGAGGCCGAACGTTCGGTAGAGAGACTATCTGCAAAGAACTCAAAAATCAGCGCAAGACAGACGGTTGCCATGATGGTTCATACAAACGACCTTGAGAAAGAGTTGCAGACTGGACACTCTTATGCTGATTGCTTCAAAGGATCTGATCGTCGCCGGACAGAAATATGCTGCATGGCATGGACTGTTCAATACCTCAGTGGATTTGGGATTCAAGGCTACACGACTTATTTTTTTGAGCAAGCAGGATTGGCTGCTGAAAATGCATACAAGATGACCCTTGCGTACTTTGCCATTGGATTCGTGGGAACTGTGTTGGCCTGGTTCCTCATGATGAACTTTGGCCGGCGTACAATTTATGTCAGTGGGCTAGCCATACTGACCACAATTATGTTCATTATTGGCTTTCTTTCGTTGGCACCCGAATCCAACAAAGGTGCCCAGTGGGCGGTAGGTGTCATGCTTATCATTTGGGTATTTTTCTATGACTTTACGATTGGCCCAGTGGGCTATGCAATCTTTGGAGAGACTTCCTCGACCCGCTTACGCACCAAATCCATAGCTCTAGCACGGATTCTCTATGCCCTGGTGAGCATTGTTGGAAGTATCGTAACACCGTATGTCTCTCTGCCGCCATGCTTATATAGATACATGCTGAACCCGGGTGAGGGAAACTGGAAAGGCAAAGCCGCATTTCTCAGTGGAGGCATATCTCTTTGCTGTTTTGCCTGGGGATTTTTCCGCCTTCCCGAGTGCAAGGGCCGCACGTACGAGGAGATTGATATTCTCTTTGAGAGGAAAGTGCCCGCGCGACAGTTCAAGGGCTACAAGGTTGATGCGTACGAGCATACCAATCTGTTGAAGGAGGACAGCATTAAAAAGGAAGCTACGCTGTCCACAACTCTATCGTAG",
      "translation": "MSPSYASEVCPVALRGYLTTFVNICWLIGQFIASGVLDGMVGVTSGWGYRIPFAIQWIWPIPLFIIVLYAPESPWWLVRKGRLREAERSVERLSAKNSKISARQTVAMMVHTNDLEKELQTGHSYADCFKGSDRRRTEICCMAWTVQYLSGFGIQGYTTYFFEQAGLAAENAYKMTLAYFAIGFVGTVLAWFLMMNFGRRTIYVSGLAILTTIMFIIGFLSLAPESNKGAQWAVGVMLIIWVFFYDFTIGPVGYAIFGETSSTRLRTKSIALARILYALVSIVGSIVTPYVSLPPCLYRYMLNPGEGNWKGKAAFLSGGISLCCFAWGFFRLPECKGRTYEEIDILFERKVPARQFKGYKVDAYEHTNLLKEDSIKKEATLSTTLS",
      "product": "hypothetical protein"
     },
     {
      "start": 5332,
      "end": 6708,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004294",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004294</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004294</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004294-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,332 - 6,708,\n (total: 1377 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004294 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07350.15 (Protein of unknown function (DUF1479)): [19:431](score: 407.9, e-value: 4.7e-122)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004294\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAACGAACGAACACGCCAACGGAGCATTGCCATATGCCGACAAGGATTTGCCTCGCCTTGATTCGCGGTTTGCGGAAATAAAAAAGATTATCATCAAGCCAGAGAATGTTGACGAGGTACGGCAATCCTACGCACGCTTACTCGTCGCTCTGCAGAAGGAGGCTGACAGGATCAAATCGCTCGCTCGCGACGTCATCCCGCAAATCCAGTGGAGCGAGATTGCAGCCAATGGCGACCGACTCCCTTCGCAGGTTTTGCAGGCGGCCCGCGAATCCGGGTGTTTGATTGTGCGGGGGGTGATAGATCGGCAGACCGCCATCAGGTGGAAAGACGAGCTGCGCGCTTACTGCCTTGAACATCCCAAAAATGGGCGCCCGTCCTCTATCTGGCCGTACCATTGGACGCGGCCAAAGATGCAGTCGCGCAGCCACCCTGACACCATTCGTGTGGTCAATGCGGTGAGTATGCTGTGGCACCCCGCCAGTGATCAAACCCCCGTCGACCTCTCCAGCCATGTCGTGTACAGCGACCGCTTCCGCATCCGCTATCCCGAGGATGGCGAGGGCACGCTCCCGCCGCATCAGGACAATGGGTCTGTGGAGCGATGGGAGGATCCTACTTACAGAAAGTACTATGCAAAAATATTTGAAGGCACATGGGAGGAATTTGATCCGTGGATGCTCGACGATCGTGTAGACGCCAATATCGACATGTACCGTGACTCCCCTTGCCAATCCGGTTTCCGATCGCTGCAAGGCTGGCTGGCGCTCTCGCAGACCAATGTCGGCGAAGGCACGCTACGGCTGGTGCCAAACCTGAAACTGGTTACGGCGTACATCATGCTGCGCCCATACTTTATGCAAGGTAGTGACGCATTTGACGACGCCAGCTCCGTCTTCCCTGGCTGTGTGGTCAAAGACGGCCAATTTTACCCCACTGAGCAGTTCCACCCGCATCTGCGCTTACAGGACACGATGCTCAATATCCCGCCCATCGAGCCGGGCGACTTTGTCTTTTGGCATTGCGACCAAGTGCATGACGTGGATCGCATTCATCGTGGACCCAAGGGCAAAGACTCTTCTGTCATCTACATACCCGTTGCCCCACTCTGCGATGAAAACATCAAGAATATGATGCATCACCGCACCGCCTTTGAGCAATGCAAGCCTATTGACGACTTCCCCAACGAGGCAAAGAATATCAAGGATGGGGTCGAGGCACAGCATGTGAATCACGGAGCACGGAGAGAGAATATCATGACGGAGGAAGGATTGCGCGCACTTGGATTGGCTCCTTTCGACGTAAGCGAGCATGGTCTCTCGCAGGGTGCGCGAACTATTCGAGAGCGCGCCAACTCTGCCATGAAGGCCTAG",
      "translation": "MTTNEHANGALPYADKDLPRLDSRFAEIKKIIIKPENVDEVRQSYARLLVALQKEADRIKSLARDVIPQIQWSEIAANGDRLPSQVLQAARESGCLIVRGVIDRQTAIRWKDELRAYCLEHPKNGRPSSIWPYHWTRPKMQSRSHPDTIRVVNAVSMLWHPASDQTPVDLSSHVVYSDRFRIRYPEDGEGTLPPHQDNGSVERWEDPTYRKYYAKIFEGTWEEFDPWMLDDRVDANIDMYRDSPCQSGFRSLQGWLALSQTNVGEGTLRLVPNLKLVTAYIMLRPYFMQGSDAFDDASSVFPGCVVKDGQFYPTEQFHPHLRLQDTMLNIPPIEPGDFVFWHCDQVHDVDRIHRGPKGKDSSVIYIPVAPLCDENIKNMMHHRTAFEQCKPIDDFPNEAKNIKDGVEAQHVNHGARRENIMTEEGLRALGLAPFDVSEHGLSQGARTIRERANSAMKA",
      "product": "hypothetical protein"
     },
     {
      "start": 6753,
      "end": 9119,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004295",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004295</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004295</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004295-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,753 - 9,119,\n (total: 2367 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004295 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16334.8 (Domain of unknown function (DUF4964)): [26:88](score: 38.5, e-value: 7e-10)<br>\n \n  PF17168.7 (Domain of unknown function (DUF5127)): [108:351](score: 177.6, e-value: 3.5e-52)<br>\n \n  PF16335.8 (Domain of unknown function (DUF4965)): [421:600](score: 217.8, e-value: 7.9e-65)<br>\n \n  PF08760.14 (Domain of unknown function (DUF1793)): [605:778](score: 219.7, e-value: 3.2e-65)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004295\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGGCCACCGTATGGAAGGCTGTCTTGCTGGCCGGGCTGGCCCTTGGCAAATCGCAGCCACTGTACTCCCCCGCTCGCCCACCAGCGGTGCCATTGGCTGTCCGCAGCCCATACACGTCCACCTGGTCGAGCACCGCAAAAAACGCCACTCTCAACAGCGCTGACCCTATTTTCTGGGACGGGACAAGTATTGGCTGGGAGGGCTTTGTTGCTGTGGACGGCATTGCCTATGAATACCTCGGTAGTGCGAGGTCTGGCCTGCCCCCCACCAATTTCATCAAGCAGGCCAACCAGACTCGTCTGGACTATGACTCGTCTTACTCCAACTTCACCTTCATGGCCGGTCCGGTACAATTAAATGTGGATTTTTTGTCGACTGTCTATCCGCAGGATATATGCCGCACCAGTATTCCTCTCTCCTATCTAACGGTCTCGGCAACTTCCATGGACGGTGGAAGCCACAACGTACAGCTTTACAACGACATCAATGGAGCATGGATTTCTAAGGAGTCGAATGCGACCCTGCAATGGGACCTTTTCAACAATGGCCAAAACGTCACCACAAGTTCTGGCAGCAACTCCAACTCGAATGTGTTTTCCTGGATTGTTGCTCTCGAGAAGCAGTATACGTTTGGAGAGCTGTTTAACTTTCCTTTATGGGGCAAGCTGACGTTCAATACCATGACTAATGGTCACAAGATGTCCTACCAAGCTGGAAATGCATTGGCTGTGCGATGGAACTGGATTTCCAACCGCACTCTCACGAACACAATTGACCGCAGTTTTCGCGGATGGGGACAGGGGTCACCAGTCTATGCTTTTGCACACGACCTCGGCAGTATTTCTGGGACCGAATCCGTAACATACACTGTTGGTTCCGTCCAGGACCCGGCGATAAGGTATCTCGACAACTCGGGAGTGCAAGGCCTTCATCCGTACTGGCAACACTGCTATGGTAATGATCTTTTCAATCTCATCAGCACGCATTTTAACGATCTCTCGCAATCAGCAGCTCTAGCTGCTGAATTTGAGTCGAAGCTCAAAGCAGATGTGAATTCGTACTATGCTGCCGAGGGTGCCATGGTCTACTCCAAAGGAGGTGAATCGAGAGGGCCCATGTTTGATCAATTCAACGGAACTGATCAAACCTACATTAACAACCAACAAGTGCAGGAATATTTCACGTTCAACCCTTTCAACGGGTATGGATTCCTCAACTCCAACAACTTTTCCAACATACCAATCCCTGATGTCACTGAAAGCCAGGCCTACTATTCCATTGTGGCTTTGTCAGCTCGGCAAGTCATGGGAGCCTACGCGCTGACTACTGGCGCCACCGATGCTTGCACCGGCCAAAACAGCAGCGGCCCATTGATGTTTCAAAGGGAGATCTCATCGGGTGCAAATGTCAACACGGTCGATGTACTGTACCCAGCCATGCCTTTCTTTCTTTATGCAAACCCTGACATGATTAAATACCAGCTAGACCCGCTCTTTCAAAATCAGGAAAACAACTTCTATCCAAATATGTATTCCATGCATGACCTTGGCACCCACTATCCTAACGCGACGGGCCATGTGGAAGGAAATGACGAGTACATGCCAGTCGAAGAGTCAGGTAACATGATACTCCTCTCTCAGGCATACACACTCTTCAAAGGCGACTCGAGCTACATCAGCATGCACTACGCCAAGCTGAAGCAATTGTCAGAGTATCTAATCAACTTTAGTCTTCTACCCGGAGTGCAATTGAGCACGGACGATTTTGCCGGATCTTTGGCCAATCAGACCAATTTGGCCATCAAAGGCATCGTTGGATTGGCGGCCATGAGTAAAATTGCTTCTGCAACTGGCCACAACTCAGACGCACAGAACTTCACTGAGATTGCAAATTCCTACTTTACTCGATGGGAGGGGTTTGGAATCGACCCGAGCGGCAAGCATTCCATTCTAGGCTATGAATGGCGATCTTCATGGAGTTTGCTCTACAACATCATGCCTGCCAAGTTGCTTGGTTTGTCCATCATCCCGCAGCGTATTTACGACATGCAGAGTGAATGGTATCCCCAGGTCGCCCAATTATTTGGCGTCCCGCTCGACAACCGACATGACTACACCAAGTCCGACTGGGAGATGTGGTGTGCGTCGATTGCCAGCCCATCTACTCGTATGATGTTTGTCAACGCACTCGGGTACTGGCTCAACAACACCAATACAAACACCCCCTTCTCCGATCTCTATCAGACGACGGAAATGGGCGGCTATCCAGAGGACCCGTTGGTCAAATTCATTGCACGTCCTGTTGTGGGTGGGCATTATGCACTTCTTGCCATGGACATGTCGGCCAAGTTGAACCAATCTTAA",
      "translation": "MMATVWKAVLLAGLALGKSQPLYSPARPPAVPLAVRSPYTSTWSSTAKNATLNSADPIFWDGTSIGWEGFVAVDGIAYEYLGSARSGLPPTNFIKQANQTRLDYDSSYSNFTFMAGPVQLNVDFLSTVYPQDICRTSIPLSYLTVSATSMDGGSHNVQLYNDINGAWISKESNATLQWDLFNNGQNVTTSSGSNSNSNVFSWIVALEKQYTFGELFNFPLWGKLTFNTMTNGHKMSYQAGNALAVRWNWISNRTLTNTIDRSFRGWGQGSPVYAFAHDLGSISGTESVTYTVGSVQDPAIRYLDNSGVQGLHPYWQHCYGNDLFNLISTHFNDLSQSAALAAEFESKLKADVNSYYAAEGAMVYSKGGESRGPMFDQFNGTDQTYINNQQVQEYFTFNPFNGYGFLNSNNFSNIPIPDVTESQAYYSIVALSARQVMGAYALTTGATDACTGQNSSGPLMFQREISSGANVNTVDVLYPAMPFFLYANPDMIKYQLDPLFQNQENNFYPNMYSMHDLGTHYPNATGHVEGNDEYMPVEESGNMILLSQAYTLFKGDSSYISMHYAKLKQLSEYLINFSLLPGVQLSTDDFAGSLANQTNLAIKGIVGLAAMSKIASATGHNSDAQNFTEIANSYFTRWEGFGIDPSGKHSILGYEWRSSWSLLYNIMPAKLLGLSIIPQRIYDMQSEWYPQVAQLFGVPLDNRHDYTKSDWEMWCASIASPSTRMMFVNALGYWLNNTNTNTPFSDLYQTTEMGGYPEDPLVKFIARPVVGGHYALLAMDMSAKLNQS",
      "product": "hypothetical protein"
     },
     {
      "start": 9508,
      "end": 10959,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004296",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004296</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004296</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004296-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,508 - 10,959,\n (total: 1452 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004296 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01263.23 (Aldose 1-epimerase): [128:424](score: 180.9, e-value: 3.7e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004296 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01263.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016853' target='_blank'>GO:0016853</a>: isomerase activity<br>\n  \n   PF01263.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005975' target='_blank'>GO:0005975</a>: carbohydrate metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004296\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004296-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTCGCCCTCCTGGCCCCTGTTCTAGCCTACCTCAGCAGTGCAAATGCACAAGCCACCACCGGTACCTCAGCCTCCGGCTCACTTTTGGCGGGCATTACTGGTGCTCCCGGCAGCGCAGCTACTGCCATGACCACCATGGCTACCATGCCCTCTGGGATGTCCGCCATGTCCTCTGGGATGTCTTCTGCAATGGCCGCGGCTGGCATGTCTTCCATGACCAGCATGTCAGCCAGCATGGCTAGCGGCATGGCTGCTAACATGTCCTCTTCCATGCCAAAAGTACAGGCGCAGAGCATGGTCTCCATGCCCCTGGTTGCCAACATGACTATTAACTCCTCCGACTCCACCGTGGGGTCAGCCAACCCTTTCACCATCTACAATATCTCGGCCACCAACATCTCCGCTTCTTTCATTCCCTACGGTGCCCGTCTCACTGCTCTCAAGGTCCCGGACCGCAATGGCGTCATGCAAGACGTTGTATGTGGTTACGACACCGGCGAGCAGTACCTCAATGACACCGAACACAATCACTCCTACTTTGGTGCTGTAGTTGGACGGTATGCGAATCGCATTAAAAATGGAACATTTATGCTCAACAACCAAACTTACCACATCCCCGCAAATGAGCATCACGGTCAAGATACACTCCACGGTGGTACTGTGGGCTATGATCAGCGGAATTGGACTGTCGCCGCTCAGACGCCAAACTCCATCACCTTCAGTCTCTTGGATGAGGGCTTCGAAGGATTCCCGGGTAGTCTGATGAACTATGTGACCTACACCGTCGGCAATGACTCCACCTGGACCATCCGCATGGTCTCCATTCCATTGACCGAAGCCACCCCAGTCTTGATGTCGAGCCACGTCTACTGGAACCTGGACGCCTTCACCAACCCATCCAACGCAACCGTGCTGAACGAGACTCTGTGGATGCCATATAGCAGCCGGATTACTGGAATCAACGGCATTGAGGTTCCTAATGGAACACTTGAGAGTGTGTTGAACGGTCCTTATGACTTTACCCTACCCAAACCAATTGGACGCGATATCCTCCAAGCAGTTGGCGGTTGCGGAACCAACTGCACCGGATACGACCAGTGCTTCCTCATCGACAGACCTCGATACGCTGCTCCGGAAGCCACTGATCTGACAGTCCTCACGTACTCCTCTGACGTTACTGGAATCAAACTCGAAATCGAGACCAACCAGCAGGCTCTACAGATCTACACGTGTGACAACCTGGACGGGACAATCCCAGTCAAACAGTCGCAGCAACATGGAAATGGAACCACAACAATCCCGCAATACGGTTGCATGGTTATTGAGGTCGAGGGTATCATCGATAATATAAATTTCCCAGCACTCGGGAATGAACAATACCAAATCTACTCCACGGACACCGAGCCCTCTGTTGTCTTTGCACAGTATCATTTCAGCGTGATGGACTAA",
      "translation": "MLALLAPVLAYLSSANAQATTGTSASGSLLAGITGAPGSAATAMTTMATMPSGMSAMSSGMSSAMAAAGMSSMTSMSASMASGMAANMSSSMPKVQAQSMVSMPLVANMTINSSDSTVGSANPFTIYNISATNISASFIPYGARLTALKVPDRNGVMQDVVCGYDTGEQYLNDTEHNHSYFGAVVGRYANRIKNGTFMLNNQTYHIPANEHHGQDTLHGGTVGYDQRNWTVAAQTPNSITFSLLDEGFEGFPGSLMNYVTYTVGNDSTWTIRMVSIPLTEATPVLMSSHVYWNLDAFTNPSNATVLNETLWMPYSSRITGINGIEVPNGTLESVLNGPYDFTLPKPIGRDILQAVGGCGTNCTGYDQCFLIDRPRYAAPEATDLTVLTYSSDVTGIKLEIETNQQALQIYTCDNLDGTIPVKQSQQHGNGTTTIPQYGCMVIEVEGIIDNINFPALGNEQYQIYSTDTEPSVVFAQYHFSVMD",
      "product": "hypothetical protein"
     },
     {
      "start": 11046,
      "end": 12263,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004297",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004297</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004297</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004297-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,046 - 12,263,\n (total: 1218 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 131.4; E-value: 8.1e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004297 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01408.25 (Oxidoreductase family, NAD-binding Rossmann fold): [1:119](score: 66.5, e-value: 3.6e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004297 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01408.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004297\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004297-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAATTGGGCATCATTGGTCTCGGACAATTCGGTCCAGAGCTTGCACAGCTCTTCTACGCCCATCCCGGCGTCGACCACCTCGCTCTCTGTGATGTGGTCAAAGACCGCGCAAAAGCCGTGCAGTCGTCTCTTGGCCCCGACACACGGGTCGTTGATAACTTTGATGACATGTGCGCTTCTGACGTGGATGCTGTCGCCATCTTCACACAGCGCTGGCTCCATGCCGAGATGACAATCAAGGCGCTCAAAGCTGGCAAGCATGTATACTGCGCCGTGCCCATGGCCAACACGGTCGCGGAGGTGAAGCAGATCTTGGATACTGTCCAGCGCACAGGTCTCGTGTACATGTCGGGCGAAACATGTTACTACTACCCCGCCGTCATCTACTGCCGCGAAAAGTGGCAAAAAGGGGATTTTGGGCACTTTGTGTATGCAGAGGGTGAGTACAGGCATGACATGTCTCATGGCTTCTACGACGCCTACAAGTTCAGCGGCGGCGCCACATGGAAGGAGACTGCCAGTTTCCCTCCCATGATGTACCCAACGCACTCTGTCAGTGCCGTGCTGGCCTCCGTTGGGTCCTACTTCACCAAAGTCTCCTGCATCGGCTACCGCGACCAGGAGAACGACGGTGTCTTTGACCGCAAGGTGAGCAAATGGAACAATGACTTTAGCAACGAATCCGCATTCTTCACTCGTGCCGACGGCGGCGCAGTTCGAATCAATGAGTTTCGACGTATTGGAAGCCACCAAGAGCACGCCTACCCTATGAGTATAATCGGCACTCAAGGGAGCTTTGAACTGAATACGCGTAGTGCAACCTTCCAGACACTCAACAATTTAGAGGACGTGTCCGAGCTACTGGCCTGCGACGAAGGCAAGAGCGAGAAGAACATTGAGGCGTCGGATGTCAATGCGGAAATTCTCGAAGGATTCCGATCCGGCATGTCGAAGTTGCATGATGTCAAACGACTCCCGTCTGAATTCAAGGGCCTTCCGAATGGTCATGAAGGGTCCCATCAGTTTCTTGTGGATGACTTTGTCAAGGCATGCGTCTCGCAGACCGTTCCGCCAATCAGTGCGTGGCGCGCGGCACGATATGTGGTCCCCGGCCTGGTTGCACACCAATCTGCCCTGCGTGACGGCGAGCGAATGAATGTCCCTGATTTTGGGCCCGGACCTGAAGTAGGTACTGCTGTGGCAAGCAAAAAGTAA",
      "translation": "MKLGIIGLGQFGPELAQLFYAHPGVDHLALCDVVKDRAKAVQSSLGPDTRVVDNFDDMCASDVDAVAIFTQRWLHAEMTIKALKAGKHVYCAVPMANTVAEVKQILDTVQRTGLVYMSGETCYYYPAVIYCREKWQKGDFGHFVYAEGEYRHDMSHGFYDAYKFSGGATWKETASFPPMMYPTHSVSAVLASVGSYFTKVSCIGYRDQENDGVFDRKVSKWNNDFSNESAFFTRADGGAVRINEFRRIGSHQEHAYPMSIIGTQGSFELNTRSATFQTLNNLEDVSELLACDEGKSEKNIEASDVNAEILEGFRSGMSKLHDVKRLPSEFKGLPNGHEGSHQFLVDDFVKACVSQTVPPISAWRAARYVVPGLVAHQSALRDGERMNVPDFGPGPEVGTAVASKK",
      "product": "hypothetical protein"
     },
     {
      "start": 15493,
      "end": 16782,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004298",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004298</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004298</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004298-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,493 - 16,782,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1100:3-hydroxyisobutyrate dehydrogenase (Score: 206.6; E-value: 9.1e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004298 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [7:104](score: 44.1, e-value: 2.2e-11)<br>\n \n  PF03446.18 (NAD binding domain of 6-phosphogluconate dehydrogenase): [133:287](score: 117.6, e-value: 6.2e-34)<br>\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [299:420](score: 92.5, e-value: 2.3e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004298 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03446.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding<br>\n  \n   PF14833.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004298\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004298-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAACAGACTGAGAAACATCTCAGGGCCCTCCACTTGGCAACAGCGTTTGAAGCCATTGCACTTGGAACTGCTTCAGGGCTGAATGGCTCCCAACTGTACGCTATCTTTTCCACATCCGCTGCGCAGTCATGGACGTTCAACTACGTCATTCCGAATCTATTAAGTGGGAAAGCTTTACCCTTTGATGTAGATGAAGCTCTAGACGATATTCAGGAAATACTAAAGCAAGCGAATGAATGTAGATTCTTCAGTCCAATGACTAGCGTAGTTGAACAATATCTTTTATCGGTCAAAGCATCTGGGGGCGTTCACAAGTACTATGAGACACTTGGCGTCTCTTCTTTGAAACAGAAGAATTTTACTCCCTCTCGACTCCCTTCATCTTCCAGAAAACCGACCGTCGGATTTGTTGGCCTTGGAGCTATGGGTCTGGGTATGGCTAGTATTCTATATAAAGCAGGGTTTGCTGTCAAAGGATTCGATGTGTTTCCGCAAAGTGTTGAAAAGTTCGTGACTGTGGGAGGACAAAGGGCTGCTTCTGCTGCTGAAGCGGCCATTGGAGTTGAAGTACTGTTGATCATGTGCGCTACTTCTGCACAAGCTGACACTATTCTTTTCGGGGAAGATGGAGCTGCCTCCAAAATGAGTAAAGGAGCGGTTGTTCTCCTCTGTGCAACAGTCGCACCATCATATATAACAGAATTAAATCAGAAGCTCGCCCGCAGTGCCATTAAGCTAGTGGACGCGCCTGTCTCGGGCGGTACTTATCGCGCCGCCAGTGGCGAGCTTTCCATTATGTGCTCCGGCGATACGGAAACGCTACAAATTGTTTCCCCCGTACTAAATGCATTAGCCGGCAAAGAAGAGAATGTCTACGTTATTGAAGGCAAAGTAGGGTCTGGTTGCAAAGTCAAAATGGTGAATCAAGTTCTTGCTGGTACACAATGTGTCTGCACCGCGGAAGCACTTGCCTTTTCAGTGGCTAGGGGACTGGTTGCAATGGACGTATATGAATGGATTTCATCGTCTCGTGGAGCTTCATGGATGTGGTCAAATCGAGGTCATCATATGGTAACTGGAGACTTTTCCCCATTATCGGCTACAACTATCTTCATCAAAGACATGAACATTGTTGTCTCAGAAGCAAGAAGGCTTGGGCTGCCATCGGTTTGCTCTTCCATGGCACAGCAGTTATTTATTCTGTCCGCCGCAGCTGGACATTCAAAAGATGACGATTCTAGTGTTGTAAAAGTATGGGAAAAAGCATGTGGAATTAAGACCTACTAA",
      "translation": "MEQTEKHLRALHLATAFEAIALGTASGLNGSQLYAIFSTSAAQSWTFNYVIPNLLSGKALPFDVDEALDDIQEILKQANECRFFSPMTSVVEQYLLSVKASGGVHKYYETLGVSSLKQKNFTPSRLPSSSRKPTVGFVGLGAMGLGMASILYKAGFAVKGFDVFPQSVEKFVTVGGQRAASAAEAAIGVEVLLIMCATSAQADTILFGEDGAASKMSKGAVVLLCATVAPSYITELNQKLARSAIKLVDAPVSGGTYRAASGELSIMCSGDTETLQIVSPVLNALAGKEENVYVIEGKVGSGCKVKMVNQVLAGTQCVCTAEALAFSVARGLVAMDVYEWISSSRGASWMWSNRGHHMVTGDFSPLSATTIFIKDMNIVVSEARRLGLPSVCSSMAQQLFILSAAAGHSKDDDSSVVKVWEKACGIKTY",
      "product": "hypothetical protein"
     },
     {
      "start": 17046,
      "end": 18044,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004299",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004299</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004299</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004299-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,046 - 18,044,\n (total: 999 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 58.8; E-value: 8.1e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004299 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:331](score: 55.9, e-value: 3.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004299 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004299\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGTCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAGAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACTATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGTATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCGTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACTGA",
      "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLREQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDYIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMVLAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETN",
      "product": "hypothetical protein"
     },
     {
      "start": 18141,
      "end": 18509,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004300",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004300</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004300</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004300-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,141 - 18,509,\n (total: 369 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004300 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [3:62](score: 51.4, e-value: 7.9e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004300 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004300\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004300-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCGCTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACGATGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
      "translation": "MTIASPLVTSRDEEIFPDPHRYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYDVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
      "product": "hypothetical protein"
     },
     {
      "start": 18687,
      "end": 21690,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004301",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004301</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004301</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004301-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,687 - 21,690,\n (total: 2967 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 123.1; E-value: 1.8e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004301 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [20:320](score: 124.3, e-value: 5.2e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 32.0, e-value: 1.3e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.9, e-value: 5.2e-42)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004301\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004301-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGAAATCATCAACGATCCGGACTCGAATTTCAACTATAAAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGGGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACGGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCAAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGCGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTTGGGCAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGGAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCTTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGCGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGCAAATTGCTGCTATTGATGGATCATTAG",
      "translation": "MSFLSVNELLDARARDDGDVEIINDPDSNFNYKRYTYNSLLGIASGLAADYGQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENGEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVKPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAACRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLFGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGKLLLLMDH",
      "product": "hypothetical protein"
     },
     {
      "start": 21742,
      "end": 23625,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004302",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004302</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004302</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004302-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,742 - 23,625,\n (total: 1884 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004302 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00172.21 (Fungal Zn(2)-Cys(6) binuclear cluster domain): [20:52](score: 37.8, e-value: 1.6e-09)<br>\n \n  PF04082.21 (Fungal specific transcription factor domain): [166:392](score: 91.6, e-value: 4.5e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004302 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004302\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004302-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCTCTCCACAATCGAAGAAGCCTCGCTTATGCGAAGATGCGAGGGTGCGGGTAACCCGTGCGTGTGATGCGTGCAAGAGGAAGAAAGTGCGCTGTGACGGGACAGCACCGTGCGGCAGGTGCATCAGCCATAATGTCGTTTGCCGGTACGAAGCACCATACCTGCGTCGGAAGCAGTCTCACATCAGCACGGAGGTGGAGAAGCGCGAAGATGATGAGTCTATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGACACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTGATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
      "translation": "MGSPQSKKPRLCEDARVRVTRACDACKRKKVRCDGTAPCGRCISHNVVCRYEAPYLRRKQSHISTEVEKREDDESMQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
      "product": "hypothetical protein"
     },
     {
      "start": 25280,
      "end": 26713,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004303",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004303</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004303</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004303-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,280 - 26,713,\n (total: 1398 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1137:Major facilitator superfamily MFS 1 (Score: 376.1; E-value: 2.7e-114)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004303 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [80:327](score: 68.3, e-value: 5.8e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004303 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004303\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004303-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKPAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLVVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFMFLGLLVIANLGVKSRLPRRGGSVPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAACATGAACTCTAACGAAGCAGCAATCGCTAAGCCCCGTGATGTTGAAGCAGGCACACTATCTACACGTACCAGCTTTTCCAGTGCTCATGAGCAATTATCAGACCATACCACTGTTGCCAATGAGTCACCCGTGAATGAAAAGGTCGAAGAGGAGAAAGTCAAGCCTGCGATGCCCCCCCCTTCGGATTTCCCAGATGGAGGCCTTCGAGCTTGGATGTGCGTTGTGGGTGGATGGTGTGCAATGTTTTGCACTTTTGGCTTTGTGAACAATGTTGGTGTATTCCAAAACTACTACCAAACGACTTTCCTCAGACAGTATACACCCTCTACGGTAGGATGGATCGCTTCGCTTCAACTCTTTCTGCAGTTTTTCATGGGCTTTCCAGTGGGTCGCGTATACGACGCCTACGGTCCTGCTTGGTTGTTGCGCATCGGAAGTTTCCTTGTTGTATTTGGACTCATGATGGCTTCCTTGAGTACGAAATACTACCAGCTGCTTCTTTCACAGGCCGTAGTCTTCGGAATAGGTGCATCTATGGTCTTCTTTCCGGTCATAACTGCGACGTCTACATGGTTTTTCAAGAAGCGAGCTCTGGCGATCGGTTTGGCGAGTGTGGGCAGCTCTATGGGGGGTATTATACAGCCAATCATGATTACCAATCTCATACCGCAGATAGGCTTCGGATGGACCATGCGAACTATAGCCTTCATGTTCCTCGGCTTATTAGTGATTGCAAATCTTGGAGTGAAGTCACGTTTGCCGCGGAGGGGTGGCAGCGTGCCAAAAATATCTGAAATTACAGCTGTACTTACAGACAAGGACTGGGCCCTACTGACGGCTGGCTACTTCATCTTTGTTTGGGGCATGTTCACGCCATTCACTTATATTCCGGATTATGGATTGTACTATGGGATGTCTCAACATTTGAGCATCTACCTTGTGTCCATTCTCAATGCTGGTTCGGTCTTTGGTCGGACTATTCCAGCTGGGCTTGGTGACCGATTTGGACGGTTCAATGTGTTCACATTGATGAGCTTCTTCAGTGGTATCATCACGTTGGCAATGTGGATTCCGTCAAGGAGCCATGCTGTTATCATTGCGTACTCGGCACTATTTGGATTCAGTAGTGGTGCGTTTGTAAGCTTAGGACCGGCTTGCATTGCACAAATATCTGATATTCGCCAGCTCGGACTGCGTGTTGGGGTTTGTTTTGCAATATTTGCAATTGCGGCACTGACCGGCGTGCCCATTGCCGGAGCGCTCTTAGGACACAACAATAATTGGGTGCATGTTCAAATCTGGGCAGGCGTGACAATGATCGCTGGGAGCTCTATTATGTTATTCTTACGCTTCAAATTGGCCGGGTACAAGTTAATGGTGAAGGTCTAA",
      "translation": "MSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKPAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLVVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFMFLGLLVIANLGVKSRLPRRGGSVPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV",
      "product": "hypothetical protein"
     },
     {
      "start": 26976,
      "end": 30335,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004304",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004304</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004304</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004304-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,976 - 30,335,\n (total: 3360 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004304 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00176.26 (SNF2-related domain): [448:755](score: 213.5, e-value: 3.7e-63)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [933:1048](score: 50.8, e-value: 2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004304 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004304\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004304-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATAGATGTATTAGAACAGGTAGCGATTTACAGATCGCTCTTAGATACCATCTCGCCGGGGCCGAGTGAACACCGTACTGCGATAGAGCGTAAGCTACGAGATGTTGAGGCCAAGGTGGATCAAAATGAGCTACAAAGTAGCGAACGGAACAAGCGTCGGAAATTAGAACAAGAGCAGGAGGATGAGATATTTGCATGGACCTTGGAGATGCAAGAGAAGGGCAGCAACACGAGCGAAAATTTCGATTATGAAACGATTGATCTGACTGAGCAAATTGAGAACGACGCAGCTCTAGCACGAGAGCTAGCGGATGAGGAAGGCGCAAGGCCTGCACAGTCTGCTCCTCCTGCTCCCTATTTAGGAGCAACTCCCAAGCTCGAACATGATTCGAACGCGGTTCAGCCGGATGGCTCGGTAAATGTTATTGCGGGCACTATACCAGCATTCACAATTGTTGGAACCGATACCGTGGGGCCTAATAATGCAACGGCGAACACCGAAGCTCCCAATACATTATCAATGACCGATCAGGATCTAGCTAATTTTTTCATGACAATTGAGGATCGTGTTTCCAAAGTATATGGAAAAAAAGAGGTCCGACCGCTACACTTTGTTCGAGGTCCCTTCAATTTGTTCAAGAGATCAGCACTTGAAAATCTGAAGAAGCGCGGTCTAGACTATTTGGTTCAAGATACAGATAACGAAATAGCACAAACGTATGAAGACTCCATATCCCTTACCATGCAGAGACTAGAGGCAGCTGAGTGGCAGCAAGTACTTTACCGGAATCTTCGTCGCAAAACGCAGCCAACTCCTGCCCTACCAATGGACGAACCAAAAACGGCAAACGCCGAGCCTGTTCAACCACAAGCGCCTGCACCTACACCTGCAGGGATTTCTGAACAGCGACTCATGGAGCTACGAATTGCAGCAGATGCTAAACTTCTACGAATCCATGGACCTCCACAGCTTTTCACCGGGAGCATGCTCACGTCCTACGAGAAACTGCGAAAGGCATATCGTGACGAAGCTATTATGAATGAGAAAGTCAACGCTCTCAAAAATATAAAGCCCGCACAGAATACACTCTGGCCAGATTCGATGGCAGCGGGCCCGTCTACAACAGCAAGTATTGGCCTCCCTTCGAGCTATTATGACTACAGCCACAGCTACTCGATGCGATTCGATGCTGAAAAGAACCGTGAAGATCTTAAGAAACTTATCGAGAGTATTCAGCCGGACGCTGATATTGAACCACACGCACGAAGAGGGACTCCAAGTGCCATGACTTTCGTGTTGATGGAACATCAAAAAGTTGGACTTACCTGGATGCGACGTATGGAAGAAGGTAACAATAAAGGAGGTTTATTGGCCGATGACATGGGGCTTGGAAAGACAATCCAAGCACTTGCTCTAATATTGTCTCATCAGCCCGAAGACCCATCTATCAAGACTACACTTATAGTTGCGCCACTCGCGTTGCTTAAACAATGGCATCGAGAAATTGAGTCAAAAATCAAGCCAATGTATGCACAGAAGGTGTGTATTTACCACAGTATTGGAAGACGCAACATGACGTGGGTCGATCTTCGAAAGTATGACATTGTCTTGACCACGTATGGTATGATTGCATCCGACTATAAAGCACAAGTTAAATGGGAGGCCGACGTGAAGGTTGATGCGAGAAATGAAGTTTACAAGCCAGAGTCACCTCTCCTTGACAAAGATAGCCAATTTCATCGAATAATCCTAGATGAGGCTCAAATGATTAAAAATAGAAATGCACTGGCATCGAGGGGTGTCGCAATTCTCCATGCAAAGTATCGCTGGGGCCTCAGTGGTACACCTGCACAAAACAACATTGACGAGTTTTATGCAATCATTCGCTTCTTACGTGTACGCCCTTTCTGCGACTGGGATGAATTTCGAACTCAGCTGTCTAATGCAGCGAGATCAAGGGATCTCAAAAGAGTTGACAAAAGTACGCGATTGCTGCAGGGTGTGTTGCGGGCAATCATGTTACGAAGAACGAAAGATTCAAAGATCGATGGCGAAAGTATACTTGACCTCCCACCCAAGACCATCGAAGAGACTCATGTTGTTTTTAACGTAGACCAGCAAGCATTCTACAACAATTTGGAACACAAATCTCAGATGTTAATGAATCGCTACGAGCAAAACAACACCATTGGGAAAAACTATGCAAACATATTGGTCCTTTTGCTTAGACTCCGTCAGGCATGTTGCCACCCACATCTCATTCCTGACACCGGTACATCTACTGGAATTTCTTATGAAGCTGGAGTTGTCCCCAAATCGGCCGAGGAAATGGAGGCGATGGCCCGGCAGATGCCTAGTGATGTAGTCAATCGTCTCAAGAATGACAAAGACATGCTTTGCCCTGTCTGCTGGGACACACCAACCGACATGAAAATTATCCTCTTTTGTGGTCATTATGGATGTGGCGAATGCGTCAACAAGCTATTCACGCTGCAGACTCAAGTGAATCAGTCTCATGATGAGCTTGAGCCAGCACTGTGTCCGACGTGCCGCAGCGCAATGAGTAGCGACAAATTGCTGGGCTTTAATCTGTTCAAAAAGGTCCACATGCCAGAAGCGCTTACTCCGGAACCGCAACCGGAAGCTGTCAAGGATGAAAGCTCGGCTGTCGGAGGGAGTGGGACGAAAGGCAAAGAGAAAGCGGTGATTCCCGAAAGAGAGGAGACTCCGCTCGAGGACTTGGCGCCCCGCCAAAGGATTTTGCGAAGACTAAAGAAAGACTGGATCTCCTCTGCAAAGATTGACAAATGCTTGGAAATCCTGGAGACCGTCAAAGCGCGGGACCCGACGGAGAAGACCGTCGTGTTTTCCCAATTCATTCTGCTGCTTGACTTTTTGGAGATTCCGTTGGCGGACATGGGATTTAAGTGGAAGCGGTATGAAGGTTCCATGTCTGCCGTTGCTCGGGACGATGCCGTGCTTGACTTTATGAAGAGCCCAGATATCAACATCATGCTTGTTTCCTTGAAGGCCGGCAATGTTGGCCTCAACCTGACCTGTGCATCTCAGTGCATTGTGATGGATCCCTTTTGGAATCCGTTTGTGGAATTACAAGCCATTGATCGTACGCATCGAATTGGACAGTCACGGCCAGTCTGCGTGCACCGCATCTGCGTTGCGGGGACAGTCGAAGACAGGATTCTGGAGCTGCAAAATCAAAAGCAGGAGCTCATTGAGACGGCCCTGGATGATCAGGCGGCAAAGTCAATCCAACGGCTGAGTCCTCGTGAATTGATGTATCTTTTCGGGATCAACGACCCCAACAGTCAGAACAGCCAGAACAACCAGCATATTTAA",
      "translation": "MIDVLEQVAIYRSLLDTISPGPSEHRTAIERKLRDVEAKVDQNELQSSERNKRRKLEQEQEDEIFAWTLEMQEKGSNTSENFDYETIDLTEQIENDAALARELADEEGARPAQSAPPAPYLGATPKLEHDSNAVQPDGSVNVIAGTIPAFTIVGTDTVGPNNATANTEAPNTLSMTDQDLANFFMTIEDRVSKVYGKKEVRPLHFVRGPFNLFKRSALENLKKRGLDYLVQDTDNEIAQTYEDSISLTMQRLEAAEWQQVLYRNLRRKTQPTPALPMDEPKTANAEPVQPQAPAPTPAGISEQRLMELRIAADAKLLRIHGPPQLFTGSMLTSYEKLRKAYRDEAIMNEKVNALKNIKPAQNTLWPDSMAAGPSTTASIGLPSSYYDYSHSYSMRFDAEKNREDLKKLIESIQPDADIEPHARRGTPSAMTFVLMEHQKVGLTWMRRMEEGNNKGGLLADDMGLGKTIQALALILSHQPEDPSIKTTLIVAPLALLKQWHREIESKIKPMYAQKVCIYHSIGRRNMTWVDLRKYDIVLTTYGMIASDYKAQVKWEADVKVDARNEVYKPESPLLDKDSQFHRIILDEAQMIKNRNALASRGVAILHAKYRWGLSGTPAQNNIDEFYAIIRFLRVRPFCDWDEFRTQLSNAARSRDLKRVDKSTRLLQGVLRAIMLRRTKDSKIDGESILDLPPKTIEETHVVFNVDQQAFYNNLEHKSQMLMNRYEQNNTIGKNYANILVLLLRLRQACCHPHLIPDTGTSTGISYEAGVVPKSAEEMEAMARQMPSDVVNRLKNDKDMLCPVCWDTPTDMKIILFCGHYGCGECVNKLFTLQTQVNQSHDELEPALCPTCRSAMSSDKLLGFNLFKKVHMPEALTPEPQPEAVKDESSAVGGSGTKGKEKAVIPEREETPLEDLAPRQRILRRLKKDWISSAKIDKCLEILETVKARDPTEKTVVFSQFILLLDFLEIPLADMGFKWKRYEGSMSAVARDDAVLDFMKSPDINIMLVSLKAGNVGLNLTCASQCIVMDPFWNPFVELQAIDRTHRIGQSRPVCVHRICVAGTVEDRILELQNQKQELIETALDDQAAKSIQRLSPRELMYLFGINDPNSQNSQNNQHI",
      "product": "hypothetical protein"
     },
     {
      "start": 30531,
      "end": 33344,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004305",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004305</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004305</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004305-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,531 - 33,344,\n (total: 2775 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 272.3; E-value: 8.9e-83)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004305 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [288:593](score: 159.5, e-value: 1.3e-46)<br>\n \n  PF08240.15 (Alcohol dehydrogenase GroES-like domain): [625:689](score: 38.1, e-value: 1.2e-09)<br>\n \n  PF00107.29 (Zinc-binding dehydrogenase): [747:870](score: 91.5, e-value: 4.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004305 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004305\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004305-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCGAGAGCAGCAGAGAGGCGATCCCAGCGCGCCGGCGACGGTCCAGCGCCAGCAAGGGTTTTGCCCCGCCCTTCCAGCAGCGACGCGCGCAGTTCGTGCAGCAGGAGCAGCAGCAGCAGCGCAGTCTCAGCCCCAGCTCCCTCGACTCGAACGCCCTCTTGGACCACCGCTCCCAGCCAGAGAGCATCCCCCGGCCCTCCTTCCTGCGCAACCGCAGCGACAGGACCGGCGGCGAGCGGGAGGAGCGACGGGGCAAGGGCAGAAGGGAGAGCCGCGACCGCCACCATGAGCAGACACCTCTGTTGGAGGGCGAGGGAGAAGGGGGGGCGGGGCCCAGCTCGGGGGAGCAGGCGGACCAGCACCCCTTTGTGCACTACCAGCCAAACTACGGGTCCGGGGCCCATGGAGACGCAGTCATCACTATCGAGGGCGCCGGCGATGGGAGCTCCACGGACGACTTCACCAACGACCCCACCAGCGATGAGGCCTCCAACAACTCCGAGGCCCTGGACGACGTCTGCTTCCCACAGGACGTGGGCGACGACGGCGAGCGCAAGTGGCCGGATGTCGCCGTGCTCGAGGAGTGGGCCGAGGAGGAGAAGAAGGAGAGCGGAGACGGAGGGGGCGTGGGAAATGCAGAGTGGCTGAGATCGCGCCAGACCAGCGAGCCAGAGCGCATTAATGGGCGGCTGCGTGGCGTGCACCAAACCAAGGAGGAGAGCGACCGGCCCTACCGTTTCACCTACTTCTCCGACTCCCTCCCCGCTACCATCCATTCCCAAAACATCTCCGGGCTCGTGCAGTCCGATCTCTCCTTTACAGACCTCTTCTCCCCCAAGGCGGACTTGGCGCCCACCTTCTGGCTGGACTGCCTAACCCCCACAGACTCCGAAATGAAAGTCCTGGCGCGTGCATTCGGCATCCACCCGCTGACGGCCGAGGATATCACCATGGGAGAGACGCGCGAAAAGGTGGAACTCTTTCGAAACTACTATCTCGTCTCCTTCCGATCCTTTGAACAGGATCCCAAGGCGGAGGAGTATCTTGAAGGCCTGGACTTCTACATCATTGTCTTCCGCCAAGGTGTCATTTCCTTCCATCACTCCCTCACCCCTCATCCGGCAAATGTCCGCAGGCGCATACGCCAGCTAAAGGATTACATCACCGTGACATCCGACTGGATCTCATACGCATTGATTGATGACATTACAGACGCCTTCCAGCCCCTCATCTACTCCATCGAGACAGAGGTGGACGATATCGACGACTCCATCCTATCTTTTCATTCCGACAACTCTGTGGCGGACGACAGCGAGATGCTTCGGCGCATTGGCGAGTGCCGAAAGAAAGTGATGGGTCTGCTTCGTCTGCTCGGATCCAAAGCGGATGTCATCAAAGGCTTCTCCAAGCGCTGCAACGAGCATTGGGACATTGCCCCACGTTCGGAGATTGGGCTATATCTCGGAGACATCCAAGACCACATCGTCACGATGGTCCAGAATCTGGGCCACTATGAAAAGATGATGTCGCGGTCCCACTCCAACTACCTTGCCCAGATAAATATCCAGATGACGCGAGTCAACAACAACATGAACGACGTGCTCTCTCGCCTGACGGTGCTGGGGACAATCGTGCTCCCAATGAACATCATCACTGGCCTGTGGGGCATGAACGTCAAGGTCCCCGGGCAGGAAATCGACAACCTCAACTGGTACTTTGGCATCACGGTGGGGCTGGTCATGTTTGGCGTGATGAGTTATTTGTTCTTCATGAGGACCTCGGTACATATGCGAGCAATTCAAATCACAGAACGCGTAGATTCGCCGTCCAAGCTGTGGCCCTCTGACATCGCACAGCCCCGGCCGAGTTCAGAGCAAGTGCGGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCATCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATTAAAATCGACCATCCTTCTCCCAAACTTTAG",
      "translation": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASNNSEALDDVCFPQDVGDDGERKWPDVAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMRTSVHMRAIQITERVDSPSKLWPSDIAQPRPSSEQVRVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARIIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
      "product": "hypothetical protein"
     },
     {
      "start": 33403,
      "end": 35298,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004306",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004306</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004306</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004306-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,403 - 35,298,\n (total: 1896 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004306 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02990.19 (Endomembrane protein 70): [51:587](score: 651.0, e-value: 1.5e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004306 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02990.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004306\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCATCGGATCCAACGGAGGCTGCTGCTGCTGCTGCTCCTCCTCCGCCAGGCAAGCGGCTTCTACATCCCCGGCTGGAGCATCCGCTCGTACGCCGACGGGGACGCAATCCCCCTGCAGACCAACAAGGTCTTCTCTGACGCCACCTCCCTGCCCTACGCCTACTCCGAGCTGCCCTTTGTCTGCGATGCCCCGGGGCGCAGCAGCAGGCGGGTCGCCCTCAACCTGGGCGAGGTTCTGCGCGGCGACCGCATCGCGACGTCCGGCTACGAGATCGAGATGGGCAAGGACGTGGCCTGTGCGCACCTGTGCGACGCGGCCGTCGATGCTGCCGGAATCGCGCGCGCCACCCAGCTCATCCGCAACGGCTACTCGGCCGAATGGATCGTGGACAACCTGCCCGGCGCCACCTCCTTCGTCACCGTCGACCGCACCAAAAAGTACTACGCGGCCGGCTTCAAGCTGGGCGGGTTTGAGAATGACGTGGCAAAGTTTCATAATCACGTCAGCCTGGTCTTCCGGTGGCGCCGGCTGGAGGCAGACAGCGACCGCAAGGTCATTGTGGCCTTTGAAGTCTACCCAAAGTCTATCAAAACAAAGGATGGCGCATGCCCCACCTCGCTCGACAATCAGCCCCCGCTGGAGCTCCCGGAGACGAGCACAGTAGGGGTGGACGGCTTCACAATTCCCTACACCTACAGCATATTTTGGAAGGAAGACGACACCATCGAATGGTCGTCGAGATGGGACCTCTACTTTGTCAACAACGAAGATGCGCACCAGATCCATTGGCTGGCCATTGTAAACTCTACCGTCATTGTCATGGTGCTCAGTGGCGTGGTCTTCCTCATCCTGGTGCGAACCCTCTCGCGCGACATTCAATCCTACAACACGCCCGACGGCGACGACGACAAGGATACAGATGCCGACATAACTGGCTGGAAACTTGTGCATGGGGACGTCTTCCGACCGCCGCCGGCTGGCGGTCTGTTCTCCCCCCTTATCGGAGCGGGTGTGCAATTGCTCGTCATGATGTTGGCCCTCCTCATTTTGTCCGCGGCCGGGATCCTCAATCCCTCCTACCGGGGCGGCTTTCTCTCTTTTGCCCTCTTCCTCTTCGTCTTTGCGGGTGTCTTTTCCGGATTGCATTCCACAAAGATCTACAAAACGTTTGGAGGGTCCCAGTGGGTCAAGAATGGGTTGATGACTGCGCTCTTAGTGCCGGGAAGTGTCTTCCTGACCGTTTTTATCCTCAATTTGTTCGTCTGGGCGGAAGCGTCGTCTTCGGCCCTTCCATTTGGAACGTTGGTTGCGCTGTTGGCCATGTGGCTGCTTATCTCTCTTCCCCTAGTCTTGCTGGGAAGTTTTATTGGCTTCCGACGTCCGGCCGTGGAGCATCCTACGAAAGCCAACCAGATACCACGCCAGATCCCCGAACAGCCTCGCCACCTCCGATTCTTTCCCTCGCTGCTCATCACTGGCGTCGTTCCCTTTGCAGTCATCTTTATTGAACTTTTGTTTGTCTTCCGATCCGTGTGGGCGGAAAAGTCGGGCTACTACTACGTCTATGGATTCCTTGGGCTCATCACGCTCATCCTCCTGATTACGACGGTCGAAATAACACTCATTCATGTCTACTTTATGCTCTGTGCCGAGAACTACCATTGGTGGTGGCGATCGTTCTTTGTGGGTGGTGCGAGCGCCATCTACGTCTTTGGCTACTGCGTTTGGTACTACCTTTTCAAGCTCCAGCTGCACGGGTGGGTGAGCGGCCTGCTCTTCTTAGGCTACTCCCTGCTCGGCTGTGCCTTGTATGGGGTCTTTCTCGGGACGGTAGGGTCTCTGTCGGCATATGTCTTTGTGAGGAAGATATATGCCGCAGTCAAGGTGGATTAG",
      "translation": "MHRIQRRLLLLLLLLRQASGFYIPGWSIRSYADGDAIPLQTNKVFSDATSLPYAYSELPFVCDAPGRSSRRVALNLGEVLRGDRIATSGYEIEMGKDVACAHLCDAAVDAAGIARATQLIRNGYSAEWIVDNLPGATSFVTVDRTKKYYAAGFKLGGFENDVAKFHNHVSLVFRWRRLEADSDRKVIVAFEVYPKSIKTKDGACPTSLDNQPPLELPETSTVGVDGFTIPYTYSIFWKEDDTIEWSSRWDLYFVNNEDAHQIHWLAIVNSTVIVMVLSGVVFLILVRTLSRDIQSYNTPDGDDDKDTDADITGWKLVHGDVFRPPPAGGLFSPLIGAGVQLLVMMLALLILSAAGILNPSYRGGFLSFALFLFVFAGVFSGLHSTKIYKTFGGSQWVKNGLMTALLVPGSVFLTVFILNLFVWAEASSSALPFGTLVALLAMWLLISLPLVLLGSFIGFRRPAVEHPTKANQIPRQIPEQPRHLRFFPSLLITGVVPFAVIFIELLFVFRSVWAEKSGYYYVYGFLGLITLILLITTVEITLIHVYFMLCAENYHWWWRSFFVGGASAIYVFGYCVWYYLFKLQLHGWVSGLLFLGYSLLGCALYGVFLGTVGSLSAYVFVRKIYAAVKVD",
      "product": "hypothetical protein"
     },
     {
      "start": 35335,
      "end": 36600,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004307",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004307</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004307</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004307-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,335 - 36,600,\n (total: 1266 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004307\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGTGAAGCGGAGACTGTCCTCCACATCGCGGTCGTCCGCTGACGCAGACGCGCCAGATTCAGCGGCCGCGATCTGGCCCGCGCCGCAACGAGACTTGGAGAGCGCGCGAGCCTTCATTCAAGAGGCGGCCAGATCGCAGCGCAAGATTGTGATTGCACCGGATCGCGACGCTGATGGGCTCTGCTCTGGCGCACAGCTACGACATACCCTTCTACACCTGGGTGCGGCACCCGACCAGATCGCCATCAAGTTTGTCGCCAAAGGACGGAATGTGCATTGTGATGAAGAGCGCGCGGACTTAGAGCGGTATCAGGCGGAGTATATCTTTGTTCTCGATCATGGAAGTCGAGGCGGTGGGCCCATAGCAGATGGGAAGGTGCTCATCCTAGATCATCACTGGAGCGAGGACTTCCCAGACGACGCGCAGGTGGTGAGTGCATGCAAGTATCTACCCGTGGCCACGGCGTCACTATTGACGTATGTCGTCTGCCTCGCCATCAATGAGCACCTCCCGGCCTGGCTCGCAGTCACTGGCACCGTTGGCGATCTCGGCACTACCGTTACGTTTGAGCCCCCATTTCCAACAAGTTTGGCGCAGACATTCAAGGCGCAAGGCAAGAAGCAGATCGCAGAGGTTGTCGCCCTGTTGAATGCACCTCGACGCACTCCAGCCTGCGACCCGACCGAGGCGTGGCAGCTGCTGATTGCAAGCGCGTCTGCCCGAGACTTCCTCGCATCACCGAGCACGCGCTCGCTGGACGACGCGCGCGTATATATCCAAAGAGAGACAGAGCGATGCACGCATGCGGCCCCCAGATTCACAAAGGACGGTCGGATGGCCATTTTGGAGATGTCGTCGCCTGCACAGATCCATCAGCTCATTGCGACGCGCTGGGCCGGCTTCCTGAAATCCAAAGCGCTGCTTGCAGTCGGTGTTGCTAATCGGGGGTACGCTCCCGACAAAGTTCATCTGTCCTGCCGCCTTGTCAAGAGTAGGCGGAGTGAAGAGCCGCCTGTCAACTTGATTGCCCTGCTTAACGAATACCTCGCCCGAGACGCAGGTCTGGCAAAGACCATTGGACCCGATTTTGCGCATGGTCACAAGGAAGCTGCAGGGGGCCACATGTCTCCTGAGCAATGGGACAGGCTAGTCGCGGCGATGGAAATTGGAAATTGGAAGTCGCCCAACAAGGACAGCCCCAAAAAGCCCTCCGTGGACGCGAAGCAATCCAACTTGACAGGTTATTTCAAGCGTGTCTAG",
      "translation": "MGVKRRLSSTSRSSADADAPDSAAAIWPAPQRDLESARAFIQEAARSQRKIVIAPDRDADGLCSGAQLRHTLLHLGAAPDQIAIKFVAKGRNVHCDEERADLERYQAEYIFVLDHGSRGGGPIADGKVLILDHHWSEDFPDDAQVVSACKYLPVATASLLTYVVCLAINEHLPAWLAVTGTVGDLGTTVTFEPPFPTSLAQTFKAQGKKQIAEVVALLNAPRRTPACDPTEAWQLLIASASARDFLASPSTRSLDDARVYIQRETERCTHAAPRFTKDGRMAILEMSSPAQIHQLIATRWAGFLKSKALLAVGVANRGYAPDKVHLSCRLVKSRRSEEPPVNLIALLNEYLARDAGLAKTIGPDFAHGHKEAAGGHMSPEQWDRLVAAMEIGNWKSPNKDSPKKPSVDAKQSNLTGYFKRV",
      "product": "hypothetical protein"
     },
     {
      "start": 36748,
      "end": 38344,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004308",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004308</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004308</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004308-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,748 - 38,344,\n (total: 1562 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004308 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13813.9 (Membrane bound O-acyl transferase family): [226:309](score: 50.6, e-value: 1.8e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004308\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACTTCATGAATACAAATGAAGCAAGGATGGCATTCTCGTTTTGGACGCAGCTATTTATAGACGCAGGATGGCCGGTCGACGTGGACGACCAGCCCCGCGAAATACTGTGGTCTAGGCCGCTGCCGCTGGTGGCTTCCGTCTTTCCATTCCTCATCTGCGTGCTGACTCTAGCATATCACCCGCTGCTCATCCAGCCAGAGGCCTCGCGTCTCGAAATCCTCCTGTGTCTGCTCGTTGGCCTCTTTCCCGTCATTTGGGGAGCGCAAGGCAGCGGATCTGCTGTTTTTGAATTTGCGCTATCGACAATCACGAGCGTGGTCGGTCTTCGCATGGTTCGACTGTCGTTCTTTCGACGCCGCACCAGACGGAGCAGGCTGGATATGTGGACAGAGCTGATCAGCCTGCCACTCCCCGACCAAACAACTCATTCGCAAGCACAGGCTCCTTCATCTGCACGACGCCAAAATGCAATTCAAGCCATGCAAGCTTTGCCCCAGGCTGTGCTGGTTCCTACCCTACTTCGATGCATACCACCCCCTGAGTCCTTAATACACATGTCCTTCATCCAGGCCAGGCTTTATCACATGCTGGCTGGGCTGGCCATCCTTTTTGTCCTGCAGGGCTCCGTGCAACTCTGCCTATCCAGCTGGGGAATTGTCATGAACTCTCGGCAAAAGCCCATGTTCAGGAATCCATTGGGAGCTCGCACCTTGCAGGAGCTTTGGGGCCAGAGGTGGAACCGAGTTGTTCAAGAGCAGCTACACTTTCTCTTTGCATGCCTCGCTGGAAATAAAGTCAAAGGGGGAAGGCGTCGGCGGACACTGGCTGCACTGGCAACCTTTCTCCTGTCTGGCCTCTTTCACGAGTACCTGGCCTACCAGTCTTTTGGAACTGCTTCCTTTCAGCAGTTCTGGTTCTTCATGATTCAGGGTGTTCTTTGCAGTATGGAGCCATACATTCCCAAAGGCGCCACCTACGCCTGGCTCGTTCGTGTGAGCTGGGTCCTGATGTGCGAGATGAATACCGGCGCATGGTTGCAGAGCCACTTCTTTGAACAAGCAAAAGCCTTCCTCCCCGGACCGATCAGAGTGGACTCCATGGGTAGTCTTTCCGAGCTCTTCGATGGTATCCTCAAAGAGCATGCCTGCTTGAATACTCCATTCACGATTGTAGACACGCACAGCAATGGTGCGTGCATCATTCACGACACTCGCAATCCGCACCTTGGAGGTGGAGTCCACCCGGCCACACAGACCTACAAAGAGGGTGTCGAGCCGCCTGGAGAGGGGGAAGAGGACTGCTGTAGGCGGGAAGGCGGGCAGATAGGAGAACAGACTGCCCGTGAGTGTCAGGGCATATTGTACGCGTATGTAAACCGGGGACTGCTCCAAGATCTCCAGAATGGGCTTTGCGTCGCTGGCAATCTGGGGGAAGCTGGTGTAGCCGTCGTCTGCGCTGAACTTCTTGTTGAACCTGCGCGACACTTGCAGCAGTCTGGTGTCGAGGAAGGTGGCCATCGAGCGTTAACGACCCGAGGAAAAGTTGCATCACATGACTC",
      "translation": "MDFMNTNEARMAFSFWTQLFIDAGWPVDVDDQPREILWSRPLPLVASVFPFLICVLTLAYHPLLIQPEASRLEILLCLLVGLFPVIWGAQGSGSAVFEFALSTITSVVGLRMVRLSFFRRRTRRSRLDMWTELISLPLPDQTTHSQAQAPSSARRQNAIQAMQALPQAVLVPTLLRCIPPPESLIHMSFIQARLYHMLAGLAILFVLQGSVQLCLSSWGIVMNSRQKPMFRNPLGARTLQELWGQRWNRVVQEQLHFLFACLAGNKVKGGRRRRTLAALATFLLSGLFHEYLAYQSFGTASFQQFWFFMIQGVLCSMEPYIPKGATYAWLVRVSWVLMCEMNTGAWLQSHFFEQAKAFLPGPIRVDSMGSLSELFDGILKEHACLNTPFTIVDTHSNGACIIHDTRNPHLGGGVHPATQTYKEGVEPPGEGEEDCCRREGGQIGEQTARECQGILYAYVNRGLLQDLQNGLCVAGNLGEAGVAVVCAELLVEPARHLQQSGVEEGGHRALTTRGKVASHDS",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 18686,
      "end": 21690,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 38397,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r85c1"
   }
  ]
 },
 {
  "length": 38189,
  "seq_id": "scaffold_86",
  "regions": []
 },
 {
  "length": 38046,
  "seq_id": "scaffold_87",
  "regions": []
 },
 {
  "length": 37820,
  "seq_id": "scaffold_88",
  "regions": []
 },
 {
  "length": 36970,
  "seq_id": "scaffold_89",
  "regions": []
 },
 {
  "length": 36403,
  "seq_id": "scaffold_90",
  "regions": []
 },
 {
  "length": 35638,
  "seq_id": "scaffold_91",
  "regions": []
 },
 {
  "length": 34443,
  "seq_id": "scaffold_92",
  "regions": []
 },
 {
  "length": 34089,
  "seq_id": "scaffold_93",
  "regions": []
 },
 {
  "length": 33222,
  "seq_id": "scaffold_94",
  "regions": []
 },
 {
  "length": 33196,
  "seq_id": "scaffold_95",
  "regions": []
 },
 {
  "length": 32859,
  "seq_id": "scaffold_96",
  "regions": []
 },
 {
  "length": 32802,
  "seq_id": "scaffold_97",
  "regions": []
 },
 {
  "length": 32403,
  "seq_id": "scaffold_98",
  "regions": []
 },
 {
  "length": 32004,
  "seq_id": "scaffold_99",
  "regions": []
 },
 {
  "length": 30968,
  "seq_id": "scaffold_100",
  "regions": []
 },
 {
  "length": 29404,
  "seq_id": "scaffold_101",
  "regions": []
 },
 {
  "length": 29224,
  "seq_id": "scaffold_102",
  "regions": []
 },
 {
  "length": 28689,
  "seq_id": "scaffold_103",
  "regions": []
 },
 {
  "length": 28588,
  "seq_id": "scaffold_104",
  "regions": []
 },
 {
  "length": 28249,
  "seq_id": "scaffold_105",
  "regions": [
   {
    "start": 11006,
    "end": 28249,
    "idx": 1,
    "orfs": [
     {
      "start": 13853,
      "end": 16574,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004659",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004659</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004659</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004659-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,853 - 16,574,\n (total: 2691 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004659 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.4e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 56.3, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004659\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACCATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGCTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTACGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTCGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGAATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAGGCAGCCAGATTTAGGCTCTTCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCGGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGCGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAATTTTTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTTCACATATTGGAAAGCTCTATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAGGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGCGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACGTCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAATTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
      "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKRQPDLGSSLLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVAMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKNFFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKGVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQAAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERRRGAIEIQDGQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSNFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
      "product": "hypothetical protein"
     },
     {
      "start": 16675,
      "end": 19701,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004660",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004660</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004660</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004660-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,675 - 19,701,\n (total: 2886 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004660 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [11:273](score: 119.8, e-value: 1.1e-34)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [492:556](score: 28.2, e-value: 1.6e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [826:907](score: 50.4, e-value: 1.9e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004660 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004660\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTGTGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATGTTTGTCCAATTCGTACTCGAAAACATATGGGCGGTTTATGATTATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAAAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCTAGCGTTGGAATGAACCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGAAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCATAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTTGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTAATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
      "translation": "MRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPMFVQFVLENIWAVYDYKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKKSPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEKLSSALERITNYMRKSISGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
      "product": "hypothetical protein"
     },
     {
      "start": 20011,
      "end": 20952,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004661",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004661</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004661</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004661-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,011 - 20,952,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004661 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004661\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
      "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
      "product": "hypothetical protein"
     },
     {
      "start": 21006,
      "end": 21950,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004662",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004662</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004662</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004662-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,006 - 21,950,\n (total: 912 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004662 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [29:285](score: 173.0, e-value: 8.9e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004662 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004662\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTGTGAAACGAATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGTCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
      "translation": "MLVKRMSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
      "product": "hypothetical protein"
     },
     {
      "start": 22300,
      "end": 22824,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004663",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004663</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004663</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004663-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,300 - 22,824,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004663 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004663 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004663\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
      "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
      "product": "hypothetical protein"
     },
     {
      "start": 23437,
      "end": 24468,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004664",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004664</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004664</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004664-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,437 - 24,468,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004664 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [103:307](score: 208.1, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004664\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGAGCGACCAGCCAGACACAGCGATGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGCCGACAAAAGTAGCATCCCACATGACACAGGCGAGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
      "translation": "MSSRKLLSNPVKPRRYFPQSRERPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARADKSSIPHDTGESSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
      "product": "hypothetical protein"
     },
     {
      "start": 24510,
      "end": 25220,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004665",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004665</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004665</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004665-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,510 - 25,220,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004665 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [71:224](score: 147.6, e-value: 2.4e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004665\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCATTGATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTACACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCGTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCTTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
      "translation": "MALMTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPITPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
      "product": "hypothetical protein"
     },
     {
      "start": 25738,
      "end": 26760,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004666",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004666</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004666</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004666-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,738 - 26,760,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004666 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004666\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
      "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
      "product": "hypothetical protein"
     },
     {
      "start": 26815,
      "end": 27261,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004667",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004667</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004667</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004667-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,815 - 27,261,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004667\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATTGGAATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
      "translation": "MGMDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 21005,
      "end": 21950,
      "tool": "rule-based-clusters",
      "neighbouring_start": 11005,
      "neighbouring_end": 28249,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r105c1"
   }
  ]
 },
 {
  "length": 28067,
  "seq_id": "scaffold_106",
  "regions": []
 },
 {
  "length": 27785,
  "seq_id": "scaffold_107",
  "regions": []
 },
 {
  "length": 27652,
  "seq_id": "scaffold_108",
  "regions": []
 },
 {
  "length": 27486,
  "seq_id": "scaffold_109",
  "regions": []
 },
 {
  "length": 27193,
  "seq_id": "scaffold_110",
  "regions": [
   {
    "start": 1,
    "end": 27193,
    "idx": 1,
    "orfs": [
     {
      "start": 415,
      "end": 1386,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004725",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004725</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004725</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004725-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 415 - 1,386,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004725 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:270](score: 203.7, e-value: 3e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004725\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004725-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTTAACAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGCATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTGGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGCCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
      "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
      "product": "hypothetical protein"
     },
     {
      "start": 1872,
      "end": 3532,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004726",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004726</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004726</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004726-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,872 - 3,532,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 963.0, e-value: 4.7e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004726\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004726-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAAAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCGCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
      "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDKGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
      "product": "hypothetical protein"
     },
     {
      "start": 3546,
      "end": 7613,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004727",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004727</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004727</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004727-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,546 - 7,613,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 241.6; E-value: 2.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004727 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 220.3, e-value: 3.8e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004727 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1898.5, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004727\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004727-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAGCATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGCGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACAATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
      "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKAYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
      "product": "hypothetical protein"
     },
     {
      "start": 7884,
      "end": 9374,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004728",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004728</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004728</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004728-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,884 - 9,374,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004728\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAAGGAAGTAA",
      "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALRK",
      "product": "hypothetical protein"
     },
     {
      "start": 9394,
      "end": 12078,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004729",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004729</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004729</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004729-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,394 - 12,078,\n (total: 2685 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004729 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [632:762](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [785:820](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004729 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004729\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004729-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAACCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTAATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGACCAGGCGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTGGTCAAGATCGTATTATAGTTACCCCTGCAGACGTGGTTTCGAACGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
      "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLNEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRPGDASGRKLTPVHLLTGGQDRIIVTPADVVSNEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
      "product": "hypothetical protein"
     },
     {
      "start": 12532,
      "end": 13539,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004730",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004730</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004730</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004730-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,532 - 13,539,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004730 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [1:61](score: 51.2, e-value: 8.9e-14)<br>\n \n  PF00013.32 (KH domain): [94:159](score: 56.3, e-value: 2.3e-15)<br>\n \n  PF00013.32 (KH domain): [184:250](score: 56.7, e-value: 1.6e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004730 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004730\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGACACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
      "translation": "MVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
      "product": "hypothetical protein"
     },
     {
      "start": 14198,
      "end": 16413,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004731",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004731</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004731</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004731-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,198 - 16,413,\n (total: 2148 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [7:262](score: 298.8, e-value: 2.5e-89)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [365:689](score: 166.6, e-value: 8.8e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [319:701](score: 578.4, e-value: 1.7e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [8:262](score: 223.2, e-value: 5.9e-67)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004731\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004731-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGCGATTAAGGAGACATTCAGCAGATGCAGGCGAGAAAATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCGTTTTCGCGGTCTTTGCAAAACCCACTCGATGAGTTATGTTCCTTTGATTGCACCAAGTACAAATGAGTCCAGGCTTGCCCTTTTGTGTTCGATAGCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTATGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTACCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCAATGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
      "translation": "MQAIKETFSRCRRENRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIRFRGLCKTHSMSYVPLIAPSTNESRLALLCSIADSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVCTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTTADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEAMRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
      "product": "hypothetical protein"
     },
     {
      "start": 17170,
      "end": 17739,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004732",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004732</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004732</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004732-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,170 - 17,739,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004732 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [112:186](score: 58.0, e-value: 1.3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004732 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004732\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGGCTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAACACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
      "translation": "MVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSGSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEEHPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 3545,
      "end": 7613,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 27193,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r110c1"
   }
  ]
 },
 {
  "length": 26893,
  "seq_id": "scaffold_111",
  "regions": []
 },
 {
  "length": 26103,
  "seq_id": "scaffold_112",
  "regions": []
 },
 {
  "length": 24871,
  "seq_id": "scaffold_113",
  "regions": []
 },
 {
  "length": 24835,
  "seq_id": "scaffold_114",
  "regions": []
 },
 {
  "length": 24505,
  "seq_id": "scaffold_115",
  "regions": [
   {
    "start": 12557,
    "end": 24505,
    "idx": 1,
    "orfs": [
     {
      "start": 15867,
      "end": 17826,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004792",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004792</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004792</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004792-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,867 - 17,826,\n (total: 1632 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1139:aminotransferase class V (Score: 313.2; E-value: 4.1e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004792 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00266.22 (Aminotransferase class-V): [145:508](score: 296.8, e-value: 2.2e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004792\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004792-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTTGCCTTGACTAATATTAAGTGGTACTACTTCTCGTACGAGCTGGGGAAGGTTGCTCCGTTTGATCTTCGAAAAGCCATGGCCTACGTGGACGGGATTTCACAATCTTGGCAATCACAAGCCAAATCGCGTGGAAATGACCATATTGAGCTGTCAGAGTTTTCCGCTTTTCCTCTGCACAATGTCTCTCTTAGATTACACTCTACTGGACTTCTCGAGGAAGGAGACATCAATCACTACCTCGAACCAATTGGTATTGCGCCGCGTTATGCCAACGTGCTCTACAAGAGGACCAGCTGTGCTCGCACCAGGTGCGCTGCAACCTATGTGACGCAAAGCAAACCCGCCGAAGCAGCTATCGTTGAATCGAAGCTGCCGCATGGCACGGGAATCCTGAAGCAAACCGTCGAGCCCAAGGCAGAAGGTCGCCCAATCTACTTGGACATGCAGGCTACTACGCCGTTGGATCCACGCGTGCTTGACATCATGCTGCCGTTCATGACTGGAATGTATGGAAATCCCCATTCGAGGACACATGCATATGGATGGGAGACGAATGAAGCGAGCGAGATAGCACGCACGCACGTTGCAAATCTTATTGGAGCGGATCCAAAGGAAATCATCTTCACCTCCGGTGCCACCGAGTCGAACAATATGAGTATCAAGGGAGTAGCTCGATTTTACAAAGGGACAAAAAATCACATCATCACCTGCCAAACAGAACACAAATGCGTGCTGGATTCATGCAGACATTTGCAAAATGAGGGTTTTGATGTCACCTACCTCCCCGTTCAACAGAACGGCTTAATCTCGCTCGAGCAGTTGGAGAAGGAGATTCGACCGGATACGGCTCTAGTGTCCATCATGGCTGTAAACAATGAAATTGGAGTCATTCAGCCGATCGATGAGATTGGCCGATTGTGCCGGAAGAATAAGATCTTTTTCCACACCGACGCTGCACAAGCTGTTGGGAAGATCTGTATGGATGTAAACAAATCCAACATTGATCTCATGTCTATCTCGAGTCATAAGATATATGGTCCCAAGGGCATGGGTGCATGTTATGTGCGGAGACGCCCGCGAGTGCGTCTCGATCCCATTATCTCTGGTGGCGGCCAAGAAAGAGGTTTACGAAGCGGCACGCTCGCGCCTAATCTAGTCGTCGGCTTTGGAGAGGCGTCGCGTCTTGCATTGCAAGAATTCCCCTATGACGAAAAAAGAATCAAAAGCCTGTCAGATCGTTTGGTCAATGGTCTACTTGCCCTCGATCACGTTCATCAAAATGGTGCCCCTGATCGATTCTACCCTGGATGTGTCAATATGTCATTCGCCTATGTCGAGGGCGAATCTCTATTGATGGCACTGAAGGACATTGCTCTCAGCTCCGGTTCCGCCTGCACGTCTGCCTCACTGGAGCCTTCCTATGTGCTGCGGGCTCTAGGCGCTGCGGACGACATGGCCCATTCTTCCATTCGGTTCGGTCTTGGACGGTTCACTACCGAAGACGAGGTGGAGTATGTATTAAAGGCGGTCCGTGATCGCGTGACTTGGCTTCGCGATATGTCTCCGCTTTATGAAATGGTGCAGGATGGAATCGACCTGAAATCAATCCAATGGAGTCAACATTGA",
      "translation": "MVALTNIKWYYFSYELGKVAPFDLRKAMAYVDGISQSWQSQAKSRGNDHIELSEFSAFPLHNVSLRLHSTGLLEEGDINHYLEPIGIAPRYANVLYKRTSCARTRCAATYVTQSKPAEAAIVESKLPHGTGILKQTVEPKAEGRPIYLDMQATTPLDPRVLDIMLPFMTGMYGNPHSRTHAYGWETNEASEIARTHVANLIGADPKEIIFTSGATESNNMSIKGVARFYKGTKNHIITCQTEHKCVLDSCRHLQNEGFDVTYLPVQQNGLISLEQLEKEIRPDTALVSIMAVNNEIGVIQPIDEIGRLCRKNKIFFHTDAAQAVGKICMDVNKSNIDLMSISSHKIYGPKGMGACYVRRRPRVRLDPIISGGGQERGLRSGTLAPNLVVGFGEASRLALQEFPYDEKRIKSLSDRLVNGLLALDHVHQNGAPDRFYPGCVNMSFAYVEGESLLMALKDIALSSGSACTSASLEPSYVLRALGAADDMAHSSIRFGLGRFTTEDEVEYVLKAVRDRVTWLRDMSPLYEMVQDGIDLKSIQWSQH",
      "product": "hypothetical protein"
     },
     {
      "start": 18627,
      "end": 19973,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004793",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004793</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004793</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004793-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,627 - 19,973,\n (total: 1347 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004793 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05743.16 (UEV domain): [24:142](score: 112.9, e-value: 8.3e-33)<br>\n \n  PF09454.13 (Vps23 core domain): [377:440](score: 79.5, e-value: 1.5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004793 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport<br>\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004793\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCAACCAGAAGTCGCGCAATGGCTCCAACGAGTCGTCTCTCGAGACTACTCGGACAAGAAACGAGTGTATGGGGATGTCATCGACCTCTTGACGCGCTACCCGTCATTATCTCCCCGCACCAAAGTGTTCTCCTTTGAAGACGGGCGGTCAGAGCTCTTGCTTTGCATTCACGGCACGCTACCGGTACGATTTCGAAATGCAGACTACAACACGCCAATCACTCTGTGGGTAGACAAGGTATACCCTGTGTCACGTCCTTTGGCATTTGTCACTCCTTCTCCGGAAATGGGTATTCGCGCAGGGAATCACGTAGACCCAAATGGTGCCATCTACCACCCCTTATTGGCGTACTGGGATGCGAAAAAGACAATAGTGGAGCTCGCAGAGCTGTTACGTGAAGTCTTTGGTGCCGAAATGCCAGCATATGCACGCACGGCGAAACAAAATGGAGACAAGGATTTCTACGGCTCCACTTCTCCTCCCCCGCCTCCTCTACCCCCAGCCCCTCACCGAGCAAACTCACCTACTTCTCCAATTCATCCCTCTTCACCCATACCACCACCTCGGCCAAACTACAACGCACCTCCACCGAAACCACCTTTACCTCCACGACTTCAGCCAGGCCCTTCTACCGCATACTCAACTTCTCCAACACCTCCATCACCTCGTGAGTACAGCCCATCTTTCGAGAGACCGCCTACCACACAACTACAACCCAGACCGTCCTCTACACAGTTACCGCCCTCATGGCAAGCTCCAGCACGGCGGCCATCGCCGACACGGCCAACGATAGATATTCTAGATCTCCAGGACGCACTACCTGCAACCTCTGCACCTCCGCTACCCGAGAACCCGGCTCGAAGGGCCCAATTTGAAGAACTAAATAAACGCTTATGCCGTCGAGCGGAGACGTCCACTGAAAAGACTACGACGATGCTGGAGTCAGCCAAGCAAGTTCGCGAGCGGCTTGTTGCTACCGAAACTAGGCTGGAGCTCGAGACCAGCGAACTCCGGCGAATTGAAGAAGCATGCACGCGGGATACTGCGATTCTGCAGGAGCGGATCAATGCTGCAGAGGGAGTCACGAGGGATGCACTTCAATCAGACGAAGTAGACATCGACAAGATCCTCGTCGGATCGAGAGTCGTATACAACCAAATCTACGATCTCGTCTGCGCCGACTTGGCAATTGACGATACGATCTACGCGTTGGGGATAGCGCACGAGCGGGAATGCATCACGTTTGATGTCTTTCTGCGGCATGTCCGCATCCTCGCTCGAGAGCAATTCCTCAAGAAGGCACTGCTGGCAAAGATTAGGGAGCAGACCAAGCTCCAATAA",
      "translation": "MLQPEVAQWLQRVVSRDYSDKKRVYGDVIDLLTRYPSLSPRTKVFSFEDGRSELLLCIHGTLPVRFRNADYNTPITLWVDKVYPVSRPLAFVTPSPEMGIRAGNHVDPNGAIYHPLLAYWDAKKTIVELAELLREVFGAEMPAYARTAKQNGDKDFYGSTSPPPPPLPPAPHRANSPTSPIHPSSPIPPPRPNYNAPPPKPPLPPRLQPGPSTAYSTSPTPPSPREYSPSFERPPTTQLQPRPSSTQLPPSWQAPARRPSPTRPTIDILDLQDALPATSAPPLPENPARRAQFEELNKRLCRRAETSTEKTTTMLESAKQVRERLVATETRLELETSELRRIEEACTRDTAILQERINAAEGVTRDALQSDEVDIDKILVGSRVVYNQIYDLVCADLAIDDTIYALGIAHERECITFDVFLRHVRILAREQFLKKALLAKIREQTKLQ",
      "product": "hypothetical protein"
     },
     {
      "start": 20091,
      "end": 20865,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004794",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004794</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004794</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004794-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,091 - 20,865,\n (total: 738 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004794 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01738.21 (Dienelactone hydrolase family): [34:231](score: 46.1, e-value: 4.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004794 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01738.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004794\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004794-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTGACAAATGCTGCCCCTCAGACCTCCCTGCTTTTCAGAGCGACTACAAGCCTCTCGGCCAGACAGTCAAGCTGACAAAGGCGGCGGGCCGTGCATTAGAGACGTACGTGTATCAGCCAGGCGGGAAGGTTGAGCTGGGAATCATCTACTATGCCGACGTCTTTGGCCTCTTGCCCAATGCTCTACAAGGGGCAGACTTGCTGGCAAGGAGTCTAAATGCGCGAGTGTACGTGCCAGACCTCTACGAAGGTCAGCCGTGGGAAACGTCCAATATGCCGCCAAAGGAAGGCTATGAAGCAATGTTTGCCCACTTCGGTAAAGTGGCGCCTCCTGAAAAAATCCGTGAGCTCACAATTGAATTGATCGAGCAACTCCGGGGAGATGGCATTGAACGGGTGGGCGCAATTGGGTTTTGTTTAGGCGCCAAACTCCTTGCAGCAAATTCCGCACTTGTAGGTGCCACAGCCTATATTCATCCGTCAGGCTTCACTGTTGAGGAAGCGAAAGGCTATCGTGGACCGGTCGCTCTCCTTCCATCACAGGACGAGGACAAAGAGCTCATGAAAAACTTTTGGGCAGCTCTCTCAGAGACCGCAAAGAAGGATGGCGTCTTCCAGACCTTCCCTGTCCATCACGGCTTTGCAGCAGGAAGATCAGACTGGAATGACCCTGAGCTTGGCAAGCATGCCCACGAGGCTTTTGAGCTTGCTGCATCAGTCCTGGCAAAGGCCTGA",
      "translation": "MSDKCCPSDLPAFQSDYKPLGQTVKLTKAAGRALETYVYQPGGKVELGIIYYADVFGLLPNALQGADLLARSLNARVYVPDLYEGQPWETSNMPPKEGYEAMFAHFGKVAPPEKIRELTIELIEQLRGDGIERVGAIGFCLGAKLLAANSALVGATAYIHPSGFTVEEAKGYRGPVALLPSQDEDKELMKNFWAALSETAKKDGVFQTFPVHHGFAAGRSDWNDPELGKHAHEAFELAASVLAKA",
      "product": "hypothetical protein"
     },
     {
      "start": 21663,
      "end": 22457,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004795",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004795</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004795</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004795-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,663 - 22,457,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004795 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [186:250](score: 47.7, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004795\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGATCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
      "translation": "MIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
      "product": "hypothetical protein"
     },
     {
      "start": 22557,
      "end": 23558,
      "strand": -1,
      "locus_tag": "MARS52BIN25_004796",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004796</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004796</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004796-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,557 - 23,558,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 234.9; E-value: 1.8e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004796 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 223.5, e-value: 2.5e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004796 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004796\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004796-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGTTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGGTAATACTGCATTGATGGAGATCCTTAACAGTTGGCATAGTTCTTTGTGTGGCACAGATTAG",
      "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNVWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGGNTALMEILNSWHSSLCGTD",
      "product": "hypothetical protein"
     },
     {
      "start": 23673,
      "end": 24398,
      "strand": 1,
      "locus_tag": "MARS52BIN25_004797",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004797</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004797</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004797-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,673 - 24,398,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004797 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004797\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGCGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAAGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
      "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 22556,
      "end": 23558,
      "tool": "rule-based-clusters",
      "neighbouring_start": 12556,
      "neighbouring_end": 24505,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r115c1"
   }
  ]
 },
 {
  "length": 23362,
  "seq_id": "scaffold_116",
  "regions": []
 },
 {
  "length": 23179,
  "seq_id": "scaffold_117",
  "regions": []
 },
 {
  "length": 22327,
  "seq_id": "scaffold_118",
  "regions": []
 },
 {
  "length": 21456,
  "seq_id": "scaffold_119",
  "regions": []
 },
 {
  "length": 21422,
  "seq_id": "scaffold_120",
  "regions": []
 },
 {
  "length": 21175,
  "seq_id": "scaffold_121",
  "regions": []
 },
 {
  "length": 20978,
  "seq_id": "scaffold_122",
  "regions": []
 },
 {
  "length": 20761,
  "seq_id": "scaffold_123",
  "regions": []
 },
 {
  "length": 20357,
  "seq_id": "scaffold_124",
  "regions": []
 },
 {
  "length": 19901,
  "seq_id": "scaffold_125",
  "regions": []
 },
 {
  "length": 19695,
  "seq_id": "scaffold_126",
  "regions": []
 },
 {
  "length": 19609,
  "seq_id": "scaffold_127",
  "regions": []
 },
 {
  "length": 19594,
  "seq_id": "scaffold_128",
  "regions": []
 },
 {
  "length": 18850,
  "seq_id": "scaffold_129",
  "regions": []
 },
 {
  "length": 18741,
  "seq_id": "scaffold_130",
  "regions": []
 },
 {
  "length": 18686,
  "seq_id": "scaffold_131",
  "regions": []
 },
 {
  "length": 18143,
  "seq_id": "scaffold_132",
  "regions": []
 },
 {
  "length": 17274,
  "seq_id": "scaffold_133",
  "regions": []
 },
 {
  "length": 16970,
  "seq_id": "scaffold_134",
  "regions": []
 },
 {
  "length": 15887,
  "seq_id": "scaffold_135",
  "regions": []
 },
 {
  "length": 15631,
  "seq_id": "scaffold_136",
  "regions": []
 },
 {
  "length": 14794,
  "seq_id": "scaffold_137",
  "regions": []
 },
 {
  "length": 14361,
  "seq_id": "scaffold_138",
  "regions": []
 },
 {
  "length": 14014,
  "seq_id": "scaffold_139",
  "regions": []
 },
 {
  "length": 13672,
  "seq_id": "scaffold_140",
  "regions": []
 },
 {
  "length": 13016,
  "seq_id": "scaffold_141",
  "regions": []
 },
 {
  "length": 10964,
  "seq_id": "scaffold_142",
  "regions": []
 },
 {
  "length": 10684,
  "seq_id": "scaffold_143",
  "regions": []
 },
 {
  "length": 10269,
  "seq_id": "scaffold_144",
  "regions": []
 },
 {
  "length": 10159,
  "seq_id": "scaffold_145",
  "regions": []
 },
 {
  "length": 9858,
  "seq_id": "scaffold_146",
  "regions": []
 },
 {
  "length": 9832,
  "seq_id": "scaffold_147",
  "regions": []
 },
 {
  "length": 9513,
  "seq_id": "scaffold_148",
  "regions": []
 },
 {
  "length": 9233,
  "seq_id": "scaffold_149",
  "regions": []
 },
 {
  "length": 9175,
  "seq_id": "scaffold_150",
  "regions": []
 },
 {
  "length": 8946,
  "seq_id": "scaffold_151",
  "regions": []
 },
 {
  "length": 8568,
  "seq_id": "scaffold_152",
  "regions": []
 },
 {
  "length": 8525,
  "seq_id": "scaffold_153",
  "regions": []
 },
 {
  "length": 8497,
  "seq_id": "scaffold_154",
  "regions": []
 },
 {
  "length": 8171,
  "seq_id": "scaffold_155",
  "regions": []
 },
 {
  "length": 8010,
  "seq_id": "scaffold_156",
  "regions": []
 },
 {
  "length": 8007,
  "seq_id": "scaffold_157",
  "regions": []
 },
 {
  "length": 7453,
  "seq_id": "scaffold_158",
  "regions": []
 },
 {
  "length": 7202,
  "seq_id": "scaffold_159",
  "regions": []
 },
 {
  "length": 6532,
  "seq_id": "scaffold_160",
  "regions": []
 },
 {
  "length": 6445,
  "seq_id": "scaffold_161",
  "regions": []
 },
 {
  "length": 6436,
  "seq_id": "scaffold_162",
  "regions": []
 },
 {
  "length": 5507,
  "seq_id": "scaffold_163",
  "regions": []
 },
 {
  "length": 5117,
  "seq_id": "scaffold_164",
  "regions": []
 },
 {
  "length": 4987,
  "seq_id": "scaffold_165",
  "regions": []
 },
 {
  "length": 4688,
  "seq_id": "scaffold_166",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r15c1",
  "r40c1",
  "r85c1",
  "r105c1",
  "r110c1",
  "r115c1"
 ],
 "r15c1": {
  "start": 7422,
  "end": 28723,
  "idx": 1,
  "orfs": [
   {
    "start": 9046,
    "end": 9552,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001680",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001680</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001680</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001680-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,046 - 9,552,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001680 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04588.16 (Hypoxia induced protein conserved region): [59:111](score: 71.4, e-value: 5.3e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001680\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001680\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACATCTCCAGGGAGGAGTGACGACGGTGACGCCTCTCCAAAAGCCAACAGGATGGAGAGATTTGACGATAACTCAATCATTCGGATGCCCTCGTCTTTTGATTTTGGAGATGAAGGAATGACAGGCCAAAAACCTGAGCCGCAAGGTCTAAACAAAATCTTACAGCGTTGCAAAGAGGAACCGCTTGTGCCCATTGGGTGCCTACTAACATGCGGAGCCCTGTTTGGATCTGCAGTTGGGCTAAGAAAGGGAAATAAAGATATGGCTCAGCGGATGTTTCGTTATAGAATTGGTTTTCAATTCGCGACTCTGGGATTTGTTATCGCTGGTGCACTGTACTATGGCAATGATCGAGCATCGCGGAAGCAGGAAGATCAAGCAGTACAGCAGCAGAAAGCAATGGATCGTCGGGCAGCCTGGCTACGGGAGCTAGACAGTCGTGACCGATTGCTCAAGGAACGAAGTCGACGGTTGGCAGAGAAGAAGGAACAGCCGCACCAGTAA",
    "translation": "MTSPGRSDDGDASPKANRMERFDDNSIIRMPSSFDFGDEGMTGQKPEPQGLNKILQRCKEEPLVPIGCLLTCGALFGSAVGLRKGNKDMAQRMFRYRIGFQFATLGFVIAGALYYGNDRASRKQEDQAVQQQKAMDRRAAWLRELDSRDRLLKERSRRLAEKKEQPHQ",
    "product": "hypothetical protein"
   },
   {
    "start": 9786,
    "end": 10385,
    "strand": 1,
    "locus_tag": "MARS52BIN25_001681",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001681</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001681</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001681-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,786 - 10,385,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001681 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00581.23 (Rhodanese-like domain): [11:123](score: 22.8, e-value: 0.00011)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001681\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001681\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCAATTGCCAACGCTTCGATCATAACTTCCGAGCAATTGAGTACAAGATTAAAGCAAGGCAGAATTCTACCTGTAGATGCAACATGGTACTTGCCAAACGTTCAGAGGAACGCTCGGGCCGAGTTCATACAGAAAAGGCTGCCAGGAGCGCGCTTTTTTGATCTGGATAAAATCAAAGACACAGAGTCATCACTCCCACATATGCTCCCATCAGGCGAGCTCTTTTCTACGGAAATGCGTAAAATGGGTATTTCTCGCAGTGATGAGATCGTTGTTTACGACACCTCAGCTCTGGGTATATTTAGCGCTGCACGCGCTTATTGGATGTTTAAAATCTTCGGTCACTCTAGTGTGATGCTTTTGAATTCGCTTTCACATTACAGCGGCCCATATGAAGAGGGTATTCCTAATGGTGTTACCCCAACGAAATATCCAGTTGTGGATGCAGATCAAAATCGAGTAGCCACATACGAAGAGGTCCTCGAAAACATTCAGAGACACGACGACGTACAGATTCTGGATGCTCGCCCATCCGGTCGTTTCGAAGGCGTCGATCCTGAACTTCGACCTGGTGAGCCCAACTACCGAATTTTCTAA",
    "translation": "MSIANASIITSEQLSTRLKQGRILPVDATWYLPNVQRNARAEFIQKRLPGARFFDLDKIKDTESSLPHMLPSGELFSTEMRKMGISRSDEIVVYDTSALGIFSAARAYWMFKIFGHSSVMLLNSLSHYSGPYEEGIPNGVTPTKYPVVDADQNRVATYEEVLENIQRHDDVQILDARPSGRFEGVDPELRPGEPNYRIF",
    "product": "hypothetical protein"
   },
   {
    "start": 10790,
    "end": 13483,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001682",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001682</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001682</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001682-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,790 - 13,483,\n (total: 2694 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001682\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001682\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTGGATCAAAGTACGCTTGATGAATACGGTACCATTAGTGGCGTCCTTCGACTGAGTGCGATATTAAATCCAAGGGTAATTAAAAAAGAGAGGAGTCGGAAATTCGAGGTTGCAAGCGCAAACTTCGGTCAGATTAGCTTTCTTTCTGAGGAGGTGACTATCATAAGACCACAACTGCAAAGATCCTGCACCTGGATACCTGTTCCTGATGGCGCTCGAACCTTGTTCTTCACTTGCACAATTACCCTTCCTACTGGTTATCAGTGGTCCAAACTTGTTCTTTCCGATGAGATCGTGAGAGGAAACGCCACCTTTGTCAGCGCTACATTCATAGAAGAAGAGATAGCCAATCAACACAAGCCAAAGCTTGTGTCATTGAGTTTGTACGACGAAAATACTAGCAAGAACTATGAGTTACGTATGCGAAGTCTCACTTTAGATGGGTCGAGAAACCGATACCATCTCGAAATCACGTACCAATCACACCTGGATCCTGATAAACCTAGAAGTTTTGTGGGAATAGCAAAAGTCACAAGTACACATTACAGATTCCATCGAGAATCTTACCTGCATCCGTATACGGCGAGAATTCCTTTAATAACCCAAGAAGAATTACTGAATCAAACAAAATGGGCCCCGTCTGAGCATCTCCCAATACCGGCGTATATAATAATGGACGCAGATCACGAAGGCCTTGCACCAAGACCACTATTAGTTGGTCCGGAGGATCAAAGTAATGGAACAAATAACTCAATCCCGGTAGGGTCAGCAGAAGAACATCTCCAAAATTCCAAGAGTAAGCATACTTTCTCTCCTCTATACCATCATGTCGACATAATAACGTTGCATGAGTCCACGAATGAAACAAAAGCGACAGATTCATCCAGAAATGAATTGCACACGGATTCGATCACGACGCCATTTACGGAGAAGACTTTTACGGTAAACACAACAACCAGGGACGTCGAGCCTCCTCATTCTGTGCTTCCTATACCAGGCTTCCTAACTTCGAACCAAACGGCTTATAACCTTCAAAACGCAGAGGAACGTAGTAATATGATCAACACGATGCTACCTATAAGTGGTGCAAATGAAACGCGTACCATGAAAGAGACTATTGAGTCGACGACTTCTGTGAATTCTGGCAGTGGGGTGCGTAACACCCATCATTCTTCAGATCTTTTTGTATTGTCTCCTACAACTCGATTTCACTCCGGTACTACACCAAATTCTGACTTCCCGTCAACGAATTTTGGCGCCCCTACTCTATCAGTATTTGCCCATAGCACAGATTCTGCTAATTATCCACTTCATATTCCTTCAAGTAAGTGGATATCTTCACTCACGGCGCAACCGTCTCCAGGACCGGTAGGTCTTCCAATATCTACGTCCACATCTTTGCAATTCGAGTCAAGATCTGCAAAACAGTCAATATATGACCCACAGTCACAAAAATTGGACTCTATCGCCTCACAAAGCACTGGGAGTGGCACATCTGAGAGTTTTGAAGCCATGTTCGAGACAGCTAGGAGTGAGGAGACTCCCGCTTATCTGGAAAAAATCGGCCACTCATCCGACACTACTACCAAGTCATCCCGCGGGGTAGCCCACAGAGAAACACTGGTCATCACAGGTATGCGTGGTAGACTTGTTGATCAGAATGTCGTCATAAGAACGAGTCAGGTTGAAGATGGAAAAGGGCCAGACGCAACATTCTCCCCGATCTACAGAGTCCAAAATTCTGAGGACTATACGACAAGCAAAATGAAGACTAGCATTTTGACGAACAAAGGGTTTCCACAAGTAATGAGAACAGACGCAACTCTAAGAGAGACCAAAGAAACTGAAACAATATGGGGACTCAAGCCGACCAATACGATCCGACAGCGTCCTGCACAAATTTCCCACCTGAGCGCGGAGCCTGCACTGCCTTCACTTCCTACTTCATCTCAAAGCATCCCATGGAATGAAGAACAAAGTGAAAGTTCAACAGGGCATACACCGCAATTGGCAATGTTTTCTAACGATACCCTCTCTATTTTTTATGCAGAGCCGCAAAGCGCTTATAAGGCTTCAACAGACAAAGATAAACATGCCAAAGGTATAGCCGCAATAATTCGATCTGTTCAGTTGAGTTTAATCACCGAGTCAAATTTTGCACCTGGCAGGTATAGCCAAAAACCTAGAACTGCAGCAAGCATAGATGGTGATTTGAAATCTGATTTTGATCTTATTGATTGGCAAGCTTCTCGACACGGCAAAGTTGACGTCGGCCATAAGTGTGATATGAATTCGACAGTCTGTACAGCAAACGCGAGTATCGAAGCCGACGTCAATATTGGACTCCTCGGCGCTCCGTCTGACGCGTCTACTGCTGCTGCAGGCAATCGTTCTGTGGAGGACATAAATACCCCAGCCATAGAAGACTCATATAGTACAACCTCAATCTTTGTAAAAGTACACAATGAATTCACCGCGGCATCAATGCCGGTAGAAAGCGCAAAGCCACAGAAAACTGGTCATGTCGAGTCAGCGATTCACATGTCTCATACACGATCCAAAAACTCGATTTTTCTTCCACAACCAACATCACAGCCATCGGGACTGCAGCACAGCATCGCTGCTCAAGCACCACCGGCTATACGGCAAACCCTAGTGCTGCTTCTAACTTTATTTGTATTCTTTAACTAA",
    "translation": "MVDQSTLDEYGTISGVLRLSAILNPRVIKKERSRKFEVASANFGQISFLSEEVTIIRPQLQRSCTWIPVPDGARTLFFTCTITLPTGYQWSKLVLSDEIVRGNATFVSATFIEEEIANQHKPKLVSLSLYDENTSKNYELRMRSLTLDGSRNRYHLEITYQSHLDPDKPRSFVGIAKVTSTHYRFHRESYLHPYTARIPLITQEELLNQTKWAPSEHLPIPAYIIMDADHEGLAPRPLLVGPEDQSNGTNNSIPVGSAEEHLQNSKSKHTFSPLYHHVDIITLHESTNETKATDSSRNELHTDSITTPFTEKTFTVNTTTRDVEPPHSVLPIPGFLTSNQTAYNLQNAEERSNMINTMLPISGANETRTMKETIESTTSVNSGSGVRNTHHSSDLFVLSPTTRFHSGTTPNSDFPSTNFGAPTLSVFAHSTDSANYPLHIPSSKWISSLTAQPSPGPVGLPISTSTSLQFESRSAKQSIYDPQSQKLDSIASQSTGSGTSESFEAMFETARSEETPAYLEKIGHSSDTTTKSSRGVAHRETLVITGMRGRLVDQNVVIRTSQVEDGKGPDATFSPIYRVQNSEDYTTSKMKTSILTNKGFPQVMRTDATLRETKETETIWGLKPTNTIRQRPAQISHLSAEPALPSLPTSSQSIPWNEEQSESSTGHTPQLAMFSNDTLSIFYAEPQSAYKASTDKDKHAKGIAAIIRSVQLSLITESNFAPGRYSQKPRTAASIDGDLKSDFDLIDWQASRHGKVDVGHKCDMNSTVCTANASIEADVNIGLLGAPSDASTAAAGNRSVEDINTPAIEDSYSTTSIFVKVHNEFTAASMPVESAKPQKTGHVESAIHMSHTRSKNSIFLPQPTSQPSGLQHSIAAQAPPAIRQTLVLLLTLFVFFN",
    "product": "hypothetical protein"
   },
   {
    "start": 15430,
    "end": 16848,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001683",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001683</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001683</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001683-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,430 - 16,848,\n (total: 1419 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001683\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001683\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTGTTTTGACCTTGGGTTTATGGGTCTTCATACAAAGCGCTTTCGCGCAAAGTAGTTACCCTGCTAATTTTTCAATTGAGAGGGCTGAAATATATAAGCATCCAAAACAAGATAATAATCATACCTCACCAATCCACATTAGTGATATTCTTACAGTGAAACTTCACTGGAGTCTCTACAATGCGACATTGGACAACTATGTCGCATTACAACTTGATCGAGCTCTGCAAATAATTCAGCCCCAAACACTTGAAATAATTGGTAGAAGTGGGGATCAAAAACCTGTTTTAAAGCTTGCGACATGCAACGAATTTCAATTAAGTGCAGGGGTGATTTTTTGCCCGCTCGATGAAGTCCCGCAGAAAATATTGAATGAGTACGGCACCTTGAACGGTTTCATTCATGTGGAGGCGACGCTGAACTCAAACTTCATCGGTGATGGCGCCCATAGAGTTTTTGAATTCGCAAACGCGAATTTCGATCAGGAATACGCTTATTCTGCGGATATAGCTATCGCTAGACCAGAGAATTATGAGAAAGTCACTATACCTGAATCGAAAATGCAGAGAACTTGCTCCTGGGGACTTCCGGCCGATGGCTACTACGACAAGGTTTTCGTTTGCACAATTAGCTTTCCTATCGGATATAATCTGTCCCGAGTCTTGGTTTCCGACAACATTCTGAGAGGAAACGCTAGACCTGTCGGCGCCGTATTCATACAAGAAGATGTGAATGATCTTAAAAAGCAAACCTTTGTGTCGATTGCGCGGTACAAAGAGACCTATGCACGTCGTGGTTACGAATTACGTATGCGGCCCCTCGTTGACGAGACTTTAGATGGATCGAAATACCGATATCGCCTTGCTATAACATACGAGTCACATCACGGTACTGATGATGTCAAAGGTTTTGTGGGAATAGCGAAAATCAGAAGTAAGGATTACGGCTTTGAGCAAAAATCTTATCTGCCTCCATTTTCAACGTGGAAGCGAATTTTCCCCCACATATGCAAGAATGATCATGAAGAATGGTTGTCTGCCTCCATTCAATATCCTTTGATCCCATCCGAACAAATTCAATTGCCGGCATATTCAGTCATGGCTGGGTCTCATAGGGACCAGCTATCATTTCCACTCTCAATTGGTTCAGAGGAGCAAGGTGAGTGGACCACCCCTAAATCAACGACGAATTCGTCGGACAGAGACCCACAAAGTATCGAGATCAAGCATAGTCTGTCCCCTCTACATTTCCACATGAATCGTACAATGTTGTATGAAGCCCCAAAAGGTAAAATAACAGCCACGACCCACTCCAGAATGGAGTTTTCACATGTGCGGTCTCGGCGTTCACAGGTGACACAAGGCCGACAAGCACGACACCAAAAGCTCAAAACAGTCAATCTCAATCTTTCTTGA",
    "translation": "MGVLTLGLWVFIQSAFAQSSYPANFSIERAEIYKHPKQDNNHTSPIHISDILTVKLHWSLYNATLDNYVALQLDRALQIIQPQTLEIIGRSGDQKPVLKLATCNEFQLSAGVIFCPLDEVPQKILNEYGTLNGFIHVEATLNSNFIGDGAHRVFEFANANFDQEYAYSADIAIARPENYEKVTIPESKMQRTCSWGLPADGYYDKVFVCTISFPIGYNLSRVLVSDNILRGNARPVGAVFIQEDVNDLKKQTFVSIARYKETYARRGYELRMRPLVDETLDGSKYRYRLAITYESHHGTDDVKGFVGIAKIRSKDYGFEQKSYLPPFSTWKRIFPHICKNDHEEWLSASIQYPLIPSEQIQLPAYSVMAGSHRDQLSFPLSIGSEEQGEWTTPKSTTNSSDRDPQSIEIKHSLSPLHFHMNRTMLYEAPKGKITATTHSRMEFSHVRSRRSQVTQGRQARHQKLKTVNLNLS",
    "product": "hypothetical protein"
   },
   {
    "start": 17422,
    "end": 18723,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001684",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001684</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001684</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001684-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,422 - 18,723,\n (total: 1302 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 159.8, e-value: 9.4e-47)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.3, e-value: 7e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_001684 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001684\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001684\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGAAGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACCATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGGACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGCAACTCCTAGGTCCATTGCTCCTGAGCAGTAA",
    "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWEGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDHDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLDLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKATPRSIAPEQ",
    "product": "hypothetical protein"
   },
   {
    "start": 19407,
    "end": 21044,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001685",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001685</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001685</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001685-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,407 - 21,044,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001685 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 64.0, e-value: 1.8e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001685\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001685\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATCTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGCTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAGAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACGCAGAGGGAGCCATGGGTGAAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTATTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACTACATGGAAACATACTACACAAGGTACATTTGGCGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGGCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATATTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
    "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLLVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFRTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHAEGAMGESVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTTWKHTTQGTFGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
    "product": "hypothetical protein"
   },
   {
    "start": 21958,
    "end": 23710,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001686",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001686</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001686</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001686-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,958 - 23,710,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75.6; E-value: 5.2e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001686 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.2e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.9e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_001686 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 667.1, e-value: 3.4e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001686\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_001686-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001686\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATTGCAGCATACGTGAAACGTATTGCACCGCAAGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTGGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCGCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
    "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPQVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSASDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
    "product": "hypothetical protein"
   },
   {
    "start": 25815,
    "end": 26123,
    "strand": -1,
    "locus_tag": "MARS52BIN25_001687",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_001687</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_001687</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_001687-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,815 - 26,123,\n (total: 309 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_001687\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_001687\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGTGCAGAGGCTGCAACACAGTGGGAGCCTTCCCCGGCCGTTACAGGCCAACCTTCGTCCAGCAATGTGCGAAAACGAAAGCTGAAGGAAGCGGAAGAGGAAGAAAGGGAGAGGAAAGAGCTTCGAAGGAATGGAGCCGATGCGAAGCTGGAGTTTGCCAGAAGTCGTCGCATCATGCAAGAAAATCAGAGAGACATGCAGAGCAGATTGCTGCAAATGCTGGAAACTCGATTCCCTCCCCTGACGACCTCGACCGCCGAAGCAGCTGACAAACAGGGTGAACGCGATTCGCCTTCCGACCAATAG",
    "translation": "MRAEAATQWEPSPAVTGQPSSSNVRKRKLKEAEEEERERKELRRNGADAKLEFARSRRIMQENQRDMQSRLLQMLETRFPPLTTSTAEAADKQGERDSPSDQ",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 17421,
    "end": 18723,
    "tool": "rule-based-clusters",
    "neighbouring_start": 7421,
    "neighbouring_end": 28723,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r15c1"
 },
 "r40c1": {
  "start": 15010,
  "end": 36945,
  "idx": 1,
  "orfs": [
   {
    "start": 16655,
    "end": 18205,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003073",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003073</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003073</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003073-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,655 - 18,205,\n (total: 1551 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003073\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003073\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACCGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAAGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACAATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATGCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
    "translation": "MNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRPRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYKNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIQWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIACCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
    "product": "hypothetical protein"
   },
   {
    "start": 18215,
    "end": 18889,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003074",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003074</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003074</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003074-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,215 - 18,889,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003074\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003074\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCTATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
    "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
    "product": "hypothetical protein"
   },
   {
    "start": 18961,
    "end": 19866,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003075",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003075</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003075</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003075-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,961 - 19,866,\n (total: 906 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003075 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [1:109](score: 50.5, e-value: 1.8e-13)<br>\n \n  PF03473.20 (MOSC domain): [159:288](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003075 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003075\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003075\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATAGCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGCGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAAAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTGGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTGGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
    "translation": "MHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDSEELVLAFDGIAQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
    "product": "hypothetical protein"
   },
   {
    "start": 20079,
    "end": 21383,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003076",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003076</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003076</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003076-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,079 - 21,383,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003076 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003076\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003076\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATCGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTGCGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
    "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGIGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLATPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
    "product": "hypothetical protein"
   },
   {
    "start": 21653,
    "end": 22684,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003077",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003077</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003077</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003077-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,653 - 22,684,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003077 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [27:235](score: 122.2, e-value: 2.5e-35)<br>\n \n  PF03129.23 (Anticodon binding domain): [255:302](score: 21.1, e-value: 0.00029)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003077 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003077\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003077\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCGTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
    "translation": "MTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
    "product": "hypothetical protein"
   },
   {
    "start": 22947,
    "end": 24926,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003078",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003078</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003078</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003078-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,947 - 24,926,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003078 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003078 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003078\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003078\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTCCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
    "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
    "product": "hypothetical protein"
   },
   {
    "start": 25010,
    "end": 26945,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003079",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003079</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003079</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003079-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,010 - 26,945,\n (total: 1407 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [65:356](score: 129.0, e-value: 2.5e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [56:406](score: 425.1, e-value: 4.4e-128)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003079 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003079\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_003079-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003079\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCCCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTACAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAACGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTTTGATGATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
    "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPATFQRNVKITKGEACALMMQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
    "product": "hypothetical protein"
   },
   {
    "start": 27406,
    "end": 29298,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003080",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003080</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003080</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003080-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,406 - 29,298,\n (total: 1893 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 56.4; E-value: 3.8e-17)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003080 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [124:159](score: 23.4, e-value: 8.4e-05)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003080 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003080\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003080\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGGGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGAGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGTTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGTGAATAG",
    "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKGRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQSE",
    "product": "hypothetical protein"
   },
   {
    "start": 30399,
    "end": 31238,
    "strand": 1,
    "locus_tag": "MARS52BIN25_003081",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003081</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003081</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003081-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,399 - 31,238,\n (total: 774 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003081 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [99:223](score: 118.9, e-value: 1.6e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003081 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003081\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003081\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTGAACTAATGAAAGCGAACGCCACGTCACTAATGCCAGTGGGAGCTCCTGGCATGCCCACTAATTTCGACAACTCAAACCTTCACAAAAGTCAAGCTTCTTTCCCCCCGTCTTCGCCTGCTGGCTCTCTGCAAGGCAACAATACGAGCATATCGGTCCAAGACCGATATGGGTTGCGTGGCCTCTTAAGTATCATTCGCATGGACAATCCGGATGCGAGCATGCTGTCTCTAGGCAGCGACCTGACTAGCCTTGGCCTGAATTTGAATCAGCCCGACGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAGCAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
    "translation": "MSELMKANATSLMPVGAPGMPTNFDNSNLHKSQASFPPSSPAGSLQGNNTSISVQDRYGLRGLLSIIRMDNPDASMLSLGSDLTSLGLNLNQPDDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
    "product": "hypothetical protein"
   },
   {
    "start": 31337,
    "end": 32085,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003082",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003082</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003082</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003082-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,337 - 32,085,\n (total: 711 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003082 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [30:233](score: 294.3, e-value: 4.8e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003082 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003082\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003082\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGGGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGACATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
    "translation": "MKTLATTSLALSLCLVCGVVGQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
    "product": "hypothetical protein"
   },
   {
    "start": 32200,
    "end": 33447,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003083",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003083</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003083</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003083-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,200 - 33,447,\n (total: 1173 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003083 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:353](score: 70.0, e-value: 2.3e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_003083 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003083\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003083\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCGGTCTCGCCTGAAATCGCCAAACGTGCCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACATTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTTGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAATTCTCTACGTCGAACCACGCTCGAGACTTTCGGGAGAAGGTTGTGTCTCTTGTACCCAAGGAGCCCAGAGCATCCAGCAGCCCGGCCAAACAAGGCCCGCCATCCCCAACCACCAACCCCACCACCACGGCGCAGGAGGACGCGTCGAGCAAAGACTAA",
    "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRAEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKFSTSNHARDFREKVVSLVPKEPRASSSPAKQGPPSPTTNPTTTAQEDASSKD",
    "product": "hypothetical protein"
   },
   {
    "start": 33559,
    "end": 36274,
    "strand": -1,
    "locus_tag": "MARS52BIN25_003084",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_003084</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_003084</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_003084-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,559 - 36,274,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_003084 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [8:195](score: 131.1, e-value: 3.6e-38)<br>\n \n  PF00106.28 (short chain dehydrogenase): [313:496](score: 146.2, e-value: 8.9e-43)<br>\n \n  PF01575.22 (MaoC like domain): [769:879](score: 113.0, e-value: 6.8e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_003084\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_003084-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_003084\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCGATCTACGGTTCGATGACCAGGTAGTCGTAGTCACTGGTGCTGGTGGAGGCTTGGGCAAGGCGTACGCGCTTTTCTTCGCCAGCCGAGGTGCGAACGTGGTTGTTAATGATTTGGGTGGCAGCTTTCACGGAGAAGGACAGAGCTCAAAGGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCATGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGAATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGTAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCACTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAAAAGACTCAGAAAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTATTGAAAATATAAGTAATCGTACCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTATTTGAAGTCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTAAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
    "translation": "MPDLRFDDQVVVVTGAGGGLGKAYALFFASRGANVVVNDLGGSFHGEGQSSKAADLVVDEIKKAGGHAVADYNNVQNGDQIIETAVKEFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQKMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIIENISNRTGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEVSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 25009,
    "end": 26945,
    "tool": "rule-based-clusters",
    "neighbouring_start": 15009,
    "neighbouring_end": 36945,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r40c1"
 },
 "r85c1": {
  "start": 1,
  "end": 38397,
  "idx": 1,
  "orfs": [
   {
    "start": 42,
    "end": 2081,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004291",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004291</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004291</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004291-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42 - 2,081,\n (total: 1938 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 273.3; E-value: 5.9e-83)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00083.27 (Sugar (and other) transporter): [139:593](score: 291.3, e-value: 1.4e-86)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00879 (SP: MFS transporter, sugar porter (SP) family): [135:589](score: 280.5, e-value: 5.5e-84)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004291 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004291\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMFTDGSFPYFVSQLRVSFHNMSTKMYTSLSTQEIGTSSKSEVEHAPITSTTTLLNSSTGTRIENPLADVSRDELMRQVAEFAGENGLLHALPLLQKGALVAQRPTEWDAIPELDEDDRAALEYEFLHKWRQTKDLYITILVCSVGAAVQGWDQTGSNGANLSFPLEFGINPVAGEPNYERNSWLVGLVNCAPYIAAALLGCWLSDPLNHYFGRRGTIFFSAVFCCFSVIGSGFARNWEELVFCRVLLGIGLGSKASIVPVFAAENSPAAIRGGLTMGWQLWTGVGIWLGYSANLAVFNTGAIAWRLQLGSAFIPTIPLLFGVYLCPESPRWYLKKGRYVDAYKSLCRLRKTQLQAARDLYYIHAQLMEESKITRGAGYVARFIELFSIPRNRRASAAAFTVMVAQQLCGINIISFYSSTIFVTAGASDFKALCIAFGTGIIGPVAALLAVYTIDTFGRRNLLLITFPNMAWQLLAVAFSFYIPKENDAHLIVVSVFIFLFSTTYSIGGGPVPFAYSAEAFPLSHREIGMSFAVATNNLFAAILSLTFFRISAVFGISGAFFFYAGLNVLAFIMIFFLVPETKQRTLEELDYVFGPTTVHIKYQVTQAVPYFIRRWVCFDKSAKLEPLLQLHSDMDAENLREKLRN\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004291\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTCACGGATGGGAGCTTTCCCTACTTCGTGTCGCAGCTACGGGTATCCTTTCACAACATGTCCACCAAGATGTACACGTCTCTTTCGACCCAGGAGATAGGGACGAGCAGCAAAAGCGAGGTCGAGCATGCACCCATCACGTCCACCACCACCCTCCTCAACTCAAGTACAGGCACAAGGATAGAAAATCCGCTTGCAGATGTTTCTCGAGACGAGCTGATGCGACAAGTGGCGGAATTTGCAGGGGAAAATGGTCTACTACATGCCTTGCCATTGCTGCAAAAAGGCGCGCTTGTCGCGCAAAGACCTACGGAATGGGATGCAATCCCTGAACTTGATGAGGATGATAGAGCTGCCTTGGAGTATGAATTCCTGCACAAATGGCGCCAAACAAAGGACCTGTACATCACTATATTGGTCTGCTCGGTTGGAGCAGCTGTTCAGGGCTGGGACCAAACAGGATCCAACGGTGCGAATCTTTCTTTCCCGCTGGAGTTTGGAATTAATCCTGTTGCTGGAGAGCCAAATTACGAAAGGAACAGCTGGCTAGTGGGACTCGTGAACTGTGCACCTTATATCGCCGCTGCACTTCTCGGCTGCTGGCTGTCAGACCCCCTGAATCACTACTTTGGCCGTCGTGGGACGATATTTTTTTCTGCTGTCTTTTGCTGTTTCTCCGTGATTGGTTCTGGGTTCGCAAGAAACTGGGAGGAACTTGTTTTCTGTCGGGTGCTTCTTGGAATCGGACTGGGCTCAAAGGCTTCTATTGTTCCTGTCTTTGCTGCGGAAAATTCGCCGGCTGCTATCCGGGGTGGCCTTACGATGGGCTGGCAGCTGTGGACGGGAGTGGGAATCTGGCTTGGCTATTCTGCAAATTTGGCTGTTTTCAATACTGGAGCCATCGCTTGGCGGCTTCAACTAGGGTCTGCATTCATACCTACGATCCCTTTGCTGTTCGGAGTCTACCTTTGCCCAGAATCTCCACGATGGTATCTTAAAAAGGGTAGATATGTGGATGCGTACAAGTCTCTGTGTAGATTGCGAAAGACACAACTACAAGCTGCTCGGGATCTATATTACATCCATGCCCAACTCATGGAGGAGTCAAAAATTACAAGAGGAGCAGGTTATGTGGCGCGATTCATCGAACTCTTCTCCATTCCCCGAAATCGACGAGCGTCTGCTGCCGCATTCACAGTGATGGTGGCTCAGCAACTATGCGGCATCAATATCATTTCCTTCTACTCGTCAACAATATTTGTGACGGCAGGAGCCAGTGACTTCAAAGCTCTATGTATTGCGTTTGGCACAGGTATTATTGGGCCAGTTGCTGCATTACTTGCGGTATATACGATCGACACCTTTGGTCGCAGAAACTTGCTTCTCATCACCTTCCCAAACATGGCTTGGCAGCTGCTTGCGGTAGCTTTTAGCTTCTATATTCCAAAGGAGAACGACGCGCATCTCATAGTGGTATCTGTGTTTATCTTCCTCTTCTCTACCACATACAGTATTGGCGGGGGCCCAGTTCCTTTTGCTTATTCAGCAGAGGCGTTTCCGCTGTCGCATCGTGAAATCGGAATGAGCTTTGCAGTGGCGACAAACAACCTTTTCGCGGCAATCTTATCGCTCACTTTTTTTCGCATATCTGCTGTATTTGGCATAAGTGGTGCTTTTTTCTTTTACGCCGGACTGAACGTGCTTGCTTTCATCATGATATTCTTCCTGGTGCCCGAGACAAAGCAACGTACATTAGAGGAGCTTGATTACGTTTTTGGCCCTACCACAGTCCACATCAAGTATCAGGTTACGCAAGCAGTCCCATACTTTATCAGACGCTGGGTATGCTTTGACAAGTCGGCAAAACTGGAACCGCTGTTGCAGCTCCACAGCGACATGGACGCTGAAAATTTACGAGAGAAACTGCGAAATTGA",
    "translation": "MFTDGSFPYFVSQLRVSFHNMSTKMYTSLSTQEIGTSSKSEVEHAPITSTTTLLNSSTGTRIENPLADVSRDELMRQVAEFAGENGLLHALPLLQKGALVAQRPTEWDAIPELDEDDRAALEYEFLHKWRQTKDLYITILVCSVGAAVQGWDQTGSNGANLSFPLEFGINPVAGEPNYERNSWLVGLVNCAPYIAAALLGCWLSDPLNHYFGRRGTIFFSAVFCCFSVIGSGFARNWEELVFCRVLLGIGLGSKASIVPVFAAENSPAAIRGGLTMGWQLWTGVGIWLGYSANLAVFNTGAIAWRLQLGSAFIPTIPLLFGVYLCPESPRWYLKKGRYVDAYKSLCRLRKTQLQAARDLYYIHAQLMEESKITRGAGYVARFIELFSIPRNRRASAAAFTVMVAQQLCGINIISFYSSTIFVTAGASDFKALCIAFGTGIIGPVAALLAVYTIDTFGRRNLLLITFPNMAWQLLAVAFSFYIPKENDAHLIVVSVFIFLFSTTYSIGGGPVPFAYSAEAFPLSHREIGMSFAVATNNLFAAILSLTFFRISAVFGISGAFFFYAGLNVLAFIMIFFLVPETKQRTLEELDYVFGPTTVHIKYQVTQAVPYFIRRWVCFDKSAKLEPLLQLHSDMDAENLREKLRN",
    "product": "hypothetical protein"
   },
   {
    "start": 2167,
    "end": 2412,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004292",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004292</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004292</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004292-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,167 - 2,412,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004292\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004292\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTTGGAAAGCCGTACATGGTGGATATTGTGGAGAAGCCCGGTGGTCAAGGAAATGACGACCCCGTCTTGCTGGAGGATATCCTGGGAGAACCCAAGCCCGACCGCTTCAAACGCGCATCATTCATCCGCGAAGGTGCCATATCAGTGCTCGTTGGCGCAGGTGGCAACCTTTCGATGCGGACTGGTGAAGCCGTCAATCTGACCGACCTCGTCAAGTTTTTGGTTGCATTCGTTACACCATAG",
    "translation": "MFGKPYMVDIVEKPGGQGNDDPVLLEDILGEPKPDRFKRASFIREGAISVLVGAGGNLSMRTGEAVNLTDLVKFLVAFVTP",
    "product": "hypothetical protein"
   },
   {
    "start": 3065,
    "end": 4389,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004293",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004293</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004293</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004293-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,065 - 4,389,\n (total: 1161 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1169:sugar transport protein (Score: 225; E-value: 2.8e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00083.27 (Sugar (and other) transporter): [0:347](score: 211.4, e-value: 2.5e-62)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00879 (SP: MFS transporter, sugar porter (SP) family): [0:343](score: 247.3, e-value: 6.3e-74)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004293 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF00083.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004293\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004293-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSPSYASEVCPVALRGYLTTFVNICWLIGQFIASGVLDGMVGVTSGWGYRIPFAIQWIWPIPLFIIVLYAPESPWWLVRKGRLREAERSVERLSAKNSKISARQTVAMMVHTNDLEKELQTGHSYADCFKGSDRRRTEICCMAWTVQYLSGFGIQGYTTYFFEQAGLAAENAYKMTLAYFAIGFVGTVLAWFLMMNFGRRTIYVSGLAILTTIMFIIGFLSLAPESNKGAQWAVGVMLIIWVFFYDFTIGPVGYAIFGETSSTRLRTKSIALARILYALVSIVGSIVTPYVSLPPCLYRYMLNPGEGNWKGKAAFLSGGISLCCFAWGFFRLPECKGRTYEEIDILFERKVPARQFKGYKVDAYEHTNLLKEDSIKKEATLSTTLS\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004293\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCCCTCGTATGCTAGCGAGGTTTGTCCAGTCGCGCTTCGAGGGTACTTGACTACTTTTGTGAATATTTGCTGGCTCATTGGCCAATTCATAGCTTCTGGAGTGCTGGACGGCATGGTGGGTGTCACCAGTGGATGGGGCTATCGCATTCCATTCGCTATTCAATGGATCTGGCCGATCCCTTTGTTCATTATTGTCTTATATGCTCCCGAATCCCCTTGGTGGCTTGTACGGAAAGGCCGACTTCGTGAGGCCGAACGTTCGGTAGAGAGACTATCTGCAAAGAACTCAAAAATCAGCGCAAGACAGACGGTTGCCATGATGGTTCATACAAACGACCTTGAGAAAGAGTTGCAGACTGGACACTCTTATGCTGATTGCTTCAAAGGATCTGATCGTCGCCGGACAGAAATATGCTGCATGGCATGGACTGTTCAATACCTCAGTGGATTTGGGATTCAAGGCTACACGACTTATTTTTTTGAGCAAGCAGGATTGGCTGCTGAAAATGCATACAAGATGACCCTTGCGTACTTTGCCATTGGATTCGTGGGAACTGTGTTGGCCTGGTTCCTCATGATGAACTTTGGCCGGCGTACAATTTATGTCAGTGGGCTAGCCATACTGACCACAATTATGTTCATTATTGGCTTTCTTTCGTTGGCACCCGAATCCAACAAAGGTGCCCAGTGGGCGGTAGGTGTCATGCTTATCATTTGGGTATTTTTCTATGACTTTACGATTGGCCCAGTGGGCTATGCAATCTTTGGAGAGACTTCCTCGACCCGCTTACGCACCAAATCCATAGCTCTAGCACGGATTCTCTATGCCCTGGTGAGCATTGTTGGAAGTATCGTAACACCGTATGTCTCTCTGCCGCCATGCTTATATAGATACATGCTGAACCCGGGTGAGGGAAACTGGAAAGGCAAAGCCGCATTTCTCAGTGGAGGCATATCTCTTTGCTGTTTTGCCTGGGGATTTTTCCGCCTTCCCGAGTGCAAGGGCCGCACGTACGAGGAGATTGATATTCTCTTTGAGAGGAAAGTGCCCGCGCGACAGTTCAAGGGCTACAAGGTTGATGCGTACGAGCATACCAATCTGTTGAAGGAGGACAGCATTAAAAAGGAAGCTACGCTGTCCACAACTCTATCGTAG",
    "translation": "MSPSYASEVCPVALRGYLTTFVNICWLIGQFIASGVLDGMVGVTSGWGYRIPFAIQWIWPIPLFIIVLYAPESPWWLVRKGRLREAERSVERLSAKNSKISARQTVAMMVHTNDLEKELQTGHSYADCFKGSDRRRTEICCMAWTVQYLSGFGIQGYTTYFFEQAGLAAENAYKMTLAYFAIGFVGTVLAWFLMMNFGRRTIYVSGLAILTTIMFIIGFLSLAPESNKGAQWAVGVMLIIWVFFYDFTIGPVGYAIFGETSSTRLRTKSIALARILYALVSIVGSIVTPYVSLPPCLYRYMLNPGEGNWKGKAAFLSGGISLCCFAWGFFRLPECKGRTYEEIDILFERKVPARQFKGYKVDAYEHTNLLKEDSIKKEATLSTTLS",
    "product": "hypothetical protein"
   },
   {
    "start": 5332,
    "end": 6708,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004294",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004294</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004294</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004294-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,332 - 6,708,\n (total: 1377 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004294 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07350.15 (Protein of unknown function (DUF1479)): [19:431](score: 407.9, e-value: 4.7e-122)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004294\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004294\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAACGAACGAACACGCCAACGGAGCATTGCCATATGCCGACAAGGATTTGCCTCGCCTTGATTCGCGGTTTGCGGAAATAAAAAAGATTATCATCAAGCCAGAGAATGTTGACGAGGTACGGCAATCCTACGCACGCTTACTCGTCGCTCTGCAGAAGGAGGCTGACAGGATCAAATCGCTCGCTCGCGACGTCATCCCGCAAATCCAGTGGAGCGAGATTGCAGCCAATGGCGACCGACTCCCTTCGCAGGTTTTGCAGGCGGCCCGCGAATCCGGGTGTTTGATTGTGCGGGGGGTGATAGATCGGCAGACCGCCATCAGGTGGAAAGACGAGCTGCGCGCTTACTGCCTTGAACATCCCAAAAATGGGCGCCCGTCCTCTATCTGGCCGTACCATTGGACGCGGCCAAAGATGCAGTCGCGCAGCCACCCTGACACCATTCGTGTGGTCAATGCGGTGAGTATGCTGTGGCACCCCGCCAGTGATCAAACCCCCGTCGACCTCTCCAGCCATGTCGTGTACAGCGACCGCTTCCGCATCCGCTATCCCGAGGATGGCGAGGGCACGCTCCCGCCGCATCAGGACAATGGGTCTGTGGAGCGATGGGAGGATCCTACTTACAGAAAGTACTATGCAAAAATATTTGAAGGCACATGGGAGGAATTTGATCCGTGGATGCTCGACGATCGTGTAGACGCCAATATCGACATGTACCGTGACTCCCCTTGCCAATCCGGTTTCCGATCGCTGCAAGGCTGGCTGGCGCTCTCGCAGACCAATGTCGGCGAAGGCACGCTACGGCTGGTGCCAAACCTGAAACTGGTTACGGCGTACATCATGCTGCGCCCATACTTTATGCAAGGTAGTGACGCATTTGACGACGCCAGCTCCGTCTTCCCTGGCTGTGTGGTCAAAGACGGCCAATTTTACCCCACTGAGCAGTTCCACCCGCATCTGCGCTTACAGGACACGATGCTCAATATCCCGCCCATCGAGCCGGGCGACTTTGTCTTTTGGCATTGCGACCAAGTGCATGACGTGGATCGCATTCATCGTGGACCCAAGGGCAAAGACTCTTCTGTCATCTACATACCCGTTGCCCCACTCTGCGATGAAAACATCAAGAATATGATGCATCACCGCACCGCCTTTGAGCAATGCAAGCCTATTGACGACTTCCCCAACGAGGCAAAGAATATCAAGGATGGGGTCGAGGCACAGCATGTGAATCACGGAGCACGGAGAGAGAATATCATGACGGAGGAAGGATTGCGCGCACTTGGATTGGCTCCTTTCGACGTAAGCGAGCATGGTCTCTCGCAGGGTGCGCGAACTATTCGAGAGCGCGCCAACTCTGCCATGAAGGCCTAG",
    "translation": "MTTNEHANGALPYADKDLPRLDSRFAEIKKIIIKPENVDEVRQSYARLLVALQKEADRIKSLARDVIPQIQWSEIAANGDRLPSQVLQAARESGCLIVRGVIDRQTAIRWKDELRAYCLEHPKNGRPSSIWPYHWTRPKMQSRSHPDTIRVVNAVSMLWHPASDQTPVDLSSHVVYSDRFRIRYPEDGEGTLPPHQDNGSVERWEDPTYRKYYAKIFEGTWEEFDPWMLDDRVDANIDMYRDSPCQSGFRSLQGWLALSQTNVGEGTLRLVPNLKLVTAYIMLRPYFMQGSDAFDDASSVFPGCVVKDGQFYPTEQFHPHLRLQDTMLNIPPIEPGDFVFWHCDQVHDVDRIHRGPKGKDSSVIYIPVAPLCDENIKNMMHHRTAFEQCKPIDDFPNEAKNIKDGVEAQHVNHGARRENIMTEEGLRALGLAPFDVSEHGLSQGARTIRERANSAMKA",
    "product": "hypothetical protein"
   },
   {
    "start": 6753,
    "end": 9119,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004295",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004295</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004295</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004295-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,753 - 9,119,\n (total: 2367 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004295 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16334.8 (Domain of unknown function (DUF4964)): [26:88](score: 38.5, e-value: 7e-10)<br>\n \n  PF17168.7 (Domain of unknown function (DUF5127)): [108:351](score: 177.6, e-value: 3.5e-52)<br>\n \n  PF16335.8 (Domain of unknown function (DUF4965)): [421:600](score: 217.8, e-value: 7.9e-65)<br>\n \n  PF08760.14 (Domain of unknown function (DUF1793)): [605:778](score: 219.7, e-value: 3.2e-65)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004295\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004295\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGGCCACCGTATGGAAGGCTGTCTTGCTGGCCGGGCTGGCCCTTGGCAAATCGCAGCCACTGTACTCCCCCGCTCGCCCACCAGCGGTGCCATTGGCTGTCCGCAGCCCATACACGTCCACCTGGTCGAGCACCGCAAAAAACGCCACTCTCAACAGCGCTGACCCTATTTTCTGGGACGGGACAAGTATTGGCTGGGAGGGCTTTGTTGCTGTGGACGGCATTGCCTATGAATACCTCGGTAGTGCGAGGTCTGGCCTGCCCCCCACCAATTTCATCAAGCAGGCCAACCAGACTCGTCTGGACTATGACTCGTCTTACTCCAACTTCACCTTCATGGCCGGTCCGGTACAATTAAATGTGGATTTTTTGTCGACTGTCTATCCGCAGGATATATGCCGCACCAGTATTCCTCTCTCCTATCTAACGGTCTCGGCAACTTCCATGGACGGTGGAAGCCACAACGTACAGCTTTACAACGACATCAATGGAGCATGGATTTCTAAGGAGTCGAATGCGACCCTGCAATGGGACCTTTTCAACAATGGCCAAAACGTCACCACAAGTTCTGGCAGCAACTCCAACTCGAATGTGTTTTCCTGGATTGTTGCTCTCGAGAAGCAGTATACGTTTGGAGAGCTGTTTAACTTTCCTTTATGGGGCAAGCTGACGTTCAATACCATGACTAATGGTCACAAGATGTCCTACCAAGCTGGAAATGCATTGGCTGTGCGATGGAACTGGATTTCCAACCGCACTCTCACGAACACAATTGACCGCAGTTTTCGCGGATGGGGACAGGGGTCACCAGTCTATGCTTTTGCACACGACCTCGGCAGTATTTCTGGGACCGAATCCGTAACATACACTGTTGGTTCCGTCCAGGACCCGGCGATAAGGTATCTCGACAACTCGGGAGTGCAAGGCCTTCATCCGTACTGGCAACACTGCTATGGTAATGATCTTTTCAATCTCATCAGCACGCATTTTAACGATCTCTCGCAATCAGCAGCTCTAGCTGCTGAATTTGAGTCGAAGCTCAAAGCAGATGTGAATTCGTACTATGCTGCCGAGGGTGCCATGGTCTACTCCAAAGGAGGTGAATCGAGAGGGCCCATGTTTGATCAATTCAACGGAACTGATCAAACCTACATTAACAACCAACAAGTGCAGGAATATTTCACGTTCAACCCTTTCAACGGGTATGGATTCCTCAACTCCAACAACTTTTCCAACATACCAATCCCTGATGTCACTGAAAGCCAGGCCTACTATTCCATTGTGGCTTTGTCAGCTCGGCAAGTCATGGGAGCCTACGCGCTGACTACTGGCGCCACCGATGCTTGCACCGGCCAAAACAGCAGCGGCCCATTGATGTTTCAAAGGGAGATCTCATCGGGTGCAAATGTCAACACGGTCGATGTACTGTACCCAGCCATGCCTTTCTTTCTTTATGCAAACCCTGACATGATTAAATACCAGCTAGACCCGCTCTTTCAAAATCAGGAAAACAACTTCTATCCAAATATGTATTCCATGCATGACCTTGGCACCCACTATCCTAACGCGACGGGCCATGTGGAAGGAAATGACGAGTACATGCCAGTCGAAGAGTCAGGTAACATGATACTCCTCTCTCAGGCATACACACTCTTCAAAGGCGACTCGAGCTACATCAGCATGCACTACGCCAAGCTGAAGCAATTGTCAGAGTATCTAATCAACTTTAGTCTTCTACCCGGAGTGCAATTGAGCACGGACGATTTTGCCGGATCTTTGGCCAATCAGACCAATTTGGCCATCAAAGGCATCGTTGGATTGGCGGCCATGAGTAAAATTGCTTCTGCAACTGGCCACAACTCAGACGCACAGAACTTCACTGAGATTGCAAATTCCTACTTTACTCGATGGGAGGGGTTTGGAATCGACCCGAGCGGCAAGCATTCCATTCTAGGCTATGAATGGCGATCTTCATGGAGTTTGCTCTACAACATCATGCCTGCCAAGTTGCTTGGTTTGTCCATCATCCCGCAGCGTATTTACGACATGCAGAGTGAATGGTATCCCCAGGTCGCCCAATTATTTGGCGTCCCGCTCGACAACCGACATGACTACACCAAGTCCGACTGGGAGATGTGGTGTGCGTCGATTGCCAGCCCATCTACTCGTATGATGTTTGTCAACGCACTCGGGTACTGGCTCAACAACACCAATACAAACACCCCCTTCTCCGATCTCTATCAGACGACGGAAATGGGCGGCTATCCAGAGGACCCGTTGGTCAAATTCATTGCACGTCCTGTTGTGGGTGGGCATTATGCACTTCTTGCCATGGACATGTCGGCCAAGTTGAACCAATCTTAA",
    "translation": "MMATVWKAVLLAGLALGKSQPLYSPARPPAVPLAVRSPYTSTWSSTAKNATLNSADPIFWDGTSIGWEGFVAVDGIAYEYLGSARSGLPPTNFIKQANQTRLDYDSSYSNFTFMAGPVQLNVDFLSTVYPQDICRTSIPLSYLTVSATSMDGGSHNVQLYNDINGAWISKESNATLQWDLFNNGQNVTTSSGSNSNSNVFSWIVALEKQYTFGELFNFPLWGKLTFNTMTNGHKMSYQAGNALAVRWNWISNRTLTNTIDRSFRGWGQGSPVYAFAHDLGSISGTESVTYTVGSVQDPAIRYLDNSGVQGLHPYWQHCYGNDLFNLISTHFNDLSQSAALAAEFESKLKADVNSYYAAEGAMVYSKGGESRGPMFDQFNGTDQTYINNQQVQEYFTFNPFNGYGFLNSNNFSNIPIPDVTESQAYYSIVALSARQVMGAYALTTGATDACTGQNSSGPLMFQREISSGANVNTVDVLYPAMPFFLYANPDMIKYQLDPLFQNQENNFYPNMYSMHDLGTHYPNATGHVEGNDEYMPVEESGNMILLSQAYTLFKGDSSYISMHYAKLKQLSEYLINFSLLPGVQLSTDDFAGSLANQTNLAIKGIVGLAAMSKIASATGHNSDAQNFTEIANSYFTRWEGFGIDPSGKHSILGYEWRSSWSLLYNIMPAKLLGLSIIPQRIYDMQSEWYPQVAQLFGVPLDNRHDYTKSDWEMWCASIASPSTRMMFVNALGYWLNNTNTNTPFSDLYQTTEMGGYPEDPLVKFIARPVVGGHYALLAMDMSAKLNQS",
    "product": "hypothetical protein"
   },
   {
    "start": 9508,
    "end": 10959,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004296",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004296</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004296</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004296-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,508 - 10,959,\n (total: 1452 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004296 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01263.23 (Aldose 1-epimerase): [128:424](score: 180.9, e-value: 3.7e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004296 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01263.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016853' target='_blank'>GO:0016853</a>: isomerase activity<br>\n  \n   PF01263.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005975' target='_blank'>GO:0005975</a>: carbohydrate metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004296\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004296-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004296\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTCGCCCTCCTGGCCCCTGTTCTAGCCTACCTCAGCAGTGCAAATGCACAAGCCACCACCGGTACCTCAGCCTCCGGCTCACTTTTGGCGGGCATTACTGGTGCTCCCGGCAGCGCAGCTACTGCCATGACCACCATGGCTACCATGCCCTCTGGGATGTCCGCCATGTCCTCTGGGATGTCTTCTGCAATGGCCGCGGCTGGCATGTCTTCCATGACCAGCATGTCAGCCAGCATGGCTAGCGGCATGGCTGCTAACATGTCCTCTTCCATGCCAAAAGTACAGGCGCAGAGCATGGTCTCCATGCCCCTGGTTGCCAACATGACTATTAACTCCTCCGACTCCACCGTGGGGTCAGCCAACCCTTTCACCATCTACAATATCTCGGCCACCAACATCTCCGCTTCTTTCATTCCCTACGGTGCCCGTCTCACTGCTCTCAAGGTCCCGGACCGCAATGGCGTCATGCAAGACGTTGTATGTGGTTACGACACCGGCGAGCAGTACCTCAATGACACCGAACACAATCACTCCTACTTTGGTGCTGTAGTTGGACGGTATGCGAATCGCATTAAAAATGGAACATTTATGCTCAACAACCAAACTTACCACATCCCCGCAAATGAGCATCACGGTCAAGATACACTCCACGGTGGTACTGTGGGCTATGATCAGCGGAATTGGACTGTCGCCGCTCAGACGCCAAACTCCATCACCTTCAGTCTCTTGGATGAGGGCTTCGAAGGATTCCCGGGTAGTCTGATGAACTATGTGACCTACACCGTCGGCAATGACTCCACCTGGACCATCCGCATGGTCTCCATTCCATTGACCGAAGCCACCCCAGTCTTGATGTCGAGCCACGTCTACTGGAACCTGGACGCCTTCACCAACCCATCCAACGCAACCGTGCTGAACGAGACTCTGTGGATGCCATATAGCAGCCGGATTACTGGAATCAACGGCATTGAGGTTCCTAATGGAACACTTGAGAGTGTGTTGAACGGTCCTTATGACTTTACCCTACCCAAACCAATTGGACGCGATATCCTCCAAGCAGTTGGCGGTTGCGGAACCAACTGCACCGGATACGACCAGTGCTTCCTCATCGACAGACCTCGATACGCTGCTCCGGAAGCCACTGATCTGACAGTCCTCACGTACTCCTCTGACGTTACTGGAATCAAACTCGAAATCGAGACCAACCAGCAGGCTCTACAGATCTACACGTGTGACAACCTGGACGGGACAATCCCAGTCAAACAGTCGCAGCAACATGGAAATGGAACCACAACAATCCCGCAATACGGTTGCATGGTTATTGAGGTCGAGGGTATCATCGATAATATAAATTTCCCAGCACTCGGGAATGAACAATACCAAATCTACTCCACGGACACCGAGCCCTCTGTTGTCTTTGCACAGTATCATTTCAGCGTGATGGACTAA",
    "translation": "MLALLAPVLAYLSSANAQATTGTSASGSLLAGITGAPGSAATAMTTMATMPSGMSAMSSGMSSAMAAAGMSSMTSMSASMASGMAANMSSSMPKVQAQSMVSMPLVANMTINSSDSTVGSANPFTIYNISATNISASFIPYGARLTALKVPDRNGVMQDVVCGYDTGEQYLNDTEHNHSYFGAVVGRYANRIKNGTFMLNNQTYHIPANEHHGQDTLHGGTVGYDQRNWTVAAQTPNSITFSLLDEGFEGFPGSLMNYVTYTVGNDSTWTIRMVSIPLTEATPVLMSSHVYWNLDAFTNPSNATVLNETLWMPYSSRITGINGIEVPNGTLESVLNGPYDFTLPKPIGRDILQAVGGCGTNCTGYDQCFLIDRPRYAAPEATDLTVLTYSSDVTGIKLEIETNQQALQIYTCDNLDGTIPVKQSQQHGNGTTTIPQYGCMVIEVEGIIDNINFPALGNEQYQIYSTDTEPSVVFAQYHFSVMD",
    "product": "hypothetical protein"
   },
   {
    "start": 11046,
    "end": 12263,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004297",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004297</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004297</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004297-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,046 - 12,263,\n (total: 1218 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 131.4; E-value: 8.1e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004297 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01408.25 (Oxidoreductase family, NAD-binding Rossmann fold): [1:119](score: 66.5, e-value: 3.6e-18)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004297 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01408.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004297\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004297-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004297\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAATTGGGCATCATTGGTCTCGGACAATTCGGTCCAGAGCTTGCACAGCTCTTCTACGCCCATCCCGGCGTCGACCACCTCGCTCTCTGTGATGTGGTCAAAGACCGCGCAAAAGCCGTGCAGTCGTCTCTTGGCCCCGACACACGGGTCGTTGATAACTTTGATGACATGTGCGCTTCTGACGTGGATGCTGTCGCCATCTTCACACAGCGCTGGCTCCATGCCGAGATGACAATCAAGGCGCTCAAAGCTGGCAAGCATGTATACTGCGCCGTGCCCATGGCCAACACGGTCGCGGAGGTGAAGCAGATCTTGGATACTGTCCAGCGCACAGGTCTCGTGTACATGTCGGGCGAAACATGTTACTACTACCCCGCCGTCATCTACTGCCGCGAAAAGTGGCAAAAAGGGGATTTTGGGCACTTTGTGTATGCAGAGGGTGAGTACAGGCATGACATGTCTCATGGCTTCTACGACGCCTACAAGTTCAGCGGCGGCGCCACATGGAAGGAGACTGCCAGTTTCCCTCCCATGATGTACCCAACGCACTCTGTCAGTGCCGTGCTGGCCTCCGTTGGGTCCTACTTCACCAAAGTCTCCTGCATCGGCTACCGCGACCAGGAGAACGACGGTGTCTTTGACCGCAAGGTGAGCAAATGGAACAATGACTTTAGCAACGAATCCGCATTCTTCACTCGTGCCGACGGCGGCGCAGTTCGAATCAATGAGTTTCGACGTATTGGAAGCCACCAAGAGCACGCCTACCCTATGAGTATAATCGGCACTCAAGGGAGCTTTGAACTGAATACGCGTAGTGCAACCTTCCAGACACTCAACAATTTAGAGGACGTGTCCGAGCTACTGGCCTGCGACGAAGGCAAGAGCGAGAAGAACATTGAGGCGTCGGATGTCAATGCGGAAATTCTCGAAGGATTCCGATCCGGCATGTCGAAGTTGCATGATGTCAAACGACTCCCGTCTGAATTCAAGGGCCTTCCGAATGGTCATGAAGGGTCCCATCAGTTTCTTGTGGATGACTTTGTCAAGGCATGCGTCTCGCAGACCGTTCCGCCAATCAGTGCGTGGCGCGCGGCACGATATGTGGTCCCCGGCCTGGTTGCACACCAATCTGCCCTGCGTGACGGCGAGCGAATGAATGTCCCTGATTTTGGGCCCGGACCTGAAGTAGGTACTGCTGTGGCAAGCAAAAAGTAA",
    "translation": "MKLGIIGLGQFGPELAQLFYAHPGVDHLALCDVVKDRAKAVQSSLGPDTRVVDNFDDMCASDVDAVAIFTQRWLHAEMTIKALKAGKHVYCAVPMANTVAEVKQILDTVQRTGLVYMSGETCYYYPAVIYCREKWQKGDFGHFVYAEGEYRHDMSHGFYDAYKFSGGATWKETASFPPMMYPTHSVSAVLASVGSYFTKVSCIGYRDQENDGVFDRKVSKWNNDFSNESAFFTRADGGAVRINEFRRIGSHQEHAYPMSIIGTQGSFELNTRSATFQTLNNLEDVSELLACDEGKSEKNIEASDVNAEILEGFRSGMSKLHDVKRLPSEFKGLPNGHEGSHQFLVDDFVKACVSQTVPPISAWRAARYVVPGLVAHQSALRDGERMNVPDFGPGPEVGTAVASKK",
    "product": "hypothetical protein"
   },
   {
    "start": 15493,
    "end": 16782,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004298",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004298</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004298</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004298-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,493 - 16,782,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1100:3-hydroxyisobutyrate dehydrogenase (Score: 206.6; E-value: 9.1e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004298 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [7:104](score: 44.1, e-value: 2.2e-11)<br>\n \n  PF03446.18 (NAD binding domain of 6-phosphogluconate dehydrogenase): [133:287](score: 117.6, e-value: 6.2e-34)<br>\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [299:420](score: 92.5, e-value: 2.3e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004298 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03446.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding<br>\n  \n   PF14833.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004298\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004298-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004298\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAACAGACTGAGAAACATCTCAGGGCCCTCCACTTGGCAACAGCGTTTGAAGCCATTGCACTTGGAACTGCTTCAGGGCTGAATGGCTCCCAACTGTACGCTATCTTTTCCACATCCGCTGCGCAGTCATGGACGTTCAACTACGTCATTCCGAATCTATTAAGTGGGAAAGCTTTACCCTTTGATGTAGATGAAGCTCTAGACGATATTCAGGAAATACTAAAGCAAGCGAATGAATGTAGATTCTTCAGTCCAATGACTAGCGTAGTTGAACAATATCTTTTATCGGTCAAAGCATCTGGGGGCGTTCACAAGTACTATGAGACACTTGGCGTCTCTTCTTTGAAACAGAAGAATTTTACTCCCTCTCGACTCCCTTCATCTTCCAGAAAACCGACCGTCGGATTTGTTGGCCTTGGAGCTATGGGTCTGGGTATGGCTAGTATTCTATATAAAGCAGGGTTTGCTGTCAAAGGATTCGATGTGTTTCCGCAAAGTGTTGAAAAGTTCGTGACTGTGGGAGGACAAAGGGCTGCTTCTGCTGCTGAAGCGGCCATTGGAGTTGAAGTACTGTTGATCATGTGCGCTACTTCTGCACAAGCTGACACTATTCTTTTCGGGGAAGATGGAGCTGCCTCCAAAATGAGTAAAGGAGCGGTTGTTCTCCTCTGTGCAACAGTCGCACCATCATATATAACAGAATTAAATCAGAAGCTCGCCCGCAGTGCCATTAAGCTAGTGGACGCGCCTGTCTCGGGCGGTACTTATCGCGCCGCCAGTGGCGAGCTTTCCATTATGTGCTCCGGCGATACGGAAACGCTACAAATTGTTTCCCCCGTACTAAATGCATTAGCCGGCAAAGAAGAGAATGTCTACGTTATTGAAGGCAAAGTAGGGTCTGGTTGCAAAGTCAAAATGGTGAATCAAGTTCTTGCTGGTACACAATGTGTCTGCACCGCGGAAGCACTTGCCTTTTCAGTGGCTAGGGGACTGGTTGCAATGGACGTATATGAATGGATTTCATCGTCTCGTGGAGCTTCATGGATGTGGTCAAATCGAGGTCATCATATGGTAACTGGAGACTTTTCCCCATTATCGGCTACAACTATCTTCATCAAAGACATGAACATTGTTGTCTCAGAAGCAAGAAGGCTTGGGCTGCCATCGGTTTGCTCTTCCATGGCACAGCAGTTATTTATTCTGTCCGCCGCAGCTGGACATTCAAAAGATGACGATTCTAGTGTTGTAAAAGTATGGGAAAAAGCATGTGGAATTAAGACCTACTAA",
    "translation": "MEQTEKHLRALHLATAFEAIALGTASGLNGSQLYAIFSTSAAQSWTFNYVIPNLLSGKALPFDVDEALDDIQEILKQANECRFFSPMTSVVEQYLLSVKASGGVHKYYETLGVSSLKQKNFTPSRLPSSSRKPTVGFVGLGAMGLGMASILYKAGFAVKGFDVFPQSVEKFVTVGGQRAASAAEAAIGVEVLLIMCATSAQADTILFGEDGAASKMSKGAVVLLCATVAPSYITELNQKLARSAIKLVDAPVSGGTYRAASGELSIMCSGDTETLQIVSPVLNALAGKEENVYVIEGKVGSGCKVKMVNQVLAGTQCVCTAEALAFSVARGLVAMDVYEWISSSRGASWMWSNRGHHMVTGDFSPLSATTIFIKDMNIVVSEARRLGLPSVCSSMAQQLFILSAAAGHSKDDDSSVVKVWEKACGIKTY",
    "product": "hypothetical protein"
   },
   {
    "start": 17046,
    "end": 18044,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004299",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004299</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004299</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004299-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,046 - 18,044,\n (total: 999 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 58.8; E-value: 8.1e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004299 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:331](score: 55.9, e-value: 3.5e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004299 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004299\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004299\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGTCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAGAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACTATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGTATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCGTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACTGA",
    "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLREQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDYIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMVLAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETN",
    "product": "hypothetical protein"
   },
   {
    "start": 18141,
    "end": 18509,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004300",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004300</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004300</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004300-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,141 - 18,509,\n (total: 369 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004300 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [3:62](score: 51.4, e-value: 7.9e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004300 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004300\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004300-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004300\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCGCTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACGATGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
    "translation": "MTIASPLVTSRDEEIFPDPHRYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYDVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
    "product": "hypothetical protein"
   },
   {
    "start": 18687,
    "end": 21690,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004301",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004301</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004301</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004301-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,687 - 21,690,\n (total: 2967 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 123.1; E-value: 1.8e-37)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004301 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [20:320](score: 124.3, e-value: 5.2e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 32.0, e-value: 1.3e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.9, e-value: 5.2e-42)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004301\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004301-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004301\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGAAATCATCAACGATCCGGACTCGAATTTCAACTATAAAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGGGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACGGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCAAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGCGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTTGGGCAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGGAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCTTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGCGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGCAAATTGCTGCTATTGATGGATCATTAG",
    "translation": "MSFLSVNELLDARARDDGDVEIINDPDSNFNYKRYTYNSLLGIASGLAADYGQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENGEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVKPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAACRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLFGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGKLLLLMDH",
    "product": "hypothetical protein"
   },
   {
    "start": 21742,
    "end": 23625,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004302",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004302</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004302</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004302-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,742 - 23,625,\n (total: 1884 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004302 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00172.21 (Fungal Zn(2)-Cys(6) binuclear cluster domain): [20:52](score: 37.8, e-value: 1.6e-09)<br>\n \n  PF04082.21 (Fungal specific transcription factor domain): [166:392](score: 91.6, e-value: 4.5e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004302 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004302\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004302-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004302\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCTCTCCACAATCGAAGAAGCCTCGCTTATGCGAAGATGCGAGGGTGCGGGTAACCCGTGCGTGTGATGCGTGCAAGAGGAAGAAAGTGCGCTGTGACGGGACAGCACCGTGCGGCAGGTGCATCAGCCATAATGTCGTTTGCCGGTACGAAGCACCATACCTGCGTCGGAAGCAGTCTCACATCAGCACGGAGGTGGAGAAGCGCGAAGATGATGAGTCTATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGACACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTGATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
    "translation": "MGSPQSKKPRLCEDARVRVTRACDACKRKKVRCDGTAPCGRCISHNVVCRYEAPYLRRKQSHISTEVEKREDDESMQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
    "product": "hypothetical protein"
   },
   {
    "start": 25280,
    "end": 26713,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004303",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004303</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004303</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004303-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,280 - 26,713,\n (total: 1398 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1137:Major facilitator superfamily MFS 1 (Score: 376.1; E-value: 2.7e-114)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004303 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [80:327](score: 68.3, e-value: 5.8e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004303 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004303\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004303-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKPAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLVVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFMFLGLLVIANLGVKSRLPRRGGSVPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004303\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAACATGAACTCTAACGAAGCAGCAATCGCTAAGCCCCGTGATGTTGAAGCAGGCACACTATCTACACGTACCAGCTTTTCCAGTGCTCATGAGCAATTATCAGACCATACCACTGTTGCCAATGAGTCACCCGTGAATGAAAAGGTCGAAGAGGAGAAAGTCAAGCCTGCGATGCCCCCCCCTTCGGATTTCCCAGATGGAGGCCTTCGAGCTTGGATGTGCGTTGTGGGTGGATGGTGTGCAATGTTTTGCACTTTTGGCTTTGTGAACAATGTTGGTGTATTCCAAAACTACTACCAAACGACTTTCCTCAGACAGTATACACCCTCTACGGTAGGATGGATCGCTTCGCTTCAACTCTTTCTGCAGTTTTTCATGGGCTTTCCAGTGGGTCGCGTATACGACGCCTACGGTCCTGCTTGGTTGTTGCGCATCGGAAGTTTCCTTGTTGTATTTGGACTCATGATGGCTTCCTTGAGTACGAAATACTACCAGCTGCTTCTTTCACAGGCCGTAGTCTTCGGAATAGGTGCATCTATGGTCTTCTTTCCGGTCATAACTGCGACGTCTACATGGTTTTTCAAGAAGCGAGCTCTGGCGATCGGTTTGGCGAGTGTGGGCAGCTCTATGGGGGGTATTATACAGCCAATCATGATTACCAATCTCATACCGCAGATAGGCTTCGGATGGACCATGCGAACTATAGCCTTCATGTTCCTCGGCTTATTAGTGATTGCAAATCTTGGAGTGAAGTCACGTTTGCCGCGGAGGGGTGGCAGCGTGCCAAAAATATCTGAAATTACAGCTGTACTTACAGACAAGGACTGGGCCCTACTGACGGCTGGCTACTTCATCTTTGTTTGGGGCATGTTCACGCCATTCACTTATATTCCGGATTATGGATTGTACTATGGGATGTCTCAACATTTGAGCATCTACCTTGTGTCCATTCTCAATGCTGGTTCGGTCTTTGGTCGGACTATTCCAGCTGGGCTTGGTGACCGATTTGGACGGTTCAATGTGTTCACATTGATGAGCTTCTTCAGTGGTATCATCACGTTGGCAATGTGGATTCCGTCAAGGAGCCATGCTGTTATCATTGCGTACTCGGCACTATTTGGATTCAGTAGTGGTGCGTTTGTAAGCTTAGGACCGGCTTGCATTGCACAAATATCTGATATTCGCCAGCTCGGACTGCGTGTTGGGGTTTGTTTTGCAATATTTGCAATTGCGGCACTGACCGGCGTGCCCATTGCCGGAGCGCTCTTAGGACACAACAATAATTGGGTGCATGTTCAAATCTGGGCAGGCGTGACAATGATCGCTGGGAGCTCTATTATGTTATTCTTACGCTTCAAATTGGCCGGGTACAAGTTAATGGTGAAGGTCTAA",
    "translation": "MSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKPAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLVVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFMFLGLLVIANLGVKSRLPRRGGSVPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV",
    "product": "hypothetical protein"
   },
   {
    "start": 26976,
    "end": 30335,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004304",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004304</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004304</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004304-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,976 - 30,335,\n (total: 3360 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004304 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00176.26 (SNF2-related domain): [448:755](score: 213.5, e-value: 3.7e-63)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [933:1048](score: 50.8, e-value: 2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004304 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004304\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004304-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004304\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATAGATGTATTAGAACAGGTAGCGATTTACAGATCGCTCTTAGATACCATCTCGCCGGGGCCGAGTGAACACCGTACTGCGATAGAGCGTAAGCTACGAGATGTTGAGGCCAAGGTGGATCAAAATGAGCTACAAAGTAGCGAACGGAACAAGCGTCGGAAATTAGAACAAGAGCAGGAGGATGAGATATTTGCATGGACCTTGGAGATGCAAGAGAAGGGCAGCAACACGAGCGAAAATTTCGATTATGAAACGATTGATCTGACTGAGCAAATTGAGAACGACGCAGCTCTAGCACGAGAGCTAGCGGATGAGGAAGGCGCAAGGCCTGCACAGTCTGCTCCTCCTGCTCCCTATTTAGGAGCAACTCCCAAGCTCGAACATGATTCGAACGCGGTTCAGCCGGATGGCTCGGTAAATGTTATTGCGGGCACTATACCAGCATTCACAATTGTTGGAACCGATACCGTGGGGCCTAATAATGCAACGGCGAACACCGAAGCTCCCAATACATTATCAATGACCGATCAGGATCTAGCTAATTTTTTCATGACAATTGAGGATCGTGTTTCCAAAGTATATGGAAAAAAAGAGGTCCGACCGCTACACTTTGTTCGAGGTCCCTTCAATTTGTTCAAGAGATCAGCACTTGAAAATCTGAAGAAGCGCGGTCTAGACTATTTGGTTCAAGATACAGATAACGAAATAGCACAAACGTATGAAGACTCCATATCCCTTACCATGCAGAGACTAGAGGCAGCTGAGTGGCAGCAAGTACTTTACCGGAATCTTCGTCGCAAAACGCAGCCAACTCCTGCCCTACCAATGGACGAACCAAAAACGGCAAACGCCGAGCCTGTTCAACCACAAGCGCCTGCACCTACACCTGCAGGGATTTCTGAACAGCGACTCATGGAGCTACGAATTGCAGCAGATGCTAAACTTCTACGAATCCATGGACCTCCACAGCTTTTCACCGGGAGCATGCTCACGTCCTACGAGAAACTGCGAAAGGCATATCGTGACGAAGCTATTATGAATGAGAAAGTCAACGCTCTCAAAAATATAAAGCCCGCACAGAATACACTCTGGCCAGATTCGATGGCAGCGGGCCCGTCTACAACAGCAAGTATTGGCCTCCCTTCGAGCTATTATGACTACAGCCACAGCTACTCGATGCGATTCGATGCTGAAAAGAACCGTGAAGATCTTAAGAAACTTATCGAGAGTATTCAGCCGGACGCTGATATTGAACCACACGCACGAAGAGGGACTCCAAGTGCCATGACTTTCGTGTTGATGGAACATCAAAAAGTTGGACTTACCTGGATGCGACGTATGGAAGAAGGTAACAATAAAGGAGGTTTATTGGCCGATGACATGGGGCTTGGAAAGACAATCCAAGCACTTGCTCTAATATTGTCTCATCAGCCCGAAGACCCATCTATCAAGACTACACTTATAGTTGCGCCACTCGCGTTGCTTAAACAATGGCATCGAGAAATTGAGTCAAAAATCAAGCCAATGTATGCACAGAAGGTGTGTATTTACCACAGTATTGGAAGACGCAACATGACGTGGGTCGATCTTCGAAAGTATGACATTGTCTTGACCACGTATGGTATGATTGCATCCGACTATAAAGCACAAGTTAAATGGGAGGCCGACGTGAAGGTTGATGCGAGAAATGAAGTTTACAAGCCAGAGTCACCTCTCCTTGACAAAGATAGCCAATTTCATCGAATAATCCTAGATGAGGCTCAAATGATTAAAAATAGAAATGCACTGGCATCGAGGGGTGTCGCAATTCTCCATGCAAAGTATCGCTGGGGCCTCAGTGGTACACCTGCACAAAACAACATTGACGAGTTTTATGCAATCATTCGCTTCTTACGTGTACGCCCTTTCTGCGACTGGGATGAATTTCGAACTCAGCTGTCTAATGCAGCGAGATCAAGGGATCTCAAAAGAGTTGACAAAAGTACGCGATTGCTGCAGGGTGTGTTGCGGGCAATCATGTTACGAAGAACGAAAGATTCAAAGATCGATGGCGAAAGTATACTTGACCTCCCACCCAAGACCATCGAAGAGACTCATGTTGTTTTTAACGTAGACCAGCAAGCATTCTACAACAATTTGGAACACAAATCTCAGATGTTAATGAATCGCTACGAGCAAAACAACACCATTGGGAAAAACTATGCAAACATATTGGTCCTTTTGCTTAGACTCCGTCAGGCATGTTGCCACCCACATCTCATTCCTGACACCGGTACATCTACTGGAATTTCTTATGAAGCTGGAGTTGTCCCCAAATCGGCCGAGGAAATGGAGGCGATGGCCCGGCAGATGCCTAGTGATGTAGTCAATCGTCTCAAGAATGACAAAGACATGCTTTGCCCTGTCTGCTGGGACACACCAACCGACATGAAAATTATCCTCTTTTGTGGTCATTATGGATGTGGCGAATGCGTCAACAAGCTATTCACGCTGCAGACTCAAGTGAATCAGTCTCATGATGAGCTTGAGCCAGCACTGTGTCCGACGTGCCGCAGCGCAATGAGTAGCGACAAATTGCTGGGCTTTAATCTGTTCAAAAAGGTCCACATGCCAGAAGCGCTTACTCCGGAACCGCAACCGGAAGCTGTCAAGGATGAAAGCTCGGCTGTCGGAGGGAGTGGGACGAAAGGCAAAGAGAAAGCGGTGATTCCCGAAAGAGAGGAGACTCCGCTCGAGGACTTGGCGCCCCGCCAAAGGATTTTGCGAAGACTAAAGAAAGACTGGATCTCCTCTGCAAAGATTGACAAATGCTTGGAAATCCTGGAGACCGTCAAAGCGCGGGACCCGACGGAGAAGACCGTCGTGTTTTCCCAATTCATTCTGCTGCTTGACTTTTTGGAGATTCCGTTGGCGGACATGGGATTTAAGTGGAAGCGGTATGAAGGTTCCATGTCTGCCGTTGCTCGGGACGATGCCGTGCTTGACTTTATGAAGAGCCCAGATATCAACATCATGCTTGTTTCCTTGAAGGCCGGCAATGTTGGCCTCAACCTGACCTGTGCATCTCAGTGCATTGTGATGGATCCCTTTTGGAATCCGTTTGTGGAATTACAAGCCATTGATCGTACGCATCGAATTGGACAGTCACGGCCAGTCTGCGTGCACCGCATCTGCGTTGCGGGGACAGTCGAAGACAGGATTCTGGAGCTGCAAAATCAAAAGCAGGAGCTCATTGAGACGGCCCTGGATGATCAGGCGGCAAAGTCAATCCAACGGCTGAGTCCTCGTGAATTGATGTATCTTTTCGGGATCAACGACCCCAACAGTCAGAACAGCCAGAACAACCAGCATATTTAA",
    "translation": "MIDVLEQVAIYRSLLDTISPGPSEHRTAIERKLRDVEAKVDQNELQSSERNKRRKLEQEQEDEIFAWTLEMQEKGSNTSENFDYETIDLTEQIENDAALARELADEEGARPAQSAPPAPYLGATPKLEHDSNAVQPDGSVNVIAGTIPAFTIVGTDTVGPNNATANTEAPNTLSMTDQDLANFFMTIEDRVSKVYGKKEVRPLHFVRGPFNLFKRSALENLKKRGLDYLVQDTDNEIAQTYEDSISLTMQRLEAAEWQQVLYRNLRRKTQPTPALPMDEPKTANAEPVQPQAPAPTPAGISEQRLMELRIAADAKLLRIHGPPQLFTGSMLTSYEKLRKAYRDEAIMNEKVNALKNIKPAQNTLWPDSMAAGPSTTASIGLPSSYYDYSHSYSMRFDAEKNREDLKKLIESIQPDADIEPHARRGTPSAMTFVLMEHQKVGLTWMRRMEEGNNKGGLLADDMGLGKTIQALALILSHQPEDPSIKTTLIVAPLALLKQWHREIESKIKPMYAQKVCIYHSIGRRNMTWVDLRKYDIVLTTYGMIASDYKAQVKWEADVKVDARNEVYKPESPLLDKDSQFHRIILDEAQMIKNRNALASRGVAILHAKYRWGLSGTPAQNNIDEFYAIIRFLRVRPFCDWDEFRTQLSNAARSRDLKRVDKSTRLLQGVLRAIMLRRTKDSKIDGESILDLPPKTIEETHVVFNVDQQAFYNNLEHKSQMLMNRYEQNNTIGKNYANILVLLLRLRQACCHPHLIPDTGTSTGISYEAGVVPKSAEEMEAMARQMPSDVVNRLKNDKDMLCPVCWDTPTDMKIILFCGHYGCGECVNKLFTLQTQVNQSHDELEPALCPTCRSAMSSDKLLGFNLFKKVHMPEALTPEPQPEAVKDESSAVGGSGTKGKEKAVIPEREETPLEDLAPRQRILRRLKKDWISSAKIDKCLEILETVKARDPTEKTVVFSQFILLLDFLEIPLADMGFKWKRYEGSMSAVARDDAVLDFMKSPDINIMLVSLKAGNVGLNLTCASQCIVMDPFWNPFVELQAIDRTHRIGQSRPVCVHRICVAGTVEDRILELQNQKQELIETALDDQAAKSIQRLSPRELMYLFGINDPNSQNSQNNQHI",
    "product": "hypothetical protein"
   },
   {
    "start": 30531,
    "end": 33344,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004305",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004305</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004305</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004305-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,531 - 33,344,\n (total: 2775 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 272.3; E-value: 8.9e-83)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004305 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [288:593](score: 159.5, e-value: 1.3e-46)<br>\n \n  PF08240.15 (Alcohol dehydrogenase GroES-like domain): [625:689](score: 38.1, e-value: 1.2e-09)<br>\n \n  PF00107.29 (Zinc-binding dehydrogenase): [747:870](score: 91.5, e-value: 4.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004305 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004305\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004305-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004305\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCGAGAGCAGCAGAGAGGCGATCCCAGCGCGCCGGCGACGGTCCAGCGCCAGCAAGGGTTTTGCCCCGCCCTTCCAGCAGCGACGCGCGCAGTTCGTGCAGCAGGAGCAGCAGCAGCAGCGCAGTCTCAGCCCCAGCTCCCTCGACTCGAACGCCCTCTTGGACCACCGCTCCCAGCCAGAGAGCATCCCCCGGCCCTCCTTCCTGCGCAACCGCAGCGACAGGACCGGCGGCGAGCGGGAGGAGCGACGGGGCAAGGGCAGAAGGGAGAGCCGCGACCGCCACCATGAGCAGACACCTCTGTTGGAGGGCGAGGGAGAAGGGGGGGCGGGGCCCAGCTCGGGGGAGCAGGCGGACCAGCACCCCTTTGTGCACTACCAGCCAAACTACGGGTCCGGGGCCCATGGAGACGCAGTCATCACTATCGAGGGCGCCGGCGATGGGAGCTCCACGGACGACTTCACCAACGACCCCACCAGCGATGAGGCCTCCAACAACTCCGAGGCCCTGGACGACGTCTGCTTCCCACAGGACGTGGGCGACGACGGCGAGCGCAAGTGGCCGGATGTCGCCGTGCTCGAGGAGTGGGCCGAGGAGGAGAAGAAGGAGAGCGGAGACGGAGGGGGCGTGGGAAATGCAGAGTGGCTGAGATCGCGCCAGACCAGCGAGCCAGAGCGCATTAATGGGCGGCTGCGTGGCGTGCACCAAACCAAGGAGGAGAGCGACCGGCCCTACCGTTTCACCTACTTCTCCGACTCCCTCCCCGCTACCATCCATTCCCAAAACATCTCCGGGCTCGTGCAGTCCGATCTCTCCTTTACAGACCTCTTCTCCCCCAAGGCGGACTTGGCGCCCACCTTCTGGCTGGACTGCCTAACCCCCACAGACTCCGAAATGAAAGTCCTGGCGCGTGCATTCGGCATCCACCCGCTGACGGCCGAGGATATCACCATGGGAGAGACGCGCGAAAAGGTGGAACTCTTTCGAAACTACTATCTCGTCTCCTTCCGATCCTTTGAACAGGATCCCAAGGCGGAGGAGTATCTTGAAGGCCTGGACTTCTACATCATTGTCTTCCGCCAAGGTGTCATTTCCTTCCATCACTCCCTCACCCCTCATCCGGCAAATGTCCGCAGGCGCATACGCCAGCTAAAGGATTACATCACCGTGACATCCGACTGGATCTCATACGCATTGATTGATGACATTACAGACGCCTTCCAGCCCCTCATCTACTCCATCGAGACAGAGGTGGACGATATCGACGACTCCATCCTATCTTTTCATTCCGACAACTCTGTGGCGGACGACAGCGAGATGCTTCGGCGCATTGGCGAGTGCCGAAAGAAAGTGATGGGTCTGCTTCGTCTGCTCGGATCCAAAGCGGATGTCATCAAAGGCTTCTCCAAGCGCTGCAACGAGCATTGGGACATTGCCCCACGTTCGGAGATTGGGCTATATCTCGGAGACATCCAAGACCACATCGTCACGATGGTCCAGAATCTGGGCCACTATGAAAAGATGATGTCGCGGTCCCACTCCAACTACCTTGCCCAGATAAATATCCAGATGACGCGAGTCAACAACAACATGAACGACGTGCTCTCTCGCCTGACGGTGCTGGGGACAATCGTGCTCCCAATGAACATCATCACTGGCCTGTGGGGCATGAACGTCAAGGTCCCCGGGCAGGAAATCGACAACCTCAACTGGTACTTTGGCATCACGGTGGGGCTGGTCATGTTTGGCGTGATGAGTTATTTGTTCTTCATGAGGACCTCGGTACATATGCGAGCAATTCAAATCACAGAACGCGTAGATTCGCCGTCCAAGCTGTGGCCCTCTGACATCGCACAGCCCCGGCCGAGTTCAGAGCAAGTGCGGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCATCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATTAAAATCGACCATCCTTCTCCCAAACTTTAG",
    "translation": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASNNSEALDDVCFPQDVGDDGERKWPDVAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMRTSVHMRAIQITERVDSPSKLWPSDIAQPRPSSEQVRVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARIIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
    "product": "hypothetical protein"
   },
   {
    "start": 33403,
    "end": 35298,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004306",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004306</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004306</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004306-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,403 - 35,298,\n (total: 1896 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004306 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02990.19 (Endomembrane protein 70): [51:587](score: 651.0, e-value: 1.5e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004306 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02990.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004306\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004306\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCATCGGATCCAACGGAGGCTGCTGCTGCTGCTGCTCCTCCTCCGCCAGGCAAGCGGCTTCTACATCCCCGGCTGGAGCATCCGCTCGTACGCCGACGGGGACGCAATCCCCCTGCAGACCAACAAGGTCTTCTCTGACGCCACCTCCCTGCCCTACGCCTACTCCGAGCTGCCCTTTGTCTGCGATGCCCCGGGGCGCAGCAGCAGGCGGGTCGCCCTCAACCTGGGCGAGGTTCTGCGCGGCGACCGCATCGCGACGTCCGGCTACGAGATCGAGATGGGCAAGGACGTGGCCTGTGCGCACCTGTGCGACGCGGCCGTCGATGCTGCCGGAATCGCGCGCGCCACCCAGCTCATCCGCAACGGCTACTCGGCCGAATGGATCGTGGACAACCTGCCCGGCGCCACCTCCTTCGTCACCGTCGACCGCACCAAAAAGTACTACGCGGCCGGCTTCAAGCTGGGCGGGTTTGAGAATGACGTGGCAAAGTTTCATAATCACGTCAGCCTGGTCTTCCGGTGGCGCCGGCTGGAGGCAGACAGCGACCGCAAGGTCATTGTGGCCTTTGAAGTCTACCCAAAGTCTATCAAAACAAAGGATGGCGCATGCCCCACCTCGCTCGACAATCAGCCCCCGCTGGAGCTCCCGGAGACGAGCACAGTAGGGGTGGACGGCTTCACAATTCCCTACACCTACAGCATATTTTGGAAGGAAGACGACACCATCGAATGGTCGTCGAGATGGGACCTCTACTTTGTCAACAACGAAGATGCGCACCAGATCCATTGGCTGGCCATTGTAAACTCTACCGTCATTGTCATGGTGCTCAGTGGCGTGGTCTTCCTCATCCTGGTGCGAACCCTCTCGCGCGACATTCAATCCTACAACACGCCCGACGGCGACGACGACAAGGATACAGATGCCGACATAACTGGCTGGAAACTTGTGCATGGGGACGTCTTCCGACCGCCGCCGGCTGGCGGTCTGTTCTCCCCCCTTATCGGAGCGGGTGTGCAATTGCTCGTCATGATGTTGGCCCTCCTCATTTTGTCCGCGGCCGGGATCCTCAATCCCTCCTACCGGGGCGGCTTTCTCTCTTTTGCCCTCTTCCTCTTCGTCTTTGCGGGTGTCTTTTCCGGATTGCATTCCACAAAGATCTACAAAACGTTTGGAGGGTCCCAGTGGGTCAAGAATGGGTTGATGACTGCGCTCTTAGTGCCGGGAAGTGTCTTCCTGACCGTTTTTATCCTCAATTTGTTCGTCTGGGCGGAAGCGTCGTCTTCGGCCCTTCCATTTGGAACGTTGGTTGCGCTGTTGGCCATGTGGCTGCTTATCTCTCTTCCCCTAGTCTTGCTGGGAAGTTTTATTGGCTTCCGACGTCCGGCCGTGGAGCATCCTACGAAAGCCAACCAGATACCACGCCAGATCCCCGAACAGCCTCGCCACCTCCGATTCTTTCCCTCGCTGCTCATCACTGGCGTCGTTCCCTTTGCAGTCATCTTTATTGAACTTTTGTTTGTCTTCCGATCCGTGTGGGCGGAAAAGTCGGGCTACTACTACGTCTATGGATTCCTTGGGCTCATCACGCTCATCCTCCTGATTACGACGGTCGAAATAACACTCATTCATGTCTACTTTATGCTCTGTGCCGAGAACTACCATTGGTGGTGGCGATCGTTCTTTGTGGGTGGTGCGAGCGCCATCTACGTCTTTGGCTACTGCGTTTGGTACTACCTTTTCAAGCTCCAGCTGCACGGGTGGGTGAGCGGCCTGCTCTTCTTAGGCTACTCCCTGCTCGGCTGTGCCTTGTATGGGGTCTTTCTCGGGACGGTAGGGTCTCTGTCGGCATATGTCTTTGTGAGGAAGATATATGCCGCAGTCAAGGTGGATTAG",
    "translation": "MHRIQRRLLLLLLLLRQASGFYIPGWSIRSYADGDAIPLQTNKVFSDATSLPYAYSELPFVCDAPGRSSRRVALNLGEVLRGDRIATSGYEIEMGKDVACAHLCDAAVDAAGIARATQLIRNGYSAEWIVDNLPGATSFVTVDRTKKYYAAGFKLGGFENDVAKFHNHVSLVFRWRRLEADSDRKVIVAFEVYPKSIKTKDGACPTSLDNQPPLELPETSTVGVDGFTIPYTYSIFWKEDDTIEWSSRWDLYFVNNEDAHQIHWLAIVNSTVIVMVLSGVVFLILVRTLSRDIQSYNTPDGDDDKDTDADITGWKLVHGDVFRPPPAGGLFSPLIGAGVQLLVMMLALLILSAAGILNPSYRGGFLSFALFLFVFAGVFSGLHSTKIYKTFGGSQWVKNGLMTALLVPGSVFLTVFILNLFVWAEASSSALPFGTLVALLAMWLLISLPLVLLGSFIGFRRPAVEHPTKANQIPRQIPEQPRHLRFFPSLLITGVVPFAVIFIELLFVFRSVWAEKSGYYYVYGFLGLITLILLITTVEITLIHVYFMLCAENYHWWWRSFFVGGASAIYVFGYCVWYYLFKLQLHGWVSGLLFLGYSLLGCALYGVFLGTVGSLSAYVFVRKIYAAVKVD",
    "product": "hypothetical protein"
   },
   {
    "start": 35335,
    "end": 36600,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004307",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004307</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004307</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004307-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,335 - 36,600,\n (total: 1266 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004307\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004307\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGTGAAGCGGAGACTGTCCTCCACATCGCGGTCGTCCGCTGACGCAGACGCGCCAGATTCAGCGGCCGCGATCTGGCCCGCGCCGCAACGAGACTTGGAGAGCGCGCGAGCCTTCATTCAAGAGGCGGCCAGATCGCAGCGCAAGATTGTGATTGCACCGGATCGCGACGCTGATGGGCTCTGCTCTGGCGCACAGCTACGACATACCCTTCTACACCTGGGTGCGGCACCCGACCAGATCGCCATCAAGTTTGTCGCCAAAGGACGGAATGTGCATTGTGATGAAGAGCGCGCGGACTTAGAGCGGTATCAGGCGGAGTATATCTTTGTTCTCGATCATGGAAGTCGAGGCGGTGGGCCCATAGCAGATGGGAAGGTGCTCATCCTAGATCATCACTGGAGCGAGGACTTCCCAGACGACGCGCAGGTGGTGAGTGCATGCAAGTATCTACCCGTGGCCACGGCGTCACTATTGACGTATGTCGTCTGCCTCGCCATCAATGAGCACCTCCCGGCCTGGCTCGCAGTCACTGGCACCGTTGGCGATCTCGGCACTACCGTTACGTTTGAGCCCCCATTTCCAACAAGTTTGGCGCAGACATTCAAGGCGCAAGGCAAGAAGCAGATCGCAGAGGTTGTCGCCCTGTTGAATGCACCTCGACGCACTCCAGCCTGCGACCCGACCGAGGCGTGGCAGCTGCTGATTGCAAGCGCGTCTGCCCGAGACTTCCTCGCATCACCGAGCACGCGCTCGCTGGACGACGCGCGCGTATATATCCAAAGAGAGACAGAGCGATGCACGCATGCGGCCCCCAGATTCACAAAGGACGGTCGGATGGCCATTTTGGAGATGTCGTCGCCTGCACAGATCCATCAGCTCATTGCGACGCGCTGGGCCGGCTTCCTGAAATCCAAAGCGCTGCTTGCAGTCGGTGTTGCTAATCGGGGGTACGCTCCCGACAAAGTTCATCTGTCCTGCCGCCTTGTCAAGAGTAGGCGGAGTGAAGAGCCGCCTGTCAACTTGATTGCCCTGCTTAACGAATACCTCGCCCGAGACGCAGGTCTGGCAAAGACCATTGGACCCGATTTTGCGCATGGTCACAAGGAAGCTGCAGGGGGCCACATGTCTCCTGAGCAATGGGACAGGCTAGTCGCGGCGATGGAAATTGGAAATTGGAAGTCGCCCAACAAGGACAGCCCCAAAAAGCCCTCCGTGGACGCGAAGCAATCCAACTTGACAGGTTATTTCAAGCGTGTCTAG",
    "translation": "MGVKRRLSSTSRSSADADAPDSAAAIWPAPQRDLESARAFIQEAARSQRKIVIAPDRDADGLCSGAQLRHTLLHLGAAPDQIAIKFVAKGRNVHCDEERADLERYQAEYIFVLDHGSRGGGPIADGKVLILDHHWSEDFPDDAQVVSACKYLPVATASLLTYVVCLAINEHLPAWLAVTGTVGDLGTTVTFEPPFPTSLAQTFKAQGKKQIAEVVALLNAPRRTPACDPTEAWQLLIASASARDFLASPSTRSLDDARVYIQRETERCTHAAPRFTKDGRMAILEMSSPAQIHQLIATRWAGFLKSKALLAVGVANRGYAPDKVHLSCRLVKSRRSEEPPVNLIALLNEYLARDAGLAKTIGPDFAHGHKEAAGGHMSPEQWDRLVAAMEIGNWKSPNKDSPKKPSVDAKQSNLTGYFKRV",
    "product": "hypothetical protein"
   },
   {
    "start": 36748,
    "end": 38344,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004308",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004308</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004308</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004308-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,748 - 38,344,\n (total: 1562 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004308 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13813.9 (Membrane bound O-acyl transferase family): [226:309](score: 50.6, e-value: 1.8e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004308\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004308\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACTTCATGAATACAAATGAAGCAAGGATGGCATTCTCGTTTTGGACGCAGCTATTTATAGACGCAGGATGGCCGGTCGACGTGGACGACCAGCCCCGCGAAATACTGTGGTCTAGGCCGCTGCCGCTGGTGGCTTCCGTCTTTCCATTCCTCATCTGCGTGCTGACTCTAGCATATCACCCGCTGCTCATCCAGCCAGAGGCCTCGCGTCTCGAAATCCTCCTGTGTCTGCTCGTTGGCCTCTTTCCCGTCATTTGGGGAGCGCAAGGCAGCGGATCTGCTGTTTTTGAATTTGCGCTATCGACAATCACGAGCGTGGTCGGTCTTCGCATGGTTCGACTGTCGTTCTTTCGACGCCGCACCAGACGGAGCAGGCTGGATATGTGGACAGAGCTGATCAGCCTGCCACTCCCCGACCAAACAACTCATTCGCAAGCACAGGCTCCTTCATCTGCACGACGCCAAAATGCAATTCAAGCCATGCAAGCTTTGCCCCAGGCTGTGCTGGTTCCTACCCTACTTCGATGCATACCACCCCCTGAGTCCTTAATACACATGTCCTTCATCCAGGCCAGGCTTTATCACATGCTGGCTGGGCTGGCCATCCTTTTTGTCCTGCAGGGCTCCGTGCAACTCTGCCTATCCAGCTGGGGAATTGTCATGAACTCTCGGCAAAAGCCCATGTTCAGGAATCCATTGGGAGCTCGCACCTTGCAGGAGCTTTGGGGCCAGAGGTGGAACCGAGTTGTTCAAGAGCAGCTACACTTTCTCTTTGCATGCCTCGCTGGAAATAAAGTCAAAGGGGGAAGGCGTCGGCGGACACTGGCTGCACTGGCAACCTTTCTCCTGTCTGGCCTCTTTCACGAGTACCTGGCCTACCAGTCTTTTGGAACTGCTTCCTTTCAGCAGTTCTGGTTCTTCATGATTCAGGGTGTTCTTTGCAGTATGGAGCCATACATTCCCAAAGGCGCCACCTACGCCTGGCTCGTTCGTGTGAGCTGGGTCCTGATGTGCGAGATGAATACCGGCGCATGGTTGCAGAGCCACTTCTTTGAACAAGCAAAAGCCTTCCTCCCCGGACCGATCAGAGTGGACTCCATGGGTAGTCTTTCCGAGCTCTTCGATGGTATCCTCAAAGAGCATGCCTGCTTGAATACTCCATTCACGATTGTAGACACGCACAGCAATGGTGCGTGCATCATTCACGACACTCGCAATCCGCACCTTGGAGGTGGAGTCCACCCGGCCACACAGACCTACAAAGAGGGTGTCGAGCCGCCTGGAGAGGGGGAAGAGGACTGCTGTAGGCGGGAAGGCGGGCAGATAGGAGAACAGACTGCCCGTGAGTGTCAGGGCATATTGTACGCGTATGTAAACCGGGGACTGCTCCAAGATCTCCAGAATGGGCTTTGCGTCGCTGGCAATCTGGGGGAAGCTGGTGTAGCCGTCGTCTGCGCTGAACTTCTTGTTGAACCTGCGCGACACTTGCAGCAGTCTGGTGTCGAGGAAGGTGGCCATCGAGCGTTAACGACCCGAGGAAAAGTTGCATCACATGACTC",
    "translation": "MDFMNTNEARMAFSFWTQLFIDAGWPVDVDDQPREILWSRPLPLVASVFPFLICVLTLAYHPLLIQPEASRLEILLCLLVGLFPVIWGAQGSGSAVFEFALSTITSVVGLRMVRLSFFRRRTRRSRLDMWTELISLPLPDQTTHSQAQAPSSARRQNAIQAMQALPQAVLVPTLLRCIPPPESLIHMSFIQARLYHMLAGLAILFVLQGSVQLCLSSWGIVMNSRQKPMFRNPLGARTLQELWGQRWNRVVQEQLHFLFACLAGNKVKGGRRRRTLAALATFLLSGLFHEYLAYQSFGTASFQQFWFFMIQGVLCSMEPYIPKGATYAWLVRVSWVLMCEMNTGAWLQSHFFEQAKAFLPGPIRVDSMGSLSELFDGILKEHACLNTPFTIVDTHSNGACIIHDTRNPHLGGGVHPATQTYKEGVEPPGEGEEDCCRREGGQIGEQTARECQGILYAYVNRGLLQDLQNGLCVAGNLGEAGVAVVCAELLVEPARHLQQSGVEEGGHRALTTRGKVASHDS",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 18686,
    "end": 21690,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 38397,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r85c1"
 },
 "r105c1": {
  "start": 11006,
  "end": 28249,
  "idx": 1,
  "orfs": [
   {
    "start": 13853,
    "end": 16574,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004659",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004659</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004659</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004659-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,853 - 16,574,\n (total: 2691 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004659 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.4e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 56.3, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004659\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004659\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACCATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGCTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTACGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTCGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGAATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAGGCAGCCAGATTTAGGCTCTTCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCGGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGCGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAATTTTTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTTCACATATTGGAAAGCTCTATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAGGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGCGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACGTCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAATTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
    "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKRQPDLGSSLLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVAMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKNFFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKGVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQAAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERRRGAIEIQDGQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSNFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
    "product": "hypothetical protein"
   },
   {
    "start": 16675,
    "end": 19701,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004660",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004660</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004660</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004660-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,675 - 19,701,\n (total: 2886 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004660 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [11:273](score: 119.8, e-value: 1.1e-34)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [492:556](score: 28.2, e-value: 1.6e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [826:907](score: 50.4, e-value: 1.9e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004660 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004660\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004660\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTGTGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATGTTTGTCCAATTCGTACTCGAAAACATATGGGCGGTTTATGATTATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAAAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCTAGCGTTGGAATGAACCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGAAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCATAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTTGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTAATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
    "translation": "MRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPMFVQFVLENIWAVYDYKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKKSPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEKLSSALERITNYMRKSISGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
    "product": "hypothetical protein"
   },
   {
    "start": 20011,
    "end": 20952,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004661",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004661</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004661</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004661-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,011 - 20,952,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004661 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004661\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004661\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
    "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
    "product": "hypothetical protein"
   },
   {
    "start": 21006,
    "end": 21950,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004662",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004662</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004662</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004662-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,006 - 21,950,\n (total: 912 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004662 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [29:285](score: 173.0, e-value: 8.9e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004662 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004662\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004662\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTGTGAAACGAATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGTCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
    "translation": "MLVKRMSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
    "product": "hypothetical protein"
   },
   {
    "start": 22300,
    "end": 22824,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004663",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004663</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004663</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004663-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,300 - 22,824,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004663 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004663 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004663\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004663\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
    "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
    "product": "hypothetical protein"
   },
   {
    "start": 23437,
    "end": 24468,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004664",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004664</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004664</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004664-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,437 - 24,468,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004664 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [103:307](score: 208.1, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004664\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004664\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGAGCGACCAGCCAGACACAGCGATGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGCCGACAAAAGTAGCATCCCACATGACACAGGCGAGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
    "translation": "MSSRKLLSNPVKPRRYFPQSRERPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARADKSSIPHDTGESSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
    "product": "hypothetical protein"
   },
   {
    "start": 24510,
    "end": 25220,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004665",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004665</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004665</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004665-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,510 - 25,220,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004665 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [71:224](score: 147.6, e-value: 2.4e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004665\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004665\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCATTGATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTACACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCGTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCTTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
    "translation": "MALMTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPITPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
    "product": "hypothetical protein"
   },
   {
    "start": 25738,
    "end": 26760,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004666",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004666</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004666</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004666-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,738 - 26,760,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004666 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004666\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004666\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
    "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
    "product": "hypothetical protein"
   },
   {
    "start": 26815,
    "end": 27261,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004667",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004667</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004667</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004667-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,815 - 27,261,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004667\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004667\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATTGGAATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
    "translation": "MGMDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 21005,
    "end": 21950,
    "tool": "rule-based-clusters",
    "neighbouring_start": 11005,
    "neighbouring_end": 28249,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r105c1"
 },
 "r110c1": {
  "start": 1,
  "end": 27193,
  "idx": 1,
  "orfs": [
   {
    "start": 415,
    "end": 1386,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004725",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004725</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004725</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004725-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 415 - 1,386,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004725 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:270](score: 203.7, e-value: 3e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004725\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004725-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTTAACAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGCATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTGGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGCCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
    "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
    "product": "hypothetical protein"
   },
   {
    "start": 1872,
    "end": 3532,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004726",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004726</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004726</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004726-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,872 - 3,532,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 963.0, e-value: 4.7e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004726 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004726\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004726-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAAAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCGCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
    "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDKGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
    "product": "hypothetical protein"
   },
   {
    "start": 3546,
    "end": 7613,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004727",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004727</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004727</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004727-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,546 - 7,613,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 241.6; E-value: 2.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004727 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 220.3, e-value: 3.8e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004727 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1898.5, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004727\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004727-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAGCATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGCGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACAATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
    "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKAYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
    "product": "hypothetical protein"
   },
   {
    "start": 7884,
    "end": 9374,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004728",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004728</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004728</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004728-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,884 - 9,374,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004728\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004728\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAAGGAAGTAA",
    "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALRK",
    "product": "hypothetical protein"
   },
   {
    "start": 9394,
    "end": 12078,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004729",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004729</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004729</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004729-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,394 - 12,078,\n (total: 2685 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004729 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [632:762](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [785:820](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004729 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004729\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004729-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004729\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAACCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTAATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGACCAGGCGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTGGTCAAGATCGTATTATAGTTACCCCTGCAGACGTGGTTTCGAACGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
    "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLNEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRPGDASGRKLTPVHLLTGGQDRIIVTPADVVSNEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
    "product": "hypothetical protein"
   },
   {
    "start": 12532,
    "end": 13539,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004730",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004730</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004730</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004730-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,532 - 13,539,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004730 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [1:61](score: 51.2, e-value: 8.9e-14)<br>\n \n  PF00013.32 (KH domain): [94:159](score: 56.3, e-value: 2.3e-15)<br>\n \n  PF00013.32 (KH domain): [184:250](score: 56.7, e-value: 1.6e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004730 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004730\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004730\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGACACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
    "translation": "MVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
    "product": "hypothetical protein"
   },
   {
    "start": 14198,
    "end": 16413,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004731",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004731</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004731</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004731-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,198 - 16,413,\n (total: 2148 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [7:262](score: 298.8, e-value: 2.5e-89)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [365:689](score: 166.6, e-value: 8.8e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [319:701](score: 578.4, e-value: 1.7e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [8:262](score: 223.2, e-value: 5.9e-67)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004731 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004731\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004731-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004731\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGCGATTAAGGAGACATTCAGCAGATGCAGGCGAGAAAATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCGTTTTCGCGGTCTTTGCAAAACCCACTCGATGAGTTATGTTCCTTTGATTGCACCAAGTACAAATGAGTCCAGGCTTGCCCTTTTGTGTTCGATAGCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTATGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTACCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCAATGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
    "translation": "MQAIKETFSRCRRENRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIRFRGLCKTHSMSYVPLIAPSTNESRLALLCSIADSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVCTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTTADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEAMRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
    "product": "hypothetical protein"
   },
   {
    "start": 17170,
    "end": 17739,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004732",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004732</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004732</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004732-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,170 - 17,739,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004732 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [112:186](score: 58.0, e-value: 1.3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004732 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004732\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004732\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGGCTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAACACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
    "translation": "MVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSGSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEEHPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 3545,
    "end": 7613,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 27193,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r110c1"
 },
 "r115c1": {
  "start": 12557,
  "end": 24505,
  "idx": 1,
  "orfs": [
   {
    "start": 15867,
    "end": 17826,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004792",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004792</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004792</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004792-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,867 - 17,826,\n (total: 1632 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1139:aminotransferase class V (Score: 313.2; E-value: 4.1e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004792 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00266.22 (Aminotransferase class-V): [145:508](score: 296.8, e-value: 2.2e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004792\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004792-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004792\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTTGCCTTGACTAATATTAAGTGGTACTACTTCTCGTACGAGCTGGGGAAGGTTGCTCCGTTTGATCTTCGAAAAGCCATGGCCTACGTGGACGGGATTTCACAATCTTGGCAATCACAAGCCAAATCGCGTGGAAATGACCATATTGAGCTGTCAGAGTTTTCCGCTTTTCCTCTGCACAATGTCTCTCTTAGATTACACTCTACTGGACTTCTCGAGGAAGGAGACATCAATCACTACCTCGAACCAATTGGTATTGCGCCGCGTTATGCCAACGTGCTCTACAAGAGGACCAGCTGTGCTCGCACCAGGTGCGCTGCAACCTATGTGACGCAAAGCAAACCCGCCGAAGCAGCTATCGTTGAATCGAAGCTGCCGCATGGCACGGGAATCCTGAAGCAAACCGTCGAGCCCAAGGCAGAAGGTCGCCCAATCTACTTGGACATGCAGGCTACTACGCCGTTGGATCCACGCGTGCTTGACATCATGCTGCCGTTCATGACTGGAATGTATGGAAATCCCCATTCGAGGACACATGCATATGGATGGGAGACGAATGAAGCGAGCGAGATAGCACGCACGCACGTTGCAAATCTTATTGGAGCGGATCCAAAGGAAATCATCTTCACCTCCGGTGCCACCGAGTCGAACAATATGAGTATCAAGGGAGTAGCTCGATTTTACAAAGGGACAAAAAATCACATCATCACCTGCCAAACAGAACACAAATGCGTGCTGGATTCATGCAGACATTTGCAAAATGAGGGTTTTGATGTCACCTACCTCCCCGTTCAACAGAACGGCTTAATCTCGCTCGAGCAGTTGGAGAAGGAGATTCGACCGGATACGGCTCTAGTGTCCATCATGGCTGTAAACAATGAAATTGGAGTCATTCAGCCGATCGATGAGATTGGCCGATTGTGCCGGAAGAATAAGATCTTTTTCCACACCGACGCTGCACAAGCTGTTGGGAAGATCTGTATGGATGTAAACAAATCCAACATTGATCTCATGTCTATCTCGAGTCATAAGATATATGGTCCCAAGGGCATGGGTGCATGTTATGTGCGGAGACGCCCGCGAGTGCGTCTCGATCCCATTATCTCTGGTGGCGGCCAAGAAAGAGGTTTACGAAGCGGCACGCTCGCGCCTAATCTAGTCGTCGGCTTTGGAGAGGCGTCGCGTCTTGCATTGCAAGAATTCCCCTATGACGAAAAAAGAATCAAAAGCCTGTCAGATCGTTTGGTCAATGGTCTACTTGCCCTCGATCACGTTCATCAAAATGGTGCCCCTGATCGATTCTACCCTGGATGTGTCAATATGTCATTCGCCTATGTCGAGGGCGAATCTCTATTGATGGCACTGAAGGACATTGCTCTCAGCTCCGGTTCCGCCTGCACGTCTGCCTCACTGGAGCCTTCCTATGTGCTGCGGGCTCTAGGCGCTGCGGACGACATGGCCCATTCTTCCATTCGGTTCGGTCTTGGACGGTTCACTACCGAAGACGAGGTGGAGTATGTATTAAAGGCGGTCCGTGATCGCGTGACTTGGCTTCGCGATATGTCTCCGCTTTATGAAATGGTGCAGGATGGAATCGACCTGAAATCAATCCAATGGAGTCAACATTGA",
    "translation": "MVALTNIKWYYFSYELGKVAPFDLRKAMAYVDGISQSWQSQAKSRGNDHIELSEFSAFPLHNVSLRLHSTGLLEEGDINHYLEPIGIAPRYANVLYKRTSCARTRCAATYVTQSKPAEAAIVESKLPHGTGILKQTVEPKAEGRPIYLDMQATTPLDPRVLDIMLPFMTGMYGNPHSRTHAYGWETNEASEIARTHVANLIGADPKEIIFTSGATESNNMSIKGVARFYKGTKNHIITCQTEHKCVLDSCRHLQNEGFDVTYLPVQQNGLISLEQLEKEIRPDTALVSIMAVNNEIGVIQPIDEIGRLCRKNKIFFHTDAAQAVGKICMDVNKSNIDLMSISSHKIYGPKGMGACYVRRRPRVRLDPIISGGGQERGLRSGTLAPNLVVGFGEASRLALQEFPYDEKRIKSLSDRLVNGLLALDHVHQNGAPDRFYPGCVNMSFAYVEGESLLMALKDIALSSGSACTSASLEPSYVLRALGAADDMAHSSIRFGLGRFTTEDEVEYVLKAVRDRVTWLRDMSPLYEMVQDGIDLKSIQWSQH",
    "product": "hypothetical protein"
   },
   {
    "start": 18627,
    "end": 19973,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004793",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004793</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004793</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004793-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,627 - 19,973,\n (total: 1347 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004793 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05743.16 (UEV domain): [24:142](score: 112.9, e-value: 8.3e-33)<br>\n \n  PF09454.13 (Vps23 core domain): [377:440](score: 79.5, e-value: 1.5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004793 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport<br>\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004793\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004793\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCAACCAGAAGTCGCGCAATGGCTCCAACGAGTCGTCTCTCGAGACTACTCGGACAAGAAACGAGTGTATGGGGATGTCATCGACCTCTTGACGCGCTACCCGTCATTATCTCCCCGCACCAAAGTGTTCTCCTTTGAAGACGGGCGGTCAGAGCTCTTGCTTTGCATTCACGGCACGCTACCGGTACGATTTCGAAATGCAGACTACAACACGCCAATCACTCTGTGGGTAGACAAGGTATACCCTGTGTCACGTCCTTTGGCATTTGTCACTCCTTCTCCGGAAATGGGTATTCGCGCAGGGAATCACGTAGACCCAAATGGTGCCATCTACCACCCCTTATTGGCGTACTGGGATGCGAAAAAGACAATAGTGGAGCTCGCAGAGCTGTTACGTGAAGTCTTTGGTGCCGAAATGCCAGCATATGCACGCACGGCGAAACAAAATGGAGACAAGGATTTCTACGGCTCCACTTCTCCTCCCCCGCCTCCTCTACCCCCAGCCCCTCACCGAGCAAACTCACCTACTTCTCCAATTCATCCCTCTTCACCCATACCACCACCTCGGCCAAACTACAACGCACCTCCACCGAAACCACCTTTACCTCCACGACTTCAGCCAGGCCCTTCTACCGCATACTCAACTTCTCCAACACCTCCATCACCTCGTGAGTACAGCCCATCTTTCGAGAGACCGCCTACCACACAACTACAACCCAGACCGTCCTCTACACAGTTACCGCCCTCATGGCAAGCTCCAGCACGGCGGCCATCGCCGACACGGCCAACGATAGATATTCTAGATCTCCAGGACGCACTACCTGCAACCTCTGCACCTCCGCTACCCGAGAACCCGGCTCGAAGGGCCCAATTTGAAGAACTAAATAAACGCTTATGCCGTCGAGCGGAGACGTCCACTGAAAAGACTACGACGATGCTGGAGTCAGCCAAGCAAGTTCGCGAGCGGCTTGTTGCTACCGAAACTAGGCTGGAGCTCGAGACCAGCGAACTCCGGCGAATTGAAGAAGCATGCACGCGGGATACTGCGATTCTGCAGGAGCGGATCAATGCTGCAGAGGGAGTCACGAGGGATGCACTTCAATCAGACGAAGTAGACATCGACAAGATCCTCGTCGGATCGAGAGTCGTATACAACCAAATCTACGATCTCGTCTGCGCCGACTTGGCAATTGACGATACGATCTACGCGTTGGGGATAGCGCACGAGCGGGAATGCATCACGTTTGATGTCTTTCTGCGGCATGTCCGCATCCTCGCTCGAGAGCAATTCCTCAAGAAGGCACTGCTGGCAAAGATTAGGGAGCAGACCAAGCTCCAATAA",
    "translation": "MLQPEVAQWLQRVVSRDYSDKKRVYGDVIDLLTRYPSLSPRTKVFSFEDGRSELLLCIHGTLPVRFRNADYNTPITLWVDKVYPVSRPLAFVTPSPEMGIRAGNHVDPNGAIYHPLLAYWDAKKTIVELAELLREVFGAEMPAYARTAKQNGDKDFYGSTSPPPPPLPPAPHRANSPTSPIHPSSPIPPPRPNYNAPPPKPPLPPRLQPGPSTAYSTSPTPPSPREYSPSFERPPTTQLQPRPSSTQLPPSWQAPARRPSPTRPTIDILDLQDALPATSAPPLPENPARRAQFEELNKRLCRRAETSTEKTTTMLESAKQVRERLVATETRLELETSELRRIEEACTRDTAILQERINAAEGVTRDALQSDEVDIDKILVGSRVVYNQIYDLVCADLAIDDTIYALGIAHERECITFDVFLRHVRILAREQFLKKALLAKIREQTKLQ",
    "product": "hypothetical protein"
   },
   {
    "start": 20091,
    "end": 20865,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004794",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004794</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004794</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004794-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,091 - 20,865,\n (total: 738 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004794 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01738.21 (Dienelactone hydrolase family): [34:231](score: 46.1, e-value: 4.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004794 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01738.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004794\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004794-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004794\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTGACAAATGCTGCCCCTCAGACCTCCCTGCTTTTCAGAGCGACTACAAGCCTCTCGGCCAGACAGTCAAGCTGACAAAGGCGGCGGGCCGTGCATTAGAGACGTACGTGTATCAGCCAGGCGGGAAGGTTGAGCTGGGAATCATCTACTATGCCGACGTCTTTGGCCTCTTGCCCAATGCTCTACAAGGGGCAGACTTGCTGGCAAGGAGTCTAAATGCGCGAGTGTACGTGCCAGACCTCTACGAAGGTCAGCCGTGGGAAACGTCCAATATGCCGCCAAAGGAAGGCTATGAAGCAATGTTTGCCCACTTCGGTAAAGTGGCGCCTCCTGAAAAAATCCGTGAGCTCACAATTGAATTGATCGAGCAACTCCGGGGAGATGGCATTGAACGGGTGGGCGCAATTGGGTTTTGTTTAGGCGCCAAACTCCTTGCAGCAAATTCCGCACTTGTAGGTGCCACAGCCTATATTCATCCGTCAGGCTTCACTGTTGAGGAAGCGAAAGGCTATCGTGGACCGGTCGCTCTCCTTCCATCACAGGACGAGGACAAAGAGCTCATGAAAAACTTTTGGGCAGCTCTCTCAGAGACCGCAAAGAAGGATGGCGTCTTCCAGACCTTCCCTGTCCATCACGGCTTTGCAGCAGGAAGATCAGACTGGAATGACCCTGAGCTTGGCAAGCATGCCCACGAGGCTTTTGAGCTTGCTGCATCAGTCCTGGCAAAGGCCTGA",
    "translation": "MSDKCCPSDLPAFQSDYKPLGQTVKLTKAAGRALETYVYQPGGKVELGIIYYADVFGLLPNALQGADLLARSLNARVYVPDLYEGQPWETSNMPPKEGYEAMFAHFGKVAPPEKIRELTIELIEQLRGDGIERVGAIGFCLGAKLLAANSALVGATAYIHPSGFTVEEAKGYRGPVALLPSQDEDKELMKNFWAALSETAKKDGVFQTFPVHHGFAAGRSDWNDPELGKHAHEAFELAASVLAKA",
    "product": "hypothetical protein"
   },
   {
    "start": 21663,
    "end": 22457,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004795",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004795</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004795</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004795-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,663 - 22,457,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004795 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [186:250](score: 47.7, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004795\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004795\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGATCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
    "translation": "MIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
    "product": "hypothetical protein"
   },
   {
    "start": 22557,
    "end": 23558,
    "strand": -1,
    "locus_tag": "MARS52BIN25_004796",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004796</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004796</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004796-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,557 - 23,558,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 234.9; E-value: 1.8e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004796 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 223.5, e-value: 2.5e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS52BIN25_004796 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004796\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS52BIN25_004796-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004796\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGTTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGGTAATACTGCATTGATGGAGATCCTTAACAGTTGGCATAGTTCTTTGTGTGGCACAGATTAG",
    "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNVWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGGNTALMEILNSWHSSLCGTD",
    "product": "hypothetical protein"
   },
   {
    "start": 23673,
    "end": 24398,
    "strand": 1,
    "locus_tag": "MARS52BIN25_004797",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS52BIN25_004797</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS52BIN25_004797</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS52BIN25_004797-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,673 - 24,398,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS52BIN25_004797 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS52BIN25_004797\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS52BIN25_004797\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGCGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAAGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
    "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 22556,
    "end": 23558,
    "tool": "rule-based-clusters",
    "neighbouring_start": 12556,
    "neighbouring_end": 24505,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r115c1"
 }
};
var details_data = {
 "nrpspks": {
  "r85c1": {
   "id": "r85c1",
   "orfs": [
    {
     "id": "MARS52BIN25_004301",
     "sequence": "MSFLSVNELLDARARDDGDVEIINDPDSNFNYKRYTYNSLLGIASGLAADYGQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENGEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVKPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAACRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLFGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGKLLLLMDH",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 24,
       "end": 341,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "DPDSNFNYKRYTYNSLLGIASGLAADYGQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENGEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVKPYVR",
       "dna_sequence": "GATCCGGACTCGAATTTCAACTATAAAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGGGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACGGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCAAACCCTATGTGCGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 535,
       "end": 606,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLFGQNMIYENPSIDRMAAFI",
       "dna_sequence": "TATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTTGGGCAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "TD",
       "start": 655,
       "end": 891,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKII",
       "dna_sequence": "ATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCTTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATT",
       "abbreviation": "TD",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 24,
       "end": 891,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "MARS52BIN25_004305",
     "sequence": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASNNSEALDDVCFPQDVGDDGERKWPDVAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMRTSVHMRAIQITERVDSPSKLWPSDIAQPRPSSEQVRVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARIIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
     "domains": [
      {
       "type": "PKS_ER",
       "start": 615,
       "end": 915,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SDIAQPRPSSEQVRVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARIIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTI",
       "dna_sequence": "TCTGACATCGCACAGCCCCGGCCGAGTTCAGAGCAAGTGCGGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCATCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATT",
       "abbreviation": "ER",
       "html_class": "jsdomain-mod-er"
      }
     ],
     "modules": []
    }
   ]
  },
  "r110c1": {
   "id": "r110c1",
   "orfs": [
    {
     "id": "MARS52BIN25_004727",
     "sequence": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKAYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 223,
       "end": 688,
       "predictions": [
        [
         "substrate consensus",
         "Aad"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARNAKNHPERPCVIETPKPGHLHEGTKAYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIR",
       "dna_sequence": "TTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAGCATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGCGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 821,
       "end": 888,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEID",
       "dna_sequence": "GCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 944,
       "end": 1194,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVI",
       "dna_sequence": "CTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 223,
       "end": 1194,
       "complete": true,
       "iterative": false,
       "monomer": "Aad",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r15c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {}
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_001680": {
     "functions": []
    },
    "MARS52BIN25_001681": {
     "functions": []
    },
    "MARS52BIN25_001682": {
     "functions": []
    },
    "MARS52BIN25_001683": {
     "functions": []
    },
    "MARS52BIN25_001684": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS52BIN25_001685": {
     "functions": []
    },
    "MARS52BIN25_001686": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1081:cysteine synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_001687": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_001680",
      "seqLength": 168,
      "domains": [
       {
        "start": 59,
        "end": 111,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HIG_1_N",
        "accession": "PF04588",
        "description": "Hypoxia induced protein conserved region",
        "evalue": "5.3e-20",
        "score": "71.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_001681",
      "seqLength": 199,
      "domains": [
       {
        "start": 11,
        "end": 123,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Rhodanese",
        "accession": "PF00581",
        "description": "Rhodanese-like domain",
        "evalue": "0.00011",
        "score": "22.8"
       }
      ]
     },
     {
      "id": "MARS52BIN25_001684",
      "seqLength": 433,
      "domains": [
       {
        "start": 134,
        "end": 418,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "9.4e-47",
        "score": "159.8"
       }
      ]
     },
     {
      "id": "MARS52BIN25_001685",
      "seqLength": 545,
      "domains": [
       {
        "start": 305,
        "end": 491,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TLD",
        "accession": "PF07534",
        "description": "TLD",
        "evalue": "1.8e-17",
        "score": "64.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_001686",
      "seqLength": 572,
      "domains": [
       {
        "start": 79,
        "end": 372,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "4.2e-77",
        "score": "259.6"
       },
       {
        "start": 385,
        "end": 476,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "9.6e-16",
        "score": "57.5"
       },
       {
        "start": 487,
        "end": 569,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "2.9e-20",
        "score": "72.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS52BIN25_001684",
      "seqLength": 433,
      "domains": [
       {
        "start": 1,
        "end": 74,
        "name": "TIGR03462",
        "description": "CarR_dom_SF: lycopene cyclase domain",
        "accession": "TIGR03462",
        "evalue": "7e-15",
        "score": "53.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS52BIN25_001686",
      "seqLength": 572,
      "domains": [
       {
        "start": 65,
        "end": 568,
        "name": "TIGR01124",
        "description": "ilvA_2Cterm: threonine ammonia-lyase, biosynthetic",
        "accession": "TIGR01124",
        "evalue": "3.4e-201",
        "score": "667.1",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r40c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS52BIN25_003079",
         "subject": "gene2",
         "query_loc": 25977,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_003079"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS52BIN25_003079",
         "subject": "mfR6",
         "query_loc": 25977,
         "subject_loc": 67091
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_003079"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001156: 94-35670": {
       "start": 94,
       "end": 35670,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ADD82998.1",
         "query_loc": 34916,
         "subject_loc": 8304
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADD82990.1",
         "start": 1496,
         "end": 2801,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82991.1",
         "start": 5114,
         "end": 6683,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82992.1",
         "start": 30609,
         "end": 32190,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82993.1",
         "start": 19021,
         "end": 19855,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82994.1",
         "start": 19907,
         "end": 21014,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82995.1",
         "start": 21019,
         "end": 22210,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82996.1",
         "start": 22288,
         "end": 23164,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82997.1",
         "start": 3955,
         "end": 5113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82998.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ADD82999.1",
         "start": 14739,
         "end": 16086,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83000.1",
         "start": 16093,
         "end": 17194,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83001.1",
         "start": 17180,
         "end": 18944,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83002.1",
         "start": 94,
         "end": 859,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83003.1",
         "start": 9718,
         "end": 11044,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83004.1",
         "start": 12783,
         "end": 13626,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83005.1",
         "start": 26001,
         "end": 26907,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83006.1",
         "start": 27947,
         "end": 28784,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83007.1",
         "start": 35334,
         "end": 35670,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83008.1",
         "start": 23245,
         "end": 24670,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83009.1",
         "start": 24742,
         "end": 25987,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83010.1",
         "start": 32357,
         "end": 33572,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83011.1",
         "start": 33689,
         "end": 35312,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ADD83012.1",
         "start": 26939,
         "end": 27656,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ADD83013.1",
         "start": 3554,
         "end": 3956,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83014.1",
         "start": 8795,
         "end": 9722,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83015.1",
         "start": 11043,
         "end": 12645,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83016.1",
         "start": 13693,
         "end": 14740,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83017.1",
         "start": 855,
         "end": 1419,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83018.1",
         "start": 2797,
         "end": 3508,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83019.1",
         "start": 6711,
         "end": 7782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83020.1",
         "start": 28780,
         "end": 30571,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ABC42561.1",
         "query_loc": 34916,
         "subject_loc": 27217
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001140: 97-41076": {
       "start": 97,
       "end": 41076,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ACO31273.1",
         "query_loc": 34916,
         "subject_loc": 8304
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACO31265.1",
         "start": 97,
         "end": 862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31266.1",
         "start": 858,
         "end": 1413,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31267.1",
         "start": 1499,
         "end": 2804,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31268.1",
         "start": 2800,
         "end": 3511,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31269.1",
         "start": 3556,
         "end": 3958,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31270.1",
         "start": 3957,
         "end": 5115,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31271.1",
         "start": 5116,
         "end": 6685,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31272.1",
         "start": 6713,
         "end": 7796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31273.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ACO31274.1",
         "start": 8796,
         "end": 9723,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31275.1",
         "start": 9719,
         "end": 11042,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31276.1",
         "start": 11041,
         "end": 12643,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31277.1",
         "start": 12780,
         "end": 13638,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31278.1",
         "start": 13637,
         "end": 14804,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31279.1",
         "start": 14800,
         "end": 15730,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31280.1",
         "start": 15770,
         "end": 17063,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31281.1",
         "start": 17059,
         "end": 18127,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31282.1",
         "start": 18214,
         "end": 19057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31283.1",
         "start": 19113,
         "end": 20160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31284.1",
         "start": 20159,
         "end": 21506,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31285.1",
         "start": 21513,
         "end": 22614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31286.1",
         "start": 22600,
         "end": 24364,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31287.1",
         "start": 24441,
         "end": 25275,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31288.1",
         "start": 25326,
         "end": 26433,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31289.1",
         "start": 26438,
         "end": 27629,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31290.1",
         "start": 27687,
         "end": 28563,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31291.1",
         "start": 28648,
         "end": 30073,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31292.1",
         "start": 30144,
         "end": 31389,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31293.1",
         "start": 31403,
         "end": 32309,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31294.1",
         "start": 32341,
         "end": 33058,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ACO31295.1",
         "start": 33349,
         "end": 34186,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31296.1",
         "start": 34182,
         "end": 35973,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31297.1",
         "start": 36011,
         "end": 37595,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13710.1",
         "start": 37762,
         "end": 38977,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13711.1",
         "start": 39094,
         "end": 40717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACS13712.1",
         "start": 40740,
         "end": 41076,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS52BIN25_003079",
         "subject": "gene2",
         "query_loc": 25977,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_003079"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS52BIN25_003079",
         "subject": "mfR6",
         "query_loc": 25977,
         "subject_loc": 67091
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_003079"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001156: 94-35670": {
       "start": 94,
       "end": 35670,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ADD82998.1",
         "query_loc": 34916,
         "subject_loc": 8304
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADD82990.1",
         "start": 1496,
         "end": 2801,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82991.1",
         "start": 5114,
         "end": 6683,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82992.1",
         "start": 30609,
         "end": 32190,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82993.1",
         "start": 19021,
         "end": 19855,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82994.1",
         "start": 19907,
         "end": 21014,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82995.1",
         "start": 21019,
         "end": 22210,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82996.1",
         "start": 22288,
         "end": 23164,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82997.1",
         "start": 3955,
         "end": 5113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82998.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ADD82999.1",
         "start": 14739,
         "end": 16086,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83000.1",
         "start": 16093,
         "end": 17194,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83001.1",
         "start": 17180,
         "end": 18944,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83002.1",
         "start": 94,
         "end": 859,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83003.1",
         "start": 9718,
         "end": 11044,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83004.1",
         "start": 12783,
         "end": 13626,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83005.1",
         "start": 26001,
         "end": 26907,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83006.1",
         "start": 27947,
         "end": 28784,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83007.1",
         "start": 35334,
         "end": 35670,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83008.1",
         "start": 23245,
         "end": 24670,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83009.1",
         "start": 24742,
         "end": 25987,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83010.1",
         "start": 32357,
         "end": 33572,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83011.1",
         "start": 33689,
         "end": 35312,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ADD83012.1",
         "start": 26939,
         "end": 27656,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ADD83013.1",
         "start": 3554,
         "end": 3956,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83014.1",
         "start": 8795,
         "end": 9722,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83015.1",
         "start": 11043,
         "end": 12645,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83016.1",
         "start": 13693,
         "end": 14740,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83017.1",
         "start": 855,
         "end": 1419,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83018.1",
         "start": 2797,
         "end": 3508,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83019.1",
         "start": 6711,
         "end": 7782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83020.1",
         "start": 28780,
         "end": 30571,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ABC42561.1",
         "query_loc": 34916,
         "subject_loc": 27217
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001140: 97-41076": {
       "start": 97,
       "end": 41076,
       "links": [
        {
         "query": "MARS52BIN25_003084",
         "subject": "ACO31273.1",
         "query_loc": 34916,
         "subject_loc": 8304
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACO31265.1",
         "start": 97,
         "end": 862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31266.1",
         "start": 858,
         "end": 1413,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31267.1",
         "start": 1499,
         "end": 2804,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31268.1",
         "start": 2800,
         "end": 3511,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31269.1",
         "start": 3556,
         "end": 3958,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31270.1",
         "start": 3957,
         "end": 5115,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31271.1",
         "start": 5116,
         "end": 6685,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31272.1",
         "start": 6713,
         "end": 7796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31273.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS52BIN25_003084"
         }
        },
        {
         "locus_tag": "ACO31274.1",
         "start": 8796,
         "end": 9723,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31275.1",
         "start": 9719,
         "end": 11042,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31276.1",
         "start": 11041,
         "end": 12643,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31277.1",
         "start": 12780,
         "end": 13638,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31278.1",
         "start": 13637,
         "end": 14804,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31279.1",
         "start": 14800,
         "end": 15730,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31280.1",
         "start": 15770,
         "end": 17063,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31281.1",
         "start": 17059,
         "end": 18127,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31282.1",
         "start": 18214,
         "end": 19057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31283.1",
         "start": 19113,
         "end": 20160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31284.1",
         "start": 20159,
         "end": 21506,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31285.1",
         "start": 21513,
         "end": 22614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31286.1",
         "start": 22600,
         "end": 24364,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31287.1",
         "start": 24441,
         "end": 25275,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31288.1",
         "start": 25326,
         "end": 26433,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31289.1",
         "start": 26438,
         "end": 27629,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31290.1",
         "start": 27687,
         "end": 28563,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31291.1",
         "start": 28648,
         "end": 30073,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31292.1",
         "start": 30144,
         "end": 31389,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31293.1",
         "start": 31403,
         "end": 32309,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31294.1",
         "start": 32341,
         "end": 33058,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ACO31295.1",
         "start": 33349,
         "end": 34186,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31296.1",
         "start": 34182,
         "end": 35973,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31297.1",
         "start": 36011,
         "end": 37595,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13710.1",
         "start": 37762,
         "end": 38977,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13711.1",
         "start": 39094,
         "end": 40717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACS13712.1",
         "start": 40740,
         "end": 41076,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_003073": {
     "functions": []
    },
    "MARS52BIN25_003074": {
     "functions": []
    },
    "MARS52BIN25_003075": {
     "functions": []
    },
    "MARS52BIN25_003076": {
     "functions": []
    },
    "MARS52BIN25_003077": {
     "functions": []
    },
    "MARS52BIN25_003078": {
     "functions": []
    },
    "MARS52BIN25_003079": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS52BIN25_003080": {
     "functions": [
      {
       "description": "SMCOG1173:WD-40 repeat-containing protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_003081": {
     "functions": []
    },
    "MARS52BIN25_003082": {
     "functions": []
    },
    "MARS52BIN25_003083": {
     "functions": []
    },
    "MARS52BIN25_003084": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_003075",
      "seqLength": 301,
      "domains": [
       {
        "start": 1,
        "end": 109,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MOSC_N",
        "accession": "PF03476",
        "description": "MOSC N-terminal beta barrel domain",
        "evalue": "1.8e-13",
        "score": "50.5"
       },
       {
        "start": 159,
        "end": 288,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "MOSC",
        "accession": "PF03473",
        "description": "MOSC domain",
        "evalue": "1.2e-24",
        "score": "87.1"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003076",
      "seqLength": 434,
      "domains": [
       {
        "start": 23,
        "end": 46,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00041",
        "score": "20.8"
       },
       {
        "start": 52,
        "end": 76,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00088",
        "score": "19.7"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003077",
      "seqLength": 343,
      "domains": [
       {
        "start": 27,
        "end": 235,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation"
        ],
        "html_class": "generic-type-other",
        "name": "tRNA-synt_2b",
        "accession": "PF00587",
        "description": "tRNA synthetase class II core domain (G, H, P, S and T)",
        "evalue": "2.5e-35",
        "score": "122.2"
       },
       {
        "start": 255,
        "end": 302,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HGTP_anticodon",
        "accession": "PF03129",
        "description": "Anticodon binding domain",
        "evalue": "0.00029",
        "score": "21.1"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003078",
      "seqLength": 659,
      "domains": [
       {
        "start": 90,
        "end": 406,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GCP_N_terminal",
        "accession": "PF17681",
        "description": "Gamma tubulin complex component N-terminal",
        "evalue": "1e-60",
        "score": "206.1"
       },
       {
        "start": 410,
        "end": 657,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding"
        ],
        "html_class": "generic-type-other",
        "name": "GCP_C_terminal",
        "accession": "PF04130",
        "description": "Gamma tubulin complex component C-terminal",
        "evalue": "2.8e-50",
        "score": "171.6"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003079",
      "seqLength": 468,
      "domains": [
       {
        "start": 65,
        "end": 356,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "2.5e-37",
        "score": "129.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003080",
      "seqLength": 630,
      "domains": [
       {
        "start": 124,
        "end": 159,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "WD40",
        "accession": "PF00400",
        "description": "WD domain, G-beta repeat",
        "evalue": "8.4e-05",
        "score": "23.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003081",
      "seqLength": 257,
      "domains": [
       {
        "start": 99,
        "end": 223,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "NOT2_3_5",
        "accession": "PF04153",
        "description": "NOT2 / NOT3 / NOT5 family",
        "evalue": "1.6e-34",
        "score": "118.9"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003082",
      "seqLength": 236,
      "domains": [
       {
        "start": 30,
        "end": 233,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum"
        ],
        "html_class": "generic-type-other",
        "name": "Rot1",
        "accession": "PF10681",
        "description": "Chaperone for protein-folding within the ER, fungal",
        "evalue": "4.8e-88",
        "score": "294.3"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003083",
      "seqLength": 390,
      "domains": [
       {
        "start": 235,
        "end": 353,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport"
        ],
        "html_class": "generic-type-other",
        "name": "Ran_BP1",
        "accession": "PF00638",
        "description": "RanBP1 domain",
        "evalue": "2.3e-19",
        "score": "70.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_003084",
      "seqLength": 893,
      "domains": [
       {
        "start": 8,
        "end": 195,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "3.6e-38",
        "score": "131.1"
       },
       {
        "start": 313,
        "end": 496,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "8.9e-43",
        "score": "146.2"
       },
       {
        "start": 769,
        "end": 879,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "MaoC_dehydratas",
        "accession": "PF01575",
        "description": "MaoC like domain",
        "evalue": "6.8e-33",
        "score": "113.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS52BIN25_003079",
      "seqLength": 468,
      "domains": [
       {
        "start": 56,
        "end": 406,
        "name": "TIGR01559",
        "description": "squal_synth: farnesyl-diphosphate farnesyltransferase",
        "accession": "TIGR01559",
        "evalue": "4.4e-128",
        "score": "425.1",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r85c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000677: 120-4940": {
       "start": 120,
       "end": 4940,
       "links": [
        {
         "query": "MARS52BIN25_004300",
         "subject": "BAI44339.1",
         "query_loc": 18324,
         "subject_loc": 2806
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAI44337.1",
         "start": 120,
         "end": 1200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BAI44338.1",
         "start": 1196,
         "end": 2120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAI44339.1",
         "start": 2116,
         "end": 3496,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004300"
         }
        },
        {
         "locus_tag": "BAI44340.1",
         "start": 3560,
         "end": 4940,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001516: 0-14978": {
       "start": 0,
       "end": 14978,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AFLA_023050",
         "query_loc": 25996,
         "subject_loc": 13316
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFLA_023000",
         "start": 0,
         "end": 1069,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023010",
         "start": 2762,
         "end": 3758,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023020",
         "start": 4299,
         "end": 7365,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023030",
         "start": 7979,
         "end": 9639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023040",
         "start": 9846,
         "end": 11965,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023050",
         "start": 12565,
         "end": 14067,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "AFLA_023060",
         "start": 14709,
         "end": 14978,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002602: 406-14432": {
       "start": 406,
       "end": 14432,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AZL87947.1",
         "query_loc": 25996,
         "subject_loc": 13682
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AZL87942.1",
         "start": 406,
         "end": 1475,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87943.1",
         "start": 3167,
         "end": 4163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87944.1",
         "start": 4677,
         "end": 7743,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AZL87945.1",
         "start": 8332,
         "end": 10007,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AZL87946.1",
         "start": 10377,
         "end": 12334,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87947.1",
         "start": 12932,
         "end": 14432,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        }
       ]
      },
      "BGC0002213: 0-33851": {
       "start": 0,
       "end": 33851,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "PUNSTDRAFT_51778",
         "query_loc": 25996,
         "subject_loc": 15277
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PUNSTDRAFT_101387",
         "start": 0,
         "end": 1870,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_101403",
         "start": 32203,
         "end": 33851,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143067",
         "start": 6011,
         "end": 13646,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143069",
         "start": 17866,
         "end": 20360,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143070",
         "start": 22036,
         "end": 24200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143071",
         "start": 24847,
         "end": 26040,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51778",
         "start": 14240,
         "end": 16314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "PUNSTDRAFT_51779",
         "start": 17422,
         "end": 17642,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51781",
         "start": 27435,
         "end": 27922,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51782",
         "start": 28627,
         "end": 28873,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51783",
         "start": 30604,
         "end": 31659,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_85939",
         "start": 2443,
         "end": 4527,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001305: 0-24253": {
       "start": 0,
       "end": 24253,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "FFUJ_12242",
         "query_loc": 25996,
         "subject_loc": 13661
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FFUJ_12239",
         "start": 0,
         "end": 7646,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12240",
         "start": 8284,
         "end": 9379,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12241",
         "start": 10274,
         "end": 11368,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12242",
         "start": 12857,
         "end": 14466,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "FFUJ_12243",
         "start": 15419,
         "end": 16774,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12244",
         "start": 22521,
         "end": 24253,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000154: 266-31301": {
       "start": 266,
       "end": 31301,
       "links": [
        {
         "query": "MARS52BIN25_004301",
         "subject": "TSTA_117750",
         "query_loc": 20188,
         "subject_loc": 11891
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "TSTA_117720",
         "start": 266,
         "end": 1319,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730",
         "start": 2958,
         "end": 4856,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730_rename1",
         "start": 2958,
         "end": 4392,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117740",
         "start": 5779,
         "end": 7202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117750",
         "start": 7861,
         "end": 15921,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004301"
         }
        },
        {
         "locus_tag": "TSTA_117760",
         "start": 16374,
         "end": 17254,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117760_rename1",
         "start": 16374,
         "end": 16965,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117770",
         "start": 17890,
         "end": 19546,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117780",
         "start": 20154,
         "end": 21134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117790",
         "start": 21843,
         "end": 23432,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117800",
         "start": 24056,
         "end": 25227,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810_rename1",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117820",
         "start": 30394,
         "end": 31301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002158: 177-13328": {
       "start": 177,
       "end": 13328,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "MGG_07802",
         "query_loc": 25996,
         "subject_loc": 4761
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MGG_07800",
         "start": 177,
         "end": 2585,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MGG_07802",
         "start": 4043,
         "end": 5480,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "MGG_07803",
         "start": 7152,
         "end": 13328,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MGG_16932",
         "start": 3001,
         "end": 3236,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002268: 0-26854": {
       "start": 0,
       "end": 26854,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "QNH68022.1",
         "query_loc": 25996,
         "subject_loc": 9229
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QNH68018.1",
         "start": 0,
         "end": 1901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68019.1",
         "start": 2450,
         "end": 4076,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68020.1",
         "start": 4498,
         "end": 6351,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68021.1",
         "start": 6671,
         "end": 7713,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68022.1",
         "start": 8463,
         "end": 9996,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "QNH68023.1",
         "start": 11606,
         "end": 13995,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68024.1",
         "start": 14697,
         "end": 26854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000088: 1812-55428": {
       "start": 1812,
       "end": 55428,
       "links": [
        {
         "query": "MARS52BIN25_004305",
         "subject": "lovF",
         "query_loc": 31937,
         "subject_loc": 32546
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAD34550.1",
         "start": 1812,
         "end": 6865,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34551.1",
         "start": 7615,
         "end": 8602,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34553.1",
         "start": 13089,
         "end": 13860,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34556.1",
         "start": 17658,
         "end": 21162,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAD34558.1",
         "start": 25499,
         "end": 27660,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAD34560.1",
         "start": 36808,
         "end": 37696,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34561.1",
         "start": 38230,
         "end": 40708,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34562.1",
         "start": 42440,
         "end": 43742,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34563.1",
         "start": 44431,
         "end": 45960,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34564.1",
         "start": 46917,
         "end": 48621,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAD34565.1",
         "start": 50936,
         "end": 52625,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAD34566.1",
         "start": 53925,
         "end": 55428,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "lovA",
         "start": 9979,
         "end": 11712,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovC",
         "start": 14257,
         "end": 15510,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovD",
         "start": 15909,
         "end": 17303,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovE",
         "start": 22459,
         "end": 23971,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "lovF",
         "start": 28529,
         "end": 36564,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004305"
         }
        }
       ]
      },
      "BGC0001445: 0-31620": {
       "start": 0,
       "end": 31620,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AFLA_066880",
         "query_loc": 25996,
         "subject_loc": 16596
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFLA_066840",
         "start": 0,
         "end": 11841,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066850",
         "start": 12125,
         "end": 12604,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066860",
         "start": 12933,
         "end": 14712,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066870",
         "start": 14786,
         "end": 15209,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066880",
         "start": 15841,
         "end": 17352,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "AFLA_066890",
         "start": 17950,
         "end": 19862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066900",
         "start": 22137,
         "end": 24674,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066910",
         "start": 25388,
         "end": 26529,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066920",
         "start": 26765,
         "end": 28030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066930",
         "start": 28241,
         "end": 29894,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066940",
         "start": 30226,
         "end": 31620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000677: 120-4940": {
       "start": 120,
       "end": 4940,
       "links": [
        {
         "query": "MARS52BIN25_004300",
         "subject": "BAI44339.1",
         "query_loc": 18324,
         "subject_loc": 2806
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BAI44337.1",
         "start": 120,
         "end": 1200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "BAI44338.1",
         "start": 1196,
         "end": 2120,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BAI44339.1",
         "start": 2116,
         "end": 3496,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004300"
         }
        },
        {
         "locus_tag": "BAI44340.1",
         "start": 3560,
         "end": 4940,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001516: 0-14978": {
       "start": 0,
       "end": 14978,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AFLA_023050",
         "query_loc": 25996,
         "subject_loc": 13316
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFLA_023000",
         "start": 0,
         "end": 1069,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023010",
         "start": 2762,
         "end": 3758,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023020",
         "start": 4299,
         "end": 7365,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023030",
         "start": 7979,
         "end": 9639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023040",
         "start": 9846,
         "end": 11965,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023050",
         "start": 12565,
         "end": 14067,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "AFLA_023060",
         "start": 14709,
         "end": 14978,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002602: 406-14432": {
       "start": 406,
       "end": 14432,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AZL87947.1",
         "query_loc": 25996,
         "subject_loc": 13682
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AZL87942.1",
         "start": 406,
         "end": 1475,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87943.1",
         "start": 3167,
         "end": 4163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87944.1",
         "start": 4677,
         "end": 7743,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AZL87945.1",
         "start": 8332,
         "end": 10007,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AZL87946.1",
         "start": 10377,
         "end": 12334,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87947.1",
         "start": 12932,
         "end": 14432,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        }
       ]
      },
      "BGC0002213: 0-33851": {
       "start": 0,
       "end": 33851,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "PUNSTDRAFT_51778",
         "query_loc": 25996,
         "subject_loc": 15277
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PUNSTDRAFT_101387",
         "start": 0,
         "end": 1870,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_101403",
         "start": 32203,
         "end": 33851,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143067",
         "start": 6011,
         "end": 13646,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143069",
         "start": 17866,
         "end": 20360,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143070",
         "start": 22036,
         "end": 24200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143071",
         "start": 24847,
         "end": 26040,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51778",
         "start": 14240,
         "end": 16314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "PUNSTDRAFT_51779",
         "start": 17422,
         "end": 17642,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51781",
         "start": 27435,
         "end": 27922,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51782",
         "start": 28627,
         "end": 28873,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51783",
         "start": 30604,
         "end": 31659,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_85939",
         "start": 2443,
         "end": 4527,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001305: 0-24253": {
       "start": 0,
       "end": 24253,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "FFUJ_12242",
         "query_loc": 25996,
         "subject_loc": 13661
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FFUJ_12239",
         "start": 0,
         "end": 7646,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12240",
         "start": 8284,
         "end": 9379,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12241",
         "start": 10274,
         "end": 11368,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12242",
         "start": 12857,
         "end": 14466,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "FFUJ_12243",
         "start": 15419,
         "end": 16774,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12244",
         "start": 22521,
         "end": 24253,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000154: 266-31301": {
       "start": 266,
       "end": 31301,
       "links": [
        {
         "query": "MARS52BIN25_004301",
         "subject": "TSTA_117750",
         "query_loc": 20188,
         "subject_loc": 11891
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "TSTA_117720",
         "start": 266,
         "end": 1319,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730",
         "start": 2958,
         "end": 4856,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730_rename1",
         "start": 2958,
         "end": 4392,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117740",
         "start": 5779,
         "end": 7202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117750",
         "start": 7861,
         "end": 15921,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004301"
         }
        },
        {
         "locus_tag": "TSTA_117760",
         "start": 16374,
         "end": 17254,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117760_rename1",
         "start": 16374,
         "end": 16965,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117770",
         "start": 17890,
         "end": 19546,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117780",
         "start": 20154,
         "end": 21134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117790",
         "start": 21843,
         "end": 23432,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117800",
         "start": 24056,
         "end": 25227,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810_rename1",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117820",
         "start": 30394,
         "end": 31301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002158: 177-13328": {
       "start": 177,
       "end": 13328,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "MGG_07802",
         "query_loc": 25996,
         "subject_loc": 4761
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MGG_07800",
         "start": 177,
         "end": 2585,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MGG_07802",
         "start": 4043,
         "end": 5480,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "MGG_07803",
         "start": 7152,
         "end": 13328,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MGG_16932",
         "start": 3001,
         "end": 3236,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002268: 0-26854": {
       "start": 0,
       "end": 26854,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "QNH68022.1",
         "query_loc": 25996,
         "subject_loc": 9229
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QNH68018.1",
         "start": 0,
         "end": 1901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68019.1",
         "start": 2450,
         "end": 4076,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68020.1",
         "start": 4498,
         "end": 6351,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68021.1",
         "start": 6671,
         "end": 7713,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68022.1",
         "start": 8463,
         "end": 9996,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "QNH68023.1",
         "start": 11606,
         "end": 13995,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68024.1",
         "start": 14697,
         "end": 26854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000088: 1812-55428": {
       "start": 1812,
       "end": 55428,
       "links": [
        {
         "query": "MARS52BIN25_004305",
         "subject": "lovF",
         "query_loc": 31937,
         "subject_loc": 32546
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AAD34550.1",
         "start": 1812,
         "end": 6865,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34551.1",
         "start": 7615,
         "end": 8602,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34553.1",
         "start": 13089,
         "end": 13860,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34556.1",
         "start": 17658,
         "end": 21162,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAD34558.1",
         "start": 25499,
         "end": 27660,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAD34560.1",
         "start": 36808,
         "end": 37696,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34561.1",
         "start": 38230,
         "end": 40708,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34562.1",
         "start": 42440,
         "end": 43742,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34563.1",
         "start": 44431,
         "end": 45960,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AAD34564.1",
         "start": 46917,
         "end": 48621,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AAD34565.1",
         "start": 50936,
         "end": 52625,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AAD34566.1",
         "start": 53925,
         "end": 55428,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "lovA",
         "start": 9979,
         "end": 11712,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovC",
         "start": 14257,
         "end": 15510,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovD",
         "start": 15909,
         "end": 17303,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "lovE",
         "start": 22459,
         "end": 23971,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "lovF",
         "start": 28529,
         "end": 36564,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004305"
         }
        }
       ]
      },
      "BGC0001445: 0-31620": {
       "start": 0,
       "end": 31620,
       "links": [
        {
         "query": "MARS52BIN25_004303",
         "subject": "AFLA_066880",
         "query_loc": 25996,
         "subject_loc": 16596
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFLA_066840",
         "start": 0,
         "end": 11841,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066850",
         "start": 12125,
         "end": 12604,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066860",
         "start": 12933,
         "end": 14712,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066870",
         "start": 14786,
         "end": 15209,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066880",
         "start": 15841,
         "end": 17352,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS52BIN25_004303"
         }
        },
        {
         "locus_tag": "AFLA_066890",
         "start": 17950,
         "end": 19862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066900",
         "start": 22137,
         "end": 24674,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066910",
         "start": 25388,
         "end": 26529,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066920",
         "start": 26765,
         "end": 28030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066930",
         "start": 28241,
         "end": 29894,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_066940",
         "start": 30226,
         "end": 31620,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004301",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 24,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004301",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 535,
        "terminalDocking": ""
       },
       {
        "name": "TD",
        "description": "TD",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004301",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 655,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_004291": {
     "functions": [
      {
       "description": "SMCOG1169:sugar transport protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004292": {
     "functions": []
    },
    "MARS52BIN25_004293": {
     "functions": [
      {
       "description": "SMCOG1169:sugar transport protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004294": {
     "functions": []
    },
    "MARS52BIN25_004295": {
     "functions": []
    },
    "MARS52BIN25_004296": {
     "functions": []
    },
    "MARS52BIN25_004297": {
     "functions": [
      {
       "description": "SMCOG1079:oxidoreductase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004298": {
     "functions": [
      {
       "description": "SMCOG1100:3-hydroxyisobutyrate dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004299": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1034:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004300": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS52BIN25_004301": {
     "functions": [
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004302": {
     "functions": []
    },
    "MARS52BIN25_004303": {
     "functions": [
      {
       "description": "SMCOG1137:Major facilitator superfamily MFS 1 ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004304": {
     "functions": []
    },
    "MARS52BIN25_004305": {
     "functions": [
      {
       "description": "ADH_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ADH_zinc_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004306": {
     "functions": []
    },
    "MARS52BIN25_004307": {
     "functions": []
    },
    "MARS52BIN25_004308": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_004291",
      "seqLength": 645,
      "domains": [
       {
        "start": 139,
        "end": 593,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "Sugar_tr",
        "accession": "PF00083",
        "description": "Sugar (and other) transporter",
        "evalue": "1.4e-86",
        "score": "291.3"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004293",
      "seqLength": 386,
      "domains": [
       {
        "start": 0,
        "end": 347,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "Sugar_tr",
        "accession": "PF00083",
        "description": "Sugar (and other) transporter",
        "evalue": "2.5e-62",
        "score": "211.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004294",
      "seqLength": 458,
      "domains": [
       {
        "start": 19,
        "end": 431,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF1479",
        "accession": "PF07350",
        "description": "Protein of unknown function (DUF1479)",
        "evalue": "4.7e-122",
        "score": "407.9"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004295",
      "seqLength": 788,
      "domains": [
       {
        "start": 26,
        "end": 88,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF4964",
        "accession": "PF16334",
        "description": "Domain of unknown function (DUF4964)",
        "evalue": "7e-10",
        "score": "38.5"
       },
       {
        "start": 108,
        "end": 351,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF5127",
        "accession": "PF17168",
        "description": "Domain of unknown function (DUF5127)",
        "evalue": "3.5e-52",
        "score": "177.6"
       },
       {
        "start": 421,
        "end": 600,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF4965",
        "accession": "PF16335",
        "description": "Domain of unknown function (DUF4965)",
        "evalue": "7.9e-65",
        "score": "217.8"
       },
       {
        "start": 605,
        "end": 778,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF1793",
        "accession": "PF08760",
        "description": "Domain of unknown function (DUF1793)",
        "evalue": "3.2e-65",
        "score": "219.7"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004296",
      "seqLength": 483,
      "domains": [
       {
        "start": 128,
        "end": 424,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016853' target='_blank'>GO:0016853</a>: isomerase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005975' target='_blank'>GO:0005975</a>: carbohydrate metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Aldose_epim",
        "accession": "PF01263",
        "description": "Aldose 1-epimerase",
        "evalue": "3.7e-53",
        "score": "180.9"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004297",
      "seqLength": 405,
      "domains": [
       {
        "start": 1,
        "end": 119,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GFO_IDH_MocA",
        "accession": "PF01408",
        "description": "Oxidoreductase family, NAD-binding Rossmann fold",
        "evalue": "3.6e-18",
        "score": "66.5"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004298",
      "seqLength": 429,
      "domains": [
       {
        "start": 7,
        "end": 104,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding"
        ],
        "html_class": "generic-type-other",
        "name": "NAD_binding_11",
        "accession": "PF14833",
        "description": "NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase",
        "evalue": "2.2e-11",
        "score": "44.1"
       },
       {
        "start": 133,
        "end": 287,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "NAD_binding_2",
        "accession": "PF03446",
        "description": "NAD binding domain of 6-phosphogluconate dehydrogenase",
        "evalue": "6.2e-34",
        "score": "117.6"
       },
       {
        "start": 299,
        "end": 420,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding"
        ],
        "html_class": "generic-type-other",
        "name": "NAD_binding_11",
        "accession": "PF14833",
        "description": "NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase",
        "evalue": "2.3e-26",
        "score": "92.5"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004299",
      "seqLength": 332,
      "domains": [
       {
        "start": 34,
        "end": 331,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "3.5e-15",
        "score": "55.9"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004300",
      "seqLength": 122,
      "domains": [
       {
        "start": 3,
        "end": 62,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "7.9e-14",
        "score": "51.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004301",
      "seqLength": 988,
      "domains": [
       {
        "start": 20,
        "end": 320,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "5.2e-36",
        "score": "124.3"
       },
       {
        "start": 536,
        "end": 606,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.3e-07",
        "score": "32.0"
       },
       {
        "start": 657,
        "end": 891,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "5.2e-42",
        "score": "143.9"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004302",
      "seqLength": 627,
      "domains": [
       {
        "start": 20,
        "end": 52,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "Zn_clus",
        "accession": "PF00172",
        "description": "Fungal Zn(2)-Cys(6) binuclear cluster domain",
        "evalue": "1.6e-09",
        "score": "37.8"
       },
       {
        "start": 166,
        "end": 392,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Fungal_trans",
        "accession": "PF04082",
        "description": "Fungal specific transcription factor domain",
        "evalue": "4.5e-26",
        "score": "91.6"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004303",
      "seqLength": 465,
      "domains": [
       {
        "start": 80,
        "end": 327,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
        ],
        "html_class": "generic-type-transport",
        "name": "MFS_1",
        "accession": "PF07690",
        "description": "Major Facilitator Superfamily",
        "evalue": "5.8e-19",
        "score": "68.3"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004304",
      "seqLength": 1119,
      "domains": [
       {
        "start": 448,
        "end": 755,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity"
        ],
        "html_class": "generic-type-other",
        "name": "SNF2-rel_dom",
        "accession": "PF00176",
        "description": "SNF2-related domain",
        "evalue": "3.7e-63",
        "score": "213.5"
       },
       {
        "start": 933,
        "end": 1048,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "2e-13",
        "score": "50.8"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004305",
      "seqLength": 924,
      "domains": [
       {
        "start": 288,
        "end": 593,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "CorA",
        "accession": "PF01544",
        "description": "CorA-like Mg2+ transporter protein",
        "evalue": "1.3e-46",
        "score": "159.5"
       },
       {
        "start": 625,
        "end": 689,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ADH_N",
        "accession": "PF08240",
        "description": "Alcohol dehydrogenase GroES-like domain",
        "evalue": "1.2e-09",
        "score": "38.1"
       },
       {
        "start": 747,
        "end": 870,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ADH_zinc_N",
        "accession": "PF00107",
        "description": "Zinc-binding dehydrogenase",
        "evalue": "4.4e-26",
        "score": "91.5"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004306",
      "seqLength": 631,
      "domains": [
       {
        "start": 51,
        "end": 587,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "EMP70",
        "accession": "PF02990",
        "description": "Endomembrane protein 70",
        "evalue": "1.5e-195",
        "score": "651.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004308",
      "seqLength": 521,
      "domains": [
       {
        "start": 226,
        "end": 309,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MBOAT_2",
        "accession": "PF13813",
        "description": "Membrane bound O-acyl transferase family",
        "evalue": "1.8e-13",
        "score": "50.6"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS52BIN25_004291",
      "seqLength": 645,
      "domains": [
       {
        "start": 135,
        "end": 589,
        "name": "TIGR00879",
        "description": "SP: MFS transporter, sugar porter (SP) family",
        "accession": "TIGR00879",
        "evalue": "5.5e-84",
        "score": "280.5",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004293",
      "seqLength": 386,
      "domains": [
       {
        "start": 0,
        "end": 343,
        "name": "TIGR00879",
        "description": "SP: MFS transporter, sugar porter (SP) family",
        "accession": "TIGR00879",
        "evalue": "6.3e-74",
        "score": "247.3",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r105c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {}
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_004659": {
     "functions": []
    },
    "MARS52BIN25_004660": {
     "functions": []
    },
    "MARS52BIN25_004661": {
     "functions": []
    },
    "MARS52BIN25_004662": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS52BIN25_004663": {
     "functions": []
    },
    "MARS52BIN25_004664": {
     "functions": []
    },
    "MARS52BIN25_004665": {
     "functions": []
    },
    "MARS52BIN25_004666": {
     "functions": []
    },
    "MARS52BIN25_004667": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_004659",
      "seqLength": 896,
      "domains": [
       {
        "start": 228,
        "end": 403,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_N",
        "accession": "PF00350",
        "description": "Dynamin family",
        "evalue": "8.4e-42",
        "score": "143.2"
       },
       {
        "start": 410,
        "end": 541,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_M",
        "accession": "PF01031",
        "description": "Dynamin central region",
        "evalue": "3e-15",
        "score": "56.3"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004660",
      "seqLength": 961,
      "domains": [
       {
        "start": 11,
        "end": 273,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GTP_EFTU",
        "accession": "PF00009",
        "description": "Elongation factor Tu GTP binding domain",
        "evalue": "1.1e-34",
        "score": "119.8"
       },
       {
        "start": 492,
        "end": 556,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_III",
        "accession": "PF14492",
        "description": "Elongation Factor G, domain III",
        "evalue": "1.6e-06",
        "score": "28.2"
       },
       {
        "start": 826,
        "end": 907,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_C",
        "accession": "PF00679",
        "description": "Elongation factor G C-terminus",
        "evalue": "1.9e-13",
        "score": "50.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004661",
      "seqLength": 313,
      "domains": [
       {
        "start": 9,
        "end": 99,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.6e-14",
        "score": "54.4"
       },
       {
        "start": 214,
        "end": 306,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.1e-16",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004662",
      "seqLength": 303,
      "domains": [
       {
        "start": 29,
        "end": 285,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "8.9e-51",
        "score": "173.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004663",
      "seqLength": 174,
      "domains": [
       {
        "start": 1,
        "end": 68,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation"
        ],
        "html_class": "generic-type-other",
        "name": "IF3_N",
        "accession": "PF05198",
        "description": "Translation initiation factor IF-3, N-terminal domain",
        "evalue": "1.4e-08",
        "score": "35.0"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004664",
      "seqLength": 343,
      "domains": [
       {
        "start": 103,
        "end": 307,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MFAP1",
        "accession": "PF06991",
        "description": "Microfibril-associated/Pre-mRNA processing",
        "evalue": "1.7e-61",
        "score": "208.1"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004665",
      "seqLength": 236,
      "domains": [
       {
        "start": 71,
        "end": 224,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TRAPP",
        "accession": "PF04051",
        "description": "Transport protein particle (TRAPP) component",
        "evalue": "2.4e-43",
        "score": "147.6"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004666",
      "seqLength": 340,
      "domains": [
       {
        "start": 57,
        "end": 300,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PP2C",
        "accession": "PF00481",
        "description": "Protein phosphatase 2C",
        "evalue": "2.9e-67",
        "score": "227.2"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r110c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "perA",
         "query_loc": 5579,
         "subject_loc": 4161
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "icoS",
         "query_loc": 5579,
         "subject_loc": 22489
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "XNC1_2022",
         "query_loc": 5579,
         "subject_loc": 6208
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "plu3123",
         "query_loc": 5579,
         "subject_loc": 8187
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "plu3263",
         "query_loc": 5579,
         "subject_loc": 7860
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "PLU_RS13235",
         "query_loc": 5579,
         "subject_loc": 24552
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "X797_010654",
         "query_loc": 5579,
         "subject_loc": 14258
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "AN5318.2",
         "query_loc": 5579,
         "subject_loc": 1906
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 5579,
         "subject_loc": 4534
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "BO96DRAFT_451379",
         "query_loc": 5579,
         "subject_loc": 6032
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "perA",
         "query_loc": 5579,
         "subject_loc": 4161
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "icoS",
         "query_loc": 5579,
         "subject_loc": 22489
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "XNC1_2022",
         "query_loc": 5579,
         "subject_loc": 6208
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "plu3123",
         "query_loc": 5579,
         "subject_loc": 8187
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "plu3263",
         "query_loc": 5579,
         "subject_loc": 7860
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "PLU_RS13235",
         "query_loc": 5579,
         "subject_loc": 24552
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "X797_010654",
         "query_loc": 5579,
         "subject_loc": 14258
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "AN5318.2",
         "query_loc": 5579,
         "subject_loc": 1906
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 5579,
         "subject_loc": 4534
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS52BIN25_004727",
         "subject": "BO96DRAFT_451379",
         "query_loc": 5579,
         "subject_loc": 6032
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004727"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004727",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 223,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004727",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 821,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "MARS52BIN25_004727",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 944,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Aad"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_004725": {
     "functions": []
    },
    "MARS52BIN25_004726": {
     "functions": []
    },
    "MARS52BIN25_004727": {
     "functions": [
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004728": {
     "functions": []
    },
    "MARS52BIN25_004729": {
     "functions": []
    },
    "MARS52BIN25_004730": {
     "functions": []
    },
    "MARS52BIN25_004731": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS52BIN25_004732": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_004725",
      "seqLength": 323,
      "domains": [
       {
        "start": 27,
        "end": 270,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF1295",
        "accession": "PF06966",
        "description": "Protein of unknown function (DUF1295)",
        "evalue": "3e-60",
        "score": "203.7"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004726",
      "seqLength": 528,
      "domains": [
       {
        "start": 36,
        "end": 102,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab_N",
        "accession": "PF02874",
        "description": "ATP synthase alpha/beta family, beta-barrel domain",
        "evalue": "2.2e-14",
        "score": "53.9"
       },
       {
        "start": 158,
        "end": 386,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab",
        "accession": "PF00006",
        "description": "ATP synthase alpha/beta family, nucleotide-binding domain",
        "evalue": "6.7e-64",
        "score": "215.6"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004727",
      "seqLength": 1355,
      "domains": [
       {
        "start": 223,
        "end": 688,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "3.8e-65",
        "score": "220.3"
       },
       {
        "start": 822,
        "end": 887,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "2.9e-12",
        "score": "46.8"
       },
       {
        "start": 944,
        "end": 1194,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "1.5e-76",
        "score": "257.1"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004729",
      "seqLength": 894,
      "domains": [
       {
        "start": 632,
        "end": 762,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity"
        ],
        "html_class": "generic-type-other",
        "name": "AAA",
        "accession": "PF00004",
        "description": "ATPase family associated with various cellular activities (AAA)",
        "evalue": "3.1e-40",
        "score": "137.8"
       },
       {
        "start": 785,
        "end": 820,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_lid_3",
        "accession": "PF17862",
        "description": "AAA+ lid domain",
        "evalue": "4.3e-07",
        "score": "29.8"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004730",
      "seqLength": 335,
      "domains": [
       {
        "start": 1,
        "end": 61,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "8.9e-14",
        "score": "51.2"
       },
       {
        "start": 94,
        "end": 159,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "2.3e-15",
        "score": "56.3"
       },
       {
        "start": 184,
        "end": 250,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "1.6e-15",
        "score": "56.7"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004731",
      "seqLength": 715,
      "domains": [
       {
        "start": 7,
        "end": 262,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Trp_syntA",
        "accession": "PF00290",
        "description": "Tryptophan synthase alpha chain",
        "evalue": "2.5e-89",
        "score": "298.8"
       },
       {
        "start": 365,
        "end": 689,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "8.8e-49",
        "score": "166.6"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004732",
      "seqLength": 189,
      "domains": [
       {
        "start": 112,
        "end": 186,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding"
        ],
        "html_class": "generic-type-other",
        "name": "PX",
        "accession": "PF00787",
        "description": "PX domain",
        "evalue": "1.3e-15",
        "score": "58.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS52BIN25_004726",
      "seqLength": 528,
      "domains": [
       {
        "start": 32,
        "end": 495,
        "name": "TIGR01040",
        "description": "V-ATPase_V1_B: V-type ATPase, B subunit",
        "accession": "TIGR01040",
        "evalue": "4.7e-291",
        "score": "963.0",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004727",
      "seqLength": 1355,
      "domains": [
       {
        "start": 6,
        "end": 1350,
        "name": "TIGR03443",
        "description": "alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase",
        "accession": "TIGR03443",
        "evalue": "0",
        "score": "1898.5",
        "html_class": "generic-type-other"
       },
       {
        "start": 253,
        "end": 711,
        "name": "TIGR01733",
        "description": "AA-adenyl-dom: amino acid adenylation domain",
        "accession": "TIGR01733",
        "evalue": "5.1e-114",
        "score": "379.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 941,
        "end": 1317,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "1.8e-104",
        "score": "347.9",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004731",
      "seqLength": 715,
      "domains": [
       {
        "start": 319,
        "end": 701,
        "name": "TIGR00263",
        "description": "trpB: tryptophan synthase, beta subunit",
        "accession": "TIGR00263",
        "evalue": "1.7e-174",
        "score": "578.4",
        "html_class": "generic-type-other"
       },
       {
        "start": 8,
        "end": 262,
        "name": "TIGR00262",
        "description": "trpA: tryptophan synthase, alpha subunit",
        "accession": "TIGR00262",
        "evalue": "5.9e-67",
        "score": "223.2",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r115c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "ANIA_01592",
         "query_loc": 23057,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "PCH_Pc20g10860",
         "query_loc": 23057,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002716: 0-53197": {
       "start": 0,
       "end": 53197,
       "links": [
        {
         "query": "MARS52BIN25_004792",
         "subject": "PluTT01m_16900",
         "query_loc": 16846,
         "subject_loc": 51233
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PluTT01m_16730",
         "start": 0,
         "end": 1080,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16735",
         "start": 1099,
         "end": 1321,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16740",
         "start": 1339,
         "end": 1573,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16745",
         "start": 1660,
         "end": 2767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16750",
         "start": 2888,
         "end": 3980,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16755",
         "start": 3972,
         "end": 5583,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16760",
         "start": 5585,
         "end": 8114,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16765",
         "start": 8290,
         "end": 8782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16770",
         "start": 8800,
         "end": 10528,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16775",
         "start": 10524,
         "end": 10812,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16780",
         "start": 10840,
         "end": 11206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16785",
         "start": 11199,
         "end": 11535,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16790",
         "start": 11598,
         "end": 13104,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16795",
         "start": 13153,
         "end": 13546,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16800",
         "start": 13542,
         "end": 14892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16805",
         "start": 14907,
         "end": 16434,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16810",
         "start": 16465,
         "end": 16963,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16815",
         "start": 18118,
         "end": 33769,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16820",
         "start": 34943,
         "end": 35918,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16825",
         "start": 35974,
         "end": 37000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16830",
         "start": 37014,
         "end": 37485,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16835",
         "start": 37600,
         "end": 39217,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16840",
         "start": 39584,
         "end": 40598,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16845",
         "start": 41671,
         "end": 42633,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16850",
         "start": 42616,
         "end": 42868,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16855",
         "start": 42854,
         "end": 44651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16860",
         "start": 44742,
         "end": 45165,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16865",
         "start": 45200,
         "end": 46496,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16870",
         "start": 46804,
         "end": 47005,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16875",
         "start": 47023,
         "end": 47359,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16880",
         "start": 47361,
         "end": 49212,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16885",
         "start": 49223,
         "end": 49745,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16890",
         "start": 49782,
         "end": 50106,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16895",
         "start": 50215,
         "end": 50602,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16900",
         "start": 50626,
         "end": 51841,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004792"
         }
        },
        {
         "locus_tag": "PluTT01m_16905",
         "start": 51890,
         "end": 52385,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16910",
         "start": 52471,
         "end": 53197,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "PbGGS",
         "query_loc": 23057,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "ctg1_orf003",
         "query_loc": 23057,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "aspC",
         "query_loc": 23057,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "MAA_07498",
         "query_loc": 23057,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "paxG",
         "query_loc": 23057,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "sre2",
         "query_loc": 23057,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002610: 0-6468": {
       "start": 0,
       "end": 6468,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "Stl-TS",
         "query_loc": 23057,
         "subject_loc": 1320
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "Stl-P450",
         "start": 4383,
         "end": 6468,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Stl-TS",
         "start": 0,
         "end": 2640,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "ANIA_01592",
         "query_loc": 23057,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "PCH_Pc20g10860",
         "query_loc": 23057,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002716: 0-53197": {
       "start": 0,
       "end": 53197,
       "links": [
        {
         "query": "MARS52BIN25_004792",
         "subject": "PluTT01m_16900",
         "query_loc": 16846,
         "subject_loc": 51233
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PluTT01m_16730",
         "start": 0,
         "end": 1080,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16735",
         "start": 1099,
         "end": 1321,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16740",
         "start": 1339,
         "end": 1573,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16745",
         "start": 1660,
         "end": 2767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16750",
         "start": 2888,
         "end": 3980,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16755",
         "start": 3972,
         "end": 5583,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16760",
         "start": 5585,
         "end": 8114,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16765",
         "start": 8290,
         "end": 8782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16770",
         "start": 8800,
         "end": 10528,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16775",
         "start": 10524,
         "end": 10812,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16780",
         "start": 10840,
         "end": 11206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16785",
         "start": 11199,
         "end": 11535,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16790",
         "start": 11598,
         "end": 13104,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16795",
         "start": 13153,
         "end": 13546,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16800",
         "start": 13542,
         "end": 14892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16805",
         "start": 14907,
         "end": 16434,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16810",
         "start": 16465,
         "end": 16963,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16815",
         "start": 18118,
         "end": 33769,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16820",
         "start": 34943,
         "end": 35918,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16825",
         "start": 35974,
         "end": 37000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16830",
         "start": 37014,
         "end": 37485,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16835",
         "start": 37600,
         "end": 39217,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16840",
         "start": 39584,
         "end": 40598,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16845",
         "start": 41671,
         "end": 42633,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16850",
         "start": 42616,
         "end": 42868,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16855",
         "start": 42854,
         "end": 44651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16860",
         "start": 44742,
         "end": 45165,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16865",
         "start": 45200,
         "end": 46496,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16870",
         "start": 46804,
         "end": 47005,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16875",
         "start": 47023,
         "end": 47359,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16880",
         "start": 47361,
         "end": 49212,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16885",
         "start": 49223,
         "end": 49745,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16890",
         "start": 49782,
         "end": 50106,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16895",
         "start": 50215,
         "end": 50602,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16900",
         "start": 50626,
         "end": 51841,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004792"
         }
        },
        {
         "locus_tag": "PluTT01m_16905",
         "start": 51890,
         "end": 52385,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16910",
         "start": 52471,
         "end": 53197,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "PbGGS",
         "query_loc": 23057,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "ctg1_orf003",
         "query_loc": 23057,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "aspC",
         "query_loc": 23057,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "MAA_07498",
         "query_loc": 23057,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "paxG",
         "query_loc": 23057,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "sre2",
         "query_loc": 23057,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002610: 0-6468": {
       "start": 0,
       "end": 6468,
       "links": [
        {
         "query": "MARS52BIN25_004796",
         "subject": "Stl-TS",
         "query_loc": 23057,
         "subject_loc": 1320
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "Stl-P450",
         "start": 4383,
         "end": 6468,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Stl-TS",
         "start": 0,
         "end": 2640,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS52BIN25_004796"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS52BIN25_004792": {
     "functions": [
      {
       "description": "Aminotran_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "DegT_DnrJ_EryC1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1139:aminotransferase class V ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004793": {
     "functions": []
    },
    "MARS52BIN25_004794": {
     "functions": []
    },
    "MARS52BIN25_004795": {
     "functions": []
    },
    "MARS52BIN25_004796": {
     "functions": [
      {
       "description": "fung_ggpps",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS52BIN25_004797": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS52BIN25_004792",
      "seqLength": 543,
      "domains": [
       {
        "start": 145,
        "end": 508,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Aminotran_5",
        "accession": "PF00266",
        "description": "Aminotransferase class-V",
        "evalue": "2.2e-88",
        "score": "296.8"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004793",
      "seqLength": 448,
      "domains": [
       {
        "start": 24,
        "end": 142,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process"
        ],
        "html_class": "generic-type-other",
        "name": "UEV",
        "accession": "PF05743",
        "description": "UEV domain",
        "evalue": "8.3e-33",
        "score": "112.9"
       },
       {
        "start": 377,
        "end": 440,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Vps23_core",
        "accession": "PF09454",
        "description": "Vps23 core domain",
        "evalue": "1.5e-22",
        "score": "79.5"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004794",
      "seqLength": 245,
      "domains": [
       {
        "start": 34,
        "end": 231,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "DLH",
        "accession": "PF01738",
        "description": "Dienelactone hydrolase family",
        "evalue": "4.4e-12",
        "score": "46.1"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004795",
      "seqLength": 264,
      "domains": [
       {
        "start": 186,
        "end": 250,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GST_C_6",
        "accession": "PF17171",
        "description": "Glutathione S-transferase, C-terminal domain",
        "evalue": "1.1e-12",
        "score": "47.7"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004796",
      "seqLength": 333,
      "domains": [
       {
        "start": 42,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "2.5e-66",
        "score": "223.5"
       }
      ]
     },
     {
      "id": "MARS52BIN25_004797",
      "seqLength": 241,
      "domains": [
       {
        "start": 0,
        "end": 38,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "3.8e-07",
        "score": "29.6"
       },
       {
        "start": 39,
        "end": 235,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "1.2e-56",
        "score": "192.1"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};

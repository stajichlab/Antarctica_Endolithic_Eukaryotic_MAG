var recordData = [
 {
  "length": 67829,
  "seq_id": "scaffold_1",
  "regions": []
 },
 {
  "length": 51334,
  "seq_id": "scaffold_2",
  "regions": []
 },
 {
  "length": 48809,
  "seq_id": "scaffold_3",
  "regions": []
 },
 {
  "length": 48298,
  "seq_id": "scaffold_4",
  "regions": []
 },
 {
  "length": 47374,
  "seq_id": "scaffold_5",
  "regions": []
 },
 {
  "length": 42112,
  "seq_id": "scaffold_6",
  "regions": []
 },
 {
  "length": 41924,
  "seq_id": "scaffold_7",
  "regions": []
 },
 {
  "length": 41017,
  "seq_id": "scaffold_8",
  "regions": []
 },
 {
  "length": 40834,
  "seq_id": "scaffold_9",
  "regions": []
 },
 {
  "length": 39930,
  "seq_id": "scaffold_10",
  "regions": []
 },
 {
  "length": 39555,
  "seq_id": "scaffold_11",
  "regions": []
 },
 {
  "length": 39390,
  "seq_id": "scaffold_12",
  "regions": []
 },
 {
  "length": 38896,
  "seq_id": "scaffold_13",
  "regions": []
 },
 {
  "length": 38735,
  "seq_id": "scaffold_14",
  "regions": []
 },
 {
  "length": 38449,
  "seq_id": "scaffold_15",
  "regions": []
 },
 {
  "length": 37754,
  "seq_id": "scaffold_16",
  "regions": []
 },
 {
  "length": 37344,
  "seq_id": "scaffold_17",
  "regions": []
 },
 {
  "length": 36834,
  "seq_id": "scaffold_18",
  "regions": []
 },
 {
  "length": 35526,
  "seq_id": "scaffold_19",
  "regions": []
 },
 {
  "length": 33851,
  "seq_id": "scaffold_20",
  "regions": []
 },
 {
  "length": 32890,
  "seq_id": "scaffold_21",
  "regions": []
 },
 {
  "length": 32616,
  "seq_id": "scaffold_22",
  "regions": []
 },
 {
  "length": 32366,
  "seq_id": "scaffold_23",
  "regions": []
 },
 {
  "length": 32277,
  "seq_id": "scaffold_24",
  "regions": []
 },
 {
  "length": 31957,
  "seq_id": "scaffold_25",
  "regions": []
 },
 {
  "length": 31723,
  "seq_id": "scaffold_26",
  "regions": []
 },
 {
  "length": 31672,
  "seq_id": "scaffold_27",
  "regions": []
 },
 {
  "length": 30798,
  "seq_id": "scaffold_28",
  "regions": []
 },
 {
  "length": 30532,
  "seq_id": "scaffold_29",
  "regions": []
 },
 {
  "length": 30426,
  "seq_id": "scaffold_30",
  "regions": []
 },
 {
  "length": 30367,
  "seq_id": "scaffold_31",
  "regions": []
 },
 {
  "length": 30345,
  "seq_id": "scaffold_32",
  "regions": []
 },
 {
  "length": 30006,
  "seq_id": "scaffold_33",
  "regions": []
 },
 {
  "length": 29712,
  "seq_id": "scaffold_34",
  "regions": []
 },
 {
  "length": 29372,
  "seq_id": "scaffold_35",
  "regions": []
 },
 {
  "length": 28991,
  "seq_id": "scaffold_36",
  "regions": []
 },
 {
  "length": 28986,
  "seq_id": "scaffold_37",
  "regions": []
 },
 {
  "length": 28854,
  "seq_id": "scaffold_38",
  "regions": []
 },
 {
  "length": 28696,
  "seq_id": "scaffold_39",
  "regions": []
 },
 {
  "length": 28695,
  "seq_id": "scaffold_40",
  "regions": []
 },
 {
  "length": 28575,
  "seq_id": "scaffold_41",
  "regions": []
 },
 {
  "length": 28152,
  "seq_id": "scaffold_42",
  "regions": []
 },
 {
  "length": 28132,
  "seq_id": "scaffold_43",
  "regions": []
 },
 {
  "length": 27702,
  "seq_id": "scaffold_44",
  "regions": []
 },
 {
  "length": 27684,
  "seq_id": "scaffold_45",
  "regions": []
 },
 {
  "length": 26969,
  "seq_id": "scaffold_46",
  "regions": []
 },
 {
  "length": 26719,
  "seq_id": "scaffold_47",
  "regions": []
 },
 {
  "length": 26266,
  "seq_id": "scaffold_48",
  "regions": []
 },
 {
  "length": 26174,
  "seq_id": "scaffold_49",
  "regions": [
   {
    "start": 118,
    "end": 26174,
    "idx": 1,
    "orfs": [
     {
      "start": 219,
      "end": 1072,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000881",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000881</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000881</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000881-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 219 - 1,072,\n (total: 820 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000881 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02487.20 (CLN3 protein): [10:273](score: 314.7, e-value: 9.8e-94)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000881 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02487.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000881\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCTCCCCAGTGTTCCGAACGAGTCTTGCATTTTGGCTTTTTGGATTAATCAACAATGTTCTCTATGTAGTCATACTCACTGCCGCTGTGGATCTCGTCAATACGCTGCCCAAGGCAATTGTTCTGCTGGCCGACATCATGCCATCCTTTGCAGTGAAGTTATTGGCGCCATTTGTAATACACCTAATTCCCTACCGCCTACGGATCCTGGTATTCACGTGCTTGTCGATCACTGGAATGCAAATTATTGCCTGGTCTGGCGGGATACCGATGCGGTTGCTTGGTATCATATTGGCTTCAGCGAGTGCGGGTGGAGGAGAACTATCATTTCTGCAACTAACGCACTTCTACGGACCAAGATCTCTTCCTTTCTTCAGCAGTGGCACGGGCGCTGCCGGGTTGGTTGGAGCAGGTTTATTCTCATTCATGACGGTCTTTATTGGATTGAGCGTAAGACGGAGCTTGCTTCTATTGAGTTTCCTACCCGTCATCATGACAATTACCTTTTTTGTCATTTTACCAAAGCATGATTTCAATTTCCAAACGGAGTACGATCCGTTGGAAAGACAGGAACAGGGACCAGTGGCCGAGCCTACGCTTATGCCAAATCACAACCAGTCTTTGCTCAGGACCCTAAAATCAAACATGAACCGAGCAAAGTACTTATTTGTTCCTTTTATGTTGCCATTAGCCCTGGTGTATTTTGCAGAGTATGAGATAAATCAGGGCGTTGCACCCACGCTTCTTTATCCCTTACAAGACACCCCGTTTAACTCATACCGAGACATGTATCCAATGTACTCAACTCTATATCAAG",
      "translation": "MTSPVFRTSLAFWLFGLINNVLYVVILTAAVDLVNTLPKAIVLLADIMPSFAVKLLAPFVIHLIPYRLRILVFTCLSITGMQIIAWSGGIPMRLLGIILASASAGGGELSFLQLTHFYGPRSLPFFSSGTGAAGLVGAGLFSFMTVFIGLSVRRSLLLLSFLPVIMTITFFVILPKHDFNFQTEYDPLERQEQGPVAEPTLMPNHNQSLLRTLKSNMNRAKYLFVPFMLPLALVYFAEYEINQGVAPTLLYPLQDTPFNSYRDMYPMYSTLYQ",
      "product": "hypothetical protein"
     },
     {
      "start": 1334,
      "end": 3001,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000882",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000882</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000882</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000882-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,334 - 3,001,\n (total: 1668 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000882 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF09329.14 (Primase zinc finger): [336:382](score: 59.9, e-value: 1.6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000882 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF09329.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication<br>\n  \n   PF09329.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005634' target='_blank'>GO:0005634</a>: nucleus<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000882\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGCGCAGCCTGGTGAGTGGCCGCCAGTGTCGCCTGCAAAGGCCAGACTGCTCGTGTCCCCGGGCACGCTGAAGCGGAAGCAGCACGATCGTAGCAGTGAGTCAGGGTCTGAAGATGAGGAAACACTGCAGCTCAAACTGGCTCACATTGAAGCACGCCTGAAGCTGAAGCAAGTACAGAAGAAGAAAAGGAAAACAGCTGAAGATATTCCGGCTGAGGCCACAAAAACTCCGTCCAAGCCGAGTCCACCCGCAACGGAGCCCTCAAATCTCCAAATCTCGCCGAGCAGGGTACAGCTTGGGGTGGATAAGGGAATGACGGCCAAAGATGTTTCTTTGCGTAGGCCATATGGCCAATCGACTCCTGAGAAGCCTACCAAGACCTTTGCCCAACGGCTTGCTGAATTACGGGCTGGTGACAAGGACGAACAAACGCGGAGAGACAAAGTGCTGATGCAAAGGTCAAAGGCGTTTGCGCCGCTTCCTTTCAGAGCAGATGCTCCGAAAGGCGGGCTTGATGCCACAATCCCTACATCTCAGATCTCAAGCCAGCCTCAGGTACGGTCGATATCTGCTCATTCTGAACTATACGACGCCTACTCTGGGTTCAAAATGACCAATCGCCTACTACCTCACTCAGCACTTTCGCATCATTTTGCTGGGAAAAAGATTTACGATCTCGTCTCCATACTGAAAGAGATTGTCCCTCCAACCTACGATCCCCCAGAGGTTGCCGATTGGGTCTTACTCGGCATAATAGCACACAAGTCCGAAGCGCGTGAGGCAAAGAGAAAAGACGGCAACAAGTACTTGGTGCTCACGATTACCGACTTGAACTACGAAATCACCTTGTTCCTTTTCGGTGATGCGTTTCAGAAGTTCTGGAAGTTACAATTGGGTCATATAATTGGTATACTCAATCCAACAGTCATGAAGCCCCAGAGTAAAGACAGCACGAAATGGTGTGTAAAGGTTTCAGAAGCACAAGACGTTATTCTTGATATCGGTAGAGCCAAAGACTTGCAATTTTGCCAAAGCTTAAAAAAGGACGGTACACAATGCGGCCAATGGGTTGATGGACGCCGAACCGAGTACTGCGAATACCATGTTTCACAAGACTTAAAAAGATATAAAAGCCGAAGGACCGAGGTTGCTATCGGCACGAAAGGCTATTCTCCCAAGAAGAAAAGTGTCCACTTTGTATCAAATGAAGTGCCTGGTCGAGGACATGAGCCGTCGCATAATGCGCAAGAAGCCTACTCGGGCACGTTACGCGACGACGACAATCTCTCGAATGTACAAATACGCGAGCATATTGCGCGGCATAACATGGTTCGCGAGAAAGAGCGACAGGTTTCCGCAAAGATTGTGGGAACGAGTGGTGGAGGTATTGGGGAAGAATACCTACGGAAATCCTACGAAATGACTCCACCGGAAGCAGTAAAACCATGCATTGACGATGGCAAGAATCCCTTCTCTGCCAACGTACTTCGGCGCATTGGCTTCGATCCTACAAAACGCGTCGAAAAGTCGAAAGTTATCCAAGAGTCATTGGGCATAACCGGGGACCGGACTGAGGCGCGACTCAGCCCAGTGAAAAATCGCGCCGTTTCTCAACAAAACAAAGTGTCAAGTGGCGACCAAGAGCTGGAGATCATAATGTAG",
      "translation": "MTAQPGEWPPVSPAKARLLVSPGTLKRKQHDRSSESGSEDEETLQLKLAHIEARLKLKQVQKKKRKTAEDIPAEATKTPSKPSPPATEPSNLQISPSRVQLGVDKGMTAKDVSLRRPYGQSTPEKPTKTFAQRLAELRAGDKDEQTRRDKVLMQRSKAFAPLPFRADAPKGGLDATIPTSQISSQPQVRSISAHSELYDAYSGFKMTNRLLPHSALSHHFAGKKIYDLVSILKEIVPPTYDPPEVADWVLLGIIAHKSEAREAKRKDGNKYLVLTITDLNYEITLFLFGDAFQKFWKLQLGHIIGILNPTVMKPQSKDSTKWCVKVSEAQDVILDIGRAKDLQFCQSLKKDGTQCGQWVDGRRTEYCEYHVSQDLKRYKSRRTEVAIGTKGYSPKKKSVHFVSNEVPGRGHEPSHNAQEAYSGTLRDDDNLSNVQIREHIARHNMVREKERQVSAKIVGTSGGGIGEEYLRKSYEMTPPEAVKPCIDDGKNPFSANVLRRIGFDPTKRVEKSKVIQESLGITGDRTEARLSPVKNRAVSQQNKVSSGDQELEIIM",
      "product": "hypothetical protein"
     },
     {
      "start": 3707,
      "end": 6387,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000883",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000883</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000883</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000883-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,707 - 6,387,\n (total: 2388 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000883 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08642.13 (Histone deacetylation protein Rxt3): [54:94](score: 38.6, e-value: 1.7e-09)<br>\n \n  PF03343.16 (SART-1 family): [304:774](score: 321.9, e-value: 9e-96)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000883 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03343.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000398' target='_blank'>GO:0000398</a>: mRNA splicing, via spliceosome<br>\n  \n   PF08642.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016575' target='_blank'>GO:0016575</a>: histone deacetylation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000883\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTCCTCTCCCTGATCACAAGCCAGAACTCATTGTTCACAGTGGGAGGGCTTTTGATGCTCTCCAGGATATGAAGAGTGTACATCTAGGAAGCCACGTCTACGAAGGTCAACTTGTTTCATTACCTCGTTTAGCGGGTCGAGAAAATGCACTTATCTCCATACGAATTCCGGAGCGTTTTGTTGAGCAATCAGATGCAATGGATAAGAGACGTATATGGGGTACTGACATCTACACTGACGACTCTGACCCCGTTTGTATCCTCAAACATATAGGCAAAAGGCCTGAGCGACCTCGTCAGGATGTGATTATCACATTTCGGGTGCTGCCTCCTTTAGTGGAGTACAAGGGTAGTCTACGTCACCAGATGAAGACTCGTACATGGAACGTTCAGCATGATGGGATGAGTATAATGGTAGAGAATGTGGACTTTGTCACCGTCGGGATAGCTGAGGAAAGAGGTGGTGAAATGGCGAAAAAACGCATTCGTGATTACATTGAGCTGAGCGGCCGCGGGCTGCATCCACAATGGAAGCCAACGCTTGAAAAACGGAGCAAGCTAGCCGTGCCAAGTACCGCACAAGAGCAAAATAAAGTGGAAAAGAGTTCGGGTTCTGAAGGTGAGCATAAGCAAAACTCCAATGGATCAAAATCTCCACCGAAAAGGCCTTCAAAATCCTCTAATGCTGTGGAGACTATAAAACAGACTGACGACAAAGAAGCCGAAGAAACCAGAGCCATCGATACGGCCTTGACTGAGGCACATGATGGTGCCAAAGCTGAAACAAATGACAAGGCAAAGTTTCGTACGATCGACAAGGGGGATGCGCATGATATGTCAATGCACGATGCACCACCAGCATCCTCCGACGATGATTCCCTCGACGCTGCAAAGGAGAACGCGGCCGTCTTAGCACGGATAGAGAAGACAAAGAAAAAGGCCGCAAGATTTGAGCGGCTCGAAGGTCGTGGGCTTGCTGATGACGATGATGAAGAGACAGACGCCCGTCAGTGGGTATTTAAAACCAAGAAAATCAAGAAGAGAAAGCTAGATGAGACGCCAGAGGAGCTTCATTCGACTTACAACGAGGAAAGCCTGTCAGGGCTTAGAGTTGGTCACGATATTGGAGATTTCGACACGAATGCCACCATTCTAACGTTGAAGGACGCCTCAGTCTTGGAGGACCAGGAAGAGGATCAATTAGAGTCTTTGAAACTAGTAGAAAAAGAGCGCACCCAAAAGAACTTGAACAGGAAGAACAAAACGAAATCTGGCGACACGACCGAGCAAGATGGCAAAGGCATTTTGTCGAAATACGACGAAGAAGAGGAGCCCAAGTTTATGGTTCTTGGTGAAACGGCTTTGGAGAGAGAAGTGGTGGAAGATAGGCGTGGTACAGCTATTTCTCTTGACGTGGAGCGGGTAGCAGAATCTTCCGACTACATGGACACTACAATTAGAAAGTCGAAAAAGAAACGTCCCAAAAGCATACGAGTCAAAGAAGGGGCGGAAGGCGATGACATTTCTTTCAAGCCTCAAATGCTTACTAATAGGGAAGAGTCGAATATTGCTGACGATGAAGAATTGCAGGCGGCTCTTTCACGGCAGCGTCGGATAGCTCAGAAGCGCCATGCGTCGATTGTCCGGCCGGTGAAAGACATTGAAGCCTACAACGAAGATCTCTATGATGGTGGTATGGTATTTGATGAAGCCACGGGATTTCTCTCTGGGATCAGACCTGTCGAGAAAGCTGCTTACGCAGTCAAAGAAGAGCCGTTAGACAGAGTAGACATTAAGATGGAAATCAAGCAGGATCCCAATGAACTGCTACTCGATAAGACAAGTGAAGATGGAGAAGATCTCATTGAAGAGCCTGGGATGGGTCATGGGCTTGGTGCTGCACTCAAGATGCTTCAGCAGCGTGGAGTTGTTGACAGAGCCAGCGAAGAGACGACGCAAAAGCTGGAGCAGCAGCGGCAAAATATGGCGTGGCTGGCAGAGAAGCGCCGTAAAGATGCTCTGCGCGAGGCACAACTCCGTCGCGAAAAAATCGAAGGGCGCGAAAAGATGAAGAACATGAGTGCTCGCGAGCGTGAGCGTACGTTGGAGGAAGAGAACCGGCGGCGCACAAAGCACGAAGCGGCAGCAGAGTTTGACAAGTTCAAGGAGTTTAAGCCGGATGTGCATCTTCACTACAAGGATGAGTTTGGGAGAGATATGACGCCAAAAGAGGCCTTTCGGCAAATGTCCCACCAGTTTCATGGCAAAGGCAGTGGCGTGATCAAGAGTGAGAAGCGCCTCAAACGGATTCAAGAGGAACAGGAACGCGAAAAGCAAGCAATGGCAAGTGGAGTCTTTGCTTCCTCTGGCGTTCGGTTATCTTGA",
      "translation": "MTPLPDHKPELIVHSGRAFDALQDMKSVHLGSHVYEGQLVSLPRLAGRENALISIRIPERFVEQSDAMDKRRIWGTDIYTDDSDPVCILKHIGKRPERPRQDVIITFRVLPPLVEYKGSLRHQMKTRTWNVQHDGMSIMVENVDFVTVGIAEERGGEMAKKRIRDYIELSGRGLHPQWKPTLEKRSKLAVPSTAQEQNKVEKSSGSEGEHKQNSNGSKSPPKRPSKSSNAVETIKQTDDKEAEETRAIDTALTEAHDGAKAETNDKAKFRTIDKGDAHDMSMHDAPPASSDDDSLDAAKENAAVLARIEKTKKKAARFERLEGRGLADDDDEETDARQWVFKTKKIKKRKLDETPEELHSTYNEESLSGLRVGHDIGDFDTNATILTLKDASVLEDQEEDQLESLKLVEKERTQKNLNRKNKTKSGDTTEQDGKGILSKYDEEEEPKFMVLGETALEREVVEDRRGTAISLDVERVAESSDYMDTTIRKSKKKRPKSIRVKEGAEGDDISFKPQMLTNREESNIADDEELQAALSRQRRIAQKRHASIVRPVKDIEAYNEDLYDGGMVFDEATGFLSGIRPVEKAAYAVKEEPLDRVDIKMEIKQDPNELLLDKTSEDGEDLIEEPGMGHGLGAALKMLQQRGVVDRASEETTQKLEQQRQNMAWLAEKRRKDALREAQLRREKIEGREKMKNMSARERERTLEEENRRRTKHEAAAEFDKFKEFKPDVHLHYKDEFGRDMTPKEAFRQMSHQFHGKGSGVIKSEKRLKRIQEEQEREKQAMASGVFASSGVRLS",
      "product": "hypothetical protein"
     },
     {
      "start": 6425,
      "end": 6949,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000884",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000884</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000884</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000884-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,425 - 6,949,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01981.19 (Peptidyl-tRNA hydrolase PTH2): [59:174](score: 148.6, e-value: 9.3e-44)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00283 (arch_pth2: peptidyl-tRNA hydrolase): [60:174](score: 128.3, e-value: 3.7e-38)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01981.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004045' target='_blank'>GO:0004045</a>: aminoacyl-tRNA hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000884\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTACGGCGACAAGCGCCGGGATCGCAGGGATCCTAATTGGCGCCTGTCTGGGCTTCTACGGGGCACTTGGGGCCTCTCTGCCCATCTCAAGAGGCAACGCCGCGCTAGACGTGGACTCGGACTGCGAAGGGAGCAGTGAGAAGGATGGGGGTGGACTGCTTCCCGACGAGGAGTACAAGATGGTGCTTGTGGTCAGGACGGATCTCAAGATGAGTCGAGGCAAGGCAGGTGCTCAGTGCGCACATGCGGCAGTGGCCTGCTACAAAGCTGCTGCAAAGCGCAATCAACCACTACTGGCCGCCTGGGAGAACTGTGGACAGCCGAAGATCTGCCTGCAGACGAGCTCCGAGGAAGATTTAGCCACGTTGTACGCGTCAGCCATGTCCCTAAGACTCACAGCCAAGACAATTCAAGATGCGGGGCGCACGGAAGTACCAGCCGGGTCGACAACAGTCCTTGGAATCGGACCGGCTCCAGTCAGTCAAATTAATATCGTCACGGGTCATCTGAAGTTGTTCTGA",
      "translation": "MATATSAGIAGILIGACLGFYGALGASLPISRGNAALDVDSDCEGSSEKDGGGLLPDEEYKMVLVVRTDLKMSRGKAGAQCAHAAVACYKAAAKRNQPLLAAWENCGQPKICLQTSSEEDLATLYASAMSLRLTAKTIQDAGRTEVPAGSTTVLGIGPAPVSQINIVTGHLKLF",
      "product": "hypothetical protein"
     },
     {
      "start": 6986,
      "end": 8266,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000885",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000885</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000885</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000885-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,986 - 8,266,\n (total: 1281 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000885 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00155.24 (Aminotransferase class I and II): [55:421](score: 277.4, e-value: 2e-82)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000885 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00155.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n   PF00155.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000885\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATGGCCTATTGCGAGGAGCTGGGCGGACGGGAGCTGATGCAAGCGCAAGACTCGGCTGGAGGAGTGTAGGCAGATTCAGCAGCACATGGAGAGAGGTGCCTCAAGGACCGCCGGACGCAATTCTTGGAATTACGCAGGCCTTCATGGCAGACAAGAGTTCAAAGAAGGTGAATGTGGGAGTCGGTGCATACAGAGACGACCAGGGCAAGCCTTATGTCCTCCCTTCCGTACGAGAGGCTGAACGGAAGATTCTCGACATGGACAAGGAATACGCAGGTATCACAGGTATCCCAACCTTCACCAAAGCGGCAGCGCAATTGGCGTATGGCGAGGGAAGCAAAGCCTTCCAGGAAGGACGAGTTGCCATCACGCAGTCCATATCTGGCACCGGAGCTCTTCGAATTGGAGGGGAGTTCTTGAGGAGGTGGTTCCCGACCTCGAAAACCATCTACCTGCCCACGCCATCGTGGGCCAACCATGTCCCCATCTTCCGAGACAGTGGGCTTGAAGTCAAGTCTTACCGCTACTATGACAAGTCTACCGTGGGACTCGATGCAAAGGGCATGCTGGCGGATATTAAAGCGGCGCCAAAGGGATCCATGATTCTTTTACATGCGTGTGCACACAACCCCACCGGTGTGGATCCGACTGAGGAGCAGTGGAGCTCGATTGAGCAGGCTGTCAAGGCAGGGGGCCACTTCCCCTTCTTTGACATGGCCTACCAAGGCTTCGCCAGCGGAGACTGCACCAAAGATGCCTATGCGTTGCGGTACTTTGTTGATCGCGGCCACCAAGTGGCGCTCTCTCAGAGCTTTGCCAAAAATATGGGCCTGTATGGCGAGCGAGCCGGAGCTTTCTCTGTCGTCACCTCTTCGGAAGAGGAATCCCGACGCGTGGACTGTCAGCTCAAGATTATCGTGCGGCCACTCTACTCCAATCCGCCTATCAACGGAGCGCGGATTGCGTCTGCTATCCTCAACGACAGCGCCCTCAACACACAGTGGTTGGGAGAGGTCAAGGGCATGGCTGACCGAATCATTTCCATGCGCGCACTCCTGAAGAAGAATCTAGAGGATCTCGGATCGAAGCGATCCTGGGATCATATTACATCGCAAATTGGCATGTTTTGCTACACAGGACTTTCGGCTGGGCAGGTTGACCGACTGGCCAAGGAGTACTCCATCTATGGCACGCGTGACGGGCGCATCTCTGTCGCAGGCGTCAACAGTGGCAACGTAGAATACCTAGCACAAGCCATCCACGAGGTGACTAGATAG",
      "translation": "MNGLLRGAGRTGADASARLGWRSVGRFSSTWREVPQGPPDAILGITQAFMADKSSKKVNVGVGAYRDDQGKPYVLPSVREAERKILDMDKEYAGITGIPTFTKAAAQLAYGEGSKAFQEGRVAITQSISGTGALRIGGEFLRRWFPTSKTIYLPTPSWANHVPIFRDSGLEVKSYRYYDKSTVGLDAKGMLADIKAAPKGSMILLHACAHNPTGVDPTEEQWSSIEQAVKAGGHFPFFDMAYQGFASGDCTKDAYALRYFVDRGHQVALSQSFAKNMGLYGERAGAFSVVTSSEEESRRVDCQLKIIVRPLYSNPPINGARIASAILNDSALNTQWLGEVKGMADRIISMRALLKKNLEDLGSKRSWDHITSQIGMFCYTGLSAGQVDRLAKEYSIYGTRDGRISVAGVNSGNVEYLAQAIHEVTR",
      "product": "hypothetical protein"
     },
     {
      "start": 8564,
      "end": 9095,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000886",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000886</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000886</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000886-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,564 - 9,095,\n (total: 441 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000886 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01627.26 (Hpt domain): [44:116](score: 45.1, e-value: 9.9e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000886 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01627.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000886\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAGAGGAAACGGTGGAAGCGGTGGACAAGGAGGCGAAGGAGATGGTGTTTGGCGATGTGGTAGATAAGGACACCTTCCACCAATTGCTCGAAATGGACGACGACGAAGAGCGCGAGTTCAGCAAGAGCATTGTGTGGAATTACTTTGAGCAAGCCGAGACCACCTTTCAGCAGATGGACGAAGCCTTAACAGACACCAACCTTGCCGAGCTCTCTTCTCTCGGCCACTTTCTCAAAGGCAGTTCCGCGGCGCTTGGGTTGAAGAAGGTCCAGGCCGCCTGCGAGAAGATACAGTACCTCGGCGCGCGAAAGGATGAAACGGAGAGCAAAACAGATCTGCCAGAGCAGGAGTGTCTTGAGCGGATAGAAAAAACCCTGCACGTGGTCAAAGAGGATTACGCCGAGGCGGAGACCAAGCTGAAGGACTACTATGAATAG",
      "translation": "MPEETVEAVDKEAKEMVFGDVVDKDTFHQLLEMDDDEEREFSKSIVWNYFEQAETTFQQMDEALTDTNLAELSSLGHFLKGSSAALGLKKVQAACEKIQYLGARKDETESKTDLPEQECLERIEKTLHVVKEDYAEAETKLKDYYE",
      "product": "hypothetical protein"
     },
     {
      "start": 10593,
      "end": 12305,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000887",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000887</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000887</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000887-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,593 - 12,305,\n (total: 1713 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000887\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTCATCAAGCTGCAGCCAAAGCCACCCAAGCAAGTGTTATGCCGGCCCAGGCGAGTGTTCAAGCAGCGCAAGCAAGTGTTAAGCCGGCCCAGGCGAGTGTTCAAGCAGCGCAAGCTTCTGCCTGCACGACCACGACTGTCACAACCACCGTCACCGGCACCAATTGTGCGGCTTCAGTTGCTGCTCAGGGATCGGTTCAGCCTGCCATGGTTCAAGCGACCGCGGTCGCACCTATTTCGACTGTCACCTCAGCCTGCCCCGTGTGCAGCCCCCAGACAATCACCGCTCTTGGTCAAATGGTCTCTTCCGTCGTGCAAGCTACATCTACCTCCACCACATCCTGCCCTGCTGGTCAATGTATTGTTGGCGCTCAGACTACTACCGTCACTGCACCATGCACCCTGAGCTACATGTCAACCACCATCTGCGCGTCTGGCAGCACCTGCACCGTCAATGGCCAGGCTATCATGCCTATTTCCACAAGCACCATCTTCGTTACAGCTTCGACCACCTGTCCTTCTGCTGGTGTCTACACGCTTGGAGGTATGACGACCAGTCTCGTGTCGGCTCAGCAGGTTAGCTACCCAGTTCTCGCTGCTGGCAGCACTACCACTTTTCCCTTTTGGCAAACACAGATCTTTGCTGGGCAAACGGTTTCCGCAGCCAGCCAAGCTATTACCTCTTCGGCCCAGATGACCAAGACAACATCGACTTATTGCCCCTCTGCAGGAGTATACACGCTCGCCGGGGTCACGCACTCGATCACGCAGCCGCAATGGATCACTTATGTTATCATCATTACCCAGGACTACGTGTGCGAGGCAGCTCAATGCTTGGGTGCGGCTCCTACAAAGTCGATCAATGTTTACGAGCACAATGGAAACACACAAATCACAGCCTACGGCTTGATCTTGATCGACATTGTCGTTGTCCAGTATATCACGACTGCCTGTCCTACACCGACCACCATCATCAATGTGGATGTCTCTATTGTTGTGTCGGTGGCTCCAACGACGATTACCTACCCGATCACTGTCACCACTACATCCACCATCACCGTCTCTGCGTCATCATCATTGTCGGCATCTGGCTCTGCAACACAGACTGGATCTGTCTCAAGTTCAGCTTCCAAGTCTGGCTCTGCAACACAGACTGGATCTGTCTCAAGTTCAGCTTCCAAGTCTGGCTCTGTGTCTGCTTCAGCTTCTGCTTCGCCTACAGTTGTTCCGGTCACTACTGCCTTCTCCTTGGCGGTTGCTGGAGAGGTTATTGTTGCGTCTGGTTCCTCCCTTCTGATTGTGTCTCCGGCAGACACGACAAACTTTGCTGCAGTCTCCTTCACCATCAATACCGTCGGCCAACTGGTCGCCTCGACTGGTGCTACTGTCGTGGCTACCTTCTCCACCGGAGGAGCTGGTCCATTGGTCTTTGGAGGCTCGCCTGCTGCACGACGCAAACGGCAGGGAGTGCTTGTTGACCGTGTTTACACTGCTGCAGGTGGTTCGCTTACCCTCAACGATCTCATCTTCTCGTCGTGTCCCAACTCGGATGGAAGTTCGACGCCAGACGTGGGTGACTCGGTTCCTGCTGGGTGCACTCAAATCACTTTGACCCTCACAGCTGCGAACGCACCAACCACTCCATTCCAGAATGGCACGATGAAGAGGGGCTTGCAGCGTCGTCACTTTAGACAACACACAATAAGGTAG",
      "translation": "MAHQAAAKATQASVMPAQASVQAAQASVKPAQASVQAAQASACTTTTVTTTVTGTNCAASVAAQGSVQPAMVQATAVAPISTVTSACPVCSPQTITALGQMVSSVVQATSTSTTSCPAGQCIVGAQTTTVTAPCTLSYMSTTICASGSTCTVNGQAIMPISTSTIFVTASTTCPSAGVYTLGGMTTSLVSAQQVSYPVLAAGSTTTFPFWQTQIFAGQTVSAASQAITSSAQMTKTTSTYCPSAGVYTLAGVTHSITQPQWITYVIIITQDYVCEAAQCLGAAPTKSINVYEHNGNTQITAYGLILIDIVVVQYITTACPTPTTIINVDVSIVVSVAPTTITYPITVTTTSTITVSASSSLSASGSATQTGSVSSSASKSGSATQTGSVSSSASKSGSVSASASASPTVVPVTTAFSLAVAGEVIVASGSSLLIVSPADTTNFAAVSFTINTVGQLVASTGATVVATFSTGGAGPLVFGGSPAARRKRQGVLVDRVYTAAGGSLTLNDLIFSSCPNSDGSSTPDVGDSVPAGCTQITLTLTAANAPTTPFQNGTMKRGLQRRHFRQHTIR",
      "product": "hypothetical protein"
     },
     {
      "start": 12368,
      "end": 13213,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000888",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000888</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000888</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000888-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,368 - 13,213,\n (total: 846 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000888 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [20:102](score: 28.5, e-value: 1e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000888\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAGCGCTTCATTAAATCGTGCCGAGCAAGCCGTGTTACTCAGGATCTGACTGGTCGTACAGCTCTCATCGTAGGGGGAACAAAAGGCATTGGTGCAGAAGTTGCCAATCGTTTAAAAGAGCGTGGAGCAACGACCTATGTCGCCGGCCGAAGCACGACGCCGGCCTCAAATCTACATACGTACCTCCCAGCCGACCTCTCCACCATCCGTGGCATCAACGATTTCATCCGACTCGCCAGATCACGACTTCCTGCCAAAGATGTAATGCTCATCCAATGCTCAGGCCATCCGCCCAATGGGACCCTAAACGTATATCAAACCGTCGACAAGGACTTTTGCGTGCAATGCTTTGGAAGACTGTTCGTTGCCTGGGACTTGGCTCCGCAGACTTCGAGTATCGTGTGGGTTGCTGCCCCTGGCGGAGGATATCTTGATGTGAATGATATTCAAACGCTAAAGTCCACATGGACGCCGCTCATCGTTCGACAATTTCTTCGCGATAGCGCCTTCCTCGATATCTCGGCGGCCATGATAGCACAGGAGCGCGGGGCAAAGATTACGCATACCTTCCCTGGAATTGTAGCGACGGAGGGGTATCGAAATTTGTTTTGGAAACCGGTGGAATGGATGCAGGGTCTTCTACTTCGCACCATTGGCACTAGTGCAGTTGACTACTCAGAGGTACCGGCATACTATGCAATGAACCCATCGCAAACGAACGAGGCGCGATTCACGAGTGGGGGTAGAAGCATTACGCCGAGCACGATTGCAAATGATGCATTGAAGCGGCAAGCGGTCTTGGATTGGAGTATGGAGAAGCGAAGGATGGCTGAGCAGAATTAA",
      "translation": "MQRFIKSCRASRVTQDLTGRTALIVGGTKGIGAEVANRLKERGATTYVAGRSTTPASNLHTYLPADLSTIRGINDFIRLARSRLPAKDVMLIQCSGHPPNGTLNVYQTVDKDFCVQCFGRLFVAWDLAPQTSSIVWVAAPGGGYLDVNDIQTLKSTWTPLIVRQFLRDSAFLDISAAMIAQERGAKITHTFPGIVATEGYRNLFWKPVEWMQGLLLRTIGTSAVDYSEVPAYYAMNPSQTNEARFTSGGRSITPSTIANDALKRQAVLDWSMEKRRMAEQN",
      "product": "hypothetical protein"
     },
     {
      "start": 15010,
      "end": 16410,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000889",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000889</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000889</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000889-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,010 - 16,410,\n (total: 1401 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000889 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [105:216](score: 60.3, e-value: 2.7e-16)<br>\n \n  PF16193.8 (AAA C-terminal domain): [235:304](score: 76.7, e-value: 1.4e-21)<br>\n \n  PF12002.11 (MgsA AAA+ ATPase C terminal): [304:463](score: 179.2, e-value: 6.2e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000889 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000889\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAGAATGTCCTATATGTCAAAAGCAGGTCTCCGAAGCTCGGATCAACCAGCACCTAGACACAGACTGCGGTCGTGAGAAGCAAAAAGCACTCACTCCGCCAAGCTCATCTAATGGATATGAATTGAACCAAGTAAAAATCAACGAGGAAGAGAGACCGGCGAAACGCCAGAAGAATACCGCGTTAATGGAAGCAAGACCATTAGCCGAACGCGTTCGGCCCCTCAAATTGGATGGTTTTGTGGGACAGAATGAGCTAGTAGGAAGGGATGGGGTGTTGCGAAAGCTTTTGGAGATGGATAAGTGTCCATCCATGATCCTATGGGGACCAAGCGGGACCGGCAAGACCACACTTGCGCGTTTGGTAGCGAAATCAACACGATCAAGATTTGTAGAAATGAGCGCAACTGCAGTCGGGACTGGAGAGTGCAAGAAGCTCTTTGAAGAGGCCCGTAACGGCTTGAAACTACTTGGGCAACGAACTATCCTTTTTCTTGATGAAATACATCGCTTTGCAAAAAACCAGCAGGATATCTTTCTTCCCTATGTAGAGTCTGGTTTGATTTGCCTAATTGGTGCTACAACCGAGAATCCTTCCTTCAAAGTCAATAATGCTCTCCTGTCGCGATGCCGCGTGTTTATTCTGAAAAAGCTCACAGAGCATGAGGTGGCGGAAATCCTCAGACGGGTCGGCATTGAAGGTGTTTCGGAAGACATGCTTACCTACATGGCACAAATTTCAGACGGTGATGCCCGAATTGCTTTGAATATCCTGGAAGTGGCTGAACAACTGTCTGACAAGCTTGGCGATGAGGAGGTGAAGCAAGCTGTTCGGCGTACGCATTTTGCGTACGACACTCATGGAGACGCACACTATGACGCCATCTCTGCTTTGCACAAGTCGATTCGCGGTAGTGATCCCGACGCCGCTTTATTTTATGCTACGCGCATGATGGAGAGTGGCGAAGATCCCTTGTACATTTGCCGCCGCCTCATTCGTGCTGCATCTGAAGACATTGGGACAGCAGATTCTAGCATGCTTACACTCGCGACTTCTACATACACGGCCGTCCAACAAGTAGGCATGCCGGAAGCCGACTGCATGATTGCTCATTGTGTGGTAGCGTTGGCAGAGGCACCCAAGTCAGTCCGTGTCTACCGCGCCATGAAGTGTGTGAAATCTTTGCTTCACCAAGATCATAAAGCAGCAGGAGCCGCGATCCCAATTCATTTGCGCAACGCACCGACCACACTTATGAAGAAAATAGGCTACGGGAAGGAATACAAGTATCCTCCAGACGATGACAGTCATCAGGACTACTTGCCAGAGGGACTCATAGGCACGCGTTTTCTTGACCCTGGAGAGATTGAGTTTGACGAATCGTTGGGCAAGGATTGA",
      "translation": "MVECPICQKQVSEARINQHLDTDCGREKQKALTPPSSSNGYELNQVKINEEERPAKRQKNTALMEARPLAERVRPLKLDGFVGQNELVGRDGVLRKLLEMDKCPSMILWGPSGTGKTTLARLVAKSTRSRFVEMSATAVGTGECKKLFEEARNGLKLLGQRTILFLDEIHRFAKNQQDIFLPYVESGLICLIGATTENPSFKVNNALLSRCRVFILKKLTEHEVAEILRRVGIEGVSEDMLTYMAQISDGDARIALNILEVAEQLSDKLGDEEVKQAVRRTHFAYDTHGDAHYDAISALHKSIRGSDPDAALFYATRMMESGEDPLYICRRLIRAASEDIGTADSSMLTLATSTYTAVQQVGMPEADCMIAHCVVALAEAPKSVRVYRAMKCVKSLLHQDHKAAGAAIPIHLRNAPTTLMKKIGYGKEYKYPPDDDSHQDYLPEGLIGTRFLDPGEIEFDESLGKD",
      "product": "hypothetical protein"
     },
     {
      "start": 16990,
      "end": 17958,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000890",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000890</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000890</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000890-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,990 - 17,958,\n (total: 969 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000890 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:269](score: 204.0, e-value: 2.5e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000890\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000890-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTCAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGGATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTCGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGGCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
      "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
      "product": "hypothetical protein"
     },
     {
      "start": 18444,
      "end": 20104,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000891",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000891</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000891</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000891-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,444 - 20,104,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 963.0, e-value: 4.7e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000891\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000891-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAAAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAACCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCGTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCCGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCCAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
      "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDKGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
      "product": "hypothetical protein"
     },
     {
      "start": 20118,
      "end": 24185,
      "strand": -1,
      "locus_tag": "MARS9BIN1_000892",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000892</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000892</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000892-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,118 - 24,185,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.4; E-value: 1.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000892 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.9, e-value: 1.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000892 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1899.2, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000892\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000892-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAACCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAGGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACGATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
      "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
      "product": "hypothetical protein"
     },
     {
      "start": 24457,
      "end": 25947,
      "strand": 1,
      "locus_tag": "MARS9BIN1_000893",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000893</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000893</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000893-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,457 - 25,947,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000893\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGGTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
      "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILGFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 20117,
      "end": 24185,
      "tool": "rule-based-clusters",
      "neighbouring_start": 117,
      "neighbouring_end": 26174,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r49c1"
   }
  ]
 },
 {
  "length": 26117,
  "seq_id": "scaffold_50",
  "regions": []
 },
 {
  "length": 26075,
  "seq_id": "scaffold_51",
  "regions": []
 },
 {
  "length": 25747,
  "seq_id": "scaffold_52",
  "regions": []
 },
 {
  "length": 25594,
  "seq_id": "scaffold_53",
  "regions": []
 },
 {
  "length": 25542,
  "seq_id": "scaffold_54",
  "regions": []
 },
 {
  "length": 25374,
  "seq_id": "scaffold_55",
  "regions": []
 },
 {
  "length": 25298,
  "seq_id": "scaffold_56",
  "regions": []
 },
 {
  "length": 25102,
  "seq_id": "scaffold_57",
  "regions": []
 },
 {
  "length": 24740,
  "seq_id": "scaffold_58",
  "regions": []
 },
 {
  "length": 24739,
  "seq_id": "scaffold_59",
  "regions": []
 },
 {
  "length": 24325,
  "seq_id": "scaffold_60",
  "regions": []
 },
 {
  "length": 24116,
  "seq_id": "scaffold_61",
  "regions": []
 },
 {
  "length": 23858,
  "seq_id": "scaffold_62",
  "regions": []
 },
 {
  "length": 23809,
  "seq_id": "scaffold_63",
  "regions": []
 },
 {
  "length": 23768,
  "seq_id": "scaffold_64",
  "regions": []
 },
 {
  "length": 23626,
  "seq_id": "scaffold_65",
  "regions": []
 },
 {
  "length": 23597,
  "seq_id": "scaffold_66",
  "regions": []
 },
 {
  "length": 23158,
  "seq_id": "scaffold_67",
  "regions": []
 },
 {
  "length": 22494,
  "seq_id": "scaffold_68",
  "regions": []
 },
 {
  "length": 22418,
  "seq_id": "scaffold_69",
  "regions": []
 },
 {
  "length": 21892,
  "seq_id": "scaffold_70",
  "regions": []
 },
 {
  "length": 21778,
  "seq_id": "scaffold_71",
  "regions": []
 },
 {
  "length": 21589,
  "seq_id": "scaffold_72",
  "regions": []
 },
 {
  "length": 21572,
  "seq_id": "scaffold_73",
  "regions": []
 },
 {
  "length": 21545,
  "seq_id": "scaffold_74",
  "regions": []
 },
 {
  "length": 20865,
  "seq_id": "scaffold_75",
  "regions": []
 },
 {
  "length": 20779,
  "seq_id": "scaffold_76",
  "regions": []
 },
 {
  "length": 20735,
  "seq_id": "scaffold_77",
  "regions": []
 },
 {
  "length": 20672,
  "seq_id": "scaffold_78",
  "regions": []
 },
 {
  "length": 20630,
  "seq_id": "scaffold_79",
  "regions": []
 },
 {
  "length": 20622,
  "seq_id": "scaffold_80",
  "regions": []
 },
 {
  "length": 20534,
  "seq_id": "scaffold_81",
  "regions": []
 },
 {
  "length": 20467,
  "seq_id": "scaffold_82",
  "regions": []
 },
 {
  "length": 20453,
  "seq_id": "scaffold_83",
  "regions": []
 },
 {
  "length": 20403,
  "seq_id": "scaffold_84",
  "regions": []
 },
 {
  "length": 20358,
  "seq_id": "scaffold_85",
  "regions": []
 },
 {
  "length": 20335,
  "seq_id": "scaffold_86",
  "regions": []
 },
 {
  "length": 19930,
  "seq_id": "scaffold_87",
  "regions": []
 },
 {
  "length": 19925,
  "seq_id": "scaffold_88",
  "regions": []
 },
 {
  "length": 19732,
  "seq_id": "scaffold_89",
  "regions": []
 },
 {
  "length": 19456,
  "seq_id": "scaffold_90",
  "regions": []
 },
 {
  "length": 19213,
  "seq_id": "scaffold_91",
  "regions": []
 },
 {
  "length": 19181,
  "seq_id": "scaffold_92",
  "regions": []
 },
 {
  "length": 19178,
  "seq_id": "scaffold_93",
  "regions": []
 },
 {
  "length": 19153,
  "seq_id": "scaffold_94",
  "regions": []
 },
 {
  "length": 19145,
  "seq_id": "scaffold_95",
  "regions": []
 },
 {
  "length": 18735,
  "seq_id": "scaffold_96",
  "regions": []
 },
 {
  "length": 18631,
  "seq_id": "scaffold_97",
  "regions": []
 },
 {
  "length": 18577,
  "seq_id": "scaffold_98",
  "regions": []
 },
 {
  "length": 18487,
  "seq_id": "scaffold_99",
  "regions": []
 },
 {
  "length": 18344,
  "seq_id": "scaffold_100",
  "regions": []
 },
 {
  "length": 18258,
  "seq_id": "scaffold_101",
  "regions": []
 },
 {
  "length": 18019,
  "seq_id": "scaffold_102",
  "regions": []
 },
 {
  "length": 18000,
  "seq_id": "scaffold_103",
  "regions": []
 },
 {
  "length": 17995,
  "seq_id": "scaffold_104",
  "regions": []
 },
 {
  "length": 17954,
  "seq_id": "scaffold_105",
  "regions": []
 },
 {
  "length": 17895,
  "seq_id": "scaffold_106",
  "regions": []
 },
 {
  "length": 17889,
  "seq_id": "scaffold_107",
  "regions": []
 },
 {
  "length": 17651,
  "seq_id": "scaffold_108",
  "regions": []
 },
 {
  "length": 17521,
  "seq_id": "scaffold_109",
  "regions": []
 },
 {
  "length": 17513,
  "seq_id": "scaffold_110",
  "regions": []
 },
 {
  "length": 17452,
  "seq_id": "scaffold_111",
  "regions": []
 },
 {
  "length": 17424,
  "seq_id": "scaffold_112",
  "regions": []
 },
 {
  "length": 17330,
  "seq_id": "scaffold_113",
  "regions": []
 },
 {
  "length": 17252,
  "seq_id": "scaffold_114",
  "regions": []
 },
 {
  "length": 17039,
  "seq_id": "scaffold_115",
  "regions": []
 },
 {
  "length": 16984,
  "seq_id": "scaffold_116",
  "regions": []
 },
 {
  "length": 16806,
  "seq_id": "scaffold_117",
  "regions": []
 },
 {
  "length": 16746,
  "seq_id": "scaffold_118",
  "regions": []
 },
 {
  "length": 16664,
  "seq_id": "scaffold_119",
  "regions": []
 },
 {
  "length": 16536,
  "seq_id": "scaffold_120",
  "regions": []
 },
 {
  "length": 16488,
  "seq_id": "scaffold_121",
  "regions": []
 },
 {
  "length": 16474,
  "seq_id": "scaffold_122",
  "regions": []
 },
 {
  "length": 16446,
  "seq_id": "scaffold_123",
  "regions": []
 },
 {
  "length": 16419,
  "seq_id": "scaffold_124",
  "regions": []
 },
 {
  "length": 16381,
  "seq_id": "scaffold_125",
  "regions": []
 },
 {
  "length": 16291,
  "seq_id": "scaffold_126",
  "regions": []
 },
 {
  "length": 16273,
  "seq_id": "scaffold_127",
  "regions": []
 },
 {
  "length": 16263,
  "seq_id": "scaffold_128",
  "regions": []
 },
 {
  "length": 16216,
  "seq_id": "scaffold_129",
  "regions": []
 },
 {
  "length": 16212,
  "seq_id": "scaffold_130",
  "regions": []
 },
 {
  "length": 16119,
  "seq_id": "scaffold_131",
  "regions": []
 },
 {
  "length": 16057,
  "seq_id": "scaffold_132",
  "regions": []
 },
 {
  "length": 15908,
  "seq_id": "scaffold_133",
  "regions": []
 },
 {
  "length": 15888,
  "seq_id": "scaffold_134",
  "regions": []
 },
 {
  "length": 15831,
  "seq_id": "scaffold_135",
  "regions": []
 },
 {
  "length": 15746,
  "seq_id": "scaffold_136",
  "regions": []
 },
 {
  "length": 15692,
  "seq_id": "scaffold_137",
  "regions": []
 },
 {
  "length": 15686,
  "seq_id": "scaffold_138",
  "regions": []
 },
 {
  "length": 15676,
  "seq_id": "scaffold_139",
  "regions": []
 },
 {
  "length": 15572,
  "seq_id": "scaffold_140",
  "regions": [
   {
    "start": 1,
    "end": 15572,
    "idx": 1,
    "orfs": [
     {
      "start": 180,
      "end": 1440,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001871",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001871</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001871</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001871-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 180 - 1,440,\n (total: 1230 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001871\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAGGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAATTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
      "translation": "MSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKGVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSNFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
      "product": "hypothetical protein"
     },
     {
      "start": 1541,
      "end": 4567,
      "strand": -1,
      "locus_tag": "MARS9BIN1_001872",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001872</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001872</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001872-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,541 - 4,567,\n (total: 2808 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 61.5; E-value: 1.1e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001872 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [11:257](score: 120.2, e-value: 8.3e-35)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [466:530](score: 28.2, e-value: 1.6e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [800:881](score: 50.4, e-value: 1.9e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001872 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001872\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCCCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAATAAAATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGGCTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCTAGCGTTGGAATGAACCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCATAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTACATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTTGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTAATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
      "translation": "MRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQNKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRGLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSISGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLHGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
      "product": "hypothetical protein"
     },
     {
      "start": 4877,
      "end": 5818,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001873",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001873</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001873</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001873-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,877 - 5,818,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001873 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001873\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
      "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
      "product": "hypothetical protein"
     },
     {
      "start": 5872,
      "end": 6800,
      "strand": -1,
      "locus_tag": "MARS9BIN1_001874",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001874</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001874</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001874-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,872 - 6,800,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001874 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001874\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
      "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
      "product": "hypothetical protein"
     },
     {
      "start": 7165,
      "end": 7689,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001875",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001875</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001875</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001875-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,165 - 7,689,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001875 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001875 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001875\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
      "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
      "product": "hypothetical protein"
     },
     {
      "start": 8291,
      "end": 9340,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001876",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001876</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001876</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001876-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,291 - 9,340,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001876 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 207.4, e-value: 2.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001876\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTCGGGAAGCGCGGCCGCTCCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
      "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRSKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
      "product": "hypothetical protein"
     },
     {
      "start": 9382,
      "end": 10083,
      "strand": -1,
      "locus_tag": "MARS9BIN1_001877",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001877</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001877</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001877-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,382 - 10,083,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001877 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001877\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
      "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
      "product": "hypothetical protein"
     },
     {
      "start": 10610,
      "end": 11632,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001878",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001878</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001878</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001878-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,610 - 11,632,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001878 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001878\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
      "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
      "product": "hypothetical protein"
     },
     {
      "start": 11687,
      "end": 12127,
      "strand": -1,
      "locus_tag": "MARS9BIN1_001879",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001879</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001879</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001879-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,687 - 12,127,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001879\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
      "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
      "product": "hypothetical protein"
     },
     {
      "start": 12900,
      "end": 14204,
      "strand": 1,
      "locus_tag": "MARS9BIN1_001880",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001880</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001880</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001880-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,900 - 14,204,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325.2; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001880 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.3, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001880 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001880\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_001880-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGCAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCGTGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
      "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTAEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVVAMDKEQVKRKRKLRAG",
      "product": "hypothetical protein"
     },
     {
      "start": 14295,
      "end": 15445,
      "strand": -1,
      "locus_tag": "MARS9BIN1_001881",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001881</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001881</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001881-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,295 - 15,445,\n (total: 1119 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001881 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [22:62](score: 49.9, e-value: 2.1e-13)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [77:106](score: 24.1, e-value: 2.8e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [111:146](score: 23.9, e-value: 3.2e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [152:189](score: 32.3, e-value: 7.2e-08)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [231:272](score: 25.9, e-value: 7.7e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001881 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00514.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001881\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "CTAGCCAAGTCAAGGGACCTGCGCGTTCAACGAAATGCTACAGGAGCTCTATTGAATATGACTCATTCCGATGAAAACAGGCAGCAGCTTGTCAATGCCGGCGCAATACCAGTGCTCGTCCACCTCTTAACTTCTCAAGACTCTGATGTCCAATACTACTGCACTACTGCGCTAAGCAACATCGCAGTTGACGCTTCGAACCGCAAGAAACTGGCAAATTCCGAGCCTAGGTTGGTGCAAGCGCTCATCGCTTTGATGGAGTCATCTAGCCCAAAAGTGCAATGCCAATCAGCTCTGGCGCTGCGCAATCTCGCGTCGGACGAGAAATATCAACTCGATATTGTGCGGTCTAATGGGTTGCCTGCTCTCTTACGTTTATTACAATCTTCCTTCCTAGCTCTGATACTTTCAGCAGTCGCTTGTATACGCAATATCTCTATTCACCCGCTAAACGAGTCGCCTATCATTGATGCTGGTTTCCTAAGGCCTTTGGTCGAACTTCTTGGTTCGACGGATAATGAAGAGATTCAATGTCATGCCATCTCCACCTTACGGAATCTAGCGGCAAGCTCAGAACGAAATAAAAAAGCCATTGTTGAAGCGGGAGCAATTCAGAAATGTAAGGAACTCGTTTTGCATGTGCCACTTAGCGTCCAAAGTGAGATGACGGCATGCATTGCCGTACTTGCTCTGTCTGACGAGCTCAAAACCTACTTGTTGTCTCTCGGAGTTTTTGATGTACTCATTCCTCTAACGGATTCAACGAGCATTGAGGTGCAGGGGAACAGCGCAGCAGCTCTGGGCAATTTGTCATCGAAAGTGAGCGACTACACACCTCTCTTGAATGCATGGAAGGAACCAGACGGAGGTTTCAAAGGCTACCTAGAGCACTTTCTCTCTAGTGGTGATGGTGCGTTTCAGCACATTGCCACATGGACCGTCCTACAGCTCCTGGAAGCTGACGAGCCGGATGTCAAAGCCCTGATTGTGGAAAGTCCGGAAATTGTGCGGGCGATTCGTCAGACGGCTGAGCGAGAACCGCAAACTGATGACGATCCCGAAGGAGAAGGCGAAATTGTGCCTCTTGCCAGGCGGGTTGTGGAACTAATCGACCAGTGA",
      "translation": "MAKSRDLRVQRNATGALLNMTHSDENRQQLVNAGAIPVLVHLLTSQDSDVQYYCTTALSNIAVDASNRKKLANSEPRLVQALIALMESSSPKVQCQSALALRNLASDEKYQLDIVRSNGLPALLRLLQSSFLALILSAVACIRNISIHPLNESPIIDAGFLRPLVELLGSTDNEEIQCHAISTLRNLAASSERNKKAIVEAGAIQKCKELVLHVPLSVQSEMTACIAVLALSDELKTYLLSLGVFDVLIPLTDSTSIEVQGNSAAALGNLSSKVSDYTPLLNAWKEPDGGFKGYLEHFLSSGDGAFQHIATWTVLQLLEADEPDVKALIVESPEIVRAIRQTAEREPQTDDDPEGEGEIVPLARRVVELIDQ",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 5871,
      "end": 6800,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 15572,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r140c1"
   }
  ]
 },
 {
  "length": 15488,
  "seq_id": "scaffold_141",
  "regions": []
 },
 {
  "length": 15460,
  "seq_id": "scaffold_142",
  "regions": []
 },
 {
  "length": 15443,
  "seq_id": "scaffold_143",
  "regions": []
 },
 {
  "length": 15436,
  "seq_id": "scaffold_144",
  "regions": []
 },
 {
  "length": 15430,
  "seq_id": "scaffold_145",
  "regions": []
 },
 {
  "length": 15361,
  "seq_id": "scaffold_146",
  "regions": []
 },
 {
  "length": 15263,
  "seq_id": "scaffold_147",
  "regions": []
 },
 {
  "length": 15097,
  "seq_id": "scaffold_148",
  "regions": []
 },
 {
  "length": 15077,
  "seq_id": "scaffold_149",
  "regions": []
 },
 {
  "length": 14995,
  "seq_id": "scaffold_150",
  "regions": []
 },
 {
  "length": 14993,
  "seq_id": "scaffold_151",
  "regions": []
 },
 {
  "length": 14850,
  "seq_id": "scaffold_152",
  "regions": []
 },
 {
  "length": 14826,
  "seq_id": "scaffold_153",
  "regions": []
 },
 {
  "length": 14814,
  "seq_id": "scaffold_154",
  "regions": []
 },
 {
  "length": 14756,
  "seq_id": "scaffold_155",
  "regions": []
 },
 {
  "length": 14431,
  "seq_id": "scaffold_156",
  "regions": []
 },
 {
  "length": 14340,
  "seq_id": "scaffold_157",
  "regions": []
 },
 {
  "length": 14306,
  "seq_id": "scaffold_158",
  "regions": []
 },
 {
  "length": 14234,
  "seq_id": "scaffold_159",
  "regions": []
 },
 {
  "length": 14202,
  "seq_id": "scaffold_160",
  "regions": []
 },
 {
  "length": 14117,
  "seq_id": "scaffold_161",
  "regions": []
 },
 {
  "length": 14106,
  "seq_id": "scaffold_162",
  "regions": []
 },
 {
  "length": 14067,
  "seq_id": "scaffold_163",
  "regions": []
 },
 {
  "length": 14007,
  "seq_id": "scaffold_164",
  "regions": []
 },
 {
  "length": 13919,
  "seq_id": "scaffold_165",
  "regions": []
 },
 {
  "length": 13918,
  "seq_id": "scaffold_166",
  "regions": []
 },
 {
  "length": 13884,
  "seq_id": "scaffold_167",
  "regions": []
 },
 {
  "length": 13805,
  "seq_id": "scaffold_168",
  "regions": []
 },
 {
  "length": 13722,
  "seq_id": "scaffold_169",
  "regions": []
 },
 {
  "length": 13682,
  "seq_id": "scaffold_170",
  "regions": []
 },
 {
  "length": 13623,
  "seq_id": "scaffold_171",
  "regions": []
 },
 {
  "length": 13555,
  "seq_id": "scaffold_172",
  "regions": []
 },
 {
  "length": 13544,
  "seq_id": "scaffold_173",
  "regions": []
 },
 {
  "length": 13530,
  "seq_id": "scaffold_174",
  "regions": []
 },
 {
  "length": 13522,
  "seq_id": "scaffold_175",
  "regions": []
 },
 {
  "length": 13398,
  "seq_id": "scaffold_176",
  "regions": []
 },
 {
  "length": 13376,
  "seq_id": "scaffold_177",
  "regions": []
 },
 {
  "length": 13344,
  "seq_id": "scaffold_178",
  "regions": []
 },
 {
  "length": 13245,
  "seq_id": "scaffold_179",
  "regions": []
 },
 {
  "length": 13219,
  "seq_id": "scaffold_180",
  "regions": []
 },
 {
  "length": 13206,
  "seq_id": "scaffold_181",
  "regions": []
 },
 {
  "length": 13163,
  "seq_id": "scaffold_182",
  "regions": []
 },
 {
  "length": 13109,
  "seq_id": "scaffold_183",
  "regions": []
 },
 {
  "length": 13098,
  "seq_id": "scaffold_184",
  "regions": []
 },
 {
  "length": 13041,
  "seq_id": "scaffold_185",
  "regions": []
 },
 {
  "length": 13002,
  "seq_id": "scaffold_186",
  "regions": []
 },
 {
  "length": 12995,
  "seq_id": "scaffold_187",
  "regions": []
 },
 {
  "length": 12978,
  "seq_id": "scaffold_188",
  "regions": []
 },
 {
  "length": 12973,
  "seq_id": "scaffold_189",
  "regions": []
 },
 {
  "length": 12905,
  "seq_id": "scaffold_190",
  "regions": []
 },
 {
  "length": 12759,
  "seq_id": "scaffold_191",
  "regions": []
 },
 {
  "length": 12669,
  "seq_id": "scaffold_192",
  "regions": []
 },
 {
  "length": 12642,
  "seq_id": "scaffold_193",
  "regions": []
 },
 {
  "length": 12635,
  "seq_id": "scaffold_194",
  "regions": []
 },
 {
  "length": 12634,
  "seq_id": "scaffold_195",
  "regions": []
 },
 {
  "length": 12624,
  "seq_id": "scaffold_196",
  "regions": []
 },
 {
  "length": 12505,
  "seq_id": "scaffold_197",
  "regions": []
 },
 {
  "length": 12481,
  "seq_id": "scaffold_198",
  "regions": []
 },
 {
  "length": 12454,
  "seq_id": "scaffold_199",
  "regions": []
 },
 {
  "length": 12428,
  "seq_id": "scaffold_200",
  "regions": []
 },
 {
  "length": 12362,
  "seq_id": "scaffold_201",
  "regions": []
 },
 {
  "length": 12358,
  "seq_id": "scaffold_202",
  "regions": []
 },
 {
  "length": 12271,
  "seq_id": "scaffold_203",
  "regions": []
 },
 {
  "length": 12257,
  "seq_id": "scaffold_204",
  "regions": []
 },
 {
  "length": 12255,
  "seq_id": "scaffold_205",
  "regions": []
 },
 {
  "length": 12155,
  "seq_id": "scaffold_206",
  "regions": []
 },
 {
  "length": 12130,
  "seq_id": "scaffold_207",
  "regions": []
 },
 {
  "length": 12116,
  "seq_id": "scaffold_208",
  "regions": []
 },
 {
  "length": 12076,
  "seq_id": "scaffold_209",
  "regions": []
 },
 {
  "length": 11997,
  "seq_id": "scaffold_210",
  "regions": []
 },
 {
  "length": 11973,
  "seq_id": "scaffold_211",
  "regions": []
 },
 {
  "length": 11967,
  "seq_id": "scaffold_212",
  "regions": []
 },
 {
  "length": 11882,
  "seq_id": "scaffold_213",
  "regions": []
 },
 {
  "length": 11810,
  "seq_id": "scaffold_214",
  "regions": []
 },
 {
  "length": 11791,
  "seq_id": "scaffold_215",
  "regions": []
 },
 {
  "length": 11722,
  "seq_id": "scaffold_216",
  "regions": []
 },
 {
  "length": 11698,
  "seq_id": "scaffold_217",
  "regions": []
 },
 {
  "length": 11653,
  "seq_id": "scaffold_218",
  "regions": []
 },
 {
  "length": 11653,
  "seq_id": "scaffold_219",
  "regions": []
 },
 {
  "length": 11621,
  "seq_id": "scaffold_220",
  "regions": []
 },
 {
  "length": 11608,
  "seq_id": "scaffold_221",
  "regions": []
 },
 {
  "length": 11604,
  "seq_id": "scaffold_222",
  "regions": []
 },
 {
  "length": 11603,
  "seq_id": "scaffold_223",
  "regions": []
 },
 {
  "length": 11580,
  "seq_id": "scaffold_224",
  "regions": []
 },
 {
  "length": 11523,
  "seq_id": "scaffold_225",
  "regions": []
 },
 {
  "length": 11514,
  "seq_id": "scaffold_226",
  "regions": []
 },
 {
  "length": 11487,
  "seq_id": "scaffold_227",
  "regions": []
 },
 {
  "length": 11457,
  "seq_id": "scaffold_228",
  "regions": []
 },
 {
  "length": 11320,
  "seq_id": "scaffold_229",
  "regions": []
 },
 {
  "length": 11223,
  "seq_id": "scaffold_230",
  "regions": []
 },
 {
  "length": 11175,
  "seq_id": "scaffold_231",
  "regions": []
 },
 {
  "length": 11154,
  "seq_id": "scaffold_232",
  "regions": []
 },
 {
  "length": 11122,
  "seq_id": "scaffold_233",
  "regions": []
 },
 {
  "length": 11122,
  "seq_id": "scaffold_234",
  "regions": []
 },
 {
  "length": 11121,
  "seq_id": "scaffold_235",
  "regions": []
 },
 {
  "length": 11075,
  "seq_id": "scaffold_236",
  "regions": []
 },
 {
  "length": 10941,
  "seq_id": "scaffold_237",
  "regions": []
 },
 {
  "length": 10912,
  "seq_id": "scaffold_238",
  "regions": []
 },
 {
  "length": 10866,
  "seq_id": "scaffold_239",
  "regions": []
 },
 {
  "length": 10862,
  "seq_id": "scaffold_240",
  "regions": []
 },
 {
  "length": 10827,
  "seq_id": "scaffold_241",
  "regions": []
 },
 {
  "length": 10809,
  "seq_id": "scaffold_242",
  "regions": []
 },
 {
  "length": 10751,
  "seq_id": "scaffold_243",
  "regions": []
 },
 {
  "length": 10738,
  "seq_id": "scaffold_244",
  "regions": []
 },
 {
  "length": 10717,
  "seq_id": "scaffold_245",
  "regions": []
 },
 {
  "length": 10704,
  "seq_id": "scaffold_246",
  "regions": []
 },
 {
  "length": 10668,
  "seq_id": "scaffold_247",
  "regions": []
 },
 {
  "length": 10661,
  "seq_id": "scaffold_248",
  "regions": []
 },
 {
  "length": 10639,
  "seq_id": "scaffold_249",
  "regions": []
 },
 {
  "length": 10634,
  "seq_id": "scaffold_250",
  "regions": []
 },
 {
  "length": 10528,
  "seq_id": "scaffold_251",
  "regions": []
 },
 {
  "length": 10512,
  "seq_id": "scaffold_252",
  "regions": []
 },
 {
  "length": 10481,
  "seq_id": "scaffold_253",
  "regions": []
 },
 {
  "length": 10466,
  "seq_id": "scaffold_254",
  "regions": []
 },
 {
  "length": 10459,
  "seq_id": "scaffold_255",
  "regions": []
 },
 {
  "length": 10370,
  "seq_id": "scaffold_256",
  "regions": []
 },
 {
  "length": 10352,
  "seq_id": "scaffold_257",
  "regions": []
 },
 {
  "length": 10332,
  "seq_id": "scaffold_258",
  "regions": []
 },
 {
  "length": 10322,
  "seq_id": "scaffold_259",
  "regions": []
 },
 {
  "length": 10299,
  "seq_id": "scaffold_260",
  "regions": []
 },
 {
  "length": 10198,
  "seq_id": "scaffold_261",
  "regions": []
 },
 {
  "length": 10158,
  "seq_id": "scaffold_262",
  "regions": []
 },
 {
  "length": 10151,
  "seq_id": "scaffold_263",
  "regions": []
 },
 {
  "length": 10126,
  "seq_id": "scaffold_264",
  "regions": []
 },
 {
  "length": 10111,
  "seq_id": "scaffold_265",
  "regions": []
 },
 {
  "length": 10098,
  "seq_id": "scaffold_266",
  "regions": []
 },
 {
  "length": 10081,
  "seq_id": "scaffold_267",
  "regions": []
 },
 {
  "length": 10071,
  "seq_id": "scaffold_268",
  "regions": []
 },
 {
  "length": 10035,
  "seq_id": "scaffold_269",
  "regions": []
 },
 {
  "length": 10012,
  "seq_id": "scaffold_270",
  "regions": []
 },
 {
  "length": 9969,
  "seq_id": "scaffold_271",
  "regions": []
 },
 {
  "length": 9922,
  "seq_id": "scaffold_272",
  "regions": []
 },
 {
  "length": 9866,
  "seq_id": "scaffold_273",
  "regions": []
 },
 {
  "length": 9852,
  "seq_id": "scaffold_274",
  "regions": []
 },
 {
  "length": 9838,
  "seq_id": "scaffold_275",
  "regions": []
 },
 {
  "length": 9812,
  "seq_id": "scaffold_276",
  "regions": []
 },
 {
  "length": 9756,
  "seq_id": "scaffold_277",
  "regions": []
 },
 {
  "length": 9698,
  "seq_id": "scaffold_278",
  "regions": []
 },
 {
  "length": 9692,
  "seq_id": "scaffold_279",
  "regions": []
 },
 {
  "length": 9670,
  "seq_id": "scaffold_280",
  "regions": []
 },
 {
  "length": 9657,
  "seq_id": "scaffold_281",
  "regions": []
 },
 {
  "length": 9654,
  "seq_id": "scaffold_282",
  "regions": []
 },
 {
  "length": 9599,
  "seq_id": "scaffold_283",
  "regions": []
 },
 {
  "length": 9524,
  "seq_id": "scaffold_284",
  "regions": []
 },
 {
  "length": 9509,
  "seq_id": "scaffold_285",
  "regions": []
 },
 {
  "length": 9502,
  "seq_id": "scaffold_286",
  "regions": []
 },
 {
  "length": 9481,
  "seq_id": "scaffold_287",
  "regions": []
 },
 {
  "length": 9472,
  "seq_id": "scaffold_288",
  "regions": []
 },
 {
  "length": 9337,
  "seq_id": "scaffold_289",
  "regions": []
 },
 {
  "length": 9301,
  "seq_id": "scaffold_290",
  "regions": []
 },
 {
  "length": 9299,
  "seq_id": "scaffold_291",
  "regions": []
 },
 {
  "length": 9280,
  "seq_id": "scaffold_292",
  "regions": []
 },
 {
  "length": 9255,
  "seq_id": "scaffold_293",
  "regions": []
 },
 {
  "length": 9233,
  "seq_id": "scaffold_294",
  "regions": []
 },
 {
  "length": 9182,
  "seq_id": "scaffold_295",
  "regions": []
 },
 {
  "length": 9172,
  "seq_id": "scaffold_296",
  "regions": []
 },
 {
  "length": 9145,
  "seq_id": "scaffold_297",
  "regions": []
 },
 {
  "length": 9141,
  "seq_id": "scaffold_298",
  "regions": []
 },
 {
  "length": 9070,
  "seq_id": "scaffold_299",
  "regions": []
 },
 {
  "length": 9050,
  "seq_id": "scaffold_300",
  "regions": []
 },
 {
  "length": 9040,
  "seq_id": "scaffold_301",
  "regions": []
 },
 {
  "length": 9003,
  "seq_id": "scaffold_302",
  "regions": []
 },
 {
  "length": 8983,
  "seq_id": "scaffold_303",
  "regions": []
 },
 {
  "length": 8954,
  "seq_id": "scaffold_304",
  "regions": []
 },
 {
  "length": 8946,
  "seq_id": "scaffold_305",
  "regions": []
 },
 {
  "length": 8939,
  "seq_id": "scaffold_306",
  "regions": []
 },
 {
  "length": 8935,
  "seq_id": "scaffold_307",
  "regions": []
 },
 {
  "length": 8920,
  "seq_id": "scaffold_308",
  "regions": []
 },
 {
  "length": 8879,
  "seq_id": "scaffold_309",
  "regions": []
 },
 {
  "length": 8858,
  "seq_id": "scaffold_310",
  "regions": []
 },
 {
  "length": 8853,
  "seq_id": "scaffold_311",
  "regions": []
 },
 {
  "length": 8849,
  "seq_id": "scaffold_312",
  "regions": []
 },
 {
  "length": 8821,
  "seq_id": "scaffold_313",
  "regions": []
 },
 {
  "length": 8814,
  "seq_id": "scaffold_314",
  "regions": []
 },
 {
  "length": 8774,
  "seq_id": "scaffold_315",
  "regions": []
 },
 {
  "length": 8755,
  "seq_id": "scaffold_316",
  "regions": []
 },
 {
  "length": 8755,
  "seq_id": "scaffold_317",
  "regions": []
 },
 {
  "length": 8668,
  "seq_id": "scaffold_318",
  "regions": []
 },
 {
  "length": 8656,
  "seq_id": "scaffold_319",
  "regions": []
 },
 {
  "length": 8621,
  "seq_id": "scaffold_320",
  "regions": []
 },
 {
  "length": 8607,
  "seq_id": "scaffold_321",
  "regions": []
 },
 {
  "length": 8590,
  "seq_id": "scaffold_322",
  "regions": []
 },
 {
  "length": 8561,
  "seq_id": "scaffold_323",
  "regions": []
 },
 {
  "length": 8506,
  "seq_id": "scaffold_324",
  "regions": []
 },
 {
  "length": 8486,
  "seq_id": "scaffold_325",
  "regions": []
 },
 {
  "length": 8451,
  "seq_id": "scaffold_326",
  "regions": []
 },
 {
  "length": 8360,
  "seq_id": "scaffold_327",
  "regions": []
 },
 {
  "length": 8335,
  "seq_id": "scaffold_328",
  "regions": []
 },
 {
  "length": 8321,
  "seq_id": "scaffold_329",
  "regions": []
 },
 {
  "length": 8321,
  "seq_id": "scaffold_330",
  "regions": []
 },
 {
  "length": 8296,
  "seq_id": "scaffold_331",
  "regions": []
 },
 {
  "length": 8284,
  "seq_id": "scaffold_332",
  "regions": []
 },
 {
  "length": 8278,
  "seq_id": "scaffold_333",
  "regions": []
 },
 {
  "length": 8253,
  "seq_id": "scaffold_334",
  "regions": []
 },
 {
  "length": 8183,
  "seq_id": "scaffold_335",
  "regions": []
 },
 {
  "length": 8157,
  "seq_id": "scaffold_336",
  "regions": []
 },
 {
  "length": 8149,
  "seq_id": "scaffold_337",
  "regions": []
 },
 {
  "length": 8145,
  "seq_id": "scaffold_338",
  "regions": []
 },
 {
  "length": 8143,
  "seq_id": "scaffold_339",
  "regions": []
 },
 {
  "length": 8143,
  "seq_id": "scaffold_340",
  "regions": []
 },
 {
  "length": 8137,
  "seq_id": "scaffold_341",
  "regions": []
 },
 {
  "length": 8122,
  "seq_id": "scaffold_342",
  "regions": []
 },
 {
  "length": 8119,
  "seq_id": "scaffold_343",
  "regions": []
 },
 {
  "length": 8104,
  "seq_id": "scaffold_344",
  "regions": []
 },
 {
  "length": 8065,
  "seq_id": "scaffold_345",
  "regions": []
 },
 {
  "length": 8047,
  "seq_id": "scaffold_346",
  "regions": []
 },
 {
  "length": 8033,
  "seq_id": "scaffold_347",
  "regions": []
 },
 {
  "length": 8030,
  "seq_id": "scaffold_348",
  "regions": []
 },
 {
  "length": 8023,
  "seq_id": "scaffold_349",
  "regions": []
 },
 {
  "length": 7999,
  "seq_id": "scaffold_350",
  "regions": []
 },
 {
  "length": 7993,
  "seq_id": "scaffold_351",
  "regions": []
 },
 {
  "length": 7992,
  "seq_id": "scaffold_352",
  "regions": []
 },
 {
  "length": 7985,
  "seq_id": "scaffold_353",
  "regions": []
 },
 {
  "length": 7960,
  "seq_id": "scaffold_354",
  "regions": []
 },
 {
  "length": 7944,
  "seq_id": "scaffold_355",
  "regions": []
 },
 {
  "length": 7943,
  "seq_id": "scaffold_356",
  "regions": []
 },
 {
  "length": 7925,
  "seq_id": "scaffold_357",
  "regions": []
 },
 {
  "length": 7924,
  "seq_id": "scaffold_358",
  "regions": []
 },
 {
  "length": 7911,
  "seq_id": "scaffold_359",
  "regions": []
 },
 {
  "length": 7904,
  "seq_id": "scaffold_360",
  "regions": []
 },
 {
  "length": 7904,
  "seq_id": "scaffold_361",
  "regions": []
 },
 {
  "length": 7894,
  "seq_id": "scaffold_362",
  "regions": []
 },
 {
  "length": 7892,
  "seq_id": "scaffold_363",
  "regions": []
 },
 {
  "length": 7889,
  "seq_id": "scaffold_364",
  "regions": []
 },
 {
  "length": 7874,
  "seq_id": "scaffold_365",
  "regions": []
 },
 {
  "length": 7850,
  "seq_id": "scaffold_366",
  "regions": []
 },
 {
  "length": 7821,
  "seq_id": "scaffold_367",
  "regions": []
 },
 {
  "length": 7800,
  "seq_id": "scaffold_368",
  "regions": []
 },
 {
  "length": 7796,
  "seq_id": "scaffold_369",
  "regions": []
 },
 {
  "length": 7775,
  "seq_id": "scaffold_370",
  "regions": []
 },
 {
  "length": 7755,
  "seq_id": "scaffold_371",
  "regions": []
 },
 {
  "length": 7728,
  "seq_id": "scaffold_372",
  "regions": []
 },
 {
  "length": 7723,
  "seq_id": "scaffold_373",
  "regions": []
 },
 {
  "length": 7683,
  "seq_id": "scaffold_374",
  "regions": []
 },
 {
  "length": 7676,
  "seq_id": "scaffold_375",
  "regions": []
 },
 {
  "length": 7671,
  "seq_id": "scaffold_376",
  "regions": []
 },
 {
  "length": 7668,
  "seq_id": "scaffold_377",
  "regions": []
 },
 {
  "length": 7664,
  "seq_id": "scaffold_378",
  "regions": []
 },
 {
  "length": 7611,
  "seq_id": "scaffold_379",
  "regions": []
 },
 {
  "length": 7608,
  "seq_id": "scaffold_380",
  "regions": []
 },
 {
  "length": 7600,
  "seq_id": "scaffold_381",
  "regions": []
 },
 {
  "length": 7553,
  "seq_id": "scaffold_382",
  "regions": []
 },
 {
  "length": 7529,
  "seq_id": "scaffold_383",
  "regions": []
 },
 {
  "length": 7509,
  "seq_id": "scaffold_384",
  "regions": []
 },
 {
  "length": 7493,
  "seq_id": "scaffold_385",
  "regions": []
 },
 {
  "length": 7472,
  "seq_id": "scaffold_386",
  "regions": []
 },
 {
  "length": 7428,
  "seq_id": "scaffold_387",
  "regions": []
 },
 {
  "length": 7411,
  "seq_id": "scaffold_388",
  "regions": []
 },
 {
  "length": 7383,
  "seq_id": "scaffold_389",
  "regions": []
 },
 {
  "length": 7381,
  "seq_id": "scaffold_390",
  "regions": []
 },
 {
  "length": 7363,
  "seq_id": "scaffold_391",
  "regions": []
 },
 {
  "length": 7343,
  "seq_id": "scaffold_392",
  "regions": []
 },
 {
  "length": 7339,
  "seq_id": "scaffold_393",
  "regions": []
 },
 {
  "length": 7334,
  "seq_id": "scaffold_394",
  "regions": []
 },
 {
  "length": 7316,
  "seq_id": "scaffold_395",
  "regions": []
 },
 {
  "length": 7272,
  "seq_id": "scaffold_396",
  "regions": []
 },
 {
  "length": 7244,
  "seq_id": "scaffold_397",
  "regions": []
 },
 {
  "length": 7244,
  "seq_id": "scaffold_398",
  "regions": []
 },
 {
  "length": 7190,
  "seq_id": "scaffold_399",
  "regions": []
 },
 {
  "length": 7179,
  "seq_id": "scaffold_400",
  "regions": []
 },
 {
  "length": 7160,
  "seq_id": "scaffold_401",
  "regions": []
 },
 {
  "length": 7157,
  "seq_id": "scaffold_402",
  "regions": []
 },
 {
  "length": 7130,
  "seq_id": "scaffold_403",
  "regions": []
 },
 {
  "length": 7118,
  "seq_id": "scaffold_404",
  "regions": []
 },
 {
  "length": 7067,
  "seq_id": "scaffold_405",
  "regions": []
 },
 {
  "length": 7058,
  "seq_id": "scaffold_406",
  "regions": []
 },
 {
  "length": 7042,
  "seq_id": "scaffold_407",
  "regions": []
 },
 {
  "length": 7028,
  "seq_id": "scaffold_408",
  "regions": []
 },
 {
  "length": 7012,
  "seq_id": "scaffold_409",
  "regions": []
 },
 {
  "length": 7007,
  "seq_id": "scaffold_410",
  "regions": []
 },
 {
  "length": 6981,
  "seq_id": "scaffold_411",
  "regions": []
 },
 {
  "length": 6977,
  "seq_id": "scaffold_412",
  "regions": []
 },
 {
  "length": 6964,
  "seq_id": "scaffold_413",
  "regions": []
 },
 {
  "length": 6913,
  "seq_id": "scaffold_414",
  "regions": []
 },
 {
  "length": 6911,
  "seq_id": "scaffold_415",
  "regions": []
 },
 {
  "length": 6887,
  "seq_id": "scaffold_416",
  "regions": []
 },
 {
  "length": 6863,
  "seq_id": "scaffold_417",
  "regions": []
 },
 {
  "length": 6841,
  "seq_id": "scaffold_418",
  "regions": []
 },
 {
  "length": 6821,
  "seq_id": "scaffold_419",
  "regions": []
 },
 {
  "length": 6807,
  "seq_id": "scaffold_420",
  "regions": []
 },
 {
  "length": 6791,
  "seq_id": "scaffold_421",
  "regions": []
 },
 {
  "length": 6785,
  "seq_id": "scaffold_422",
  "regions": []
 },
 {
  "length": 6776,
  "seq_id": "scaffold_423",
  "regions": []
 },
 {
  "length": 6752,
  "seq_id": "scaffold_424",
  "regions": []
 },
 {
  "length": 6750,
  "seq_id": "scaffold_425",
  "regions": []
 },
 {
  "length": 6730,
  "seq_id": "scaffold_426",
  "regions": []
 },
 {
  "length": 6694,
  "seq_id": "scaffold_427",
  "regions": []
 },
 {
  "length": 6694,
  "seq_id": "scaffold_428",
  "regions": []
 },
 {
  "length": 6689,
  "seq_id": "scaffold_429",
  "regions": []
 },
 {
  "length": 6675,
  "seq_id": "scaffold_430",
  "regions": []
 },
 {
  "length": 6666,
  "seq_id": "scaffold_431",
  "regions": []
 },
 {
  "length": 6652,
  "seq_id": "scaffold_432",
  "regions": []
 },
 {
  "length": 6622,
  "seq_id": "scaffold_433",
  "regions": []
 },
 {
  "length": 6616,
  "seq_id": "scaffold_434",
  "regions": []
 },
 {
  "length": 6612,
  "seq_id": "scaffold_435",
  "regions": []
 },
 {
  "length": 6598,
  "seq_id": "scaffold_436",
  "regions": []
 },
 {
  "length": 6594,
  "seq_id": "scaffold_437",
  "regions": []
 },
 {
  "length": 6574,
  "seq_id": "scaffold_438",
  "regions": []
 },
 {
  "length": 6568,
  "seq_id": "scaffold_439",
  "regions": []
 },
 {
  "length": 6552,
  "seq_id": "scaffold_440",
  "regions": []
 },
 {
  "length": 6506,
  "seq_id": "scaffold_441",
  "regions": []
 },
 {
  "length": 6503,
  "seq_id": "scaffold_442",
  "regions": []
 },
 {
  "length": 6499,
  "seq_id": "scaffold_443",
  "regions": []
 },
 {
  "length": 6497,
  "seq_id": "scaffold_444",
  "regions": []
 },
 {
  "length": 6488,
  "seq_id": "scaffold_445",
  "regions": []
 },
 {
  "length": 6486,
  "seq_id": "scaffold_446",
  "regions": []
 },
 {
  "length": 6473,
  "seq_id": "scaffold_447",
  "regions": []
 },
 {
  "length": 6464,
  "seq_id": "scaffold_448",
  "regions": []
 },
 {
  "length": 6457,
  "seq_id": "scaffold_449",
  "regions": []
 },
 {
  "length": 6400,
  "seq_id": "scaffold_450",
  "regions": []
 },
 {
  "length": 6399,
  "seq_id": "scaffold_451",
  "regions": []
 },
 {
  "length": 6395,
  "seq_id": "scaffold_452",
  "regions": []
 },
 {
  "length": 6392,
  "seq_id": "scaffold_453",
  "regions": []
 },
 {
  "length": 6377,
  "seq_id": "scaffold_454",
  "regions": []
 },
 {
  "length": 6359,
  "seq_id": "scaffold_455",
  "regions": []
 },
 {
  "length": 6346,
  "seq_id": "scaffold_456",
  "regions": []
 },
 {
  "length": 6335,
  "seq_id": "scaffold_457",
  "regions": []
 },
 {
  "length": 6289,
  "seq_id": "scaffold_458",
  "regions": []
 },
 {
  "length": 6287,
  "seq_id": "scaffold_459",
  "regions": []
 },
 {
  "length": 6280,
  "seq_id": "scaffold_460",
  "regions": []
 },
 {
  "length": 6254,
  "seq_id": "scaffold_461",
  "regions": []
 },
 {
  "length": 6240,
  "seq_id": "scaffold_462",
  "regions": []
 },
 {
  "length": 6225,
  "seq_id": "scaffold_463",
  "regions": []
 },
 {
  "length": 6222,
  "seq_id": "scaffold_464",
  "regions": []
 },
 {
  "length": 6193,
  "seq_id": "scaffold_465",
  "regions": []
 },
 {
  "length": 6177,
  "seq_id": "scaffold_466",
  "regions": []
 },
 {
  "length": 6170,
  "seq_id": "scaffold_467",
  "regions": []
 },
 {
  "length": 6160,
  "seq_id": "scaffold_468",
  "regions": []
 },
 {
  "length": 6158,
  "seq_id": "scaffold_469",
  "regions": []
 },
 {
  "length": 6156,
  "seq_id": "scaffold_470",
  "regions": []
 },
 {
  "length": 6150,
  "seq_id": "scaffold_471",
  "regions": []
 },
 {
  "length": 6142,
  "seq_id": "scaffold_472",
  "regions": []
 },
 {
  "length": 6128,
  "seq_id": "scaffold_473",
  "regions": []
 },
 {
  "length": 6115,
  "seq_id": "scaffold_474",
  "regions": []
 },
 {
  "length": 6110,
  "seq_id": "scaffold_475",
  "regions": []
 },
 {
  "length": 6087,
  "seq_id": "scaffold_476",
  "regions": []
 },
 {
  "length": 6081,
  "seq_id": "scaffold_477",
  "regions": []
 },
 {
  "length": 6074,
  "seq_id": "scaffold_478",
  "regions": []
 },
 {
  "length": 6051,
  "seq_id": "scaffold_479",
  "regions": []
 },
 {
  "length": 6044,
  "seq_id": "scaffold_480",
  "regions": []
 },
 {
  "length": 6032,
  "seq_id": "scaffold_481",
  "regions": []
 },
 {
  "length": 5987,
  "seq_id": "scaffold_482",
  "regions": []
 },
 {
  "length": 5961,
  "seq_id": "scaffold_483",
  "regions": []
 },
 {
  "length": 5917,
  "seq_id": "scaffold_484",
  "regions": []
 },
 {
  "length": 5875,
  "seq_id": "scaffold_485",
  "regions": []
 },
 {
  "length": 5866,
  "seq_id": "scaffold_486",
  "regions": []
 },
 {
  "length": 5858,
  "seq_id": "scaffold_487",
  "regions": []
 },
 {
  "length": 5816,
  "seq_id": "scaffold_488",
  "regions": []
 },
 {
  "length": 5804,
  "seq_id": "scaffold_489",
  "regions": []
 },
 {
  "length": 5743,
  "seq_id": "scaffold_490",
  "regions": []
 },
 {
  "length": 5669,
  "seq_id": "scaffold_491",
  "regions": []
 },
 {
  "length": 5638,
  "seq_id": "scaffold_492",
  "regions": []
 },
 {
  "length": 5630,
  "seq_id": "scaffold_493",
  "regions": []
 },
 {
  "length": 5620,
  "seq_id": "scaffold_494",
  "regions": []
 },
 {
  "length": 5616,
  "seq_id": "scaffold_495",
  "regions": []
 },
 {
  "length": 5615,
  "seq_id": "scaffold_496",
  "regions": []
 },
 {
  "length": 5614,
  "seq_id": "scaffold_497",
  "regions": []
 },
 {
  "length": 5602,
  "seq_id": "scaffold_498",
  "regions": []
 },
 {
  "length": 5594,
  "seq_id": "scaffold_499",
  "regions": []
 },
 {
  "length": 5588,
  "seq_id": "scaffold_500",
  "regions": []
 },
 {
  "length": 5570,
  "seq_id": "scaffold_501",
  "regions": []
 },
 {
  "length": 5535,
  "seq_id": "scaffold_502",
  "regions": []
 },
 {
  "length": 5512,
  "seq_id": "scaffold_503",
  "regions": []
 },
 {
  "length": 5497,
  "seq_id": "scaffold_504",
  "regions": []
 },
 {
  "length": 5496,
  "seq_id": "scaffold_505",
  "regions": []
 },
 {
  "length": 5442,
  "seq_id": "scaffold_506",
  "regions": []
 },
 {
  "length": 5411,
  "seq_id": "scaffold_507",
  "regions": []
 },
 {
  "length": 5407,
  "seq_id": "scaffold_508",
  "regions": []
 },
 {
  "length": 5357,
  "seq_id": "scaffold_509",
  "regions": []
 },
 {
  "length": 5354,
  "seq_id": "scaffold_510",
  "regions": []
 },
 {
  "length": 5351,
  "seq_id": "scaffold_511",
  "regions": []
 },
 {
  "length": 5335,
  "seq_id": "scaffold_512",
  "regions": []
 },
 {
  "length": 5320,
  "seq_id": "scaffold_513",
  "regions": []
 },
 {
  "length": 5303,
  "seq_id": "scaffold_514",
  "regions": []
 },
 {
  "length": 5249,
  "seq_id": "scaffold_515",
  "regions": []
 },
 {
  "length": 5243,
  "seq_id": "scaffold_516",
  "regions": []
 },
 {
  "length": 5215,
  "seq_id": "scaffold_517",
  "regions": []
 },
 {
  "length": 5198,
  "seq_id": "scaffold_518",
  "regions": []
 },
 {
  "length": 5192,
  "seq_id": "scaffold_519",
  "regions": []
 },
 {
  "length": 5185,
  "seq_id": "scaffold_520",
  "regions": []
 },
 {
  "length": 5176,
  "seq_id": "scaffold_521",
  "regions": []
 },
 {
  "length": 5169,
  "seq_id": "scaffold_522",
  "regions": []
 },
 {
  "length": 5163,
  "seq_id": "scaffold_523",
  "regions": []
 },
 {
  "length": 5155,
  "seq_id": "scaffold_524",
  "regions": []
 },
 {
  "length": 5144,
  "seq_id": "scaffold_525",
  "regions": []
 },
 {
  "length": 5120,
  "seq_id": "scaffold_526",
  "regions": []
 },
 {
  "length": 5118,
  "seq_id": "scaffold_527",
  "regions": []
 },
 {
  "length": 5108,
  "seq_id": "scaffold_528",
  "regions": []
 },
 {
  "length": 5102,
  "seq_id": "scaffold_529",
  "regions": []
 },
 {
  "length": 5091,
  "seq_id": "scaffold_530",
  "regions": []
 },
 {
  "length": 5069,
  "seq_id": "scaffold_531",
  "regions": []
 },
 {
  "length": 5064,
  "seq_id": "scaffold_532",
  "regions": []
 },
 {
  "length": 5062,
  "seq_id": "scaffold_533",
  "regions": []
 },
 {
  "length": 5060,
  "seq_id": "scaffold_534",
  "regions": []
 },
 {
  "length": 5030,
  "seq_id": "scaffold_535",
  "regions": []
 },
 {
  "length": 5015,
  "seq_id": "scaffold_536",
  "regions": []
 },
 {
  "length": 4991,
  "seq_id": "scaffold_537",
  "regions": []
 },
 {
  "length": 4982,
  "seq_id": "scaffold_538",
  "regions": []
 },
 {
  "length": 4972,
  "seq_id": "scaffold_539",
  "regions": []
 },
 {
  "length": 4958,
  "seq_id": "scaffold_540",
  "regions": []
 },
 {
  "length": 4957,
  "seq_id": "scaffold_541",
  "regions": []
 },
 {
  "length": 4938,
  "seq_id": "scaffold_542",
  "regions": []
 },
 {
  "length": 4935,
  "seq_id": "scaffold_543",
  "regions": []
 },
 {
  "length": 4928,
  "seq_id": "scaffold_544",
  "regions": []
 },
 {
  "length": 4912,
  "seq_id": "scaffold_545",
  "regions": []
 },
 {
  "length": 4905,
  "seq_id": "scaffold_546",
  "regions": []
 },
 {
  "length": 4846,
  "seq_id": "scaffold_547",
  "regions": []
 },
 {
  "length": 4811,
  "seq_id": "scaffold_548",
  "regions": []
 },
 {
  "length": 4806,
  "seq_id": "scaffold_549",
  "regions": []
 },
 {
  "length": 4794,
  "seq_id": "scaffold_550",
  "regions": []
 },
 {
  "length": 4767,
  "seq_id": "scaffold_551",
  "regions": []
 },
 {
  "length": 4765,
  "seq_id": "scaffold_552",
  "regions": []
 },
 {
  "length": 4765,
  "seq_id": "scaffold_553",
  "regions": []
 },
 {
  "length": 4743,
  "seq_id": "scaffold_554",
  "regions": []
 },
 {
  "length": 4738,
  "seq_id": "scaffold_555",
  "regions": []
 },
 {
  "length": 4733,
  "seq_id": "scaffold_556",
  "regions": []
 },
 {
  "length": 4724,
  "seq_id": "scaffold_557",
  "regions": []
 },
 {
  "length": 4724,
  "seq_id": "scaffold_558",
  "regions": []
 },
 {
  "length": 4719,
  "seq_id": "scaffold_559",
  "regions": []
 },
 {
  "length": 4701,
  "seq_id": "scaffold_560",
  "regions": []
 },
 {
  "length": 4692,
  "seq_id": "scaffold_561",
  "regions": []
 },
 {
  "length": 4684,
  "seq_id": "scaffold_562",
  "regions": []
 },
 {
  "length": 4676,
  "seq_id": "scaffold_563",
  "regions": []
 },
 {
  "length": 4648,
  "seq_id": "scaffold_564",
  "regions": []
 },
 {
  "length": 4648,
  "seq_id": "scaffold_565",
  "regions": [
   {
    "start": 1,
    "end": 4648,
    "idx": 1,
    "orfs": [
     {
      "start": 282,
      "end": 1745,
      "strand": 1,
      "locus_tag": "MARS9BIN1_003810",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_003810</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_003810</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_003810-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 282 - 1,745,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_003810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_003810 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_003810\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_003810-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
      "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
      "product": "hypothetical protein"
     },
     {
      "start": 1923,
      "end": 4541,
      "strand": 1,
      "locus_tag": "MARS9BIN1_003811",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_003811</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_003811</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_003811-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,923 - 4,541,\n (total: 2619 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.7; E-value: 2.9e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_003811 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 126.3, e-value: 1.3e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 32.0, e-value: 1.3e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:867](score: 134.6, e-value: 3.6e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_003811\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_003811-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGAAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCT",
      "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLP",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 1922,
      "end": 4541,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 4648,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r565c1"
   }
  ]
 },
 {
  "length": 4646,
  "seq_id": "scaffold_566",
  "regions": []
 },
 {
  "length": 4636,
  "seq_id": "scaffold_567",
  "regions": []
 },
 {
  "length": 4632,
  "seq_id": "scaffold_568",
  "regions": []
 },
 {
  "length": 4625,
  "seq_id": "scaffold_569",
  "regions": []
 },
 {
  "length": 4600,
  "seq_id": "scaffold_570",
  "regions": []
 },
 {
  "length": 4598,
  "seq_id": "scaffold_571",
  "regions": []
 },
 {
  "length": 4563,
  "seq_id": "scaffold_572",
  "regions": []
 },
 {
  "length": 4552,
  "seq_id": "scaffold_573",
  "regions": []
 },
 {
  "length": 4544,
  "seq_id": "scaffold_574",
  "regions": []
 },
 {
  "length": 4534,
  "seq_id": "scaffold_575",
  "regions": []
 },
 {
  "length": 4529,
  "seq_id": "scaffold_576",
  "regions": []
 },
 {
  "length": 4486,
  "seq_id": "scaffold_577",
  "regions": []
 },
 {
  "length": 4471,
  "seq_id": "scaffold_578",
  "regions": []
 },
 {
  "length": 4443,
  "seq_id": "scaffold_579",
  "regions": []
 },
 {
  "length": 4389,
  "seq_id": "scaffold_580",
  "regions": []
 },
 {
  "length": 4358,
  "seq_id": "scaffold_581",
  "regions": []
 },
 {
  "length": 4351,
  "seq_id": "scaffold_582",
  "regions": []
 },
 {
  "length": 4344,
  "seq_id": "scaffold_583",
  "regions": []
 },
 {
  "length": 4317,
  "seq_id": "scaffold_584",
  "regions": []
 },
 {
  "length": 4265,
  "seq_id": "scaffold_585",
  "regions": []
 },
 {
  "length": 4261,
  "seq_id": "scaffold_586",
  "regions": []
 },
 {
  "length": 4223,
  "seq_id": "scaffold_587",
  "regions": []
 },
 {
  "length": 4220,
  "seq_id": "scaffold_588",
  "regions": []
 },
 {
  "length": 4206,
  "seq_id": "scaffold_589",
  "regions": []
 },
 {
  "length": 4186,
  "seq_id": "scaffold_590",
  "regions": []
 },
 {
  "length": 4182,
  "seq_id": "scaffold_591",
  "regions": []
 },
 {
  "length": 4170,
  "seq_id": "scaffold_592",
  "regions": []
 },
 {
  "length": 4168,
  "seq_id": "scaffold_593",
  "regions": []
 },
 {
  "length": 4152,
  "seq_id": "scaffold_594",
  "regions": []
 },
 {
  "length": 4143,
  "seq_id": "scaffold_595",
  "regions": []
 },
 {
  "length": 4117,
  "seq_id": "scaffold_596",
  "regions": []
 },
 {
  "length": 4103,
  "seq_id": "scaffold_597",
  "regions": []
 },
 {
  "length": 4069,
  "seq_id": "scaffold_598",
  "regions": []
 },
 {
  "length": 4066,
  "seq_id": "scaffold_599",
  "regions": []
 },
 {
  "length": 4063,
  "seq_id": "scaffold_600",
  "regions": []
 },
 {
  "length": 4042,
  "seq_id": "scaffold_601",
  "regions": []
 },
 {
  "length": 4033,
  "seq_id": "scaffold_602",
  "regions": []
 },
 {
  "length": 4018,
  "seq_id": "scaffold_603",
  "regions": []
 },
 {
  "length": 3995,
  "seq_id": "scaffold_604",
  "regions": []
 },
 {
  "length": 3980,
  "seq_id": "scaffold_605",
  "regions": []
 },
 {
  "length": 3966,
  "seq_id": "scaffold_606",
  "regions": []
 },
 {
  "length": 3963,
  "seq_id": "scaffold_607",
  "regions": []
 },
 {
  "length": 3960,
  "seq_id": "scaffold_608",
  "regions": []
 },
 {
  "length": 3930,
  "seq_id": "scaffold_609",
  "regions": []
 },
 {
  "length": 3877,
  "seq_id": "scaffold_610",
  "regions": []
 },
 {
  "length": 3860,
  "seq_id": "scaffold_611",
  "regions": []
 },
 {
  "length": 3822,
  "seq_id": "scaffold_612",
  "regions": []
 },
 {
  "length": 3815,
  "seq_id": "scaffold_613",
  "regions": []
 },
 {
  "length": 3786,
  "seq_id": "scaffold_614",
  "regions": []
 },
 {
  "length": 3775,
  "seq_id": "scaffold_615",
  "regions": []
 },
 {
  "length": 3762,
  "seq_id": "scaffold_616",
  "regions": []
 },
 {
  "length": 3746,
  "seq_id": "scaffold_617",
  "regions": []
 },
 {
  "length": 3732,
  "seq_id": "scaffold_618",
  "regions": []
 },
 {
  "length": 3704,
  "seq_id": "scaffold_619",
  "regions": []
 },
 {
  "length": 3691,
  "seq_id": "scaffold_620",
  "regions": []
 },
 {
  "length": 3674,
  "seq_id": "scaffold_621",
  "regions": []
 },
 {
  "length": 3664,
  "seq_id": "scaffold_622",
  "regions": []
 },
 {
  "length": 3633,
  "seq_id": "scaffold_623",
  "regions": []
 },
 {
  "length": 3625,
  "seq_id": "scaffold_624",
  "regions": []
 },
 {
  "length": 3575,
  "seq_id": "scaffold_625",
  "regions": []
 },
 {
  "length": 3546,
  "seq_id": "scaffold_626",
  "regions": []
 },
 {
  "length": 3488,
  "seq_id": "scaffold_627",
  "regions": []
 },
 {
  "length": 3468,
  "seq_id": "scaffold_628",
  "regions": []
 },
 {
  "length": 3422,
  "seq_id": "scaffold_629",
  "regions": []
 },
 {
  "length": 3397,
  "seq_id": "scaffold_630",
  "regions": []
 },
 {
  "length": 3396,
  "seq_id": "scaffold_631",
  "regions": []
 },
 {
  "length": 3384,
  "seq_id": "scaffold_632",
  "regions": []
 },
 {
  "length": 3376,
  "seq_id": "scaffold_633",
  "regions": []
 },
 {
  "length": 3373,
  "seq_id": "scaffold_634",
  "regions": []
 },
 {
  "length": 3294,
  "seq_id": "scaffold_635",
  "regions": []
 },
 {
  "length": 3280,
  "seq_id": "scaffold_636",
  "regions": []
 },
 {
  "length": 3154,
  "seq_id": "scaffold_637",
  "regions": []
 },
 {
  "length": 3148,
  "seq_id": "scaffold_638",
  "regions": []
 },
 {
  "length": 3131,
  "seq_id": "scaffold_639",
  "regions": []
 },
 {
  "length": 3117,
  "seq_id": "scaffold_640",
  "regions": []
 },
 {
  "length": 2975,
  "seq_id": "scaffold_641",
  "regions": []
 },
 {
  "length": 2971,
  "seq_id": "scaffold_642",
  "regions": []
 },
 {
  "length": 2929,
  "seq_id": "scaffold_643",
  "regions": []
 },
 {
  "length": 2870,
  "seq_id": "scaffold_644",
  "regions": []
 },
 {
  "length": 2813,
  "seq_id": "scaffold_645",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r49c1",
  "r140c1",
  "r565c1"
 ],
 "r49c1": {
  "start": 118,
  "end": 26174,
  "idx": 1,
  "orfs": [
   {
    "start": 219,
    "end": 1072,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000881",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000881</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000881</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000881-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 219 - 1,072,\n (total: 820 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000881 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02487.20 (CLN3 protein): [10:273](score: 314.7, e-value: 9.8e-94)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000881 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02487.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000881\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCTCCCCAGTGTTCCGAACGAGTCTTGCATTTTGGCTTTTTGGATTAATCAACAATGTTCTCTATGTAGTCATACTCACTGCCGCTGTGGATCTCGTCAATACGCTGCCCAAGGCAATTGTTCTGCTGGCCGACATCATGCCATCCTTTGCAGTGAAGTTATTGGCGCCATTTGTAATACACCTAATTCCCTACCGCCTACGGATCCTGGTATTCACGTGCTTGTCGATCACTGGAATGCAAATTATTGCCTGGTCTGGCGGGATACCGATGCGGTTGCTTGGTATCATATTGGCTTCAGCGAGTGCGGGTGGAGGAGAACTATCATTTCTGCAACTAACGCACTTCTACGGACCAAGATCTCTTCCTTTCTTCAGCAGTGGCACGGGCGCTGCCGGGTTGGTTGGAGCAGGTTTATTCTCATTCATGACGGTCTTTATTGGATTGAGCGTAAGACGGAGCTTGCTTCTATTGAGTTTCCTACCCGTCATCATGACAATTACCTTTTTTGTCATTTTACCAAAGCATGATTTCAATTTCCAAACGGAGTACGATCCGTTGGAAAGACAGGAACAGGGACCAGTGGCCGAGCCTACGCTTATGCCAAATCACAACCAGTCTTTGCTCAGGACCCTAAAATCAAACATGAACCGAGCAAAGTACTTATTTGTTCCTTTTATGTTGCCATTAGCCCTGGTGTATTTTGCAGAGTATGAGATAAATCAGGGCGTTGCACCCACGCTTCTTTATCCCTTACAAGACACCCCGTTTAACTCATACCGAGACATGTATCCAATGTACTCAACTCTATATCAAG",
    "translation": "MTSPVFRTSLAFWLFGLINNVLYVVILTAAVDLVNTLPKAIVLLADIMPSFAVKLLAPFVIHLIPYRLRILVFTCLSITGMQIIAWSGGIPMRLLGIILASASAGGGELSFLQLTHFYGPRSLPFFSSGTGAAGLVGAGLFSFMTVFIGLSVRRSLLLLSFLPVIMTITFFVILPKHDFNFQTEYDPLERQEQGPVAEPTLMPNHNQSLLRTLKSNMNRAKYLFVPFMLPLALVYFAEYEINQGVAPTLLYPLQDTPFNSYRDMYPMYSTLYQ",
    "product": "hypothetical protein"
   },
   {
    "start": 1334,
    "end": 3001,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000882",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000882</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000882</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000882-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,334 - 3,001,\n (total: 1668 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000882 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF09329.14 (Primase zinc finger): [336:382](score: 59.9, e-value: 1.6e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000882 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF09329.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication<br>\n  \n   PF09329.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005634' target='_blank'>GO:0005634</a>: nucleus<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000882\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000882\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGCGCAGCCTGGTGAGTGGCCGCCAGTGTCGCCTGCAAAGGCCAGACTGCTCGTGTCCCCGGGCACGCTGAAGCGGAAGCAGCACGATCGTAGCAGTGAGTCAGGGTCTGAAGATGAGGAAACACTGCAGCTCAAACTGGCTCACATTGAAGCACGCCTGAAGCTGAAGCAAGTACAGAAGAAGAAAAGGAAAACAGCTGAAGATATTCCGGCTGAGGCCACAAAAACTCCGTCCAAGCCGAGTCCACCCGCAACGGAGCCCTCAAATCTCCAAATCTCGCCGAGCAGGGTACAGCTTGGGGTGGATAAGGGAATGACGGCCAAAGATGTTTCTTTGCGTAGGCCATATGGCCAATCGACTCCTGAGAAGCCTACCAAGACCTTTGCCCAACGGCTTGCTGAATTACGGGCTGGTGACAAGGACGAACAAACGCGGAGAGACAAAGTGCTGATGCAAAGGTCAAAGGCGTTTGCGCCGCTTCCTTTCAGAGCAGATGCTCCGAAAGGCGGGCTTGATGCCACAATCCCTACATCTCAGATCTCAAGCCAGCCTCAGGTACGGTCGATATCTGCTCATTCTGAACTATACGACGCCTACTCTGGGTTCAAAATGACCAATCGCCTACTACCTCACTCAGCACTTTCGCATCATTTTGCTGGGAAAAAGATTTACGATCTCGTCTCCATACTGAAAGAGATTGTCCCTCCAACCTACGATCCCCCAGAGGTTGCCGATTGGGTCTTACTCGGCATAATAGCACACAAGTCCGAAGCGCGTGAGGCAAAGAGAAAAGACGGCAACAAGTACTTGGTGCTCACGATTACCGACTTGAACTACGAAATCACCTTGTTCCTTTTCGGTGATGCGTTTCAGAAGTTCTGGAAGTTACAATTGGGTCATATAATTGGTATACTCAATCCAACAGTCATGAAGCCCCAGAGTAAAGACAGCACGAAATGGTGTGTAAAGGTTTCAGAAGCACAAGACGTTATTCTTGATATCGGTAGAGCCAAAGACTTGCAATTTTGCCAAAGCTTAAAAAAGGACGGTACACAATGCGGCCAATGGGTTGATGGACGCCGAACCGAGTACTGCGAATACCATGTTTCACAAGACTTAAAAAGATATAAAAGCCGAAGGACCGAGGTTGCTATCGGCACGAAAGGCTATTCTCCCAAGAAGAAAAGTGTCCACTTTGTATCAAATGAAGTGCCTGGTCGAGGACATGAGCCGTCGCATAATGCGCAAGAAGCCTACTCGGGCACGTTACGCGACGACGACAATCTCTCGAATGTACAAATACGCGAGCATATTGCGCGGCATAACATGGTTCGCGAGAAAGAGCGACAGGTTTCCGCAAAGATTGTGGGAACGAGTGGTGGAGGTATTGGGGAAGAATACCTACGGAAATCCTACGAAATGACTCCACCGGAAGCAGTAAAACCATGCATTGACGATGGCAAGAATCCCTTCTCTGCCAACGTACTTCGGCGCATTGGCTTCGATCCTACAAAACGCGTCGAAAAGTCGAAAGTTATCCAAGAGTCATTGGGCATAACCGGGGACCGGACTGAGGCGCGACTCAGCCCAGTGAAAAATCGCGCCGTTTCTCAACAAAACAAAGTGTCAAGTGGCGACCAAGAGCTGGAGATCATAATGTAG",
    "translation": "MTAQPGEWPPVSPAKARLLVSPGTLKRKQHDRSSESGSEDEETLQLKLAHIEARLKLKQVQKKKRKTAEDIPAEATKTPSKPSPPATEPSNLQISPSRVQLGVDKGMTAKDVSLRRPYGQSTPEKPTKTFAQRLAELRAGDKDEQTRRDKVLMQRSKAFAPLPFRADAPKGGLDATIPTSQISSQPQVRSISAHSELYDAYSGFKMTNRLLPHSALSHHFAGKKIYDLVSILKEIVPPTYDPPEVADWVLLGIIAHKSEAREAKRKDGNKYLVLTITDLNYEITLFLFGDAFQKFWKLQLGHIIGILNPTVMKPQSKDSTKWCVKVSEAQDVILDIGRAKDLQFCQSLKKDGTQCGQWVDGRRTEYCEYHVSQDLKRYKSRRTEVAIGTKGYSPKKKSVHFVSNEVPGRGHEPSHNAQEAYSGTLRDDDNLSNVQIREHIARHNMVREKERQVSAKIVGTSGGGIGEEYLRKSYEMTPPEAVKPCIDDGKNPFSANVLRRIGFDPTKRVEKSKVIQESLGITGDRTEARLSPVKNRAVSQQNKVSSGDQELEIIM",
    "product": "hypothetical protein"
   },
   {
    "start": 3707,
    "end": 6387,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000883",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000883</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000883</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000883-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,707 - 6,387,\n (total: 2388 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000883 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08642.13 (Histone deacetylation protein Rxt3): [54:94](score: 38.6, e-value: 1.7e-09)<br>\n \n  PF03343.16 (SART-1 family): [304:774](score: 321.9, e-value: 9e-96)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000883 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03343.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000398' target='_blank'>GO:0000398</a>: mRNA splicing, via spliceosome<br>\n  \n   PF08642.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016575' target='_blank'>GO:0016575</a>: histone deacetylation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000883\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000883\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTCCTCTCCCTGATCACAAGCCAGAACTCATTGTTCACAGTGGGAGGGCTTTTGATGCTCTCCAGGATATGAAGAGTGTACATCTAGGAAGCCACGTCTACGAAGGTCAACTTGTTTCATTACCTCGTTTAGCGGGTCGAGAAAATGCACTTATCTCCATACGAATTCCGGAGCGTTTTGTTGAGCAATCAGATGCAATGGATAAGAGACGTATATGGGGTACTGACATCTACACTGACGACTCTGACCCCGTTTGTATCCTCAAACATATAGGCAAAAGGCCTGAGCGACCTCGTCAGGATGTGATTATCACATTTCGGGTGCTGCCTCCTTTAGTGGAGTACAAGGGTAGTCTACGTCACCAGATGAAGACTCGTACATGGAACGTTCAGCATGATGGGATGAGTATAATGGTAGAGAATGTGGACTTTGTCACCGTCGGGATAGCTGAGGAAAGAGGTGGTGAAATGGCGAAAAAACGCATTCGTGATTACATTGAGCTGAGCGGCCGCGGGCTGCATCCACAATGGAAGCCAACGCTTGAAAAACGGAGCAAGCTAGCCGTGCCAAGTACCGCACAAGAGCAAAATAAAGTGGAAAAGAGTTCGGGTTCTGAAGGTGAGCATAAGCAAAACTCCAATGGATCAAAATCTCCACCGAAAAGGCCTTCAAAATCCTCTAATGCTGTGGAGACTATAAAACAGACTGACGACAAAGAAGCCGAAGAAACCAGAGCCATCGATACGGCCTTGACTGAGGCACATGATGGTGCCAAAGCTGAAACAAATGACAAGGCAAAGTTTCGTACGATCGACAAGGGGGATGCGCATGATATGTCAATGCACGATGCACCACCAGCATCCTCCGACGATGATTCCCTCGACGCTGCAAAGGAGAACGCGGCCGTCTTAGCACGGATAGAGAAGACAAAGAAAAAGGCCGCAAGATTTGAGCGGCTCGAAGGTCGTGGGCTTGCTGATGACGATGATGAAGAGACAGACGCCCGTCAGTGGGTATTTAAAACCAAGAAAATCAAGAAGAGAAAGCTAGATGAGACGCCAGAGGAGCTTCATTCGACTTACAACGAGGAAAGCCTGTCAGGGCTTAGAGTTGGTCACGATATTGGAGATTTCGACACGAATGCCACCATTCTAACGTTGAAGGACGCCTCAGTCTTGGAGGACCAGGAAGAGGATCAATTAGAGTCTTTGAAACTAGTAGAAAAAGAGCGCACCCAAAAGAACTTGAACAGGAAGAACAAAACGAAATCTGGCGACACGACCGAGCAAGATGGCAAAGGCATTTTGTCGAAATACGACGAAGAAGAGGAGCCCAAGTTTATGGTTCTTGGTGAAACGGCTTTGGAGAGAGAAGTGGTGGAAGATAGGCGTGGTACAGCTATTTCTCTTGACGTGGAGCGGGTAGCAGAATCTTCCGACTACATGGACACTACAATTAGAAAGTCGAAAAAGAAACGTCCCAAAAGCATACGAGTCAAAGAAGGGGCGGAAGGCGATGACATTTCTTTCAAGCCTCAAATGCTTACTAATAGGGAAGAGTCGAATATTGCTGACGATGAAGAATTGCAGGCGGCTCTTTCACGGCAGCGTCGGATAGCTCAGAAGCGCCATGCGTCGATTGTCCGGCCGGTGAAAGACATTGAAGCCTACAACGAAGATCTCTATGATGGTGGTATGGTATTTGATGAAGCCACGGGATTTCTCTCTGGGATCAGACCTGTCGAGAAAGCTGCTTACGCAGTCAAAGAAGAGCCGTTAGACAGAGTAGACATTAAGATGGAAATCAAGCAGGATCCCAATGAACTGCTACTCGATAAGACAAGTGAAGATGGAGAAGATCTCATTGAAGAGCCTGGGATGGGTCATGGGCTTGGTGCTGCACTCAAGATGCTTCAGCAGCGTGGAGTTGTTGACAGAGCCAGCGAAGAGACGACGCAAAAGCTGGAGCAGCAGCGGCAAAATATGGCGTGGCTGGCAGAGAAGCGCCGTAAAGATGCTCTGCGCGAGGCACAACTCCGTCGCGAAAAAATCGAAGGGCGCGAAAAGATGAAGAACATGAGTGCTCGCGAGCGTGAGCGTACGTTGGAGGAAGAGAACCGGCGGCGCACAAAGCACGAAGCGGCAGCAGAGTTTGACAAGTTCAAGGAGTTTAAGCCGGATGTGCATCTTCACTACAAGGATGAGTTTGGGAGAGATATGACGCCAAAAGAGGCCTTTCGGCAAATGTCCCACCAGTTTCATGGCAAAGGCAGTGGCGTGATCAAGAGTGAGAAGCGCCTCAAACGGATTCAAGAGGAACAGGAACGCGAAAAGCAAGCAATGGCAAGTGGAGTCTTTGCTTCCTCTGGCGTTCGGTTATCTTGA",
    "translation": "MTPLPDHKPELIVHSGRAFDALQDMKSVHLGSHVYEGQLVSLPRLAGRENALISIRIPERFVEQSDAMDKRRIWGTDIYTDDSDPVCILKHIGKRPERPRQDVIITFRVLPPLVEYKGSLRHQMKTRTWNVQHDGMSIMVENVDFVTVGIAEERGGEMAKKRIRDYIELSGRGLHPQWKPTLEKRSKLAVPSTAQEQNKVEKSSGSEGEHKQNSNGSKSPPKRPSKSSNAVETIKQTDDKEAEETRAIDTALTEAHDGAKAETNDKAKFRTIDKGDAHDMSMHDAPPASSDDDSLDAAKENAAVLARIEKTKKKAARFERLEGRGLADDDDEETDARQWVFKTKKIKKRKLDETPEELHSTYNEESLSGLRVGHDIGDFDTNATILTLKDASVLEDQEEDQLESLKLVEKERTQKNLNRKNKTKSGDTTEQDGKGILSKYDEEEEPKFMVLGETALEREVVEDRRGTAISLDVERVAESSDYMDTTIRKSKKKRPKSIRVKEGAEGDDISFKPQMLTNREESNIADDEELQAALSRQRRIAQKRHASIVRPVKDIEAYNEDLYDGGMVFDEATGFLSGIRPVEKAAYAVKEEPLDRVDIKMEIKQDPNELLLDKTSEDGEDLIEEPGMGHGLGAALKMLQQRGVVDRASEETTQKLEQQRQNMAWLAEKRRKDALREAQLRREKIEGREKMKNMSARERERTLEEENRRRTKHEAAAEFDKFKEFKPDVHLHYKDEFGRDMTPKEAFRQMSHQFHGKGSGVIKSEKRLKRIQEEQEREKQAMASGVFASSGVRLS",
    "product": "hypothetical protein"
   },
   {
    "start": 6425,
    "end": 6949,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000884",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000884</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000884</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000884-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,425 - 6,949,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01981.19 (Peptidyl-tRNA hydrolase PTH2): [59:174](score: 148.6, e-value: 9.3e-44)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00283 (arch_pth2: peptidyl-tRNA hydrolase): [60:174](score: 128.3, e-value: 3.7e-38)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000884 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01981.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004045' target='_blank'>GO:0004045</a>: aminoacyl-tRNA hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000884\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000884\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTACGGCGACAAGCGCCGGGATCGCAGGGATCCTAATTGGCGCCTGTCTGGGCTTCTACGGGGCACTTGGGGCCTCTCTGCCCATCTCAAGAGGCAACGCCGCGCTAGACGTGGACTCGGACTGCGAAGGGAGCAGTGAGAAGGATGGGGGTGGACTGCTTCCCGACGAGGAGTACAAGATGGTGCTTGTGGTCAGGACGGATCTCAAGATGAGTCGAGGCAAGGCAGGTGCTCAGTGCGCACATGCGGCAGTGGCCTGCTACAAAGCTGCTGCAAAGCGCAATCAACCACTACTGGCCGCCTGGGAGAACTGTGGACAGCCGAAGATCTGCCTGCAGACGAGCTCCGAGGAAGATTTAGCCACGTTGTACGCGTCAGCCATGTCCCTAAGACTCACAGCCAAGACAATTCAAGATGCGGGGCGCACGGAAGTACCAGCCGGGTCGACAACAGTCCTTGGAATCGGACCGGCTCCAGTCAGTCAAATTAATATCGTCACGGGTCATCTGAAGTTGTTCTGA",
    "translation": "MATATSAGIAGILIGACLGFYGALGASLPISRGNAALDVDSDCEGSSEKDGGGLLPDEEYKMVLVVRTDLKMSRGKAGAQCAHAAVACYKAAAKRNQPLLAAWENCGQPKICLQTSSEEDLATLYASAMSLRLTAKTIQDAGRTEVPAGSTTVLGIGPAPVSQINIVTGHLKLF",
    "product": "hypothetical protein"
   },
   {
    "start": 6986,
    "end": 8266,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000885",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000885</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000885</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000885-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,986 - 8,266,\n (total: 1281 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_1_2<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000885 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00155.24 (Aminotransferase class I and II): [55:421](score: 277.4, e-value: 2e-82)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000885 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00155.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n   PF00155.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000885\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000885\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATGGCCTATTGCGAGGAGCTGGGCGGACGGGAGCTGATGCAAGCGCAAGACTCGGCTGGAGGAGTGTAGGCAGATTCAGCAGCACATGGAGAGAGGTGCCTCAAGGACCGCCGGACGCAATTCTTGGAATTACGCAGGCCTTCATGGCAGACAAGAGTTCAAAGAAGGTGAATGTGGGAGTCGGTGCATACAGAGACGACCAGGGCAAGCCTTATGTCCTCCCTTCCGTACGAGAGGCTGAACGGAAGATTCTCGACATGGACAAGGAATACGCAGGTATCACAGGTATCCCAACCTTCACCAAAGCGGCAGCGCAATTGGCGTATGGCGAGGGAAGCAAAGCCTTCCAGGAAGGACGAGTTGCCATCACGCAGTCCATATCTGGCACCGGAGCTCTTCGAATTGGAGGGGAGTTCTTGAGGAGGTGGTTCCCGACCTCGAAAACCATCTACCTGCCCACGCCATCGTGGGCCAACCATGTCCCCATCTTCCGAGACAGTGGGCTTGAAGTCAAGTCTTACCGCTACTATGACAAGTCTACCGTGGGACTCGATGCAAAGGGCATGCTGGCGGATATTAAAGCGGCGCCAAAGGGATCCATGATTCTTTTACATGCGTGTGCACACAACCCCACCGGTGTGGATCCGACTGAGGAGCAGTGGAGCTCGATTGAGCAGGCTGTCAAGGCAGGGGGCCACTTCCCCTTCTTTGACATGGCCTACCAAGGCTTCGCCAGCGGAGACTGCACCAAAGATGCCTATGCGTTGCGGTACTTTGTTGATCGCGGCCACCAAGTGGCGCTCTCTCAGAGCTTTGCCAAAAATATGGGCCTGTATGGCGAGCGAGCCGGAGCTTTCTCTGTCGTCACCTCTTCGGAAGAGGAATCCCGACGCGTGGACTGTCAGCTCAAGATTATCGTGCGGCCACTCTACTCCAATCCGCCTATCAACGGAGCGCGGATTGCGTCTGCTATCCTCAACGACAGCGCCCTCAACACACAGTGGTTGGGAGAGGTCAAGGGCATGGCTGACCGAATCATTTCCATGCGCGCACTCCTGAAGAAGAATCTAGAGGATCTCGGATCGAAGCGATCCTGGGATCATATTACATCGCAAATTGGCATGTTTTGCTACACAGGACTTTCGGCTGGGCAGGTTGACCGACTGGCCAAGGAGTACTCCATCTATGGCACGCGTGACGGGCGCATCTCTGTCGCAGGCGTCAACAGTGGCAACGTAGAATACCTAGCACAAGCCATCCACGAGGTGACTAGATAG",
    "translation": "MNGLLRGAGRTGADASARLGWRSVGRFSSTWREVPQGPPDAILGITQAFMADKSSKKVNVGVGAYRDDQGKPYVLPSVREAERKILDMDKEYAGITGIPTFTKAAAQLAYGEGSKAFQEGRVAITQSISGTGALRIGGEFLRRWFPTSKTIYLPTPSWANHVPIFRDSGLEVKSYRYYDKSTVGLDAKGMLADIKAAPKGSMILLHACAHNPTGVDPTEEQWSSIEQAVKAGGHFPFFDMAYQGFASGDCTKDAYALRYFVDRGHQVALSQSFAKNMGLYGERAGAFSVVTSSEEESRRVDCQLKIIVRPLYSNPPINGARIASAILNDSALNTQWLGEVKGMADRIISMRALLKKNLEDLGSKRSWDHITSQIGMFCYTGLSAGQVDRLAKEYSIYGTRDGRISVAGVNSGNVEYLAQAIHEVTR",
    "product": "hypothetical protein"
   },
   {
    "start": 8564,
    "end": 9095,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000886",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000886</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000886</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000886-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,564 - 9,095,\n (total: 441 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000886 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01627.26 (Hpt domain): [44:116](score: 45.1, e-value: 9.9e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000886 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01627.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000886\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000886\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAGAGGAAACGGTGGAAGCGGTGGACAAGGAGGCGAAGGAGATGGTGTTTGGCGATGTGGTAGATAAGGACACCTTCCACCAATTGCTCGAAATGGACGACGACGAAGAGCGCGAGTTCAGCAAGAGCATTGTGTGGAATTACTTTGAGCAAGCCGAGACCACCTTTCAGCAGATGGACGAAGCCTTAACAGACACCAACCTTGCCGAGCTCTCTTCTCTCGGCCACTTTCTCAAAGGCAGTTCCGCGGCGCTTGGGTTGAAGAAGGTCCAGGCCGCCTGCGAGAAGATACAGTACCTCGGCGCGCGAAAGGATGAAACGGAGAGCAAAACAGATCTGCCAGAGCAGGAGTGTCTTGAGCGGATAGAAAAAACCCTGCACGTGGTCAAAGAGGATTACGCCGAGGCGGAGACCAAGCTGAAGGACTACTATGAATAG",
    "translation": "MPEETVEAVDKEAKEMVFGDVVDKDTFHQLLEMDDDEEREFSKSIVWNYFEQAETTFQQMDEALTDTNLAELSSLGHFLKGSSAALGLKKVQAACEKIQYLGARKDETESKTDLPEQECLERIEKTLHVVKEDYAEAETKLKDYYE",
    "product": "hypothetical protein"
   },
   {
    "start": 10593,
    "end": 12305,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000887",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000887</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000887</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000887-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,593 - 12,305,\n (total: 1713 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000887\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000887\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTCATCAAGCTGCAGCCAAAGCCACCCAAGCAAGTGTTATGCCGGCCCAGGCGAGTGTTCAAGCAGCGCAAGCAAGTGTTAAGCCGGCCCAGGCGAGTGTTCAAGCAGCGCAAGCTTCTGCCTGCACGACCACGACTGTCACAACCACCGTCACCGGCACCAATTGTGCGGCTTCAGTTGCTGCTCAGGGATCGGTTCAGCCTGCCATGGTTCAAGCGACCGCGGTCGCACCTATTTCGACTGTCACCTCAGCCTGCCCCGTGTGCAGCCCCCAGACAATCACCGCTCTTGGTCAAATGGTCTCTTCCGTCGTGCAAGCTACATCTACCTCCACCACATCCTGCCCTGCTGGTCAATGTATTGTTGGCGCTCAGACTACTACCGTCACTGCACCATGCACCCTGAGCTACATGTCAACCACCATCTGCGCGTCTGGCAGCACCTGCACCGTCAATGGCCAGGCTATCATGCCTATTTCCACAAGCACCATCTTCGTTACAGCTTCGACCACCTGTCCTTCTGCTGGTGTCTACACGCTTGGAGGTATGACGACCAGTCTCGTGTCGGCTCAGCAGGTTAGCTACCCAGTTCTCGCTGCTGGCAGCACTACCACTTTTCCCTTTTGGCAAACACAGATCTTTGCTGGGCAAACGGTTTCCGCAGCCAGCCAAGCTATTACCTCTTCGGCCCAGATGACCAAGACAACATCGACTTATTGCCCCTCTGCAGGAGTATACACGCTCGCCGGGGTCACGCACTCGATCACGCAGCCGCAATGGATCACTTATGTTATCATCATTACCCAGGACTACGTGTGCGAGGCAGCTCAATGCTTGGGTGCGGCTCCTACAAAGTCGATCAATGTTTACGAGCACAATGGAAACACACAAATCACAGCCTACGGCTTGATCTTGATCGACATTGTCGTTGTCCAGTATATCACGACTGCCTGTCCTACACCGACCACCATCATCAATGTGGATGTCTCTATTGTTGTGTCGGTGGCTCCAACGACGATTACCTACCCGATCACTGTCACCACTACATCCACCATCACCGTCTCTGCGTCATCATCATTGTCGGCATCTGGCTCTGCAACACAGACTGGATCTGTCTCAAGTTCAGCTTCCAAGTCTGGCTCTGCAACACAGACTGGATCTGTCTCAAGTTCAGCTTCCAAGTCTGGCTCTGTGTCTGCTTCAGCTTCTGCTTCGCCTACAGTTGTTCCGGTCACTACTGCCTTCTCCTTGGCGGTTGCTGGAGAGGTTATTGTTGCGTCTGGTTCCTCCCTTCTGATTGTGTCTCCGGCAGACACGACAAACTTTGCTGCAGTCTCCTTCACCATCAATACCGTCGGCCAACTGGTCGCCTCGACTGGTGCTACTGTCGTGGCTACCTTCTCCACCGGAGGAGCTGGTCCATTGGTCTTTGGAGGCTCGCCTGCTGCACGACGCAAACGGCAGGGAGTGCTTGTTGACCGTGTTTACACTGCTGCAGGTGGTTCGCTTACCCTCAACGATCTCATCTTCTCGTCGTGTCCCAACTCGGATGGAAGTTCGACGCCAGACGTGGGTGACTCGGTTCCTGCTGGGTGCACTCAAATCACTTTGACCCTCACAGCTGCGAACGCACCAACCACTCCATTCCAGAATGGCACGATGAAGAGGGGCTTGCAGCGTCGTCACTTTAGACAACACACAATAAGGTAG",
    "translation": "MAHQAAAKATQASVMPAQASVQAAQASVKPAQASVQAAQASACTTTTVTTTVTGTNCAASVAAQGSVQPAMVQATAVAPISTVTSACPVCSPQTITALGQMVSSVVQATSTSTTSCPAGQCIVGAQTTTVTAPCTLSYMSTTICASGSTCTVNGQAIMPISTSTIFVTASTTCPSAGVYTLGGMTTSLVSAQQVSYPVLAAGSTTTFPFWQTQIFAGQTVSAASQAITSSAQMTKTTSTYCPSAGVYTLAGVTHSITQPQWITYVIIITQDYVCEAAQCLGAAPTKSINVYEHNGNTQITAYGLILIDIVVVQYITTACPTPTTIINVDVSIVVSVAPTTITYPITVTTTSTITVSASSSLSASGSATQTGSVSSSASKSGSATQTGSVSSSASKSGSVSASASASPTVVPVTTAFSLAVAGEVIVASGSSLLIVSPADTTNFAAVSFTINTVGQLVASTGATVVATFSTGGAGPLVFGGSPAARRKRQGVLVDRVYTAAGGSLTLNDLIFSSCPNSDGSSTPDVGDSVPAGCTQITLTLTAANAPTTPFQNGTMKRGLQRRHFRQHTIR",
    "product": "hypothetical protein"
   },
   {
    "start": 12368,
    "end": 13213,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000888",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000888</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000888</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000888-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,368 - 13,213,\n (total: 846 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000888 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [20:102](score: 28.5, e-value: 1e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000888\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000888\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAGCGCTTCATTAAATCGTGCCGAGCAAGCCGTGTTACTCAGGATCTGACTGGTCGTACAGCTCTCATCGTAGGGGGAACAAAAGGCATTGGTGCAGAAGTTGCCAATCGTTTAAAAGAGCGTGGAGCAACGACCTATGTCGCCGGCCGAAGCACGACGCCGGCCTCAAATCTACATACGTACCTCCCAGCCGACCTCTCCACCATCCGTGGCATCAACGATTTCATCCGACTCGCCAGATCACGACTTCCTGCCAAAGATGTAATGCTCATCCAATGCTCAGGCCATCCGCCCAATGGGACCCTAAACGTATATCAAACCGTCGACAAGGACTTTTGCGTGCAATGCTTTGGAAGACTGTTCGTTGCCTGGGACTTGGCTCCGCAGACTTCGAGTATCGTGTGGGTTGCTGCCCCTGGCGGAGGATATCTTGATGTGAATGATATTCAAACGCTAAAGTCCACATGGACGCCGCTCATCGTTCGACAATTTCTTCGCGATAGCGCCTTCCTCGATATCTCGGCGGCCATGATAGCACAGGAGCGCGGGGCAAAGATTACGCATACCTTCCCTGGAATTGTAGCGACGGAGGGGTATCGAAATTTGTTTTGGAAACCGGTGGAATGGATGCAGGGTCTTCTACTTCGCACCATTGGCACTAGTGCAGTTGACTACTCAGAGGTACCGGCATACTATGCAATGAACCCATCGCAAACGAACGAGGCGCGATTCACGAGTGGGGGTAGAAGCATTACGCCGAGCACGATTGCAAATGATGCATTGAAGCGGCAAGCGGTCTTGGATTGGAGTATGGAGAAGCGAAGGATGGCTGAGCAGAATTAA",
    "translation": "MQRFIKSCRASRVTQDLTGRTALIVGGTKGIGAEVANRLKERGATTYVAGRSTTPASNLHTYLPADLSTIRGINDFIRLARSRLPAKDVMLIQCSGHPPNGTLNVYQTVDKDFCVQCFGRLFVAWDLAPQTSSIVWVAAPGGGYLDVNDIQTLKSTWTPLIVRQFLRDSAFLDISAAMIAQERGAKITHTFPGIVATEGYRNLFWKPVEWMQGLLLRTIGTSAVDYSEVPAYYAMNPSQTNEARFTSGGRSITPSTIANDALKRQAVLDWSMEKRRMAEQN",
    "product": "hypothetical protein"
   },
   {
    "start": 15010,
    "end": 16410,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000889",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000889</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000889</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000889-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,010 - 16,410,\n (total: 1401 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000889 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [105:216](score: 60.3, e-value: 2.7e-16)<br>\n \n  PF16193.8 (AAA C-terminal domain): [235:304](score: 76.7, e-value: 1.4e-21)<br>\n \n  PF12002.11 (MgsA AAA+ ATPase C terminal): [304:463](score: 179.2, e-value: 6.2e-53)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000889 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000889\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000889\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAGAATGTCCTATATGTCAAAAGCAGGTCTCCGAAGCTCGGATCAACCAGCACCTAGACACAGACTGCGGTCGTGAGAAGCAAAAAGCACTCACTCCGCCAAGCTCATCTAATGGATATGAATTGAACCAAGTAAAAATCAACGAGGAAGAGAGACCGGCGAAACGCCAGAAGAATACCGCGTTAATGGAAGCAAGACCATTAGCCGAACGCGTTCGGCCCCTCAAATTGGATGGTTTTGTGGGACAGAATGAGCTAGTAGGAAGGGATGGGGTGTTGCGAAAGCTTTTGGAGATGGATAAGTGTCCATCCATGATCCTATGGGGACCAAGCGGGACCGGCAAGACCACACTTGCGCGTTTGGTAGCGAAATCAACACGATCAAGATTTGTAGAAATGAGCGCAACTGCAGTCGGGACTGGAGAGTGCAAGAAGCTCTTTGAAGAGGCCCGTAACGGCTTGAAACTACTTGGGCAACGAACTATCCTTTTTCTTGATGAAATACATCGCTTTGCAAAAAACCAGCAGGATATCTTTCTTCCCTATGTAGAGTCTGGTTTGATTTGCCTAATTGGTGCTACAACCGAGAATCCTTCCTTCAAAGTCAATAATGCTCTCCTGTCGCGATGCCGCGTGTTTATTCTGAAAAAGCTCACAGAGCATGAGGTGGCGGAAATCCTCAGACGGGTCGGCATTGAAGGTGTTTCGGAAGACATGCTTACCTACATGGCACAAATTTCAGACGGTGATGCCCGAATTGCTTTGAATATCCTGGAAGTGGCTGAACAACTGTCTGACAAGCTTGGCGATGAGGAGGTGAAGCAAGCTGTTCGGCGTACGCATTTTGCGTACGACACTCATGGAGACGCACACTATGACGCCATCTCTGCTTTGCACAAGTCGATTCGCGGTAGTGATCCCGACGCCGCTTTATTTTATGCTACGCGCATGATGGAGAGTGGCGAAGATCCCTTGTACATTTGCCGCCGCCTCATTCGTGCTGCATCTGAAGACATTGGGACAGCAGATTCTAGCATGCTTACACTCGCGACTTCTACATACACGGCCGTCCAACAAGTAGGCATGCCGGAAGCCGACTGCATGATTGCTCATTGTGTGGTAGCGTTGGCAGAGGCACCCAAGTCAGTCCGTGTCTACCGCGCCATGAAGTGTGTGAAATCTTTGCTTCACCAAGATCATAAAGCAGCAGGAGCCGCGATCCCAATTCATTTGCGCAACGCACCGACCACACTTATGAAGAAAATAGGCTACGGGAAGGAATACAAGTATCCTCCAGACGATGACAGTCATCAGGACTACTTGCCAGAGGGACTCATAGGCACGCGTTTTCTTGACCCTGGAGAGATTGAGTTTGACGAATCGTTGGGCAAGGATTGA",
    "translation": "MVECPICQKQVSEARINQHLDTDCGREKQKALTPPSSSNGYELNQVKINEEERPAKRQKNTALMEARPLAERVRPLKLDGFVGQNELVGRDGVLRKLLEMDKCPSMILWGPSGTGKTTLARLVAKSTRSRFVEMSATAVGTGECKKLFEEARNGLKLLGQRTILFLDEIHRFAKNQQDIFLPYVESGLICLIGATTENPSFKVNNALLSRCRVFILKKLTEHEVAEILRRVGIEGVSEDMLTYMAQISDGDARIALNILEVAEQLSDKLGDEEVKQAVRRTHFAYDTHGDAHYDAISALHKSIRGSDPDAALFYATRMMESGEDPLYICRRLIRAASEDIGTADSSMLTLATSTYTAVQQVGMPEADCMIAHCVVALAEAPKSVRVYRAMKCVKSLLHQDHKAAGAAIPIHLRNAPTTLMKKIGYGKEYKYPPDDDSHQDYLPEGLIGTRFLDPGEIEFDESLGKD",
    "product": "hypothetical protein"
   },
   {
    "start": 16990,
    "end": 17958,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000890",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000890</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000890</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000890-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,990 - 17,958,\n (total: 969 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000890 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:269](score: 204.0, e-value: 2.5e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000890\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000890-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000890\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTCAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGGATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTCGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGGCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
    "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
    "product": "hypothetical protein"
   },
   {
    "start": 18444,
    "end": 20104,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000891",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000891</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000891</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000891-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,444 - 20,104,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 963.0, e-value: 4.7e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_000891 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000891\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000891-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000891\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAAAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAACCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCGTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCCGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCCAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
    "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDKGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
    "product": "hypothetical protein"
   },
   {
    "start": 20118,
    "end": 24185,
    "strand": -1,
    "locus_tag": "MARS9BIN1_000892",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000892</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000892</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000892-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,118 - 24,185,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.4; E-value: 1.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000892 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.9, e-value: 1.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_000892 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1899.2, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000892\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_000892-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000892\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAACCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAGGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACGATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
    "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
    "product": "hypothetical protein"
   },
   {
    "start": 24457,
    "end": 25947,
    "strand": 1,
    "locus_tag": "MARS9BIN1_000893",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_000893</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_000893</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_000893-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,457 - 25,947,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_000893\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_000893\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGGTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
    "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILGFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 20117,
    "end": 24185,
    "tool": "rule-based-clusters",
    "neighbouring_start": 117,
    "neighbouring_end": 26174,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r49c1"
 },
 "r140c1": {
  "start": 1,
  "end": 15572,
  "idx": 1,
  "orfs": [
   {
    "start": 180,
    "end": 1440,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001871",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001871</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001871</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001871-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 180 - 1,440,\n (total: 1230 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001871\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001871\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAGGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAATTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
    "translation": "MSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKGVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSNFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
    "product": "hypothetical protein"
   },
   {
    "start": 1541,
    "end": 4567,
    "strand": -1,
    "locus_tag": "MARS9BIN1_001872",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001872</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001872</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001872-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,541 - 4,567,\n (total: 2808 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1190:GTP-binding protein LepA (Score: 61.5; E-value: 1.1e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001872 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [11:257](score: 120.2, e-value: 8.3e-35)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [466:530](score: 28.2, e-value: 1.6e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [800:881](score: 50.4, e-value: 1.9e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001872 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001872\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCCCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAATAAAATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGGCTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCTAGCGTTGGAATGAACCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCATAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTACATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTTGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTAATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
    "translation": "MRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQNKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRGLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSISGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLHGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
    "product": "hypothetical protein"
   },
   {
    "start": 4877,
    "end": 5818,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001873",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001873</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001873</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001873-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,877 - 5,818,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001873 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001873\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
    "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
    "product": "hypothetical protein"
   },
   {
    "start": 5872,
    "end": 6800,
    "strand": -1,
    "locus_tag": "MARS9BIN1_001874",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001874</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001874</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001874-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,872 - 6,800,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001874 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001874\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
    "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
    "product": "hypothetical protein"
   },
   {
    "start": 7165,
    "end": 7689,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001875",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001875</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001875</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001875-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,165 - 7,689,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001875 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001875 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001875\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001875\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
    "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
    "product": "hypothetical protein"
   },
   {
    "start": 8291,
    "end": 9340,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001876",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001876</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001876</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001876-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,291 - 9,340,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001876 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 207.4, e-value: 2.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001876\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001876\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTCGGGAAGCGCGGCCGCTCCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
    "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRSKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
    "product": "hypothetical protein"
   },
   {
    "start": 9382,
    "end": 10083,
    "strand": -1,
    "locus_tag": "MARS9BIN1_001877",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001877</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001877</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001877-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,382 - 10,083,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001877 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001877\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001877\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
    "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
    "product": "hypothetical protein"
   },
   {
    "start": 10610,
    "end": 11632,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001878",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001878</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001878</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001878-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,610 - 11,632,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001878 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001878\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001878\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
    "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
    "product": "hypothetical protein"
   },
   {
    "start": 11687,
    "end": 12127,
    "strand": -1,
    "locus_tag": "MARS9BIN1_001879",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001879</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001879</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001879-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,687 - 12,127,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001879\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001879\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
    "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
    "product": "hypothetical protein"
   },
   {
    "start": 12900,
    "end": 14204,
    "strand": 1,
    "locus_tag": "MARS9BIN1_001880",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001880</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001880</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001880-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,900 - 14,204,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325.2; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001880 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.3, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001880 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001880\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_001880-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001880\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGCAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCGTGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
    "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTAEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVVAMDKEQVKRKRKLRAG",
    "product": "hypothetical protein"
   },
   {
    "start": 14295,
    "end": 15445,
    "strand": -1,
    "locus_tag": "MARS9BIN1_001881",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_001881</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_001881</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_001881-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,295 - 15,445,\n (total: 1119 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_001881 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [22:62](score: 49.9, e-value: 2.1e-13)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [77:106](score: 24.1, e-value: 2.8e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [111:146](score: 23.9, e-value: 3.2e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [152:189](score: 32.3, e-value: 7.2e-08)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [231:272](score: 25.9, e-value: 7.7e-06)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_001881 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00514.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_001881\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_001881\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "CTAGCCAAGTCAAGGGACCTGCGCGTTCAACGAAATGCTACAGGAGCTCTATTGAATATGACTCATTCCGATGAAAACAGGCAGCAGCTTGTCAATGCCGGCGCAATACCAGTGCTCGTCCACCTCTTAACTTCTCAAGACTCTGATGTCCAATACTACTGCACTACTGCGCTAAGCAACATCGCAGTTGACGCTTCGAACCGCAAGAAACTGGCAAATTCCGAGCCTAGGTTGGTGCAAGCGCTCATCGCTTTGATGGAGTCATCTAGCCCAAAAGTGCAATGCCAATCAGCTCTGGCGCTGCGCAATCTCGCGTCGGACGAGAAATATCAACTCGATATTGTGCGGTCTAATGGGTTGCCTGCTCTCTTACGTTTATTACAATCTTCCTTCCTAGCTCTGATACTTTCAGCAGTCGCTTGTATACGCAATATCTCTATTCACCCGCTAAACGAGTCGCCTATCATTGATGCTGGTTTCCTAAGGCCTTTGGTCGAACTTCTTGGTTCGACGGATAATGAAGAGATTCAATGTCATGCCATCTCCACCTTACGGAATCTAGCGGCAAGCTCAGAACGAAATAAAAAAGCCATTGTTGAAGCGGGAGCAATTCAGAAATGTAAGGAACTCGTTTTGCATGTGCCACTTAGCGTCCAAAGTGAGATGACGGCATGCATTGCCGTACTTGCTCTGTCTGACGAGCTCAAAACCTACTTGTTGTCTCTCGGAGTTTTTGATGTACTCATTCCTCTAACGGATTCAACGAGCATTGAGGTGCAGGGGAACAGCGCAGCAGCTCTGGGCAATTTGTCATCGAAAGTGAGCGACTACACACCTCTCTTGAATGCATGGAAGGAACCAGACGGAGGTTTCAAAGGCTACCTAGAGCACTTTCTCTCTAGTGGTGATGGTGCGTTTCAGCACATTGCCACATGGACCGTCCTACAGCTCCTGGAAGCTGACGAGCCGGATGTCAAAGCCCTGATTGTGGAAAGTCCGGAAATTGTGCGGGCGATTCGTCAGACGGCTGAGCGAGAACCGCAAACTGATGACGATCCCGAAGGAGAAGGCGAAATTGTGCCTCTTGCCAGGCGGGTTGTGGAACTAATCGACCAGTGA",
    "translation": "MAKSRDLRVQRNATGALLNMTHSDENRQQLVNAGAIPVLVHLLTSQDSDVQYYCTTALSNIAVDASNRKKLANSEPRLVQALIALMESSSPKVQCQSALALRNLASDEKYQLDIVRSNGLPALLRLLQSSFLALILSAVACIRNISIHPLNESPIIDAGFLRPLVELLGSTDNEEIQCHAISTLRNLAASSERNKKAIVEAGAIQKCKELVLHVPLSVQSEMTACIAVLALSDELKTYLLSLGVFDVLIPLTDSTSIEVQGNSAAALGNLSSKVSDYTPLLNAWKEPDGGFKGYLEHFLSSGDGAFQHIATWTVLQLLEADEPDVKALIVESPEIVRAIRQTAEREPQTDDDPEGEGEIVPLARRVVELIDQ",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 5871,
    "end": 6800,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 15572,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r140c1"
 },
 "r565c1": {
  "start": 1,
  "end": 4648,
  "idx": 1,
  "orfs": [
   {
    "start": 282,
    "end": 1745,
    "strand": 1,
    "locus_tag": "MARS9BIN1_003810",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_003810</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_003810</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_003810-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 282 - 1,745,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_003810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS9BIN1_003810 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_003810\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_003810-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
    "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
    "product": "hypothetical protein"
   },
   {
    "start": 1923,
    "end": 4541,
    "strand": 1,
    "locus_tag": "MARS9BIN1_003811",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS9BIN1_003811</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS9BIN1_003811</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS9BIN1_003811-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,923 - 4,541,\n (total: 2619 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.7; E-value: 2.9e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS9BIN1_003811 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 126.3, e-value: 1.3e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 32.0, e-value: 1.3e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:867](score: 134.6, e-value: 3.6e-39)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS9BIN1_003811\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS9BIN1_003811-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS9BIN1_003811\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGAAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCT",
    "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLP",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 1922,
    "end": 4541,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 4648,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r565c1"
 }
};
var details_data = {
 "nrpspks": {
  "r49c1": {
   "id": "r49c1",
   "orfs": [
    {
     "id": "MARS9BIN1_000885",
     "sequence": "MNGLLRGAGRTGADASARLGWRSVGRFSSTWREVPQGPPDAILGITQAFMADKSSKKVNVGVGAYRDDQGKPYVLPSVREAERKILDMDKEYAGITGIPTFTKAAAQLAYGEGSKAFQEGRVAITQSISGTGALRIGGEFLRRWFPTSKTIYLPTPSWANHVPIFRDSGLEVKSYRYYDKSTVGLDAKGMLADIKAAPKGSMILLHACAHNPTGVDPTEEQWSSIEQAVKAGGHFPFFDMAYQGFASGDCTKDAYALRYFVDRGHQVALSQSFAKNMGLYGERAGAFSVVTSSEEESRRVDCQLKIIVRPLYSNPPINGARIASAILNDSALNTQWLGEVKGMADRIISMRALLKKNLEDLGSKRSWDHITSQIGMFCYTGLSAGQVDRLAKEYSIYGTRDGRISVAGVNSGNVEYLAQAIHEVTR",
     "domains": [
      {
       "type": "Aminotran_1_2",
       "start": 55,
       "end": 421,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "KKVNVGVGAYRDDQGKPYVLPSVREAERKILDMDKEYAGITGIPTFTKAAAQLAYGEGSKAFQEGRVAITQSISGTGALRIGGEFLRRWFPTSKTIYLPTPSWANHVPIFRDSGLEVKSYRYYDKSTVGLDAKGMLADIKAAPKGSMILLHACAHNPTGVDPTEEQWSSIEQAVKAGGHFPFFDMAYQGFASGDCTKDAYALRYFVDRGHQVALSQSFAKNMGLYGERAGAFSVVTSSEEESRRVDCQLKIIVRPLYSNPPINGARIASAILNDSALNTQWLGEVKGMADRIISMRALLKKNLEDLGSKRSWDHITSQIGMFCYTGLSAGQVDRLAKEYSIYGTRDGRISVAGVNSGNVEYLAQAI",
       "dna_sequence": "AAGAAGGTGAATGTGGGAGTCGGTGCATACAGAGACGACCAGGGCAAGCCTTATGTCCTCCCTTCCGTACGAGAGGCTGAACGGAAGATTCTCGACATGGACAAGGAATACGCAGGTATCACAGGTATCCCAACCTTCACCAAAGCGGCAGCGCAATTGGCGTATGGCGAGGGAAGCAAAGCCTTCCAGGAAGGACGAGTTGCCATCACGCAGTCCATATCTGGCACCGGAGCTCTTCGAATTGGAGGGGAGTTCTTGAGGAGGTGGTTCCCGACCTCGAAAACCATCTACCTGCCCACGCCATCGTGGGCCAACCATGTCCCCATCTTCCGAGACAGTGGGCTTGAAGTCAAGTCTTACCGCTACTATGACAAGTCTACCGTGGGACTCGATGCAAAGGGCATGCTGGCGGATATTAAAGCGGCGCCAAAGGGATCCATGATTCTTTTACATGCGTGTGCACACAACCCCACCGGTGTGGATCCGACTGAGGAGCAGTGGAGCTCGATTGAGCAGGCTGTCAAGGCAGGGGGCCACTTCCCCTTCTTTGACATGGCCTACCAAGGCTTCGCCAGCGGAGACTGCACCAAAGATGCCTATGCGTTGCGGTACTTTGTTGATCGCGGCCACCAAGTGGCGCTCTCTCAGAGCTTTGCCAAAAATATGGGCCTGTATGGCGAGCGAGCCGGAGCTTTCTCTGTCGTCACCTCTTCGGAAGAGGAATCCCGACGCGTGGACTGTCAGCTCAAGATTATCGTGCGGCCACTCTACTCCAATCCGCCTATCAACGGAGCGCGGATTGCGTCTGCTATCCTCAACGACAGCGCCCTCAACACACAGTGGTTGGGAGAGGTCAAGGGCATGGCTGACCGAATCATTTCCATGCGCGCACTCCTGAAGAAGAATCTAGAGGATCTCGGATCGAAGCGATCCTGGGATCATATTACATCGCAAATTGGCATGTTTTGCTACACAGGACTTTCGGCTGGGCAGGTTGACCGACTGGCCAAGGAGTACTCCATCTATGGCACGCGTGACGGGCGCATCTCTGTCGCAGGCGTCAACAGTGGCAACGTAGAATACCTAGCACAAGCCATC",
       "abbreviation": "AmT",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": []
    },
    {
     "id": "MARS9BIN1_000892",
     "sequence": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 223,
       "end": 688,
       "predictions": [
        [
         "substrate consensus",
         "Aad"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIR",
       "dna_sequence": "TTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 821,
       "end": 888,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEID",
       "dna_sequence": "GCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 944,
       "end": 1194,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVI",
       "dna_sequence": "CTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 223,
       "end": 1194,
       "complete": true,
       "iterative": false,
       "monomer": "Aad",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r565c1": {
   "id": "r565c1",
   "orfs": [
    {
     "id": "MARS9BIN1_003811",
     "sequence": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLP",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 29,
       "end": 341,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVR",
       "dna_sequence": "TTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 535,
       "end": 606,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFI",
       "dna_sequence": "TATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "TD",
       "start": 655,
       "end": 873,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLP",
       "dna_sequence": "ATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCT",
       "abbreviation": "TD",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 29,
       "end": 873,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r49c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "perA",
         "query_loc": 22151,
         "subject_loc": 4161
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "icoS",
         "query_loc": 22151,
         "subject_loc": 22489
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "XNC1_2022",
         "query_loc": 22151,
         "subject_loc": 6208
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "plu3123",
         "query_loc": 22151,
         "subject_loc": 8187
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "plu3263",
         "query_loc": 22151,
         "subject_loc": 7860
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "PLU_RS13235",
         "query_loc": 22151,
         "subject_loc": 24552
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "X797_010654",
         "query_loc": 22151,
         "subject_loc": 14258
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "AN5318.2",
         "query_loc": 22151,
         "subject_loc": 1906
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 22151,
         "subject_loc": 4534
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "BO96DRAFT_451379",
         "query_loc": 22151,
         "subject_loc": 6032
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "perA",
         "query_loc": 22151,
         "subject_loc": 4161
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "icoS",
         "query_loc": 22151,
         "subject_loc": 22489
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "XNC1_2022",
         "query_loc": 22151,
         "subject_loc": 6208
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "plu3123",
         "query_loc": 22151,
         "subject_loc": 8187
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "plu3263",
         "query_loc": 22151,
         "subject_loc": 7860
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "PLU_RS13235",
         "query_loc": 22151,
         "subject_loc": 24552
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "X797_010654",
         "query_loc": 22151,
         "subject_loc": 14258
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "AN5318.2",
         "query_loc": 22151,
         "subject_loc": 1906
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 22151,
         "subject_loc": 4534
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS9BIN1_000892",
         "subject": "BO96DRAFT_451379",
         "query_loc": 22151,
         "subject_loc": 6032
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_000892"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_000892",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 223,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_000892",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 821,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_000892",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 944,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Aad"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS9BIN1_000881": {
     "functions": []
    },
    "MARS9BIN1_000882": {
     "functions": []
    },
    "MARS9BIN1_000883": {
     "functions": []
    },
    "MARS9BIN1_000884": {
     "functions": []
    },
    "MARS9BIN1_000885": {
     "functions": [
      {
       "description": "Aminotran_1_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS9BIN1_000886": {
     "functions": []
    },
    "MARS9BIN1_000887": {
     "functions": []
    },
    "MARS9BIN1_000888": {
     "functions": []
    },
    "MARS9BIN1_000889": {
     "functions": []
    },
    "MARS9BIN1_000890": {
     "functions": []
    },
    "MARS9BIN1_000891": {
     "functions": []
    },
    "MARS9BIN1_000892": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS9BIN1_000893": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS9BIN1_000881",
      "seqLength": 273,
      "domains": [
       {
        "start": 10,
        "end": 273,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "CLN3",
        "accession": "PF02487",
        "description": "CLN3 protein",
        "evalue": "9.8e-94",
        "score": "314.7"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000882",
      "seqLength": 555,
      "domains": [
       {
        "start": 336,
        "end": 382,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006260' target='_blank'>GO:0006260</a>: DNA replication",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005634' target='_blank'>GO:0005634</a>: nucleus"
        ],
        "html_class": "generic-type-other",
        "name": "zf-primase",
        "accession": "PF09329",
        "description": "Primase zinc finger",
        "evalue": "1.6e-16",
        "score": "59.9"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000883",
      "seqLength": 795,
      "domains": [
       {
        "start": 54,
        "end": 94,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016575' target='_blank'>GO:0016575</a>: histone deacetylation"
        ],
        "html_class": "generic-type-other",
        "name": "Rxt3",
        "accession": "PF08642",
        "description": "Histone deacetylation protein Rxt3",
        "evalue": "1.7e-09",
        "score": "38.6"
       },
       {
        "start": 304,
        "end": 774,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000398' target='_blank'>GO:0000398</a>: mRNA splicing, via spliceosome"
        ],
        "html_class": "generic-type-other",
        "name": "SART-1",
        "accession": "PF03343",
        "description": "SART-1 family",
        "evalue": "9e-96",
        "score": "321.9"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000884",
      "seqLength": 174,
      "domains": [
       {
        "start": 59,
        "end": 174,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004045' target='_blank'>GO:0004045</a>: aminoacyl-tRNA hydrolase activity"
        ],
        "html_class": "generic-type-other",
        "name": "PTH2",
        "accession": "PF01981",
        "description": "Peptidyl-tRNA hydrolase PTH2",
        "evalue": "9.3e-44",
        "score": "148.6"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000885",
      "seqLength": 426,
      "domains": [
       {
        "start": 55,
        "end": 421,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Aminotran_1_2",
        "accession": "PF00155",
        "description": "Aminotransferase class I and II",
        "evalue": "2e-82",
        "score": "277.4"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000886",
      "seqLength": 146,
      "domains": [
       {
        "start": 44,
        "end": 116,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Hpt",
        "accession": "PF01627",
        "description": "Hpt domain",
        "evalue": "9.9e-12",
        "score": "45.1"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000888",
      "seqLength": 281,
      "domains": [
       {
        "start": 20,
        "end": 102,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "1e-06",
        "score": "28.5"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000889",
      "seqLength": 466,
      "domains": [
       {
        "start": 105,
        "end": 216,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity"
        ],
        "html_class": "generic-type-other",
        "name": "AAA",
        "accession": "PF00004",
        "description": "ATPase family associated with various cellular activities (AAA)",
        "evalue": "2.7e-16",
        "score": "60.3"
       },
       {
        "start": 235,
        "end": 304,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_assoc_2",
        "accession": "PF16193",
        "description": "AAA C-terminal domain",
        "evalue": "1.4e-21",
        "score": "76.7"
       },
       {
        "start": 304,
        "end": 463,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "MgsA_C",
        "accession": "PF12002",
        "description": "MgsA AAA+ ATPase C terminal",
        "evalue": "6.2e-53",
        "score": "179.2"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000890",
      "seqLength": 322,
      "domains": [
       {
        "start": 27,
        "end": 269,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF1295",
        "accession": "PF06966",
        "description": "Protein of unknown function (DUF1295)",
        "evalue": "2.5e-60",
        "score": "204.0"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000891",
      "seqLength": 528,
      "domains": [
       {
        "start": 36,
        "end": 102,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab_N",
        "accession": "PF02874",
        "description": "ATP synthase alpha/beta family, beta-barrel domain",
        "evalue": "2.2e-14",
        "score": "53.9"
       },
       {
        "start": 158,
        "end": 386,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab",
        "accession": "PF00006",
        "description": "ATP synthase alpha/beta family, nucleotide-binding domain",
        "evalue": "6.7e-64",
        "score": "215.6"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000892",
      "seqLength": 1355,
      "domains": [
       {
        "start": 223,
        "end": 688,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.2e-65",
        "score": "221.9"
       },
       {
        "start": 822,
        "end": 887,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "2.9e-12",
        "score": "46.8"
       },
       {
        "start": 944,
        "end": 1194,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "1.5e-76",
        "score": "257.1"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS9BIN1_000884",
      "seqLength": 174,
      "domains": [
       {
        "start": 60,
        "end": 174,
        "name": "TIGR00283",
        "description": "arch_pth2: peptidyl-tRNA hydrolase",
        "accession": "TIGR00283",
        "evalue": "3.7e-38",
        "score": "128.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000891",
      "seqLength": 528,
      "domains": [
       {
        "start": 32,
        "end": 495,
        "name": "TIGR01040",
        "description": "V-ATPase_V1_B: V-type ATPase, B subunit",
        "accession": "TIGR01040",
        "evalue": "4.7e-291",
        "score": "963.0",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS9BIN1_000892",
      "seqLength": 1355,
      "domains": [
       {
        "start": 6,
        "end": 1350,
        "name": "TIGR03443",
        "description": "alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase",
        "accession": "TIGR03443",
        "evalue": "0",
        "score": "1899.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 253,
        "end": 711,
        "name": "TIGR01733",
        "description": "AA-adenyl-dom: amino acid adenylation domain",
        "accession": "TIGR01733",
        "evalue": "5.1e-114",
        "score": "379.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 941,
        "end": 1317,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "1.8e-104",
        "score": "347.9",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r140c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78731.1",
         "query_loc": 13551,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78758.1",
         "query_loc": 13551,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78811.1",
         "query_loc": 13551,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "AQM37586.1",
         "query_loc": 13551,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78797.1",
         "query_loc": 13551,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78771.1",
         "query_loc": 13551,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78784.1",
         "query_loc": 13551,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78746.1",
         "query_loc": 13551,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002060: 0-47954": {
       "start": 0,
       "end": 47954,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "Psyr_4297",
         "query_loc": 13551,
         "subject_loc": 4874
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Psyr_4293",
         "start": 0,
         "end": 870,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4294",
         "start": 1009,
         "end": 1579,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4295",
         "start": 1699,
         "end": 2617,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4296",
         "start": 2687,
         "end": 3962,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4297",
         "start": 4210,
         "end": 5539,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "Psyr_4298",
         "start": 5601,
         "end": 6516,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4299",
         "start": 6683,
         "end": 7151,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4300",
         "start": 7155,
         "end": 7770,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4301",
         "start": 7788,
         "end": 8265,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4302",
         "start": 8545,
         "end": 9250,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4303",
         "start": 9447,
         "end": 10110,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4304",
         "start": 10143,
         "end": 11286,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4305",
         "start": 11470,
         "end": 11719,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4306",
         "start": 11823,
         "end": 12021,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4307",
         "start": 12588,
         "end": 13524,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4308",
         "start": 14108,
         "end": 15665,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4309",
         "start": 15765,
         "end": 16380,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4310",
         "start": 16503,
         "end": 17439,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4311",
         "start": 17489,
         "end": 20657,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4312",
         "start": 20661,
         "end": 27444,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4313",
         "start": 27499,
         "end": 34681,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4314",
         "start": 34691,
         "end": 44387,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4315",
         "start": 44407,
         "end": 46384,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4316",
         "start": 46620,
         "end": 46866,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4317",
         "start": 46940,
         "end": 47954,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78731.1",
         "query_loc": 13551,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78758.1",
         "query_loc": 13551,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78811.1",
         "query_loc": 13551,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "AQM37586.1",
         "query_loc": 13551,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78797.1",
         "query_loc": 13551,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78771.1",
         "query_loc": 13551,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78784.1",
         "query_loc": 13551,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "APZ78746.1",
         "query_loc": 13551,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002060: 0-47954": {
       "start": 0,
       "end": 47954,
       "links": [
        {
         "query": "MARS9BIN1_001880",
         "subject": "Psyr_4297",
         "query_loc": 13551,
         "subject_loc": 4874
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Psyr_4293",
         "start": 0,
         "end": 870,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4294",
         "start": 1009,
         "end": 1579,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4295",
         "start": 1699,
         "end": 2617,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4296",
         "start": 2687,
         "end": 3962,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4297",
         "start": 4210,
         "end": 5539,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS9BIN1_001880"
         }
        },
        {
         "locus_tag": "Psyr_4298",
         "start": 5601,
         "end": 6516,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4299",
         "start": 6683,
         "end": 7151,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4300",
         "start": 7155,
         "end": 7770,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4301",
         "start": 7788,
         "end": 8265,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4302",
         "start": 8545,
         "end": 9250,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4303",
         "start": 9447,
         "end": 10110,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4304",
         "start": 10143,
         "end": 11286,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4305",
         "start": 11470,
         "end": 11719,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4306",
         "start": 11823,
         "end": 12021,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4307",
         "start": 12588,
         "end": 13524,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4308",
         "start": 14108,
         "end": 15665,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4309",
         "start": 15765,
         "end": 16380,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4310",
         "start": 16503,
         "end": 17439,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4311",
         "start": 17489,
         "end": 20657,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4312",
         "start": 20661,
         "end": 27444,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4313",
         "start": 27499,
         "end": 34681,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4314",
         "start": 34691,
         "end": 44387,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4315",
         "start": 44407,
         "end": 46384,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4316",
         "start": 46620,
         "end": 46866,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Psyr_4317",
         "start": 46940,
         "end": 47954,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS9BIN1_001871": {
     "functions": []
    },
    "MARS9BIN1_001872": {
     "functions": [
      {
       "description": "SMCOG1190:GTP-binding protein LepA ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS9BIN1_001873": {
     "functions": []
    },
    "MARS9BIN1_001874": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS9BIN1_001875": {
     "functions": []
    },
    "MARS9BIN1_001876": {
     "functions": []
    },
    "MARS9BIN1_001877": {
     "functions": []
    },
    "MARS9BIN1_001878": {
     "functions": []
    },
    "MARS9BIN1_001879": {
     "functions": []
    },
    "MARS9BIN1_001880": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS9BIN1_001881": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS9BIN1_001872",
      "seqLength": 935,
      "domains": [
       {
        "start": 11,
        "end": 257,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GTP_EFTU",
        "accession": "PF00009",
        "description": "Elongation factor Tu GTP binding domain",
        "evalue": "8.3e-35",
        "score": "120.2"
       },
       {
        "start": 466,
        "end": 530,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_III",
        "accession": "PF14492",
        "description": "Elongation Factor G, domain III",
        "evalue": "1.6e-06",
        "score": "28.2"
       },
       {
        "start": 800,
        "end": 881,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_C",
        "accession": "PF00679",
        "description": "Elongation factor G C-terminus",
        "evalue": "1.9e-13",
        "score": "50.4"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001873",
      "seqLength": 313,
      "domains": [
       {
        "start": 9,
        "end": 99,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.6e-14",
        "score": "54.4"
       },
       {
        "start": 214,
        "end": 306,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.1e-16",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001874",
      "seqLength": 298,
      "domains": [
       {
        "start": 24,
        "end": 280,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "8.4e-51",
        "score": "173.1"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001875",
      "seqLength": 174,
      "domains": [
       {
        "start": 1,
        "end": 68,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation"
        ],
        "html_class": "generic-type-other",
        "name": "IF3_N",
        "accession": "PF05198",
        "description": "Translation initiation factor IF-3, N-terminal domain",
        "evalue": "1.4e-08",
        "score": "35.0"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001876",
      "seqLength": 349,
      "domains": [
       {
        "start": 109,
        "end": 313,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MFAP1",
        "accession": "PF06991",
        "description": "Microfibril-associated/Pre-mRNA processing",
        "evalue": "2.7e-61",
        "score": "207.4"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001877",
      "seqLength": 233,
      "domains": [
       {
        "start": 68,
        "end": 221,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TRAPP",
        "accession": "PF04051",
        "description": "Transport protein particle (TRAPP) component",
        "evalue": "2.3e-43",
        "score": "147.6"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001878",
      "seqLength": 340,
      "domains": [
       {
        "start": 57,
        "end": 300,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PP2C",
        "accession": "PF00481",
        "description": "Protein phosphatase 2C",
        "evalue": "2.9e-67",
        "score": "227.2"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001880",
      "seqLength": 434,
      "domains": [
       {
        "start": 38,
        "end": 209,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "DEAD",
        "accession": "PF00270",
        "description": "DEAD/DEAH box helicase",
        "evalue": "1e-42",
        "score": "146.0"
       },
       {
        "start": 253,
        "end": 362,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "3.1e-27",
        "score": "95.3"
       }
      ]
     },
     {
      "id": "MARS9BIN1_001881",
      "seqLength": 372,
      "domains": [
       {
        "start": 22,
        "end": 62,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "2.1e-13",
        "score": "49.9"
       },
       {
        "start": 77,
        "end": 106,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "2.8e-05",
        "score": "24.1"
       },
       {
        "start": 111,
        "end": 146,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "3.2e-05",
        "score": "23.9"
       },
       {
        "start": 152,
        "end": 189,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "7.2e-08",
        "score": "32.3"
       },
       {
        "start": 231,
        "end": 272,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "7.7e-06",
        "score": "25.9"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r565c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002212: 0-24132": {
       "start": 0,
       "end": 24132,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "Moror_6830",
         "query_loc": 3231,
         "subject_loc": 6315
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Moror_6828",
         "start": 0,
         "end": 1829,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6829",
         "start": 2868,
         "end": 3953,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6830",
         "start": 4555,
         "end": 8076,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "Moror_6831",
         "start": 9066,
         "end": 10354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6832",
         "start": 11230,
         "end": 13677,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6833",
         "start": 15289,
         "end": 22320,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6834",
         "start": 23263,
         "end": 24132,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001390: 100-19645": {
       "start": 100,
       "end": 19645,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "stbB",
         "query_loc": 3231,
         "subject_loc": 13908
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "stbA",
         "start": 100,
         "end": 6880,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "stbB",
         "start": 12255,
         "end": 15561,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "stbC",
         "start": 18643,
         "end": 19645,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002248: 5-21557": {
       "start": 5,
       "end": 21557,
       "links": [
        {
         "query": "MARS9BIN1_003810",
         "subject": "G4B84_005463",
         "query_loc": 1013,
         "subject_loc": 7079
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "G4B84_005461",
         "start": 5,
         "end": 2555,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005462",
         "start": 3433,
         "end": 4507,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005463",
         "start": 4857,
         "end": 9302,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS9BIN1_003810"
         }
        },
        {
         "locus_tag": "G4B84_005464",
         "start": 9906,
         "end": 11079,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005465",
         "start": 12403,
         "end": 13702,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005466",
         "start": 14789,
         "end": 15960,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005467",
         "start": 16880,
         "end": 17417,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005468",
         "start": 18341,
         "end": 21557,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000391: 0-14231": {
       "start": 0,
       "end": 14231,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "AFO85453.1",
         "query_loc": 3231,
         "subject_loc": 5456
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFO85452.1",
         "start": 0,
         "end": 732,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85453.1",
         "start": 1145,
         "end": 9767,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "AFO85454.1",
         "start": 9763,
         "end": 11110,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85455.1",
         "start": 11166,
         "end": 12291,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFO85456.1",
         "start": 12356,
         "end": 13109,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85457.1",
         "start": 13132,
         "end": 13654,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFO85458.1",
         "start": 13712,
         "end": 14231,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001923: 495-32413": {
       "start": 495,
       "end": 32413,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "ascB",
         "query_loc": 3231,
         "subject_loc": 5735
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ascA",
         "start": 2460,
         "end": 3471,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascB",
         "start": 4041,
         "end": 7429,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "ascC",
         "start": 8442,
         "end": 14991,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ascD",
         "start": 21832,
         "end": 23695,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascE",
         "start": 24090,
         "end": 27475,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascF",
         "start": 29468,
         "end": 30340,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ascG",
         "start": 30761,
         "end": 32413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascR",
         "start": 495,
         "end": 2085,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001242: 200-22183": {
       "start": 200,
       "end": 22183,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "fsr1",
         "query_loc": 3231,
         "subject_loc": 6292
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FF_03983",
         "start": 200,
         "end": 1988,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FF_03990",
         "start": 21002,
         "end": 22183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr1",
         "start": 2756,
         "end": 9828,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "fsr2",
         "start": 10365,
         "end": 11577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr3",
         "start": 11979,
         "end": 13642,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "fsr4",
         "start": 14540,
         "end": 15660,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr5",
         "start": 16277,
         "end": 17074,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr6",
         "start": 18534,
         "end": 19551,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002734: 207-20832": {
       "start": 207,
       "end": 20832,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "ATEG_03630",
         "query_loc": 3231,
         "subject_loc": 10377
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_03629",
         "start": 207,
         "end": 8079,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03630",
         "start": 8721,
         "end": 12033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "ATEG_03631",
         "start": 12583,
         "end": 14122,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03632",
         "start": 14269,
         "end": 15057,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03633",
         "start": 15351,
         "end": 16262,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03634",
         "start": 16995,
         "end": 17955,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03635",
         "start": 18454,
         "end": 20832,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001626: 0-40540": {
       "start": 0,
       "end": 40540,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "S40285_07611",
         "query_loc": 3231,
         "subject_loc": 26760
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "S40285_07604",
         "start": 0,
         "end": 780,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07605",
         "start": 3296,
         "end": 6609,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07606",
         "start": 7868,
         "end": 9422,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07607",
         "start": 9530,
         "end": 10584,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07608",
         "start": 11098,
         "end": 12173,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07609",
         "start": 13947,
         "end": 15018,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07610",
         "start": 17431,
         "end": 18293,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07611",
         "start": 25114,
         "end": 28406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "S40285_07612",
         "start": 33782,
         "end": 40540,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "S40285_10521",
         "start": 21198,
         "end": 22188,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002209: 560-36987": {
       "start": 560,
       "end": 36987,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "HK57_00646",
         "query_loc": 3231,
         "subject_loc": 2322
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "HK57_00646",
         "start": 560,
         "end": 4085,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "HK57_00647",
         "start": 4860,
         "end": 6224,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00648",
         "start": 7509,
         "end": 8544,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00649",
         "start": 9129,
         "end": 10830,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00650",
         "start": 11600,
         "end": 13002,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00651",
         "start": 14661,
         "end": 16570,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00652",
         "start": 17289,
         "end": 19202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00653",
         "start": 24279,
         "end": 26202,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00654",
         "start": 26967,
         "end": 28667,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00655",
         "start": 29830,
         "end": 36987,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001006: 0-25045": {
       "start": 0,
       "end": 25045,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "Strop_3056",
         "query_loc": 3231,
         "subject_loc": 4533
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "Strop_3055",
         "start": 0,
         "end": 858,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3056",
         "start": 968,
         "end": 8099,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "Strop_3057",
         "start": 8225,
         "end": 10187,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3058",
         "start": 10307,
         "end": 11786,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3059",
         "start": 12067,
         "end": 13639,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3060",
         "start": 13984,
         "end": 16006,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3061",
         "start": 16072,
         "end": 18913,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3062",
         "start": 19200,
         "end": 22035,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3063",
         "start": 22161,
         "end": 22443,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3064",
         "start": 22551,
         "end": 23478,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3065",
         "start": 23633,
         "end": 24278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3066",
         "start": 24472,
         "end": 25045,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002212: 0-24132": {
       "start": 0,
       "end": 24132,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "Moror_6830",
         "query_loc": 3231,
         "subject_loc": 6315
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Moror_6828",
         "start": 0,
         "end": 1829,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6829",
         "start": 2868,
         "end": 3953,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6830",
         "start": 4555,
         "end": 8076,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "Moror_6831",
         "start": 9066,
         "end": 10354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6832",
         "start": 11230,
         "end": 13677,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6833",
         "start": 15289,
         "end": 22320,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6834",
         "start": 23263,
         "end": 24132,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001390: 100-19645": {
       "start": 100,
       "end": 19645,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "stbB",
         "query_loc": 3231,
         "subject_loc": 13908
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "stbA",
         "start": 100,
         "end": 6880,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "stbB",
         "start": 12255,
         "end": 15561,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "stbC",
         "start": 18643,
         "end": 19645,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002248: 5-21557": {
       "start": 5,
       "end": 21557,
       "links": [
        {
         "query": "MARS9BIN1_003810",
         "subject": "G4B84_005463",
         "query_loc": 1013,
         "subject_loc": 7079
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "G4B84_005461",
         "start": 5,
         "end": 2555,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005462",
         "start": 3433,
         "end": 4507,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005463",
         "start": 4857,
         "end": 9302,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS9BIN1_003810"
         }
        },
        {
         "locus_tag": "G4B84_005464",
         "start": 9906,
         "end": 11079,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005465",
         "start": 12403,
         "end": 13702,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005466",
         "start": 14789,
         "end": 15960,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005467",
         "start": 16880,
         "end": 17417,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005468",
         "start": 18341,
         "end": 21557,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000391: 0-14231": {
       "start": 0,
       "end": 14231,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "AFO85453.1",
         "query_loc": 3231,
         "subject_loc": 5456
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AFO85452.1",
         "start": 0,
         "end": 732,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85453.1",
         "start": 1145,
         "end": 9767,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "AFO85454.1",
         "start": 9763,
         "end": 11110,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85455.1",
         "start": 11166,
         "end": 12291,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFO85456.1",
         "start": 12356,
         "end": 13109,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFO85457.1",
         "start": 13132,
         "end": 13654,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFO85458.1",
         "start": 13712,
         "end": 14231,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001923: 495-32413": {
       "start": 495,
       "end": 32413,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "ascB",
         "query_loc": 3231,
         "subject_loc": 5735
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ascA",
         "start": 2460,
         "end": 3471,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascB",
         "start": 4041,
         "end": 7429,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "ascC",
         "start": 8442,
         "end": 14991,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ascD",
         "start": 21832,
         "end": 23695,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascE",
         "start": 24090,
         "end": 27475,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascF",
         "start": 29468,
         "end": 30340,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ascG",
         "start": 30761,
         "end": 32413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascR",
         "start": 495,
         "end": 2085,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001242: 200-22183": {
       "start": 200,
       "end": 22183,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "fsr1",
         "query_loc": 3231,
         "subject_loc": 6292
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FF_03983",
         "start": 200,
         "end": 1988,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FF_03990",
         "start": 21002,
         "end": 22183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr1",
         "start": 2756,
         "end": 9828,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "fsr2",
         "start": 10365,
         "end": 11577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr3",
         "start": 11979,
         "end": 13642,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "fsr4",
         "start": 14540,
         "end": 15660,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr5",
         "start": 16277,
         "end": 17074,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr6",
         "start": 18534,
         "end": 19551,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002734: 207-20832": {
       "start": 207,
       "end": 20832,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "ATEG_03630",
         "query_loc": 3231,
         "subject_loc": 10377
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_03629",
         "start": 207,
         "end": 8079,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03630",
         "start": 8721,
         "end": 12033,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "ATEG_03631",
         "start": 12583,
         "end": 14122,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03632",
         "start": 14269,
         "end": 15057,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03633",
         "start": 15351,
         "end": 16262,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03634",
         "start": 16995,
         "end": 17955,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03635",
         "start": 18454,
         "end": 20832,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001626: 0-40540": {
       "start": 0,
       "end": 40540,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "S40285_07611",
         "query_loc": 3231,
         "subject_loc": 26760
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "S40285_07604",
         "start": 0,
         "end": 780,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07605",
         "start": 3296,
         "end": 6609,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07606",
         "start": 7868,
         "end": 9422,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07607",
         "start": 9530,
         "end": 10584,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07608",
         "start": 11098,
         "end": 12173,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07609",
         "start": 13947,
         "end": 15018,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07610",
         "start": 17431,
         "end": 18293,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "S40285_07611",
         "start": 25114,
         "end": 28406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "S40285_07612",
         "start": 33782,
         "end": 40540,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "S40285_10521",
         "start": 21198,
         "end": 22188,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002209: 560-36987": {
       "start": 560,
       "end": 36987,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "HK57_00646",
         "query_loc": 3231,
         "subject_loc": 2322
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "HK57_00646",
         "start": 560,
         "end": 4085,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "HK57_00647",
         "start": 4860,
         "end": 6224,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00648",
         "start": 7509,
         "end": 8544,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00649",
         "start": 9129,
         "end": 10830,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00650",
         "start": 11600,
         "end": 13002,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00651",
         "start": 14661,
         "end": 16570,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00652",
         "start": 17289,
         "end": 19202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00653",
         "start": 24279,
         "end": 26202,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00654",
         "start": 26967,
         "end": 28667,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "HK57_00655",
         "start": 29830,
         "end": 36987,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001006: 0-25045": {
       "start": 0,
       "end": 25045,
       "links": [
        {
         "query": "MARS9BIN1_003811",
         "subject": "Strop_3056",
         "query_loc": 3231,
         "subject_loc": 4533
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "Strop_3055",
         "start": 0,
         "end": 858,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3056",
         "start": 968,
         "end": 8099,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS9BIN1_003811"
         }
        },
        {
         "locus_tag": "Strop_3057",
         "start": 8225,
         "end": 10187,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3058",
         "start": 10307,
         "end": 11786,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3059",
         "start": 12067,
         "end": 13639,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3060",
         "start": 13984,
         "end": 16006,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3061",
         "start": 16072,
         "end": 18913,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3062",
         "start": 19200,
         "end": 22035,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3063",
         "start": 22161,
         "end": 22443,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3064",
         "start": 22551,
         "end": 23478,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3065",
         "start": 23633,
         "end": 24278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "Strop_3066",
         "start": 24472,
         "end": 25045,
         "strand": 1,
         "function": "regulatory",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_003811",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 29,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_003811",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 535,
        "terminalDocking": ""
       },
       {
        "name": "TD",
        "description": "TD",
        "modifier": false,
        "special": false,
        "cds": "MARS9BIN1_003811",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 655,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS9BIN1_003810": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1034:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS9BIN1_003811": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS9BIN1_003810",
      "seqLength": 487,
      "domains": [
       {
        "start": 34,
        "end": 426,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "1.8e-40",
        "score": "139.2"
       }
      ]
     },
     {
      "id": "MARS9BIN1_003811",
      "seqLength": 873,
      "domains": [
       {
        "start": 24,
        "end": 321,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.3e-36",
        "score": "126.3"
       },
       {
        "start": 536,
        "end": 606,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.3e-07",
        "score": "32.0"
       },
       {
        "start": 657,
        "end": 867,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "3.6e-39",
        "score": "134.6"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};

var recordData = [
 {
  "length": 192984,
  "seq_id": "scaffold_1",
  "regions": []
 },
 {
  "length": 183845,
  "seq_id": "scaffold_2",
  "regions": []
 },
 {
  "length": 175249,
  "seq_id": "scaffold_3",
  "regions": []
 },
 {
  "length": 171656,
  "seq_id": "scaffold_4",
  "regions": []
 },
 {
  "length": 156075,
  "seq_id": "scaffold_5",
  "regions": []
 },
 {
  "length": 145725,
  "seq_id": "scaffold_6",
  "regions": []
 },
 {
  "length": 123502,
  "seq_id": "scaffold_7",
  "regions": []
 },
 {
  "length": 122359,
  "seq_id": "scaffold_8",
  "regions": []
 },
 {
  "length": 120660,
  "seq_id": "scaffold_9",
  "regions": [
   {
    "start": 55904,
    "end": 76871,
    "idx": 1,
    "orfs": [
     {
      "start": 56215,
      "end": 56496,
      "strand": 1,
      "locus_tag": "MARS14BIN71_000715",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000715</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000715</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000715-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,215 - 56,496,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000715 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01910.20 (Thiamine-binding protein): [0:86](score: 83.4, e-value: 8.8e-24)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000715 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00106 (TIGR00106: uncharacterized protein, MTH1187 family): [0:88](score: 86.0, e-value: 4.8e-25)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000715\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGACCTCGTCGCCGTCCGTCACACAGCATGTGGCGCGAGTACAGGTCTACTTTTCCGAGTGCGCTGGCATTGAATTCCACATGCACTCCTACGGCACAACCATCGAAGGGGAGTGGGACGACGTGATGCGCGCCATTGGAGGCGCCCATCAGTGCCTGCACGAGGCGGGCGTCGTCCGGATTGCAAGCGATATACGCGTCGGCACACGCACTGACAAGGCACAGACGTCGCAGCAAAAGGTAGACAGCGTACAAGACTTTCTCGCCACAGACAAGTAG",
      "translation": "MGTSSPSVTQHVARVQVYFSECAGIEFHMHSYGTTIEGEWDDVMRAIGGAHQCLHEAGVVRIASDIRVGTRTDKAQTSQQKVDSVQDFLATDK",
      "product": "hypothetical protein"
     },
     {
      "start": 56551,
      "end": 57765,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000716",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000716</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000716</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000716-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,551 - 57,765,\n (total: 1215 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000716 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08202.14 (Mis12-Mtw1 protein family): [109:400](score: 165.2, e-value: 2.3e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000716 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000716\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAGAAATGAGCGGCCCGAGAAACGAAAGGCGCACGCCGTTGTAGATATCGAGCCTTCGCCAGATGCGCGCAAAAGGCGAACACAACCTGATCGCAAGGCGAGGAGAAGTCTACAAAATGAAGAGGATGATGGGTTTCAATTTGCGCGTGGGAAGGGAAAACCCCGAAATGATCAGCAACCTGGCGAGGCGAAAAGCGGGAAGCAGGCCACTCGAAGGAAGGTTGTAGACCTTTCCGATACTCCGAAAGGCGAGCGGTCAAATTCTTCGCATGGTAGCGGCGAGGGCTCGACGATGATGGATTCTGTGATCCCACTCTCGACCCGTGATACGCCTATGATTCGAAAGAACAAGGAGCTACGCCAGCAATCGCGTGCCGGAGGACACCGAAGAAGCAGCTCTGGTCTACGTGGGAAACGCGCGAGTTCCATTGGCAATGGTTTCAGGGCGGTCCCCCATCCTGATATCGATGCACGAGATTTCTACAAGCATATTGCCGACGATTTACCAGATCCACTTCGAATGCGACAGCTCCTTGCGTGGTGTGCGCGCCGGGCCTTCGATGAGCAAAAAGTGAGATTGGATGCTGCTCCGCCTGAGAAGGGCCAAGTGATGGATAGGAATGCAGCTACGATTGCACAAGTCGTGAAGCAGGAAGTGCTCATGGATTTGATTGAGAGTCGGATTGAAACGAGCTGGTACCATCGTCCTGAAGGACCACCCAAAACACCTACCAAACCCAATCCTCAAAACGAAGAGAACCGAGCAAAAATTGAACACTTGCAAACTGTCTTGGAGAGGCTGAGAACCGAGGAGCGACAGTGGAAGGCACTGATCACCAATCCGCCAACCTCACAAGCAACCATGACAAATGATAAAGATATCCAACCTGAGGACCTGTCCCTTCTGAGACCGAGGGAGCGAGCATTTTGGGAGAATGTACAGCAGCAGGATTCAAGGGATGCGGAGCGCGTCCAAGAATGGATGGGCGGGGAGGAGAGCAAGCTGGAGTTGCAAGTGGATAAGCTCTTTCATATGCTGCATTCCGTGCGCATGCTTGGAAAGGCAGCCGAGGGGTTCAGCGAGCAGGCGCTGTCCCAAGCTGCTGAGGCGTTTGATGCACGTCGTGAGCGTGCCCAGGAAGAGGCCCGCACAACAGATGTCTCACCGCGCGACATTCTCCGCACCCTGTCACGGCGATCGGATGTATAA",
      "translation": "MNRNERPEKRKAHAVVDIEPSPDARKRRTQPDRKARRSLQNEEDDGFQFARGKGKPRNDQQPGEAKSGKQATRRKVVDLSDTPKGERSNSSHGSGEGSTMMDSVIPLSTRDTPMIRKNKELRQQSRAGGHRRSSSGLRGKRASSIGNGFRAVPHPDIDARDFYKHIADDLPDPLRMRQLLAWCARRAFDEQKVRLDAAPPEKGQVMDRNAATIAQVVKQEVLMDLIESRIETSWYHRPEGPPKTPTKPNPQNEENRAKIEHLQTVLERLRTEERQWKALITNPPTSQATMTNDKDIQPEDLSLLRPRERAFWENVQQQDSRDAERVQEWMGGEESKLELQVDKLFHMLHSVRMLGKAAEGFSEQALSQAAEAFDARRERAQEEARTTDVSPRDILRTLSRRSDV",
      "product": "hypothetical protein"
     },
     {
      "start": 57998,
      "end": 61162,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000717",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000717</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000717</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000717-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,998 - 61,162,\n (total: 3099 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00168.33 (C2 domain): [51:153](score: 78.7, e-value: 3.6e-22)<br>\n \n  PF00168.33 (C2 domain): [248:346](score: 61.0, e-value: 1.2e-16)<br>\n \n  PF02666.18 (Phosphatidylserine decarboxylase): [778:986](score: 194.6, e-value: 1.4e-57)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00163 (PS_decarb: phosphatidylserine decarboxylase): [772:977](score: 123.1, e-value: 2.2e-36)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity<br>\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000717\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTATCGCCTCAAAGATCAAAGGGGCGATTGCGTCTCGAAACCCTTCGCGGCAGAATTCGAGATCGACAACGCCGCAGAGCGAATTGCAGCAGCCATCGCCGAAGAGGGCGGAGACCGGAAGTTCAATTGGCTCCGCAAAGGACTCCATCTACCTACGTGTGGAGGTGATCCAAGCGAGAAATCTCGCGCCTAAAGATCTGAATAAACAATCTGACCCGTATATTGTGGCACAGCTCGACGACTATCATGAGCAGTCTCATGCAGTTCAAAAAACACTCAATCCGGTGTGGAATCACCATTTTCAAATCCCAATTGATCCATCCATGCTGTCCTCGACATTGAAGCTGGTGTGTTGGGACAAGGACAGGTACGGTAAAGACTACATGGGTGAGATTGAAATCACTCTTGAAGAATTGCTGTCGGAAGACCGCGAGAAAGCACAATGGTTTCCGTTGGTATCGTCCAGGAATAGCAAGATCTCTGGTGAGGTTGAGCTAAGCTTCGGATTACACGATCCTCTAAGCCCGAATGCGACCTTTTCCGATCTTGTAAAGGAGTGGACGAGTATGCTTACGGATACATCAGAACTTGGTAGTGATGCTGATAATGACGATTCAGAGATCGACATTTCTGCTGATGCTACGCCGCAACAAAAGGCACGGAAGCGTAGACTGAGGCGAAGAAGGAAATTGCAAAAGCCTTATGAATTCACCCAAAACAAAGTGTCAGGAGTAGCTGGAATTGTCTATTTTGAGGTCACGTCGTGCTCGGATTTACCACCCGAGAGGAATGTGACTCGAACATCTTTCGATATGGATCCATTTGTGATCATCTCTTTTGGAAAGAAGACTTTACGAACAAAGTCTTTGCGCCATACTCTTAATCCTGTATTCAACGAGAAAATGATCTTTCAGGTGTTGATGTTTGAGCAAGCATATACAATCTCTCTGAGGGTTGTCGATAAAGATAAGTTTTCATCCAATGACTTTGTTGCAGAAGCTGTACTGGACGTAAAAGAATTGATCGATACCGGCCCGACTGCAAACAGCGAGACTGGCTTGTATGATTTACCTGATCCCGAAAGCAACCTACAGTTAACCAAGTCAAAACAATCGACGCTGTCTAAGAGCAATACCAGTGAGAGATTGCATCGAGCAGCGAGCAGTAATTCATTGTCACAAGCACAGCCTCAGAAAGTTACAAAGACTGAAACAAGTGTCGCTTCGTCGCTGAACGGGGAAGATGCGCAGTCGACTGAAGGAAGGACCATGGTTCCTCAACTAAGCGAATCTATCGACTATGATCTGAAAAGCTTTACACTCCCGCTAAATATGGCGAAAAAAGAGCGATGGGAGGAAAAGCACACTCCACAGATCAAGATCAAAGCGCGTTTTGTCCCATACCCTGCACTGCGGCAACAGTTTTGGAGATGTATGTTTCGTCAATATGATAGTGACGATACCGGGCGCATTAGTCGCGTGGAAATGACAACTATGTTGGATACTTTGGGCTCGACTCTCACTGACGCCAGCATCGACGAGCTTTTTGAGCGATATAATTTAGGAACTGACGCCAAGTCGAAGGACGAGTATGAAATGACAATAGACCAGGCAATTGTCTGTCTTGAAGAAGAACTTCGCAAAATCGATGCTACGATTCCAGCTGGAGGTGAAAAGACTCCATCTGATGACGAGGAAGACTCTGAGGTCACAGGAGATGCGCACTCCTTGTCAGAAAGCTCTGAATCCAATAACTTCAAGCCTCCGACAGTGTCTTTCAAAGGGACAGAGATTGCCAAGGATGAAATGTTGCATGATGAAGGCAGACGGGAGCATGTTATCGCGATCAAGGAATGTCCACTTTGCCACCAACCGCGGTTGAATAAGCGATCCGATACAGACATTATAACCCATCTCGCAACCTGTGCAAGTCAGGACTGGCGGAGTGTTGATCGAATAGTCATGGGAGATTTCGTTACATCGAGCCAAGCCCAACGCAAATGGTACTCTAAAGTGATATCGAAAGTAGGCTATGGCGGCTACCGGCTCGGAGCAAACTCTGCCAATATTCTGGTGCAAGATCGTTTGACAGGCCAGATCCAGGAAGAGCGCATGAGTATTTATGTGCGCTTGGGCATACGCCTCTTCTACAAAGGATTGAAGAGTGGGGAAATGGAGAAGAAACGGATGCGCCGTCTGCTCTACTCGTTGAGCGTGAAGCAAGGACGCAAGTATGACGCTCCGCCTTCTGCTCGAGACATCAAGAGTTTCATTGCATTTCACAAGCTTAATATGGCTGAGGTGAAGCTACCGATTGAACAGTTCCAGACCTTCAACCAGTTCTTTTACCGCGAGTTGAAACCTGACGCAAGGCCCTGTACAGCACCGGACAATCACTGGATTGCAGTATCCCCAGCAGATTGCCGATGCGTTCTTTTCGATCGGGTTGATAAGGCTAGCGAAATCTGGGTCAAAGGCCGAGATTTCTCCGTGGCCCGATTGCTTGGCAGTGCGTATCCTGAGGATGCCGCAAAGTTCGAGAACGGATCCATTGGCATATTCCGCTTGGCACCACAAGATTACCATCGCTTCCACTGTCCGGTGGAGGGAGTCCTGCAGGAACCCAAAACGATTGATGGTCAGTACTACACGGTCAATCCGATGGCTGTCCGCTCCTCGCTGGATGTATTTGGCGAGAATGTCCGAGTGGTCTGCCCCATCGACTCCGAGGCGTTTGGGCGCGTGATGGTTGTGTGCATTGGAGCTATGATGGTGGGTAGCACTGTCATCACTGCCAAGACCGGCAGTAAGCTGTCTAGAACCCAAGAACTCGGGTACTTCAAATTTGGCGGAAGCACCCTTGTAGTCTTGTTTCAGCCAGGCAAGCTGAAATTTGACGATGACGTTGTGGGCAACTCGAAATCTTCACTCGAGACGCTGATGCGTGTAGGCATGTCTATTGGCCACCATCCGCAAGAGCCGTCCCAAGCACCTAGCAAGAAGGACCGTGAGAACGCCACACTGGAAGATCGCCAACGTGCAAGTATTGCAATTGGTGGAAGTCTGAAGCCGCCACGTGGTTTAGAACAAGATTAG",
      "translation": "MTIASKIKGAIASRNPSRQNSRSTTPQSELQQPSPKRAETGSSIGSAKDSIYLRVEVIQARNLAPKDLNKQSDPYIVAQLDDYHEQSHAVQKTLNPVWNHHFQIPIDPSMLSSTLKLVCWDKDRYGKDYMGEIEITLEELLSEDREKAQWFPLVSSRNSKISGEVELSFGLHDPLSPNATFSDLVKEWTSMLTDTSELGSDADNDDSEIDISADATPQQKARKRRLRRRRKLQKPYEFTQNKVSGVAGIVYFEVTSCSDLPPERNVTRTSFDMDPFVIISFGKKTLRTKSLRHTLNPVFNEKMIFQVLMFEQAYTISLRVVDKDKFSSNDFVAEAVLDVKELIDTGPTANSETGLYDLPDPESNLQLTKSKQSTLSKSNTSERLHRAASSNSLSQAQPQKVTKTETSVASSLNGEDAQSTEGRTMVPQLSESIDYDLKSFTLPLNMAKKERWEEKHTPQIKIKARFVPYPALRQQFWRCMFRQYDSDDTGRISRVEMTTMLDTLGSTLTDASIDELFERYNLGTDAKSKDEYEMTIDQAIVCLEEELRKIDATIPAGGEKTPSDDEEDSEVTGDAHSLSESSESNNFKPPTVSFKGTEIAKDEMLHDEGRREHVIAIKECPLCHQPRLNKRSDTDIITHLATCASQDWRSVDRIVMGDFVTSSQAQRKWYSKVISKVGYGGYRLGANSANILVQDRLTGQIQEERMSIYVRLGIRLFYKGLKSGEMEKKRMRRLLYSLSVKQGRKYDAPPSARDIKSFIAFHKLNMAEVKLPIEQFQTFNQFFYRELKPDARPCTAPDNHWIAVSPADCRCVLFDRVDKASEIWVKGRDFSVARLLGSAYPEDAAKFENGSIGIFRLAPQDYHRFHCPVEGVLQEPKTIDGQYYTVNPMAVRSSLDVFGENVRVVCPIDSEAFGRVMVVCIGAMMVGSTVITAKTGSKLSRTQELGYFKFGGSTLVVLFQPGKLKFDDDVVGNSKSSLETLMRVGMSIGHHPQEPSQAPSKKDRENATLEDRQRASIAIGGSLKPPRGLEQD",
      "product": "hypothetical protein"
     },
     {
      "start": 61375,
      "end": 62502,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000718",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000718</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000718</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000718-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,375 - 62,502,\n (total: 1128 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000718 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [15:266](score: 295.4, e-value: 3.1e-88)<br>\n \n  PF08669.14 (Glycine cleavage T-protein C-terminal barrel domain): [292:369](score: 67.5, e-value: 7.5e-19)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000718 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [11:370](score: 382.3, e-value: 4.7e-115)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000718\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000718-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGACGGTACGCCACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACGGTGTTGCAGCAGTTTGGGGAAGGAGTAAAACGTCGGCGCATTGGACTCACAGTCGAAGGAGCGCCCGCCCGCTCGGCTGCCCCTATTGAGTCCGAGAAACAAGATGTTGGAGTCGTGACAAGCGGGTGCCCATCGCCAACAACCGGGACCAATATTGCCATGGGGTATATTACGCACGGGTTGCACAAGTCTGGCACTGAGATCGCGGTCAAAGTGAGGGGCAGGGAACGGAAAGCCATTGTCACCAAAATGCCCTTTGTGCAGACCAAGTACTATAAATAA",
      "translation": "MRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQTVLQQFGEGVKRRRIGLTVEGAPARSAAPIESEKQDVGVVTSGCPSPTTGTNIAMGYITHGLHKSGTEIAVKVRGRERKAIVTKMPFVQTKYYK",
      "product": "hypothetical protein"
     },
     {
      "start": 62726,
      "end": 63763,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000719",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000719</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000719</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000719-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,726 - 63,763,\n (total: 1038 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000719 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 89.3, e-value: 4.6e-25)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000719 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 95.5, e-value: 9.5e-28)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 65.4, e-value: 1.4e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000719\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATCTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCCAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGACGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGGTTATTGCAAGGACGCCAGTGGAGGAGCGGATGTATTACTGGCCCGAATTTAGCAGTGTGCCTCGTAATGCCACTGCTATACGATGA",
      "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMVIARTPVEERMYYWPEFSSVPRNATAIR",
      "product": "hypothetical protein"
     },
     {
      "start": 65064,
      "end": 65789,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000720",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000720</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000720</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000720-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,064 - 65,789,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000720 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000720\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
      "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
      "product": "hypothetical protein"
     },
     {
      "start": 65904,
      "end": 66871,
      "strand": 1,
      "locus_tag": "MARS14BIN71_000721",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000721</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000721</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000721-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,904 - 66,871,\n (total: 948 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 233.7; E-value: 4.1e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000721 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 224.9, e-value: 9.5e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000721 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000721\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000721-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGCTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGATCCTTAA",
      "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNAWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGDP",
      "product": "hypothetical protein"
     },
     {
      "start": 67009,
      "end": 67803,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000722",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000722</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000722</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000722-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,009 - 67,803,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000722 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [186:250](score: 47.7, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000722\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGGTCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
      "translation": "MIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
      "product": "hypothetical protein"
     },
     {
      "start": 68082,
      "end": 68348,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000723",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000723</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000723</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000723-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,082 - 68,348,\n (total: 267 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000723\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGAAGGAGGAGGACAGGGAGGAGCGAGAGAGGGAGGAAGCGTTCTCGTATGAGTACTCCCCGGAAGAGCTGACGAGGCGCTTTCTGAACCAGCAGTCATCTGAGTCGACTGTGCATGTATCAACTCCGGCACACGATGAAGGGCCTTGCATTTCATTTCATGTGGAGCAGAAGCCCAACAGCAACCAGGTCAGGCTGGTGCCGAATACCTACATTGAAGACGACGGACCCGCGTGGAGAAATACCCGCGTGGCCACGGAATGA",
      "translation": "MAKEEDREEREREEAFSYEYSPEELTRRFLNQQSSESTVHVSTPAHDEGPCISFHVEQKPNSNQVRLVPNTYIEDDGPAWRNTRVATE",
      "product": "hypothetical protein"
     },
     {
      "start": 68600,
      "end": 69374,
      "strand": 1,
      "locus_tag": "MARS14BIN71_000724",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000724</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000724</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000724-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,600 - 69,374,\n (total: 738 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000724 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01738.21 (Dienelactone hydrolase family): [34:231](score: 46.1, e-value: 4.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000724 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01738.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000724\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000724-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTGACAAATGCTGCCCCTCAGACCTCCCTGCTTTTCAGAGCGACTACAAGCCTCTCGGCCAGACAGTCAAGCTGACAAAGGCGGCGGGCCGTGCATTAGAGACGTACGTGTATCAGCCAGGCGGGAAGGTTGAGCTGGGAATCATCTACTATGCCGACGTCTTTGGCCTCTTGCCCAATGCTCTACAAGGGGCAGACTTGCTGGCAAGGAGTCTAAATGCGCGAGTGTACGTGCCAGACCTCTACGAAGGTCAGCCGTGGGAAACGTCCAATATGCCGCCAAAGGAAGGCTATGAAGCAATGTTTGCCCACTTCGGTAAAGTGGCGCCTCCTGAAAAAATCCGTGAGCTCACAATTGAATTGATCGAGCAACTCCGGGGAGATGGCATTGAACGGGTGGGCGCAATTGGGTTTTGTTTAGGCGCCAAACTCCTTGCAGCAAATTCCGCACTTGTAGGTGCCACAGCCTATATTCATCCGTCAGGCTTCACTGTTGAGGAAGCGAAAGGCTATCGTGGACCGGTCGCTCTCCTTCCATCACAGGACGAGGACAAAGAGCTCATGAAAAACTTTTGGGCAGCTCTCTCAGAGACCGCAAAGAAGGATGGCGTCTTCCAGACCTTCCCTGTCCATCACGGCTTTGCAGCAGGAAGATCAGACTGGAATGACCCTGAGCTTGGCAAGCATGCCCACGAGGCTTTTGAGCTTGCTGCATCAGTCCTGGCAAAGGCCTGA",
      "translation": "MSDKCCPSDLPAFQSDYKPLGQTVKLTKAAGRALETYVYQPGGKVELGIIYYADVFGLLPNALQGADLLARSLNARVYVPDLYEGQPWETSNMPPKEGYEAMFAHFGKVAPPEKIRELTIELIEQLRGDGIERVGAIGFCLGAKLLAANSALVGATAYIHPSGFTVEEAKGYRGPVALLPSQDEDKELMKNFWAALSETAKKDGVFQTFPVHHGFAAGRSDWNDPELGKHAHEAFELAASVLAKA",
      "product": "hypothetical protein"
     },
     {
      "start": 69492,
      "end": 70838,
      "strand": 1,
      "locus_tag": "MARS14BIN71_000725",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000725</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000725</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000725-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 69,492 - 70,838,\n (total: 1347 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000725 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05743.16 (UEV domain): [24:142](score: 112.9, e-value: 8.3e-33)<br>\n \n  PF09454.13 (Vps23 core domain): [377:440](score: 79.5, e-value: 1.5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000725 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport<br>\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000725\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCAACCAGAAGTCGCGCAATGGCTCCAACGAGTCGTCTCTCGAGACTACTCGGACAAGAAACGAGTGTATGGGGATGTCATCGACCTCTTGACGCGCTACCCGTCATTATCTCCCCGCACCAAAGTGTTCTCCTTTGAAGACGGGCGGTCAGAGCTCTTGCTTTGCATTCACGGCACGCTACCGGTACGATTTCGAAATGCAGACTACAACACGCCAATCACTCTGTGGGTAGACAAGGTATACCCTGTGTCACGTCCTTTGGCATTTGTCACTCCTTCTCCGGAAATGGGTATTCGCGCAGGGAATCACGTAGACCCAAATGGTGCCATCTACCACCCCTTATTGGCGTACTGGGATGCGAAAAAGACAATAGTGGAGCTCGCAGAGCTGTTACGTGAAGTCTTTGGTGCCGAAATGCCAGCATATGCACGCACGGCGAAACAAAATGGAGACAAGGATTTCTACGGCTCCACTTCTCCTCCCCCGCCTCCTCTACCCCCAGCCCCTCACCGAGCAAACTCACCTACTTCTCCAATTCATCCCTCTTCACCCATACCACCACCTCGGCCAAACTACAACGCACCTCCACCGAAACCACCTTTACCTCCACGACTTCAGCCAGGCCCTTCTACCGCATACTCAACTTCTCCAACACCTCCATCACCTCGTGAGTACAGCCCATCTTTCGAGAGACCGCCTACCACACAACTACAACCCAGACCGTCCTCTACACAGTTACCGCCCTCATGGCAAGCTCCAGCACGGCGGCCATCGCCGACACGGCCAACGATAGATATTCTAGATCTCCAGGACGCACTACCTGCAACCTCTGCACCTCCGCTACCCGAGAACCCGGCTCGAAGGGCCCAATTTGAAGAACTAAATAAACGCTTATGCCGTCGAGCGGAGACGTCCACTGAAAAGACTACGACGATGCTGGAGTCAGCCAAGCAAGTTCGCGAGCGGCTTGTTGCTACCGAAACTAGGCTGGAGCTCGAGACCAGCGAACTCCGGCGAATTGAAGAAGCATGCACGCGGGATACTGCGATTCTGCAGGAGCGGATCAATGCTGCAGAGGGAGTCACGAGGGATGCACTTCAATCAGACGAAGTAGACATCGACAAGATCCTCGTCGGATCGAGAGTCGTATACAACCAAATCTACGATCTCGTCTGCGCCGACTTGGCAATTGACGATACGATCTACGCGTTGGGGATAGCGCACGAGCGGGAATGCATCACGTTTGATGTCTTTCTGCGGCATGTCCGCATCCTCGCTCGAGAGCAATTCCTCAAGAAGGCACTGCTGGCAAAGATTAGGGAGCAGACCAAGCTCCAATAA",
      "translation": "MLQPEVAQWLQRVVSRDYSDKKRVYGDVIDLLTRYPSLSPRTKVFSFEDGRSELLLCIHGTLPVRFRNADYNTPITLWVDKVYPVSRPLAFVTPSPEMGIRAGNHVDPNGAIYHPLLAYWDAKKTIVELAELLREVFGAEMPAYARTAKQNGDKDFYGSTSPPPPPLPPAPHRANSPTSPIHPSSPIPPPRPNYNAPPPKPPLPPRLQPGPSTAYSTSPTPPSPREYSPSFERPPTTQLQPRPSSTQLPPSWQAPARRPSPTRPTIDILDLQDALPATSAPPLPENPARRAQFEELNKRLCRRAETSTEKTTTMLESAKQVRERLVATETRLELETSELRRIEEACTRDTAILQERINAAEGVTRDALQSDEVDIDKILVGSRVVYNQIYDLVCADLAIDDTIYALGIAHERECITFDVFLRHVRILAREQFLKKALLAKIREQTKLQ",
      "product": "hypothetical protein"
     },
     {
      "start": 71639,
      "end": 73111,
      "strand": -1,
      "locus_tag": "MARS14BIN71_000726",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000726</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000726</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000726-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,639 - 73,111,\n (total: 1473 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1139:aminotransferase class V (Score: 313.6; E-value: 2.9e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00266.22 (Aminotransferase class-V): [92:455](score: 297.3, e-value: 1.6e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000726\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000726-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTGGTGTGGCCCATTACTCGTATCAATTTTTATCACATCGTCATCAATCAAACTCAACCCATGAGGCAAGCGCTGTGTGGAAGAGCTTTCAATACTAGTGCGCCGCGTTATGCCAACGTGCTCTACAAGAGGACCAGCTGTGCTCGCACCTGGTGCGCTGCAACCTATGTGACGCAAAGCAAACCCGCCGAAGCAGCTATCGTTGAATCGAAGCTGCCGCATGGCACGGGAATCCTGAAGCAAACCGTCGAGCCCAAGGCAGAAGGTCGCCCAATCTACTTGGACATGCAGGCTACTACGCCGTTGGATCCACGCGTGCTTGACATCATGCTGCCGTTCATGACTGGAATGTATGGAAATCCTCATTCGAGGACACATGCATATGGATGGGAGACGAATGAAGCGAGCGAGATAGCACGCACGCACGTTGCAAATCTTATTGGAGCGGATCCAAAGGAAATCATCTTCACCTCCGGTGCCACCGAGTCGAACAATATGAGTATCAAGGGAGTAGCTCGATTTTACAAAGGGACAAAAAATCACATCATCACCTGCCAAACAGAACACAAATGCGTGCTGGATTCATGCAGACATTTGCAAAATGAGGGTTTTGATGTCACCTACCTCCCCGTTCAACAGAACGGCTTAATCTCGCTCGAGCAGTTGGAGAAGGAGATTCGACCGGATACGGCTCTAGTGTCCATCATGGCTGTAAACAATGAAATTGGAGTCATTCAGCCGATCGATGAGATTGGCCGATTGTGCCGGAAGAATAAGATCTTTTTCCACACCGACGCTGCACAAGCTGTTGGGAAGATCTGTATGGATGTAAACAAATCCAACATTGATCTCATGTCTATCTCGAGTCATAAGATATATGGTCCCAAGGGCATGGGTGCATGTTATGTGCGGAGACGCCCGCGAGTGCGTCTCGATCCCATTATCTCTGGTGGCGGCCAAGAAAGAGGTTTACGAAGCGGCACGCTCGCGCCTAATCTAGTCGTCGGCTTTGGAGAGGCGTCGCGTCTTGCATTGCAAGAATTCCCCTATGACGAAAAAAGAATCAAAAGCCTGTCAGATCGTTTGGTCAATGGTCTACTTGCCCTTGATCACGTTCATCAAAATGGTGCCCCTGATCGATTCTACCCTGGATGTGTCAATATGTCATTCGCCTATGTCGAGGGCGAATCTCTATTGATGGCACTGAAGGACATTGCTCTCAGCTCCGGTTCCGCCTGCACGTCTGCCTCACTGGAGCCTTCCTATGTGCTGCGGGCTCTAGGCGCTGCGGACGACATGGCCCATTCTTCCATTCGGTTCGGTCTTGGACGGTTCACTACCGAAGACGAGGTGGAGTATGTATTAAAGGCGGTCCGTGATCGCGTGACTTGGCTTCGCGATATGTCTCCGCTTTATGAAATGGTGCAGGATGGAATCGACCTGAAATCAATCCAATGGAGTCAACATTGA",
      "translation": "MVVWPITRINFYHIVINQTQPMRQALCGRAFNTSAPRYANVLYKRTSCARTWCAATYVTQSKPAEAAIVESKLPHGTGILKQTVEPKAEGRPIYLDMQATTPLDPRVLDIMLPFMTGMYGNPHSRTHAYGWETNEASEIARTHVANLIGADPKEIIFTSGATESNNMSIKGVARFYKGTKNHIITCQTEHKCVLDSCRHLQNEGFDVTYLPVQQNGLISLEQLEKEIRPDTALVSIMAVNNEIGVIQPIDEIGRLCRKNKIFFHTDAAQAVGKICMDVNKSNIDLMSISSHKIYGPKGMGACYVRRRPRVRLDPIISGGGQERGLRSGTLAPNLVVGFGEASRLALQEFPYDEKRIKSLSDRLVNGLLALDHVHQNGAPDRFYPGCVNMSFAYVEGESLLMALKDIALSSGSACTSASLEPSYVLRALGAADDMAHSSIRFGLGRFTTEDEVEYVLKAVRDRVTWLRDMSPLYEMVQDGIDLKSIQWSQH",
      "product": "hypothetical protein"
     },
     {
      "start": 74237,
      "end": 76035,
      "strand": 1,
      "locus_tag": "MARS14BIN71_000727",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000727</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000727</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000727-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 74,237 - 76,035,\n (total: 906 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000727\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGAGGCTTTGGCAGATGGCAACAGCAACTCGACTGACTTGTCAGCTCCCGAATGTATTCCCGGAACTGTAAGTACCAAAACAGTGACAGCAACGACCTTTGTTATAGTTGATGGACTTGCACATAGCATTTCAGAGGTTCCTCAAATAGCCAGTGCCACCAAAGAATATGCAACAGCCACAGACTCTGTCGCAGTGACAATTGAGACATCAGCAATTGAGGATCCGGTAAATCAAAGCACACAAGATTACAACGAAAAGCCCCTTCGAGAAAATATGCACCCCACTGAGAAGTCTGTTATAACGTCTGCAATGACCATTCCAGGAACTAGTTCTCACACGGGAATGCTTCACGGATCCCAGGCAACACCAGTGTCCGCTATTGCTCGAAACAATGACGTCGGTCCTGACACAGAGGACCCGTTTTGGCAGACTCCCTTCACAAAAGATCTTTTGAAAGATCCCTGGTCACCAGAAAACTGGAGAGAGGGAGGTAATCGAGCAGCTCAGGTTTCTATGTCTGAAGGCACTGCTGGAAGCTTAGGCATGGAGCCTACAACTGAGTTCGTTTCATTTTGTCCAGAAGTGACTACTGGTGTTATGGTCCCACAAACGCTCAATTCTTCGGAGCCAAAGTTATCAACAGTACCAAGCCTAGTGGGCCACGAGGAAGCCCAGAAACCAAAATATTTTTCAGTAGCTCATATGCACCCTACCGAGCAATGTATGCGGAATTGCTCCATGAACCACGACTATTGGACCGATTGCATTGAGCATGCCATTATGTCCCCAGCTCACGATAAATGTGCTCTGGCTAGTATAGGAAAAGCAAACGATTGCTGCTTGACAAAGTGCCAGCACGAATGCAGCCACATTTCAGACTTTCTTGACTTCTACAAATAG",
      "translation": "MQEALADGNSNSTDLSAPECIPGTVSTKTVTATTFVIVDGLAHSISEVPQIASATKEYATATDSVAVTIETSAIEDPVNQSTQDYNEKPLRENMHPTEKSVITSAMTIPGTSSHTGMLHGSQATPVSAIARNNDVGPDTEDPFWQTPFTKDLLKDPWSPENWREGGNRAAQVSMSEGTAGSLGMEPTTEFVSFCPEVTTGVMVPQTLNSSEPKLSTVPSLVGHEEAQKPKYFSVAHMHPTEQCMRNCSMNHDYWTDCIEHAIMSPAHDKCALASIGKANDCCLTKCQHECSHISDFLDFYK",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 65903,
      "end": 66871,
      "tool": "rule-based-clusters",
      "neighbouring_start": 55903,
      "neighbouring_end": 76871,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r9c1"
   }
  ]
 },
 {
  "length": 116993,
  "seq_id": "scaffold_10",
  "regions": []
 },
 {
  "length": 115199,
  "seq_id": "scaffold_11",
  "regions": []
 },
 {
  "length": 104718,
  "seq_id": "scaffold_12",
  "regions": []
 },
 {
  "length": 103341,
  "seq_id": "scaffold_13",
  "regions": []
 },
 {
  "length": 101852,
  "seq_id": "scaffold_14",
  "regions": []
 },
 {
  "length": 95325,
  "seq_id": "scaffold_15",
  "regions": []
 },
 {
  "length": 92580,
  "seq_id": "scaffold_16",
  "regions": []
 },
 {
  "length": 90880,
  "seq_id": "scaffold_17",
  "regions": []
 },
 {
  "length": 90071,
  "seq_id": "scaffold_18",
  "regions": []
 },
 {
  "length": 86215,
  "seq_id": "scaffold_19",
  "regions": []
 },
 {
  "length": 84456,
  "seq_id": "scaffold_20",
  "regions": []
 },
 {
  "length": 84084,
  "seq_id": "scaffold_21",
  "regions": []
 },
 {
  "length": 82419,
  "seq_id": "scaffold_22",
  "regions": []
 },
 {
  "length": 81067,
  "seq_id": "scaffold_23",
  "regions": []
 },
 {
  "length": 80381,
  "seq_id": "scaffold_24",
  "regions": []
 },
 {
  "length": 79802,
  "seq_id": "scaffold_25",
  "regions": []
 },
 {
  "length": 78258,
  "seq_id": "scaffold_26",
  "regions": []
 },
 {
  "length": 77621,
  "seq_id": "scaffold_27",
  "regions": []
 },
 {
  "length": 76200,
  "seq_id": "scaffold_28",
  "regions": []
 },
 {
  "length": 74484,
  "seq_id": "scaffold_29",
  "regions": []
 },
 {
  "length": 72506,
  "seq_id": "scaffold_30",
  "regions": []
 },
 {
  "length": 71972,
  "seq_id": "scaffold_31",
  "regions": []
 },
 {
  "length": 70580,
  "seq_id": "scaffold_32",
  "regions": []
 },
 {
  "length": 68453,
  "seq_id": "scaffold_33",
  "regions": []
 },
 {
  "length": 67434,
  "seq_id": "scaffold_34",
  "regions": []
 },
 {
  "length": 66547,
  "seq_id": "scaffold_35",
  "regions": []
 },
 {
  "length": 65512,
  "seq_id": "scaffold_36",
  "regions": []
 },
 {
  "length": 64778,
  "seq_id": "scaffold_37",
  "regions": []
 },
 {
  "length": 64634,
  "seq_id": "scaffold_38",
  "regions": []
 },
 {
  "length": 64162,
  "seq_id": "scaffold_39",
  "regions": []
 },
 {
  "length": 63415,
  "seq_id": "scaffold_40",
  "regions": [
   {
    "start": 5421,
    "end": 26364,
    "idx": 1,
    "orfs": [
     {
      "start": 8277,
      "end": 10989,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002019",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002019</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002019</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002019-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,277 - 10,989,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002019 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.3e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 55.3, e-value: 6.4e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002019\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACGATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGTTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTAAGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTCGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGAATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAGGCAGCCAGATTTAGGCTCTTCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCGGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGTGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAAATTTTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTTCACATATTGGAAAGCTCTATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAAGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAGTTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
      "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKRQPDLGSSLLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVVMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKKFFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKSVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSSFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
      "product": "hypothetical protein"
     },
     {
      "start": 11090,
      "end": 14356,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002020",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002020</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002020</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002020-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,090 - 14,356,\n (total: 3159 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:315](score: 195.2, e-value: 8.7e-58)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [583:647](score: 28.0, e-value: 1.8e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [917:998](score: 50.2, e-value: 2.2e-13)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 49.9, e-value: 7e-14)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002020\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATGTTTGTCCAATTCGTACTCGAAAACATATGGGCGGTTTATGATTGTACAATTATCCGAAAGGACCCAATAAAAATAGATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCCAGCGTTGGAATGAATCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCGTAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTGGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTCATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
      "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPMFVQFVLENIWAVYDCTIIRKDPIKIDKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSVSGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
      "product": "hypothetical protein"
     },
     {
      "start": 14426,
      "end": 15367,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002021",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002021</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002021</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002021-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,426 - 15,367,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002021 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002021\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
      "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
      "product": "hypothetical protein"
     },
     {
      "start": 15421,
      "end": 16364,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002022",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002022</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002022</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002022-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,421 - 16,364,\n (total: 912 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002022 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [29:285](score: 173.0, e-value: 8.9e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002022 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002022\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTGTGAAACGAATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
      "translation": "MLVKRMSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
      "product": "hypothetical protein"
     },
     {
      "start": 16714,
      "end": 17238,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002023",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002023</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002023</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002023-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,714 - 17,238,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002023 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.7, e-value: 8.6e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002023 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002023\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAGGACATAAAGTGTAATGAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAACGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
      "translation": "MDEDIKCNEVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
      "product": "hypothetical protein"
     },
     {
      "start": 17942,
      "end": 18991,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002024",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002024</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002024</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002024-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,942 - 18,991,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002024 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 208.0, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002024\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
      "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
      "product": "hypothetical protein"
     },
     {
      "start": 19033,
      "end": 19734,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002025",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002025</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002025</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002025-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,033 - 19,734,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002025 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002025\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
      "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
      "product": "hypothetical protein"
     },
     {
      "start": 20261,
      "end": 21283,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002026",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002026</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002026-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,261 - 21,283,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002026 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002026\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCGGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACAGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
      "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
      "product": "hypothetical protein"
     },
     {
      "start": 21338,
      "end": 21778,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002027",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002027</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002027</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002027-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,338 - 21,778,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002027\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
      "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
      "product": "hypothetical protein"
     },
     {
      "start": 22551,
      "end": 23855,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002028",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002028</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002028</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002028-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,551 - 23,855,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325; E-value: 1.4e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002028 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.8, e-value: 2.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002028 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002028\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002028-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGTAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCATGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
      "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTVEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVMAMDKEQVKRKRKLRAG",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 15420,
      "end": 16364,
      "tool": "rule-based-clusters",
      "neighbouring_start": 5420,
      "neighbouring_end": 26364,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r40c1"
   }
  ]
 },
 {
  "length": 63193,
  "seq_id": "scaffold_41",
  "regions": []
 },
 {
  "length": 61564,
  "seq_id": "scaffold_42",
  "regions": []
 },
 {
  "length": 61454,
  "seq_id": "scaffold_43",
  "regions": []
 },
 {
  "length": 59126,
  "seq_id": "scaffold_44",
  "regions": []
 },
 {
  "length": 57236,
  "seq_id": "scaffold_45",
  "regions": []
 },
 {
  "length": 56209,
  "seq_id": "scaffold_46",
  "regions": []
 },
 {
  "length": 55586,
  "seq_id": "scaffold_47",
  "regions": []
 },
 {
  "length": 55257,
  "seq_id": "scaffold_48",
  "regions": []
 },
 {
  "length": 55127,
  "seq_id": "scaffold_49",
  "regions": []
 },
 {
  "length": 53389,
  "seq_id": "scaffold_50",
  "regions": []
 },
 {
  "length": 52732,
  "seq_id": "scaffold_51",
  "regions": []
 },
 {
  "length": 52681,
  "seq_id": "scaffold_52",
  "regions": [
   {
    "start": 15683,
    "end": 37295,
    "idx": 1,
    "orfs": [
     {
      "start": 16031,
      "end": 18746,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002405",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002405</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002405</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002405-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,031 - 18,746,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002405 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [8:195](score: 129.6, e-value: 1e-37)<br>\n \n  PF00106.28 (short chain dehydrogenase): [313:496](score: 146.2, e-value: 8.9e-43)<br>\n \n  PF01575.22 (MaoC like domain): [769:879](score: 113.0, e-value: 6.8e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002405\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002405-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCGATCTACGGTTCGATGACCAGGTAGTCGTAGTCACTGGTGCTGGTGGAGGCTTGGGCAAGGCGTACGCGCTTTTCTTCGCCAGCCGAGGTGCGAACGTGGTTGTTAATGATTTGGGTGGCAGCTTTCACGGAGAAGGACAGAGCTCAAAGGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCATGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGCATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGTAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCCCTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAGAAGACTCAGAGAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTATTGAAAATATAAGTAATCGTTCCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTGTTTGAAGGCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTGAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
      "translation": "MPDLRFDDQVVVVTGAGGGLGKAYALFFASRGANVVVNDLGGSFHGEGQSSKAADLVVDEIKKAGGHAVADYNNVQNGDQIIETAVKAFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQRMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIIENISNRSGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEGSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
      "product": "hypothetical protein"
     },
     {
      "start": 18858,
      "end": 20968,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002406",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002406</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002406</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002406-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,858 - 20,968,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002406 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:339](score: 57.8, e-value: 1.4e-15)<br>\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [366:569](score: 290.8, e-value: 5.4e-87)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002406 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002406\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCCGTCTCGCCTGAAATCGCCAAACGTGTCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACGTTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTCGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAAACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGCGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGGCATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
      "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRVEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKTLATTSLALSLCLVCGVVAQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
      "product": "hypothetical protein"
     },
     {
      "start": 21067,
      "end": 24899,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002407",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002407</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002407</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002407-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,067 - 24,899,\n (total: 3702 nt, excluding introns)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 54.7; E-value: 1.2e-16)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002407 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [131:159](score: 22.3, e-value: 0.00019)<br>\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [1075:1199](score: 115.0, e-value: 2.7e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002407 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002407\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGAGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGTGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGCTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGGAATCTATCGCATTCTGTTGCTCGTATCACGCACGATCTTGTTGCAGCCTCCTTCTCTCTTGTTGGTGTCGCGTTGATCTTCGTAGTCCACGTACGTGTTGGTAGCCGCAGGCAAAACATGAATAGACCACCCTCTATCCATCCACATATCAGACCGGCGCCCGGGCTGAGTGCGCCTGCCCAGCCATCTGCTCCTCCGACACTGCAGCCCCCCAAGCAACCACGAAGCCAGAGCTCGCTGCCTCCGCCCCAACTGGCAGGGACGCTTCGCATCCCAAACGGCAAGTTTCCGGCTCGAACATCGTCTCAGTCAAGTAACGGGCAATTGAATATGCCGAGAGCGCCGCCAAGTTGGAATAGCAGCACCTCTGGATCGATGGGCGCTTCCGAAGTGCCGCGAATCCCACCTGGCCCTTCGGGATCGTCCTTTGCACAGTCGCTCGGCCACCCGCAACCGACCACCCCGCTGGACATGTCTGAGTTCCCGGCTTTGGGGGGAGGTAGTGCTGGGATGAATGCTGGTGCAAGTGCGAATCCATCGCATAGCTCCGCAGGACCAATATCAGCGAATACCGGCTCGATGAATAATGCTGGCAGCTATGCGTTCAGAGCGGCCACTGCGTCACCGGGACAAGGGTTACGGCAGGCGTCAGGGTCTTTGGGCACGCTGCATTCACGCGGTGTAGAGGAAGATGATGGGACTATGAATGACTTTCCTGCTCTTCCAGCAGACCCGGACAAGATCGCCAGCTCGTCGTCGTATGTTCCCGTCTCAGACTCTGGCGCGCAGGATGACTGGAGCCAGCAAAATTCCCACCTCCACCAACAGAGACATGGGCCTCAGCAGCAGCAACAGCAGGAACAGCATAGATCCGCCTTATTAGGAGTAATGACCGGCGCATTTGGCCAATCTAGTATACCCCAATCTGTACCAGAACCAACCTCCCCAGCTCCTTCTAATGCCGCCGCAACCCCTCAATCTATCTCCAACAACGCTGTAGCCGCCTCACACATGCAGCCTGCTCTCACCAGTGAGCAGGACACGAGTGAACTAATGAAAGCGAACGCCACGTCACTAATGCCAGTGGGAGCTCCTGGCATGCCCACTAATTTCGACAACTCAAACCTTCACAAAAGTCAAGCTTCTTTCCCCCCGTCTTCGCCTGCTGGCTCTCTGCAAGGCAACAATACGAGCATATCGGTCCAAGACCGATATGGGTTGCGTGGCCTCTTAAGTATCATTCGCATGGACAATCCGGATGCGAGCATGCTGTCTCTAGGCAGCGACCTGACTAGCCTTGGCCTGAATTTGAATCAGCCCGACGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAACAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
      "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKSRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQRNLSHSVARITHDLVAASFSLVGVALIFVVHVRVGSRRQNMNRPPSIHPHIRPAPGLSAPAQPSAPPTLQPPKQPRSQSSLPPPQLAGTLRIPNGKFPARTSSQSSNGQLNMPRAPPSWNSSTSGSMGASEVPRIPPGPSGSSFAQSLGHPQPTTPLDMSEFPALGGGSAGMNAGASANPSHSSAGPISANTGSMNNAGSYAFRAATASPGQGLRQASGSLGTLHSRGVEEDDGTMNDFPALPADPDKIASSSSYVPVSDSGAQDDWSQQNSHLHQQRHGPQQQQQQEQHRSALLGVMTGAFGQSSIPQSVPEPTSPAPSNAAATPQSISNNAVAASHMQPALTSEQDTSELMKANATSLMPVGAPGMPTNFDNSNLHKSQASFPPSSPAGSLQGNNTSISVQDRYGLRGLLSIIRMDNPDASMLSLGSDLTSLGLNLNQPDDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
      "product": "hypothetical protein"
     },
     {
      "start": 25257,
      "end": 25680,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002408",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002408</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002408</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002408-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,257 - 25,680,\n (total: 390 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002408\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002408-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGGACTCGTGGCCTGGCTCTGTGGTGCGAGAATGGATCTCGCATTCAAAGCGGTCCGCACCATGAACTTCACAGCTCCTTCAGCACATGAGCTGTAG",
      "translation": "MQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMGLVAWLCGARMDLAFKAVRTMNFTAPSAHEL",
      "product": "hypothetical protein"
     },
     {
      "start": 25683,
      "end": 27295,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002409",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002409</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002409</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002409-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,683 - 27,295,\n (total: 1152 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [77:368](score: 129.5, e-value: 1.7e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [67:377](score: 390.9, e-value: 1.2e-117)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002409\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002409-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCCGGGACATAGCCAAGGAGAGCGAGAATATCCGAAAGTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCTCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTATAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTGTATGCATTTTCTCAGAGGCATCTAATGTTAGTTGA",
      "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETRDIAKESENIRKCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACAVCIFSEASNVS",
      "product": "hypothetical protein"
     },
     {
      "start": 27379,
      "end": 29358,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002410",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002410</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002410</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002410-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,379 - 29,358,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002410 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 204.3, e-value: 3.7e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002410 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002410\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTTCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTTCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
      "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSSTNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
      "product": "hypothetical protein"
     },
     {
      "start": 29891,
      "end": 30652,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002411",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002411</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002411</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002411-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,891 - 30,652,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002411 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [0:145](score: 44.1, e-value: 2.3e-11)<br>\n \n  PF03129.23 (Anticodon binding domain): [165:212](score: 21.7, e-value: 0.00018)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002411 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002411\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
      "translation": "MNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
      "product": "hypothetical protein"
     },
     {
      "start": 30922,
      "end": 32226,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002412",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002412</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002412</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002412-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,922 - 32,226,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002412 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002412\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTACGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
      "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGMGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLTTPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
      "product": "hypothetical protein"
     },
     {
      "start": 32439,
      "end": 33350,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002413",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002413</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002413</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002413-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,439 - 33,350,\n (total: 912 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002413 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [3:111](score: 50.9, e-value: 1.4e-13)<br>\n \n  PF03473.20 (MOSC domain): [161:290](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002413 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002413\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATAGCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGCGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAGAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTCGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTCGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
      "translation": "MTMHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDSEELVLAFDGIAQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
      "product": "hypothetical protein"
     },
     {
      "start": 33417,
      "end": 34091,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002414",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002414</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002414</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002414-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,417 - 34,091,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002414\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCCATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
      "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
      "product": "hypothetical protein"
     },
     {
      "start": 34101,
      "end": 35669,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002415",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002415</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002415</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002415-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,101 - 35,669,\n (total: 1569 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002415\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTCGTTCATTGGCGATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACTGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAGGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACGATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATCCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
      "translation": "MSRSLAMNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRLRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYRNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIRWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIASCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 25682,
      "end": 27295,
      "tool": "rule-based-clusters",
      "neighbouring_start": 15682,
      "neighbouring_end": 37295,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r52c1"
   }
  ]
 },
 {
  "length": 51154,
  "seq_id": "scaffold_53",
  "regions": []
 },
 {
  "length": 50330,
  "seq_id": "scaffold_54",
  "regions": []
 },
 {
  "length": 49606,
  "seq_id": "scaffold_55",
  "regions": []
 },
 {
  "length": 47053,
  "seq_id": "scaffold_56",
  "regions": []
 },
 {
  "length": 46825,
  "seq_id": "scaffold_57",
  "regions": []
 },
 {
  "length": 46523,
  "seq_id": "scaffold_58",
  "regions": []
 },
 {
  "length": 46136,
  "seq_id": "scaffold_59",
  "regions": []
 },
 {
  "length": 46121,
  "seq_id": "scaffold_60",
  "regions": []
 },
 {
  "length": 44288,
  "seq_id": "scaffold_61",
  "regions": []
 },
 {
  "length": 42913,
  "seq_id": "scaffold_62",
  "regions": []
 },
 {
  "length": 42493,
  "seq_id": "scaffold_63",
  "regions": []
 },
 {
  "length": 42287,
  "seq_id": "scaffold_64",
  "regions": []
 },
 {
  "length": 41993,
  "seq_id": "scaffold_65",
  "regions": []
 },
 {
  "length": 41771,
  "seq_id": "scaffold_66",
  "regions": []
 },
 {
  "length": 41720,
  "seq_id": "scaffold_67",
  "regions": []
 },
 {
  "length": 40769,
  "seq_id": "scaffold_68",
  "regions": []
 },
 {
  "length": 40421,
  "seq_id": "scaffold_69",
  "regions": []
 },
 {
  "length": 39654,
  "seq_id": "scaffold_70",
  "regions": []
 },
 {
  "length": 38725,
  "seq_id": "scaffold_71",
  "regions": []
 },
 {
  "length": 37906,
  "seq_id": "scaffold_72",
  "regions": []
 },
 {
  "length": 37113,
  "seq_id": "scaffold_73",
  "regions": []
 },
 {
  "length": 36071,
  "seq_id": "scaffold_74",
  "regions": []
 },
 {
  "length": 35875,
  "seq_id": "scaffold_75",
  "regions": [
   {
    "start": 10844,
    "end": 35875,
    "idx": 1,
    "orfs": [
     {
      "start": 11467,
      "end": 12148,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002913",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002913</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002913</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002913-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,467 - 12,148,\n (total: 648 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00071.25 (Ras family): [10:167](score: 167.2, e-value: 2.4e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [8:158](score: 76.9, e-value: 3.6e-22)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00071.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00071.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002913\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGACAAGCCGCAAGTCCCAACCTTCAAGCTCGTCCTCGTCGGAGATGGTGGCACAGGCAAAACCACGTTTGTGAAGAGGCATTTGACGGGGGAGTTTGAAAAGAAGTACATTGCCACCCTCGGCGTCGAAGTCCATCCCCTTAAATTCCACACCAATTTTGGTGAGATCCAGTTCGATGTGTGGGATACGGCAGGGCAAGAGAAGTTCGGCGGGCTGCGCGACGGGTACTACATCAATGGCCAATGCGGGATCATCATGTTTGACGTGACCTCGCGCATCACGTACAAGCAGGTGAGCAACTGGCATCGCGACCTCGTGCGGGTATGCGAAAACATCCCCATCGTGCTCTGCGGGAATAAAGTCGACGTGAAGGAGCGCAAAGTGAAGGCCAAGACAATCACCTTCCATAGGAAAAAGAACTTGCAGTACTACGATATCTCAGCCAAGAGCAACTACAACTTTGAGAAGCCGTTTCTCTGGCTCGCGAGGAAGCTGGCGGGGAATGCTACGCTCGAGTTTGTGGCGGCGCCCGCGCTCGCGCCGCCTGAAGTGCAGGTGGACGCGAATCTGATGGCGCAGTACCAAAATGAAATGGAAAATGCACAGAAAATGCCCTTGCCGGACGAAGACGAGGATTTCTAA",
      "translation": "MTDKPQVPTFKLVLVGDGGTGKTTFVKRHLTGEFEKKYIATLGVEVHPLKFHTNFGEIQFDVWDTAGQEKFGGLRDGYYINGQCGIIMFDVTSRITYKQVSNWHRDLVRVCENIPIVLCGNKVDVKERKVKAKTITFHRKKNLQYYDISAKSNYNFEKPFLWLARKLAGNATLEFVAAPALAPPEVQVDANLMAQYQNEMENAQKMPLPDEDEDF",
      "product": "hypothetical protein"
     },
     {
      "start": 12243,
      "end": 13946,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002914",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002914</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002914</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002914-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,243 - 13,946,\n (total: 1704 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 90; E-value: 2.4e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002914 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [394:419](score: 18.6, e-value: 0.0027)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002914 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002914\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATGTTTGTTGTGCCGCCTCCGCCAATGCGCGTCCCAAATGGCCAGGGAGCGTACGGCAGCAGCGCGGCCATGCAGTCCTTCCAGATGCAGGCGCAGCAGTCCTATCTGCCGCCGCCCTCCAGCCTGGAAAGCTCCAACAGCCTCAAAAATCCCGACGAGCTCTTTTCCCTCGCAGAAGGGCGGTATGTCTTGCGAGACGAGATCAGCCTGGCCTGCCCGCCGCCGCACCCGTCCGAGCCCCCGCCGTTGCAGCCCAATCCGCTGGCGTCCGCCCCGTGGGTCGAGTCCAACGGCACCTACATCTCGATATGCGCCGTGCAGGATCCAAAGGCCTTCATCCGCCCAACCTACATGCCGCCCGTCTCCAAAGACTCGAGCTCTGCAGACTCGGATGCCGACTCTGCGACAAGCGACGCCCAGCCCACGCAGCCGCTCTTCGGGATGCAGGCGCGCGGGGAGATGAAGCGGCGCAAGCCCAAGAACAACATGGCAAAGTCGAATTCGTCCTTCATCTCGCGCATCATTACACACGAGCACTTGGCGAAACGGGTCGCGGAACGGTCGCCCGAGGGCCTCTACGGCTTCATCAACATCAACCGCTCCTTCCAATGGCTGGACCTCTCTGCGCCAAACAAGGCAGAACCGCTGGCAAAGATCCTGTTTACAAAAGCCCATCCCTTGTGCTCGGATGTGAATCAATACAACAAAGCACCAAACCACCTCGATGTACTTATTGGGTTTAATACAGGCGACATCATGTGGTACGACCCGGTTGGCTCAAAGTACGCTCGTATCAATAAAAATGGAGTCTTTAATGGATCGGCAGTGTATGACATTCGGTGGATTCCCGGGAGCGAGTCGCTTTTCATGGTGGCGCACAAGGACGGACGAATCATGATCTATGATACGGAAAAGGAAGACGGACCGGCAAACATGAGCTCAGACGAGTTGGTTACCGGCACCACCTCCTTTCGCATCGTGAAGCGCTTCTCCTCTGGCAGATTGAGCAAAACCAATCCCGTGGGTGCATGGGAAATTTCCTCCAACCCGGTCTACAAGATCGCATTTTCCCCGGATGCGACGTGTCTGGCGATCGCCTCGGAAGACGGAAAGCTGCGTGTGGTGGACCTTCGCAAGGAGCGTCTGATTGATCTCTACGTCTCCTATTACGGCGGCTTCTCAAGTGTGGCATGGTCACCCGACGGCCGCTACCTCCTATCTGGGGGTCAGGATGATCTCATCACCATTTGGAGCGTGAGTGAGCGGCGGGTGGTGGCTCGATGCCCGGGCCATACCTCGTGGGTGACAGACATCGCCTTTGACCCGTGGGGCTGCGAGCACGGACAGTATCGCTTTGGATCCGTCGGCCAGGATTGCCGGCTCCTGCTCTGGGACTTCACCTTGAGCGCCCTCCACCGGCCAAAGACGCTCCTGCACAGCACCCGGATGGGCAAGACCGCACCGCGGCCGCGCGCCAACTCCAACATGTCGGCTGCGGAAGCGAGTGTGCGGCTGCACGCGCCGGAGTCGCGTGGCCAGGTCGCCACGCTGATGCCAATCGTGAGCAAGCAGATCGATGCCTCGCCACTCCTCTGTCTGCACTTCCGCAAAGACTGCTTAGTCACGAGTTCACGGCTGGGCAAGATCCGGACGTGGGACCGGCCCAAAGACGAAGACAATGGACGTGTATGGGATGACTAG",
      "translation": "MMFVVPPPPMRVPNGQGAYGSSAAMQSFQMQAQQSYLPPPSSLESSNSLKNPDELFSLAEGRYVLRDEISLACPPPHPSEPPPLQPNPLASAPWVESNGTYISICAVQDPKAFIRPTYMPPVSKDSSSADSDADSATSDAQPTQPLFGMQARGEMKRRKPKNNMAKSNSSFISRIITHEHLAKRVAERSPEGLYGFININRSFQWLDLSAPNKAEPLAKILFTKAHPLCSDVNQYNKAPNHLDVLIGFNTGDIMWYDPVGSKYARINKNGVFNGSAVYDIRWIPGSESLFMVAHKDGRIMIYDTEKEDGPANMSSDELVTGTTSFRIVKRFSSGRLSKTNPVGAWEISSNPVYKIAFSPDATCLAIASEDGKLRVVDLRKERLIDLYVSYYGGFSSVAWSPDGRYLLSGGQDDLITIWSVSERRVVARCPGHTSWVTDIAFDPWGCEHGQYRFGSVGQDCRLLLWDFTLSALHRPKTLLHSTRMGKTAPRPRANSNMSAAEASVRLHAPESRGQVATLMPIVSKQIDASPLLCLHFRKDCLVTSSRLGKIRTWDRPKDEDNGRVWDD",
      "product": "hypothetical protein"
     },
     {
      "start": 14003,
      "end": 14500,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002915",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002915</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002915</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002915-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,003 - 14,500,\n (total: 498 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002915 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17110.8 (Subunit 11 of the general transcription factor TFIIH): [48:143](score: 31.5, e-value: 1.5e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002915\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAGGAAGAAGGAGGCGATGGAGGGCGGAGATGGAGGGCAAGGGCTCACCCCGCGTCAGCTGACCAACCTGGCCACCTTCCTCGACACCAGACTGCTGCAAGTGTCGCGCAGGTTCAACAAGAAGTTCAGCGCAGACGACGGCTACACCAGCTTCCGCCAGATTGCCAGCGACGCAAAGCCCATTCTGGAGATCTTGGAGCAGTCCCCGGTTTACATACGCGTACAATATGCCCTGACACTCACGGGCAGTCTGTTCTCCTATCTGCCCGCCTTCCCGCCTACAGCAGTCCTCTTCCCCCTCTCCAGGCGGCTCGACACCCTCTTTGTAGGTCTGTGTGGCCGGGTGGACTCCACCTCCAAGGTGCGGATTGCGAGTGTCGTGAATGATGCACGCACCATTGCTGTGTGTGTCTACAATCGTGAATGGAGTATTCAAGCAGGCATGCTCTTTGAGGATACCATCGAAGAGCTCGGAAAGACTACCCTGTTTTAA",
      "translation": "MSRKKEAMEGGDGGQGLTPRQLTNLATFLDTRLLQVSRRFNKKFSADDGYTSFRQIASDAKPILEILEQSPVYIRVQYALTLTGSLFSYLPAFPPTAVLFPLSRRLDTLFVGLCGRVDSTSKVRIASVVNDARTIAVCVYNREWSIQAGMLFEDTIEELGKTTLF",
      "product": "hypothetical protein"
     },
     {
      "start": 14573,
      "end": 15630,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002916",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002916</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002916</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002916-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,573 - 15,630,\n (total: 1008 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002916 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13813.9 (Membrane bound O-acyl transferase family): [226:309](score: 51.7, e-value: 8.8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002916\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACTTCATGAATACAAATGAAGCAAGGATGGCATTCTCGTTTTGGACGCAGCTATTTATAGACGCAGGATGGCCGGTCGACGTGGACGACCAGCCCCGCGAAATACTGTGGTCTAGGCCGCTGCCGCTGGTGGCTTCCGTCTTTCCATTCCTCATCTGCGTGCTGACTCTAGCATATCACCCGCTGCTCATCCAGCCAGAGCCGTCGCGTCTCGAAATCCTCCTGTGTCTGCTCGTTGGCCTCTTTCCCGTCATTTGGGGAGCGCAAGGCAGCGGATCTGCTGTTTTTGAATTTGCGCTATCGACAATCACGAGCGTGGTCGGTCTTCGCATGGTTCGACTGTCGTTCTTTCGACGCCGCACCAGACGGAGCAGGCTGGATATGTGGACAGAGCTGATCAGCCTGCCACTCCCCGACCAAACAACTCATTCGCAAGCACAGGCTCCTTCATCTGCACGACGCCAGAATGCAATTCAAGCCATGCAAGCTTTGCCCCAGGCTGTGCTGGTTCCTACCTTACTTCGATGCATACCACCCCCTGAGTCCTTAATACACATGTCCTTCATCCAGGCCAGGCTTTATCACATGCTGGCTGGGCTGGCCATCCTTTTTGTCTTGCAGGGCTCCGTGCAACTCTGCCTATCCAGCTGGGGAATTGTCATGAACTCTCGGCAAAAGCCCATGTTCAGGAATCCATTGGGAGCTCGCACCTTGCAGGAGCTTTGGGGCCAGAGGTGGAACCGAGTTGTTCAAGAGCAGCTACACTTTCTCTTTGCATGCCTCGCTGGAAATAAAGTCAAAGGGGGAAGGCGTCGGCGGACACTGGCTGCACTGGCAACCTTTCTCCTGTCTGGCCTCTTTCACGAGTACCTGGCCTACCAGTCTTTTGGAACTGCTTCCTTTCAGCAGTTCTGGTTCTTCATGATTCAGGGTGTTCTTTGCAGTATGGAGCCATACATTCCCAAAGGCGCCACCTACGCCTGGCTCGTTCAGCCACTTCTTTGA",
      "translation": "MDFMNTNEARMAFSFWTQLFIDAGWPVDVDDQPREILWSRPLPLVASVFPFLICVLTLAYHPLLIQPEPSRLEILLCLLVGLFPVIWGAQGSGSAVFEFALSTITSVVGLRMVRLSFFRRRTRRSRLDMWTELISLPLPDQTTHSQAQAPSSARRQNAIQAMQALPQAVLVPTLLRCIPPPESLIHMSFIQARLYHMLAGLAILFVLQGSVQLCLSSWGIVMNSRQKPMFRNPLGARTLQELWGQRWNRVVQEQLHFLFACLAGNKVKGGRRRRTLAALATFLLSGLFHEYLAYQSFGTASFQQFWFFMIQGVLCSMEPYIPKGATYAWLVQPLL",
      "product": "hypothetical protein"
     },
     {
      "start": 15779,
      "end": 17044,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002917",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002917</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002917</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002917-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,779 - 17,044,\n (total: 1266 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002917\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGTGAAGCGGAGACTGTCCTCCACATCGCGGTCGTCCGCTGACGCAGACGCGCCAGATTCATCGGCCGCGATCTGGCCCGCGCCGCAACGAGACTTGGAGAGCGCGCGAGCCTTCATTCAAGAGGCGGCCAGATCGCAGCGCAAGATTGTGATTGCACCGGATCGCGACGCTGATGGGCTCTGCTCTGGCGCACAGCTACGACATACCCTTCTACACCTGGGTGCGGCACCCGACCAGATCGCCATCAAGTTTGTCGCCAAAGGACGGAATGTGCATTGTGATGAAGAGCGCGCGGACTTAGAGCGGTATCAGGCGGAGTATATCTTTGTTCTCGATCATGGAAGTCGAGGCGGTGGGCCCATAGCAGATGGGAAGGTGCTCATCCTAGATCATCACTGGAGCGAGGACTTCCCAGACGACGCGCAGGTGGTGAGTGCATGCAAGTATCTACCCGTGGCCACGGCGTCACTATTGACGTATGTCGTCTGCCTCGCCATCAATGAGCACCTCCCGGCCTGGCTCGCAGTCACTGGCACCGTTGGCGATCTCGGCACTACCGTTACGTTTGAGCCCCCATTTCCAACAAGTTTGGCGCAGACATTCAAGGCGCAAGGCAAGAAGCAGATCGCAGAGGTTGTCGCCCTGTTGAATGCACCTCGACGCACTCCAGCCTGCGACCCGACCGAGGCGTGGCAGCTGCTGATTGCAAGCGCGTCTGCCCGAGACTTCCTCGCATCACCGAGCACGCGCTCGCTGGACGACGCGCGCGTATATATCCAAAGAGAGACAGAGCGATGCACGCATGCGGCCCCCAGATTCACAAAGGACGGTCGGATGGCCATTTTGGAGATGTCGTCGCCTGCACAGATCCATCAGCTCATTGCGACGCGCTGGGCCGGCTTCCTGAAATCCAAAGCGCTGCTTGCAGTCGGTGTTGCTAATCGGGGGTACGCTCCCGACAAAGTTCATCTGTCCTGCCGCCTTGTCAAGAGTAGGCGGAGTGAAGAGCCGCCCGTCAACTTGATTGCCCTGCTTAACGAATACCTCGCCCGAGACGCAGATCTGGCAAAGACCATTGGACCCGATTTTGCGCATGGTCACAAGGAAGCTGCAGGGGGCCACATGTCTCCTGAGCAATGGGACAGGCTAGTCGCGGCGATGGAAATTGGAAATTGGAAGTCGCCCAACAAGGACAGCCCCAAAAAGCCCTCCGTGGACGCGAAGCAATCCAACTTGACAGGTTATTTCAAGCGTGTCTAG",
      "translation": "MGVKRRLSSTSRSSADADAPDSSAAIWPAPQRDLESARAFIQEAARSQRKIVIAPDRDADGLCSGAQLRHTLLHLGAAPDQIAIKFVAKGRNVHCDEERADLERYQAEYIFVLDHGSRGGGPIADGKVLILDHHWSEDFPDDAQVVSACKYLPVATASLLTYVVCLAINEHLPAWLAVTGTVGDLGTTVTFEPPFPTSLAQTFKAQGKKQIAEVVALLNAPRRTPACDPTEAWQLLIASASARDFLASPSTRSLDDARVYIQRETERCTHAAPRFTKDGRMAILEMSSPAQIHQLIATRWAGFLKSKALLAVGVANRGYAPDKVHLSCRLVKSRRSEEPPVNLIALLNEYLARDADLAKTIGPDFAHGHKEAAGGHMSPEQWDRLVAAMEIGNWKSPNKDSPKKPSVDAKQSNLTGYFKRV",
      "product": "hypothetical protein"
     },
     {
      "start": 17081,
      "end": 18976,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002918",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002918</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002918</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002918-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,081 - 18,976,\n (total: 1896 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002918 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02990.19 (Endomembrane protein 70): [51:587](score: 650.5, e-value: 2.1e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002918 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02990.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002918\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCATCGGATCCAACGGAGGCTGCTGCTGCTGCTGCTCCTCCTCCGCCAGGCAAGCGGCTTCTACATCCCCGGCTGGAGCATCCGCTCGTACGCCGACGGGGACGCAATCCCCCTGCAGACCAACAAGGTCTCCTCTGACGCCACCTCCCTGCCCTACGCCTACTCCGAGCTGCCCTTTGTCTGCGATGCCCCGGGGCGCAGCAGCAGGCGGGTCGCCCTCAACCTGGGCGAGGTTCTGCGCGGCGACCGCATCGCGACGTCCGGCTACGAGATCGAGATGGGCAAGGACGTGGCCTGTGCGCACCTGTGCGACGCGGCCGTCGATGCTGCCGGCATCGCGCGCGCCACCCAGCTCATCCGCAACGGCTACTCGGCCGAATGGATCGTGGACAACCTGCCCGGCGCCACCTCCTTCGTCACCGTCGACCGCACCAAAAAGTACTACGCGGCCGGCTTCAAGCTGGGCGGGTTTGAGAATGACGTGGCAAAGTTTCATAATCACGTCAGCCTGGTCTTCCGGTGGCGCCGGCTGGAGGCAGACAGCGACCGCAAGGTCATTGTGGCCTTTGAAGTCTACCCAAAGTCTATCAAAACAAAGGCCGGCGCATGCCCCACCTCGCTCGACAATCAGCCCCCGCTGGAGCTCCCGGAGACGAGCACAGTAGGGGTGGACGGCTTCACAATTCCCTACACCTACAGCATATTTTGGAAGGAAGACGACACCATCGAATGGTCGTCGAGATGGGACCTCTACTTTGTCAACAACGAAGATGCGCACCAGATCCATTGGCTGGCCATTGTAAACTCTACCGTCATTGTCATGGTGCTCAGTGGCGTGGTCTTCCTCATCCTGGTGCGAACCCTCTCGCGCGACATTCAATCCTACAACACGCCCGACGGCGACGACGACAAGGATACAGATGCCGACATAACTGGCTGGAAACTTGTGCATGGGGACGTCTTCCGACCGCCGCCGGCTGGCGGTCTGTTCTCCCCCCTTATCGGAGCGGGTGTGCAATTGCTCGTCATGATGTTGGCCCTCCTCATTTTGTCCGCGGCCGGGATCCTCAATCCCTCCTACCGGGGCGGCTTTCTCTCTTTTGCCCTCTTCCTCTTCGTCTTTGCGGGTGTCTTTTCCGGATTGCATTCCACAAAGATCTACAAAACGTTTGGAGGGTCCCAGTGGGTCAAGAATGGGTTGATGACTGCGCTCTTAGTGCCGGGAAGTGTCTTCCTGACCGTCTTTATCCTCAATTTGTTCGTCTGGGCGGAAGCGTCGTCTTCGGCCCTTCCATTTGGAACGTTGGTTGCGCTGTTGGCCATGTGGCTGCTTATCTCTCTTCCCCTAGTCTTGCTGGGAAGTTTCATTGGCTTCCGACGTCCGGCCGTGGAGCATCCTACGAAAGCCAACCAGATACCACGCCAGATCCCCGAACAGCCTCGCCACCTCCGATTCTTTCCCTCGCTGCTCATCACCGGCGTCGTTCCCTTTGCAGTCATCTTTATTGAACTTTTGTTTGTCTTCCGATCCGTGTGGGCGGAAAAGTCGGGCTACTACTACGTCTATGGATTCCTTGGGCTCATCACGCTCATCCTCCTGATTACGACGGTCGAAATAACACTCATTCATGTCTACTTTATGCTCTGTGCCGAGAACTACCATTGGTGGTGGCGATCGTTCTTTGTGGGTGGTGCGAGCGCCATCTACGTCTTTGGCTACTGCGTTTGGTACTACCTTTTCAAGCTCCAGCTGCACGGGTGGGTGAGCGGCCTGCTCTTCTTAGGCTACTCCCTGCTCGGCTGTGCCTTGTATGGGGTCTTCCTCGGGACGGTAGGGTCTCTGTCGGCATATGTCTTTGTGAGGAAGATATATGCCGCAGTCAAGGTGGATTAG",
      "translation": "MHRIQRRLLLLLLLLRQASGFYIPGWSIRSYADGDAIPLQTNKVSSDATSLPYAYSELPFVCDAPGRSSRRVALNLGEVLRGDRIATSGYEIEMGKDVACAHLCDAAVDAAGIARATQLIRNGYSAEWIVDNLPGATSFVTVDRTKKYYAAGFKLGGFENDVAKFHNHVSLVFRWRRLEADSDRKVIVAFEVYPKSIKTKAGACPTSLDNQPPLELPETSTVGVDGFTIPYTYSIFWKEDDTIEWSSRWDLYFVNNEDAHQIHWLAIVNSTVIVMVLSGVVFLILVRTLSRDIQSYNTPDGDDDKDTDADITGWKLVHGDVFRPPPAGGLFSPLIGAGVQLLVMMLALLILSAAGILNPSYRGGFLSFALFLFVFAGVFSGLHSTKIYKTFGGSQWVKNGLMTALLVPGSVFLTVFILNLFVWAEASSSALPFGTLVALLAMWLLISLPLVLLGSFIGFRRPAVEHPTKANQIPRQIPEQPRHLRFFPSLLITGVVPFAVIFIELLFVFRSVWAEKSGYYYVYGFLGLITLILLITTVEITLIHVYFMLCAENYHWWWRSFFVGGASAIYVFGYCVWYYLFKLQLHGWVSGLLFLGYSLLGCALYGVFLGTVGSLSAYVFVRKIYAAVKVD",
      "product": "hypothetical protein"
     },
     {
      "start": 19032,
      "end": 21845,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002919",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002919</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002919</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002919-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,032 - 21,845,\n (total: 2775 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 278.3; E-value: 1.3e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002919 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [288:592](score: 159.3, e-value: 1.4e-46)<br>\n \n  PF08240.15 (Alcohol dehydrogenase GroES-like domain): [625:689](score: 39.4, e-value: 4.9e-10)<br>\n \n  PF00107.29 (Zinc-binding dehydrogenase): [747:870](score: 92.4, e-value: 2.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002919 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002919\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002919-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCGAGAGCAGCAGAGAGGCGATCCCAGCGCGCCGGCGACGGTCCAGCGCCAGCAAGGGTTTTGCCCCGCCCTTCCAGCAGCGACGCGCGCAGTTCGTGCAGCAGGAGCAGCAGCAGCAGCGCAGTCTCAGCCCCAGCTCCCTCGACTCGAACGCCCTCTTGGACCACCGCTCCCAGCCAGAGAGCATCCCCCGGCCCTCCTTCCTGCGCAACCGCAGCGACAGGACCGGCGGCGAGCGGGAGGAGCGACGGGGCAAGGGCAGAAGGGAGAGCCGCGACCGCCACCATGAGCAGACACCTCTGTTGGAGGGCGAGGGAGAAGGGGGGGCGGGGCCCAGCTCGGGGGAGCAGGCGGACCAGCACCCCTTTGTGCACTACCAGCCAAACTACGGGTCCGGGGCCCATGGAGACGCAGTCATCACTATCGAGGGCGCCGGCGATGGGAGCTCCACGGACGACTTCACCAACGACCCCACCAGCGATGAGGCCTCCGACAACTCCGAGGCCCTGGACGACGTCTGCTTCCCACAGGACGTGGGCGACGACGGCGAGCGCAAGTGGCCGGATATCGCCGTGCTCGAGGAGTGGGCCGAGGAGGAGAAGAAGGAGAGCGGAGACGGAGGGGGCGTGGGAAATGCAGAGTGGCTGAGATCGCGCCAGACCAGCGAGCCAGAGCGCATTAATGGGCGGCTGCGTGGCGTGCACCAAACCAAGGAGGAGAGCGACCGGCCCTACCGTTTCACCTACTTCTCCGACTCCCTCCCCGCTACCATCCATTCCCAAAACATCTCCGGGCTCGTGCAGTCCGATCTCTCCTTTACAGACCTCTTCTCCCCCAAGGCGGACTTGGCGCCCACCTTCTGGCTGGACTGCCTAACCCCCACAGACTCTGAAATGAAAGTCCTGGCGCGTGCATTCGGCATCCACCCGCTGACGGCCGAGGATATCACCATGGGAGAGACGCGCGAAAAGGTGGAACTCTTTCGAAACTACTATCTCGTCTCCTTCCGATCCTTTGAACAGGATCCCAAGGCGGAGGAGTATCTTGAAGGCCTGGACTTCTACATCATTGTCTTCCGCCAAGGTGTCATTTCCTTCCATCACTCCCTCACCCCTCATCCGGCAAATGTCCGCAGGCGCATACGCCAGCTAAAGGATTACATCACCGTGACATCCGACTGGATCTCATACGCATTGATTGATGACATTACAGACGCCTTCCAGCCCCTCATCTACTCCATCGAGACAGAGGTGGACGATATCGACGACTCCATCCTATCTTTTCATTCCGACAACTCTGTGGCGGACGACAGCGAGATGCTTCGGCGCATTGGCGAGTGCCGAAAGAAAGTGATGGGTCTGCTTCGTCTGCTCGGATCCAAAGCGGATGTCATCAAAGGCTTCTCCAAGCGCTGCAACGAGCATTGGGACATTGCCCCACGTTCGGAGATTGGGCTATATCTCGGAGACATCCAAGACCACATCGTCACGATGGTCCAGAATCTGGGCCACTATGAAAAGATGATGTCGCGGTCCCACTCCAACTACCTTGCCCAGATAAATATCCAGATGACGCGAGTCAACAACAACATGAACGACGTGCTCTCTCGCCTGACGGTGCTGGGGACAATCGTGCTCCCAATGAACATCATCACTGGCCTGTGGGGCATGAACGTCAAGGTCCCCGGGCAGGAAATCGACAACCTCAACTGGTACTTTGGCATCACGGTGGGGCTGGTCATGTTTGGCGTGATGAGTTATTTGTTCTTCATGAAGACCTCGGTACATATGCGAGCAATTCAAATCACAGAACGCGTAGATTCGCCGTCCAAGCTGCGGCCCTCTGACATCGCACAGCCCCGGCCGAGTGCAGAGCAAGTGCTGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCGTCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATTAAAATCGACCATCCTTCTCCCAAACTTTAG",
      "translation": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASDNSEALDDVCFPQDVGDDGERKWPDIAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMKTSVHMRAIQITERVDSPSKLRPSDIAQPRPSAEQVLVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARVIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
      "product": "hypothetical protein"
     },
     {
      "start": 22240,
      "end": 25599,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002920",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002920</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002920</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002920-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,240 - 25,599,\n (total: 3360 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002920 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00176.26 (SNF2-related domain): [448:755](score: 211.8, e-value: 1.2e-62)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [933:1048](score: 50.8, e-value: 2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002920 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002920\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002920-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATAGATGTATTAGAACAGGTAGCGATTTACAGATCGCTCTTAGATACCATCTCGCCGGGGCCGAGTGAACACCGTACTGCGATAGAGCGTAAGCTACGAGATGTTGAGGCCAAGGTGGATCAAAATGAGCTACAAAGTAGCGAACGGAACAAGCGTCGGAAATTAGAACAAGAGCAGGAGGATGAGATATTTGCATGGACCTTGGAGATGCAAGAGAAGGGCAGCAACACGAGCGAAAATTTCGATTATGAAACGATTGATCTGACTGAGCAAATTGAGAACGATGCAGCTCTAGCACGAGAGCTAGCGGATGAGGAAGGCGCAAGGCCTGCACAGTCTGCTCCTCCTGCTCCCTATTTAGGAGCAACTCCCAAGCTCGAACATGGTTCGAACGCGGTTCAGCTGGATGACTCGGTAAATGTTATTGCGGGCACTATACCAGCATTCACAATTGTTGGAACCGATACCGTGGGGCCTAATAATGCAACGGCGAACACCGAAGCTCCCAATACATTATCAATGACCGATCAGGATCTAGCTAATTTTTTCATGACAATTGAGGATCGTGTTTCCAAAGTATATGGAAAAAAAGAGGTCCGACCGCTACACTTTGTTCGAGGTCCCTTCAATTTGTTCAAGAGATCAGCACTTGAAAATCTGAAGAAGCGCGGTCTAGACTATTTGGTTCAAGATACAGATAACGAAATAGCACAAACGTATGAAGACTCCATATCCCTTACCATGCAGAGACTAGAGGCAGCTGAGTGGCAGCAAGTACTTTACCGGAATCTTCGTCGCAAAACGCAGCCAACTCCTGCCCTACCAATGGACGAACCAAAAACGGCAAACGCCGAGCCTGTTCAACCACAAGCGCCTGCACCTACACCTGCAGGGATTTCTGAACAGCGACTCATGGAGCTACGAATTGCAGCAGATGCTAAACTTCTACGAATCCATGGACCTCCACAGCTTTTCACCGGGAGCATGCTCACGTCCTACGAGAAACTGCGAAAGGCATATCGTGACGAAGCTATTATGAATGAGAAAGTCAACGCTCTCAAAAATATAAAGCCCGCACAGAATACACTCTGGCCAGATTCGATGGCAGCGGGCCCGTCTACAACAGCAAGTATTGGCCTCCCTTCGAGCTATTATGACTACAGCCACAGCTACTCGATGCGATTCGATGCTGAAAAGAACCGTGAAGATCTTAAGAAACTTATCGAGAGTATTCAGCCGGACGCTGATATTGAACCACACGCACGAAGAGGGACTCCAAGTGCCATGACTTTCGTGTTGATGGAACATCAAAAAGTTGGACTTACCTGGATGCGACGTATGGAAGAAGGTAACAATAAAGGAGGTTTATTGGCCGATGACATGGGGCTTGGAAAGACAATCCAAGCCCTTGCTCTAATAATGTCTCATCAGCCCGAAGACCCATCTATCAAGACTACACTTATAGTTGCGCCACTCGCGTTGCTTAAACAATGGCATCGAGAAATTGAATCAAAAATCAAGCCAATGTATGCACAGAAGGTGTGTATTTACCACAGTATTGGAAGACGCAACATGACGTGGGTCGATCTTCGAAAGTATGACATTGTCTTGACCACGTATGGTATGATTGCATCCGACTATAAAGCACAAGTTAAATGGGAGGCCGACGTGAAGATTGATGCGAGAAATGAAGTTTACAAGCCAGAGTCACCTCTCCTTGACAAAGATAGCCAATTTGATCGAATAATCCTAGATGAGGCTCAAATGATTAAAAATAGAAATGCACTGGCATCGAGGGGTGTCGCAATTCTCCATGCAAAGTATCGCTGGGGCCTCAGTGGTACACCTGCACAAAACAACATTGACGAGTTTTATGCAATCATTCGCTTCTTACGTGTACGCCCTTTCTGCGACTGGGATGAATTTCGAACTCAGCTGTCTAATGCAGCGAGATCAAGGGATCTCAAAAGAGTTGACAAAAGTACGCGATTGCTGCAGGGTGTGTTGCGGGCAATCATGTTACGAAGAACGAAAGATTCAAAGATCGATGGCGAAAGTATACTTGACCTCCCACCCAAGACCATCGAAGAGACTCATGTTGTTTTTAACGTAGACCAGCAAGCATTCTACAACAATTTGGAACACAAATCTCAGATGTTAATGAATCGCTACGAGCAAAACAACACCATTGGGAAAAACTATGCAAACATATTGGTCCTTTTGCTTAGACTCCGTCAGGCATGTTGCCACCCACATCTCATTCCTGACACCGGTACATCTACTGGAATTTCTTATGAAGCTGGAGTTGTCCCCAAATCGGCCGAGGAAATGGAGGCGATGGCCCGGCAGATGCCTAGTGATGTAGTCAATCGTCTCAAGAATGACAAAGAAATGCTTTGCCCTGTCTGCTGGGACACACCAACCGACATGAAAATTATCCTCTTTTGTGGTCATTATGGATGTGGCGAATGCGTCAACAAGCTATTCACGCTGCAGACTCAAGTGAATCAGTCTCATGATGAGCTTGAGCCAGCACTGTGTCCGACGTGCCGCAGCGCAATGAGTAGCGACAAATTGCTGGGCTTTAATCTGTTCAAAAAGGTCCACATGCCAGAAGCGCTTACTCCGGAACCGCAACCGGAAGCTGTCAAGGATGAAAGCTCGGCTGTCGGAGGGAGTGGGACGAAAGGCAAAGAGAAAGCGGTGATTCCCGAAAGAGAGGAGACTCCGCTCGAGGACTTGGCGCCCCGCCAAAGGATTTTGCGAAGACTAAAGAAAGACTGGATCTCCTCTGCAAAGATTGACAAATGCTTGGAAATCCTGGAGACCGTCAAAGCGCGGGACCCGACGGAGAAGACCGTCGTGTTTTCCCAATTCATTCTGCTGCTTGACTTTTTGGAGATTCCGTTGGCGGACATGGGATTTAAGTGGAAGCGGTATGAAGGTTCCATGTCTGCCGTTGCTCGGGACGATGCCGTGCTTGACTTTATGAAGAGCCCAGATATCAACATCATGCTTGTTTCCTTGAAGGCCGGCAATGTTGGCCTCAACCTGACCTGTGCATCTCAGTGCATTGTGATGGATCCCTTTTGGAATCCGTTTGTGGAATTACAAGCCATTGATCGTACGCATCGAATTGGACAGTCACGGCCAGTCTGCGTGCACCGCATCTGCGTTGCGGGGACAGTCGAAGACAGGATTCTGGAGCTGCAAAATCAAAAGCAGGAGCTCATTGAGACGGCCCTGGATGATCAGGCGGCAAAGTCAATCCAACGGCTGAGTCCTCGTGAATTGATGTATCTTTTCGGGATCAACGACCCCAACAGTCAGAACAGCCAGAACAACCAGCATATTTAA",
      "translation": "MIDVLEQVAIYRSLLDTISPGPSEHRTAIERKLRDVEAKVDQNELQSSERNKRRKLEQEQEDEIFAWTLEMQEKGSNTSENFDYETIDLTEQIENDAALARELADEEGARPAQSAPPAPYLGATPKLEHGSNAVQLDDSVNVIAGTIPAFTIVGTDTVGPNNATANTEAPNTLSMTDQDLANFFMTIEDRVSKVYGKKEVRPLHFVRGPFNLFKRSALENLKKRGLDYLVQDTDNEIAQTYEDSISLTMQRLEAAEWQQVLYRNLRRKTQPTPALPMDEPKTANAEPVQPQAPAPTPAGISEQRLMELRIAADAKLLRIHGPPQLFTGSMLTSYEKLRKAYRDEAIMNEKVNALKNIKPAQNTLWPDSMAAGPSTTASIGLPSSYYDYSHSYSMRFDAEKNREDLKKLIESIQPDADIEPHARRGTPSAMTFVLMEHQKVGLTWMRRMEEGNNKGGLLADDMGLGKTIQALALIMSHQPEDPSIKTTLIVAPLALLKQWHREIESKIKPMYAQKVCIYHSIGRRNMTWVDLRKYDIVLTTYGMIASDYKAQVKWEADVKIDARNEVYKPESPLLDKDSQFDRIILDEAQMIKNRNALASRGVAILHAKYRWGLSGTPAQNNIDEFYAIIRFLRVRPFCDWDEFRTQLSNAARSRDLKRVDKSTRLLQGVLRAIMLRRTKDSKIDGESILDLPPKTIEETHVVFNVDQQAFYNNLEHKSQMLMNRYEQNNTIGKNYANILVLLLRLRQACCHPHLIPDTGTSTGISYEAGVVPKSAEEMEAMARQMPSDVVNRLKNDKEMLCPVCWDTPTDMKIILFCGHYGCGECVNKLFTLQTQVNQSHDELEPALCPTCRSAMSSDKLLGFNLFKKVHMPEALTPEPQPEAVKDESSAVGGSGTKGKEKAVIPEREETPLEDLAPRQRILRRLKKDWISSAKIDKCLEILETVKARDPTEKTVVFSQFILLLDFLEIPLADMGFKWKRYEGSMSAVARDDAVLDFMKSPDINIMLVSLKAGNVGLNLTCASQCIVMDPFWNPFVELQAIDRTHRIGQSRPVCVHRICVAGTVEDRILELQNQKQELIETALDDQAAKSIQRLSPRELMYLFGINDPNSQNSQNNQHI",
      "product": "hypothetical protein"
     },
     {
      "start": 25871,
      "end": 27304,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002921",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002921</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002921</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002921-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,871 - 27,304,\n (total: 1398 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1137:Major facilitator superfamily MFS 1 (Score: 376.9; E-value: 1.6e-114)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002921 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [80:360](score: 73.9, e-value: 1.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002921 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002921\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002921-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKTAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLIVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFIFLGLLVIANLGVKSRLPPRGGSMPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCAACATGAACTCTAACGAAGCAGCAATCGCTAAGCCCCGTGATGTTGAAGCAGGCACACTATCTACACGTACCAGCTTTTCCAGTGCTCATGAGCAATTATCAGACCATACCACTGTTGCCAATGAGTCACCCGTGAATGAAAAGGTCGAAGAAGAGAAAGTCAAGACTGCGATGCCGCCCCCTTCGGATTTCCCAGATGGAGGCCTTCGAGCTTGGATGTGCGTTGTGGGTGGATGGTGTGCAATGTTTTGCACTTTTGGCTTTGTGAACAATGTTGGTGTATTCCAAAACTACTACCAAACGACTTTCCTCAGACAGTATACACCCTCTACGGTAGGATGGATCGCTTCGCTTCAACTCTTTCTGCAGTTTTTCATGGGCTTTCCAGTGGGTCGCGTATACGACGCCTACGGTCCTGCTTGGTTGTTGCGCATCGGAAGTTTCCTTATTGTATTTGGACTCATGATGGCTTCCTTGAGTACGAAATACTACCAGCTGCTTCTTTCACAGGCCGTAGTCTTCGGAATAGGTGCATCTATGGTCTTCTTTCCGGTCATAACTGCGACGTCTACATGGTTTTTCAAGAAGCGAGCTCTGGCGATCGGTTTGGCGAGTGTGGGCAGCTCTATGGGGGGTATTATACAGCCAATCATGATTACCAATCTCATACCGCAGATAGGCTTCGGATGGACCATGCGAACTATAGCCTTCATCTTCCTCGGCTTATTAGTGATTGCAAATCTTGGAGTAAAGTCACGTTTGCCGCCGAGGGGTGGCAGCATGCCAAAAATATCTGAAATTACAGCTGTACTTACAGACAAGGACTGGGCCCTACTGACGGCTGGCTACTTCATCTTTGTTTGGGGCATGTTCACGCCATTCACTTATATTCCGGATTATGGATTGTACTATGGGATGTCTCAACATTTGAGCATCTACCTTGTGTCCATTCTCAATGCTGGTTCGGTCTTTGGTCGGACTATTCCAGCTGGGCTTGGTGACCGTTTTGGACGGTTCAATGTGTTCACATTGATGAGCTTCTTCAGTGGTATCATCACGTTGGCAATGTGGATTCCGTCAAGGAGCCATGCTGTTATCATTGCGTACTCGGCACTATTTGGATTCAGTAGTGGTGCGTTTGTAAGCTTAGGACCGGCTTGCATTGCACAAATATCTGATATTCGCCAGCTCGGACTGCGTGTTGGGGTTTGTTTTGCAATATTTGCAATTGCGGCACTGACCGGCGTGCCCATTGCCGGAGCGCTCTTAGGACACAACAATAATTGGGTGCATGTTCAAATCTGGGCAGGCGTGACAATGATCGCTGGGAGCTCTATTATGTTATTCTTACGCTTCAAATTGGCCGGGTACAAGTTAATGGTGAAGGTCTAA",
      "translation": "MSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKTAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLIVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFIFLGLLVIANLGVKSRLPPRGGSMPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV",
      "product": "hypothetical protein"
     },
     {
      "start": 29181,
      "end": 30839,
      "strand": 1,
      "locus_tag": "MARS14BIN71_002922",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002922</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002922</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002922-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,181 - 30,839,\n (total: 1659 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002922 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04082.21 (Fungal specific transcription factor domain): [91:317](score: 92.0, e-value: 3.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002922 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002922\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGATACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTAATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
      "translation": "MQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
      "product": "hypothetical protein"
     },
     {
      "start": 30844,
      "end": 33894,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002923",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002923</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002923</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002923-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,844 - 33,894,\n (total: 3051 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.3; E-value: 4e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002923 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 125.8, e-value: 1.8e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 31.7, e-value: 1.5e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.8, e-value: 5.5e-42)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002923 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [654:1015](score: 214.1, e-value: 8.4e-64)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002923\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002923-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGTAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGGAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGCGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGTACCCAAAGAGTGCAGCAGGACTCAAAAACATTCAGGCAAATTGCTGCTATTGATGGATCATTAGTCGGAAAGTTTGTGTCTGCATGGAAGGAGGTGGGGTTTTTGTCATGA",
      "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFVKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
      "product": "hypothetical protein"
     },
     {
      "start": 34072,
      "end": 35535,
      "strand": -1,
      "locus_tag": "MARS14BIN71_002924",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002924</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002924</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002924-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,072 - 35,535,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002924 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002924 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002924\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002924-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
      "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 30843,
      "end": 33894,
      "tool": "rule-based-clusters",
      "neighbouring_start": 10843,
      "neighbouring_end": 35875,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r75c1"
   }
  ]
 },
 {
  "length": 34392,
  "seq_id": "scaffold_76",
  "regions": []
 },
 {
  "length": 34140,
  "seq_id": "scaffold_77",
  "regions": []
 },
 {
  "length": 33945,
  "seq_id": "scaffold_78",
  "regions": []
 },
 {
  "length": 32771,
  "seq_id": "scaffold_79",
  "regions": []
 },
 {
  "length": 32318,
  "seq_id": "scaffold_80",
  "regions": []
 },
 {
  "length": 32261,
  "seq_id": "scaffold_81",
  "regions": []
 },
 {
  "length": 32183,
  "seq_id": "scaffold_82",
  "regions": []
 },
 {
  "length": 32088,
  "seq_id": "scaffold_83",
  "regions": []
 },
 {
  "length": 31371,
  "seq_id": "scaffold_84",
  "regions": []
 },
 {
  "length": 31005,
  "seq_id": "scaffold_85",
  "regions": []
 },
 {
  "length": 30808,
  "seq_id": "scaffold_86",
  "regions": []
 },
 {
  "length": 30315,
  "seq_id": "scaffold_87",
  "regions": []
 },
 {
  "length": 29924,
  "seq_id": "scaffold_88",
  "regions": []
 },
 {
  "length": 29664,
  "seq_id": "scaffold_89",
  "regions": []
 },
 {
  "length": 29353,
  "seq_id": "scaffold_90",
  "regions": []
 },
 {
  "length": 29274,
  "seq_id": "scaffold_91",
  "regions": []
 },
 {
  "length": 28962,
  "seq_id": "scaffold_92",
  "regions": []
 },
 {
  "length": 28278,
  "seq_id": "scaffold_93",
  "regions": [
   {
    "start": 11566,
    "end": 28278,
    "idx": 1,
    "orfs": [
     {
      "start": 13222,
      "end": 13728,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003216",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003216</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003216</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003216-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,222 - 13,728,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003216 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04588.16 (Hypoxia induced protein conserved region): [59:111](score: 71.4, e-value: 5.3e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003216\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACATCTCCAGGGAGGAGTGACGACGGTGACGCCTCTCCCAAAGCCAACAGGATGGAGAGATTTGACGATAACTCAATCATTCGGATGCCCTCGTCTTTTGATTTTGGAGATGAAGGAATGACAGGCCAAAAACCTGAGCCGCAAGGTCTAAACAAAATCTTACAGCGTTGCAAAGAGGAACCGCTTGTGCCCATTGGGTGCCTACTAACATGCGGAGCCCTGTTTGGATCTGCAGTTGGGCTAAGAAAGGGAAATAAAGATATGGCTCAGCGGATGTTTCGTTATAGAATTGGTTTTCAATTCGCGACTCTGGGATTTGTTATCGCTGGTGCACTGTACTATGGCAATGATCGAGCATCGCGGAAGCAGGAAGATCAAGCAGTACAGCAGCAGAAAGCAATGGATCGTCGGGCAGCCTGGCTACGGGAGCTAGACAGTCGTGACCGATTGCTCAAGGAACGAAGTCGACGGTTGGCAGAGAAGAAGGAACAGCCGCACCAGTAA",
      "translation": "MTSPGRSDDGDASPKANRMERFDDNSIIRMPSSFDFGDEGMTGQKPEPQGLNKILQRCKEEPLVPIGCLLTCGALFGSAVGLRKGNKDMAQRMFRYRIGFQFATLGFVIAGALYYGNDRASRKQEDQAVQQQKAMDRRAAWLRELDSRDRLLKERSRRLAEKKEQPHQ",
      "product": "hypothetical protein"
     },
     {
      "start": 13962,
      "end": 14561,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003217",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003217</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003217</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003217-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,962 - 14,561,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003217 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00581.23 (Rhodanese-like domain): [11:123](score: 22.8, e-value: 0.00011)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003217\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCAATTGCCAACGCTTCGATCATAACTTCCGAGCAATTGAGTACAAGATTAAAGCAAGGCAGAATTCTACCTGTAGATGCAACATGGTACTTGCCAAACGTTCAGAGGAACGCTCGGGCCGAGTTCATACAGAAAAGGCTGCCAGGAGCGCGCTTTTTTGATCTGGATAAAATCAAAGACACAGAGTCATCACTCCCACATATGCTCCCATCAGGCGAGCTCTTTTCTACGGAAATGCGTAAAATGGGTATTTCTCGCAGTGATGAGATCGTTGTTTACGACACCTCAGCTCTGGGTATATTTAGCGCTGCACGCGCTTATTGGATGTTTAAAATCTTCGGTCACTCTAGTGTGATGCTTTTGAATTCGCTTTCACATTACAGTGGCCCATATGAAGAGGGTATTCCTAATGGTGTTACCCCAACGAAATATCCAGTTGTGGATGCAGATCAAAATCGAGTAGCCACATACGAAGAGGTCCTCGAAAACATTCAGAGACACGACGACGTACAGATTCTGGATGCTCGCCCATCCGGTCGTTTCGAAGGCGTCGATCCTGAACCTCGACCTGGTGAGCCCAACTACCGAATTTTCTAA",
      "translation": "MSIANASIITSEQLSTRLKQGRILPVDATWYLPNVQRNARAEFIQKRLPGARFFDLDKIKDTESSLPHMLPSGELFSTEMRKMGISRSDEIVVYDTSALGIFSAARAYWMFKIFGHSSVMLLNSLSHYSGPYEEGIPNGVTPTKYPVVDADQNRVATYEEVLENIQRHDDVQILDARPSGRFEGVDPEPRPGEPNYRIF",
      "product": "hypothetical protein"
     },
     {
      "start": 14966,
      "end": 17905,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003218",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003218</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003218</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003218-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,966 - 17,905,\n (total: 2940 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003218\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGACTTTCTCACTGTCAAACTGCATTGGACTCTCTACAATGCTACATATAATCAATATATCCGACTAGGGATCGATCCAGCTTTGCAAATCGTACCCATCAGGAAACTCGATATTATTGGTTCAAATGCGAATCAGAAACCCCTCCGAGTTGCGCAATGCAGTCTATATGATATGATAGTACGAGGACCAAAGAATTCAAGAACTTATAAAGTGGTAATTCTCGGCCGTCTCAATATGGTGGATCAAAGTACGCTTGATGAATACGGTACCATTAGTGGCGTCCTTCGACTGAGTGCGATATTAAATCCAAGGGTAATTAAAAAAGAGAGGAGTCGGAAATTCGAGGTTGCAAGCGCAAACTTCGGTCAGATTAGCTTTCTTTCTGAGGAGGTGACTATCATAAGACCACAACTGCAAAGATCCTGCACCTGGATACCTGTTCCTGATGGCGCTCGAACCTTGTTCTTCACTTGCACACTTACCCTTCCTACTGGTTATCAGTGGTCCAAACTTGTTCTTTCCGATGAGATCGTGAGAGGAAACGCCACCTTTGTCAGCGCTACATTCATAGAAGAAGATATAGCCAATCAACACAAGCCAAAGCTTGTGTCATTGAGTTTGTACGACGAAAATACTAGCAAGAACTATGAGTTACGTATGCGAAGTCTCACTTTAGATGGGTCGAGAAACCGATACCATCTCGAAATCACGTACCAATCACACCCTGATCCTGATAAACCTAGAAGTTTTGTGGGAATAGCAAAAGTCACAAGTACACATTACAGATTCCATCGAGAATCTTACCTGCATCCGTATACGGCGAGAATTCCTTTAATAACCCAAGAAGAATTACTGAATCAAACAAAATGGGCCCCGTCTGAGCATCTCCCAATACCGGCGTATATAATAATGGACGCAGATCACGAAGGCCTTGCACCAAGACCACTATTAGTTGGTCCGGAGGATCAAAGTAATGGAACAAATAACTCAATCCCGGTAGGGTCAGCAGAAGAACATCTCCAAAATTCCAAGAGTAAGCATACTTTCTCTCCTCTATACCATCATGTCGACATAATAACGTTGCATGAGTCCACGAATGAAACAAAAGCGACAGATTCATCCAGAAATGAATTGCACACGGATTCGATCACGACGCCATTTACGGAGAAGACTTTTACGGTAAACACAACAACCAGGGACGTCGAGCCTCCTCATTCTGTGCTTCCTATACCAGGCTTCCTAACTTCGAACCAAACGGCTTATAACCCTTCTTTGCAAAACGCAGAGGAACGTATTAATATGATCAACACGATGCTACCTATAAGTGGTGCAAATGAAACGCGTACCATGAAAGAGACTATTGAGTCGACGACTTCTGTGAATTCTGGCAGTGGGGTGCGTAACACCCATCATTCTTCAGATCTTTTTGTATTGTCTCCTACAACTCGATTTCACTCCGGGACTACACCAAATTCTGACTTCCCGTCAACGAATTTTGGCGCCCCTACTCTATCAGTATTTGCCCATAGCACAGATTCTGCTAATTATCCACTCCATATTCCTTCAAGTAAGTGGATATCTTCACTCACGGCGCAACCGTCTCCAGGACCGGTAGGTCTTCCAATATCTACGTCCACATCTTTGCACTTCGAGTCAAGATCTGCAAAACAGTCAATATATGACCCACAGTCACAAAAATTGGACTCTATCGCCTCACAAAGCACTGGGAGTGGCACATCTGAGAGTTTTGAAGCCATGTTCGAGACAGCTAGGAGTGAGGAGACTCCCGCTTATCTGGAAAAAATCGGCCACTCATCCGACACTACTACCAAGTCATCATGCGGGATAGCCCACAGAGAAACACTGGTCATCACAGGTATGCGTGGTAGACTTGTTGATCAGAATGTCGTCATAAGAACGAGTCAGGTTGAAGATGGAAAAGGGCCAGACGCAACATTCTCCCCGATCTACAGAGTCCAAAATTCTGAGGACTATACGACAAGCAAAATGAAGACTAGCATTTTGACGAACAAAGGGTTTCCACAAGTAATGAGAACAGACGCAACTCTAAGAGAGACCAAAGAAACTGAAACAATATGGGGACTCAAGCCGACCAATACGATCCGACAGCGTCCTGCACAAATTTCCCACCTGAGCGCGGAGCCTGCACTGCCTTCACTTCCTACTTCATCTCAAAGCATCCCATGGAATGAAGAACAAAGTGAAAGTTCAACAGGGCATACACCGCAATTGGCAATGTTTTCTAACGATACCCTCTCTATTTTTTATGCAGAGCCGCAAAGCGCTTATAAGGCTTCAACAGACAAAGATAAACATGCCAAAGGTATAGCCACAATAATTCGATCTGTTCAGTTGAGTTTAATCACCGAGTCAAATTTTGCACCTGGCAGGTATAGCCAAAAACCTAGAACTGCAGCAAGCATAGATGGTGATTTGAAATCTGATTTTGATCTTATTGATTGGCAAGCTTCTCGACACGGCAAAGTTGACGTCGGCCATAAGTGTGATATGAATTCGACAGTCTGTACAGCAAACGCGAGTATCGAAGCCGATGTCAATATTGGACTCCTCGGCGCTCCGTCTGACGCGTCTACTGCTGCTGCAGGCAATCCTTCTGTGGAGGACATAAATACCCCAGCCATAGAAGACTCATATAGTACAACCTCAATCTTTGTAAAAGTACACAATGAATTCACCGCGGCATCAATGCCGGTAGAAAGCGCAAAGCCACAAAAAACTGGTCATGTCGAGTCAGCGATTCACATGTCTCATACACGATCCAAAAACTCGATTTTTCTTCCACAACCAACATCACAGCCATCGGGACTGCAGCACAGCATCGCTGCTCAAGCACCACCGGCTATACGGCAAACCCTAGTGCTGCTTCTAACTTTATTTGTATTCTTTAACTAA",
      "translation": "MDDFLTVKLHWTLYNATYNQYIRLGIDPALQIVPIRKLDIIGSNANQKPLRVAQCSLYDMIVRGPKNSRTYKVVILGRLNMVDQSTLDEYGTISGVLRLSAILNPRVIKKERSRKFEVASANFGQISFLSEEVTIIRPQLQRSCTWIPVPDGARTLFFTCTLTLPTGYQWSKLVLSDEIVRGNATFVSATFIEEDIANQHKPKLVSLSLYDENTSKNYELRMRSLTLDGSRNRYHLEITYQSHPDPDKPRSFVGIAKVTSTHYRFHRESYLHPYTARIPLITQEELLNQTKWAPSEHLPIPAYIIMDADHEGLAPRPLLVGPEDQSNGTNNSIPVGSAEEHLQNSKSKHTFSPLYHHVDIITLHESTNETKATDSSRNELHTDSITTPFTEKTFTVNTTTRDVEPPHSVLPIPGFLTSNQTAYNPSLQNAEERINMINTMLPISGANETRTMKETIESTTSVNSGSGVRNTHHSSDLFVLSPTTRFHSGTTPNSDFPSTNFGAPTLSVFAHSTDSANYPLHIPSSKWISSLTAQPSPGPVGLPISTSTSLHFESRSAKQSIYDPQSQKLDSIASQSTGSGTSESFEAMFETARSEETPAYLEKIGHSSDTTTKSSCGIAHRETLVITGMRGRLVDQNVVIRTSQVEDGKGPDATFSPIYRVQNSEDYTTSKMKTSILTNKGFPQVMRTDATLRETKETETIWGLKPTNTIRQRPAQISHLSAEPALPSLPTSSQSIPWNEEQSESSTGHTPQLAMFSNDTLSIFYAEPQSAYKASTDKDKHAKGIATIIRSVQLSLITESNFAPGRYSQKPRTAASIDGDLKSDFDLIDWQASRHGKVDVGHKCDMNSTVCTANASIEADVNIGLLGAPSDASTAAAGNPSVEDINTPAIEDSYSTTSIFVKVHNEFTAASMPVESAKPQKTGHVESAIHMSHTRSKNSIFLPQPTSQPSGLQHSIAAQAPPAIRQTLVLLLTLFVFFN",
      "product": "hypothetical protein"
     },
     {
      "start": 19617,
      "end": 21035,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003219",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003219</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003219</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003219-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,617 - 21,035,\n (total: 1419 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003219\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTGTTTTGACCTTGGGTTTATGGGTCTTCATACAAAGCGCTTTCGCGCAAAGTAGTTACCCTGCTAATTTTTCAATTGAGAGGGCTGAAATATATAAGCATCCAAAACAAGATAATAATCATACCTCACCAATTCACATTAGTGATATTCTTACAGTGAAACTTCACTGGAGTCTCTACAATGCGACATTGGACAACTATGTCGCATTACAACTTGATCGAGCTCTGCAAATAATTCAGCCCCAAACACTTGAAATGATTGGTAGAAGTGGGGATCAAAAACCTGTTTTAAAGCTTGCGACATGCAACGAATTTCAATTAAGTGCAGGGGTGATTTTTTGCCCGCTCGATGAAGTCCCGCAGAAAATATTGAATGAGTACGGCACCTTGAACGGTTTCATTCATGTGGAGGCGACGCTGAACTCAAACTTCATCGGTGATGGCACCCATAGAGTTTTTGAATTCGCAAACGCGAATTTCGATCAGGAATACGCTTATTCTGCGGATATAGCTATCGCTAGACCAGAGAATTATGAGAAAGTCACTATACCTGAATCGAAAATGCAGAGAACTTGCTCCTGGGGACTTCCGGCCGATGGCTACTACGACAAGGTTTTCGTTTGCACAATTAGCTTTCCTATCGGATATAATCTGTCCCGAGTCTTGGTTTCCGACAACATTCTGAGAGGAAACGCTAGACCTGTCGGCGCCGTATTCATACAAGAAGATGTGAATGATCTTAAAAAGCAAACCTTTGTGTCGATTGTGCGGTACAAAGAGACCTATGCACGTCGTGGTTACGAATTACGTATGCGGCCCCTCGTTGACGAGACTTTAGATGGATCGAAATACCGATATCGCCTTGCTATAACATACGAGTCACATCACGGTACTGATGATGTCAAAGGTTTTGTGGGAATAGCGAAAATCAGAAGTAAGGATTACGGCTTTGAGCAAAAATCTTATCTGCCTCCATTTTCAACGTGGAAGCGAATTTCCCCCCACATATGCAAGAATGATCATGAAGAATGGTTGTCTGCCTCCATTCAATATCCTTTGATCCCATCCGAACAAATTCAATTGCCGGCATATTCAGTCATGGCTGGGTCTCATAGGGACCAGCTATCATTTCCACTCTCAATTGGTTCAGAGGAGCAAGGTGAGTGGACCACCCCTAAATCAACGACGAATTCGTCGGACAGAGACCCACAAAGTATCGAGATCAAGCATAGTCTGTCCCCTCTACATTTCCACATGAATCGTACAATGTTGTATGAAGCCCCAAAAGGTAAAATAACAGCCACGACCCACTCTAGAATGGAGTTTTCACATGTGCGGTCTCGGCGTTCACAGGTGACACAAGGCCGACAAGCACGACACCAAAAGCTCAAAACAGTCAATCTCAATCTTTCTTGA",
      "translation": "MGVLTLGLWVFIQSAFAQSSYPANFSIERAEIYKHPKQDNNHTSPIHISDILTVKLHWSLYNATLDNYVALQLDRALQIIQPQTLEMIGRSGDQKPVLKLATCNEFQLSAGVIFCPLDEVPQKILNEYGTLNGFIHVEATLNSNFIGDGTHRVFEFANANFDQEYAYSADIAIARPENYEKVTIPESKMQRTCSWGLPADGYYDKVFVCTISFPIGYNLSRVLVSDNILRGNARPVGAVFIQEDVNDLKKQTFVSIVRYKETYARRGYELRMRPLVDETLDGSKYRYRLAITYESHHGTDDVKGFVGIAKIRSKDYGFEQKSYLPPFSTWKRISPHICKNDHEEWLSASIQYPLIPSEQIQLPAYSVMAGSHRDQLSFPLSIGSEEQGEWTTPKSTTNSSDRDPQSIEIKHSLSPLHFHMNRTMLYEAPKGKITATTHSRMEFSHVRSRRSQVTQGRQARHQKLKTVNLNLS",
      "product": "hypothetical protein"
     },
     {
      "start": 21566,
      "end": 22900,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003220",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003220</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003220</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003220-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,566 - 22,900,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 158.6, e-value: 2.3e-46)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.3, e-value: 7.3e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003220\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGAAGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACTATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGAACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGTAACTCCACTGCTCCTGAGCAGTAAAAAGTACGAAAATAACGAAAATACTTGGAGTCGCGCCTAA",
      "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWEGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDYDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLNLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKVTPLLLSSKKYENNENTWSRA",
      "product": "hypothetical protein"
     },
     {
      "start": 23584,
      "end": 25221,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003221",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003221</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003221</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003221-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,584 - 25,221,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003221 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 64.0, e-value: 1.8e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003221\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATCTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGGTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAAAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACACAGAGGGAGCCATGGGTGCAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTGTTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACTGCATGGAATCATACTACACAAGGTACATTTGGTGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGCCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATACTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
      "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLVVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFKTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHTEGAMGASVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTAWNHTTQGTFGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
      "product": "hypothetical protein"
     },
     {
      "start": 26135,
      "end": 27887,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003222",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003222</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003222</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003222-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,135 - 27,887,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75; E-value: 7.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003222 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.1e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.8e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003222 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 666.0, e-value: 7.5e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003222\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003222-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATTGCAGCATACGTGAAACGTATTGCACCGCACGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTCGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCTCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
      "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPHVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSSSDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 21565,
      "end": 22900,
      "tool": "rule-based-clusters",
      "neighbouring_start": 11565,
      "neighbouring_end": 28278,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r93c1"
   }
  ]
 },
 {
  "length": 27642,
  "seq_id": "scaffold_94",
  "regions": []
 },
 {
  "length": 27533,
  "seq_id": "scaffold_95",
  "regions": []
 },
 {
  "length": 27468,
  "seq_id": "scaffold_96",
  "regions": []
 },
 {
  "length": 27330,
  "seq_id": "scaffold_97",
  "regions": []
 },
 {
  "length": 27195,
  "seq_id": "scaffold_98",
  "regions": []
 },
 {
  "length": 27123,
  "seq_id": "scaffold_99",
  "regions": []
 },
 {
  "length": 26123,
  "seq_id": "scaffold_100",
  "regions": []
 },
 {
  "length": 25565,
  "seq_id": "scaffold_101",
  "regions": []
 },
 {
  "length": 24402,
  "seq_id": "scaffold_102",
  "regions": []
 },
 {
  "length": 24373,
  "seq_id": "scaffold_103",
  "regions": []
 },
 {
  "length": 23888,
  "seq_id": "scaffold_104",
  "regions": []
 },
 {
  "length": 23693,
  "seq_id": "scaffold_105",
  "regions": []
 },
 {
  "length": 23043,
  "seq_id": "scaffold_106",
  "regions": []
 },
 {
  "length": 22404,
  "seq_id": "scaffold_107",
  "regions": []
 },
 {
  "length": 22149,
  "seq_id": "scaffold_108",
  "regions": []
 },
 {
  "length": 21844,
  "seq_id": "scaffold_109",
  "regions": []
 },
 {
  "length": 21220,
  "seq_id": "scaffold_110",
  "regions": []
 },
 {
  "length": 21044,
  "seq_id": "scaffold_111",
  "regions": []
 },
 {
  "length": 20968,
  "seq_id": "scaffold_112",
  "regions": []
 },
 {
  "length": 20832,
  "seq_id": "scaffold_113",
  "regions": []
 },
 {
  "length": 20678,
  "seq_id": "scaffold_114",
  "regions": []
 },
 {
  "length": 20598,
  "seq_id": "scaffold_115",
  "regions": []
 },
 {
  "length": 19926,
  "seq_id": "scaffold_116",
  "regions": []
 },
 {
  "length": 19764,
  "seq_id": "scaffold_117",
  "regions": []
 },
 {
  "length": 19685,
  "seq_id": "scaffold_118",
  "regions": []
 },
 {
  "length": 19535,
  "seq_id": "scaffold_119",
  "regions": []
 },
 {
  "length": 19460,
  "seq_id": "scaffold_120",
  "regions": []
 },
 {
  "length": 18964,
  "seq_id": "scaffold_121",
  "regions": []
 },
 {
  "length": 18762,
  "seq_id": "scaffold_122",
  "regions": []
 },
 {
  "length": 18729,
  "seq_id": "scaffold_123",
  "regions": []
 },
 {
  "length": 18363,
  "seq_id": "scaffold_124",
  "regions": []
 },
 {
  "length": 18175,
  "seq_id": "scaffold_125",
  "regions": []
 },
 {
  "length": 18014,
  "seq_id": "scaffold_126",
  "regions": []
 },
 {
  "length": 17749,
  "seq_id": "scaffold_127",
  "regions": [
   {
    "start": 1,
    "end": 17749,
    "idx": 1,
    "orfs": [
     {
      "start": 287,
      "end": 856,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003603",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003603</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003603</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003603-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 287 - 856,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003603 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [113:186](score: 57.6, e-value: 1.7e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003603 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003603\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGACTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAAAACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
      "translation": "MVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSDSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEENPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
      "product": "hypothetical protein"
     },
     {
      "start": 1613,
      "end": 3828,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003604",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003604</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003604</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003604-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,613 - 3,828,\n (total: 2058 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [13:138](score: 171.0, e-value: 2.3e-50)<br>\n \n  PF00290.23 (Tryptophan synthase alpha chain): [140:232](score: 74.0, e-value: 9.3e-21)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [335:659](score: 166.8, e-value: 7.8e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [289:671](score: 577.7, e-value: 2.6e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [14:138](score: 128.8, e-value: 3.7e-38)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003604\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003604-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCAAGCGATTAAGGAGACATTCAGCAGATGCAGGCGAGAAAGTAAGCATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTGAGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTACCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCATTGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
      "translation": "MQAIKETFSRCRRESKHRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIPDSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVSTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTTADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEALRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
      "product": "hypothetical protein"
     },
     {
      "start": 4010,
      "end": 5494,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003605",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003605</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003605-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,010 - 5,494,\n (total: 1485 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003605 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [158:220](score: 52.1, e-value: 4.6e-14)<br>\n \n  PF00013.32 (KH domain): [253:318](score: 55.5, e-value: 4.1e-15)<br>\n \n  PF00013.32 (KH domain): [343:409](score: 55.9, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003605 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003605\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGACCAGAGCTCTTTGGCTTCGATCTTAGCAGCGCTGAGTCAAGCGCAGGCAGCTCAGCAGAGACAAAGCGGGGGTAACTTGTCTGACTCAAGACCTGCCCCCCCGATGCAACAACAACTCGGTGCGACAAATTCAGGCGGAGCAATGGGCAATAGCTACGGCTACCCGCCTCCCCCTTCCTCATCGGGTGCTATTGATCTGTCTACTCTCAAACCGTCAAATTCTGGTAGCATGTCCTTTGCAGACCCACGATTTGGCGCCTCTGGGCTCAACTCAACGTCGCCAATGATGTCTTCCAACTATTATGACCAGGGAAGAAATGGTGGTTATGATGATAGTCGTAGGCGAAGGCGGTCTAGGTCTCGATCAGGAAGTAGAGAGAGGAGTCCTTATGGCTACAGACGAAGGGACCGTGAAAGATCATACAGCCCTCCGCGACGGGGTGGAGGATCTTCTCCAGATAGGGATACAATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGATACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
      "translation": "MADQSSLASILAALSQAQAAQQRQSGGNLSDSRPAPPMQQQLGATNSGGAMGNSYGYPPPPSSSGAIDLSTLKPSNSGSMSFADPRFGASGLNSTSPMMSSNYYDQGRNGGYDDSRRRRRSRSRSGSRERSPYGYRRRDRERSYSPPRRGGGSSPDRDTMVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
      "product": "hypothetical protein"
     },
     {
      "start": 5947,
      "end": 8628,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003606",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003606</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003606-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,947 - 8,628,\n (total: 2682 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003606 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [631:761](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [784:819](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003606 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003606\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003606-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAATCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTGATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGATCAGGTGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTCAAGATCGTATTATATTTACCCCTGCAGACGTGATTTCGAAAGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
      "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLDEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRSGDASGRKLTPVHLLTGQDRIIFTPADVISKEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
      "product": "hypothetical protein"
     },
     {
      "start": 8648,
      "end": 10255,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003607",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003607</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003607</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003607-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,648 - 10,255,\n (total: 1488 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003607\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCTGCTGGTCACCAGAAGAAGCACAAGATCGAGGAAGCGCGACTGGCTACAATGCACTATTTGAGAATCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAAAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCATCTCTATATTTGCTTCAAAGTTGCACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGGGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
      "translation": "MACWSPEEAQDRGSATGYNALFENLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWKKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLGRLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
      "product": "hypothetical protein"
     },
     {
      "start": 10410,
      "end": 14477,
      "strand": 1,
      "locus_tag": "MARS14BIN71_003608",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003608</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003608</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003608-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,410 - 14,477,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.3; E-value: 1.3e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003608 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 222.1, e-value: 1.1e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.6, e-value: 3.5e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 254.2, e-value: 1.2e-75)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003608 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1894.1, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 377.5, e-value: 1.6e-113)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 342.8, e-value: 6.2e-103)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003608\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003608-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCGGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACTTTCCTAGATCACACCAATGGGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAGAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAACTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAACTAAGTACAATTGGAGGACGCGGAGGAAATAAGATAGAATCAGGCTAG",
      "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRREFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
      "product": "hypothetical protein"
     },
     {
      "start": 14491,
      "end": 16151,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003609",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003609</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003609</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003609-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,491 - 16,151,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 962.1, e-value: 8.8e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003609\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003609-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAGAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
      "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDRGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
      "product": "hypothetical protein"
     },
     {
      "start": 16637,
      "end": 17605,
      "strand": -1,
      "locus_tag": "MARS14BIN71_003610",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003610</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003610</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003610-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,637 - 17,605,\n (total: 969 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003610 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:269](score: 204.0, e-value: 2.5e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003610\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003610-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTCAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGGATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTCGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGGCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
      "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 10409,
      "end": 14477,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 17749,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r127c1"
   }
  ]
 },
 {
  "length": 17371,
  "seq_id": "scaffold_128",
  "regions": []
 },
 {
  "length": 17290,
  "seq_id": "scaffold_129",
  "regions": []
 },
 {
  "length": 17110,
  "seq_id": "scaffold_130",
  "regions": []
 },
 {
  "length": 17105,
  "seq_id": "scaffold_131",
  "regions": []
 },
 {
  "length": 17024,
  "seq_id": "scaffold_132",
  "regions": []
 },
 {
  "length": 16520,
  "seq_id": "scaffold_133",
  "regions": []
 },
 {
  "length": 16341,
  "seq_id": "scaffold_134",
  "regions": []
 },
 {
  "length": 16318,
  "seq_id": "scaffold_135",
  "regions": []
 },
 {
  "length": 16311,
  "seq_id": "scaffold_136",
  "regions": []
 },
 {
  "length": 16216,
  "seq_id": "scaffold_137",
  "regions": []
 },
 {
  "length": 16138,
  "seq_id": "scaffold_138",
  "regions": []
 },
 {
  "length": 15909,
  "seq_id": "scaffold_139",
  "regions": []
 },
 {
  "length": 15847,
  "seq_id": "scaffold_140",
  "regions": []
 },
 {
  "length": 15802,
  "seq_id": "scaffold_141",
  "regions": []
 },
 {
  "length": 15682,
  "seq_id": "scaffold_142",
  "regions": []
 },
 {
  "length": 15440,
  "seq_id": "scaffold_143",
  "regions": []
 },
 {
  "length": 15044,
  "seq_id": "scaffold_144",
  "regions": []
 },
 {
  "length": 14988,
  "seq_id": "scaffold_145",
  "regions": []
 },
 {
  "length": 14952,
  "seq_id": "scaffold_146",
  "regions": []
 },
 {
  "length": 14604,
  "seq_id": "scaffold_147",
  "regions": []
 },
 {
  "length": 14199,
  "seq_id": "scaffold_148",
  "regions": []
 },
 {
  "length": 14122,
  "seq_id": "scaffold_149",
  "regions": []
 },
 {
  "length": 13836,
  "seq_id": "scaffold_150",
  "regions": []
 },
 {
  "length": 13638,
  "seq_id": "scaffold_151",
  "regions": []
 },
 {
  "length": 13438,
  "seq_id": "scaffold_152",
  "regions": []
 },
 {
  "length": 12322,
  "seq_id": "scaffold_153",
  "regions": []
 },
 {
  "length": 12222,
  "seq_id": "scaffold_154",
  "regions": []
 },
 {
  "length": 12032,
  "seq_id": "scaffold_155",
  "regions": []
 },
 {
  "length": 11880,
  "seq_id": "scaffold_156",
  "regions": []
 },
 {
  "length": 11616,
  "seq_id": "scaffold_157",
  "regions": []
 },
 {
  "length": 11491,
  "seq_id": "scaffold_158",
  "regions": []
 },
 {
  "length": 11480,
  "seq_id": "scaffold_159",
  "regions": []
 },
 {
  "length": 11368,
  "seq_id": "scaffold_160",
  "regions": []
 },
 {
  "length": 11089,
  "seq_id": "scaffold_161",
  "regions": []
 },
 {
  "length": 10969,
  "seq_id": "scaffold_162",
  "regions": []
 },
 {
  "length": 10930,
  "seq_id": "scaffold_163",
  "regions": []
 },
 {
  "length": 10904,
  "seq_id": "scaffold_164",
  "regions": []
 },
 {
  "length": 10855,
  "seq_id": "scaffold_165",
  "regions": []
 },
 {
  "length": 10701,
  "seq_id": "scaffold_166",
  "regions": []
 },
 {
  "length": 10678,
  "seq_id": "scaffold_167",
  "regions": []
 },
 {
  "length": 10271,
  "seq_id": "scaffold_168",
  "regions": []
 },
 {
  "length": 10261,
  "seq_id": "scaffold_169",
  "regions": []
 },
 {
  "length": 10093,
  "seq_id": "scaffold_170",
  "regions": []
 },
 {
  "length": 9805,
  "seq_id": "scaffold_171",
  "regions": []
 },
 {
  "length": 9751,
  "seq_id": "scaffold_172",
  "regions": []
 },
 {
  "length": 9665,
  "seq_id": "scaffold_173",
  "regions": []
 },
 {
  "length": 9614,
  "seq_id": "scaffold_174",
  "regions": []
 },
 {
  "length": 9533,
  "seq_id": "scaffold_175",
  "regions": []
 },
 {
  "length": 9341,
  "seq_id": "scaffold_176",
  "regions": []
 },
 {
  "length": 8901,
  "seq_id": "scaffold_177",
  "regions": []
 },
 {
  "length": 8830,
  "seq_id": "scaffold_178",
  "regions": []
 },
 {
  "length": 8807,
  "seq_id": "scaffold_179",
  "regions": []
 },
 {
  "length": 8708,
  "seq_id": "scaffold_180",
  "regions": []
 },
 {
  "length": 8679,
  "seq_id": "scaffold_181",
  "regions": []
 },
 {
  "length": 8409,
  "seq_id": "scaffold_182",
  "regions": []
 },
 {
  "length": 8354,
  "seq_id": "scaffold_183",
  "regions": []
 },
 {
  "length": 8280,
  "seq_id": "scaffold_184",
  "regions": []
 },
 {
  "length": 8272,
  "seq_id": "scaffold_185",
  "regions": []
 },
 {
  "length": 8244,
  "seq_id": "scaffold_186",
  "regions": []
 },
 {
  "length": 8110,
  "seq_id": "scaffold_187",
  "regions": []
 },
 {
  "length": 8024,
  "seq_id": "scaffold_188",
  "regions": []
 },
 {
  "length": 7664,
  "seq_id": "scaffold_189",
  "regions": []
 },
 {
  "length": 7521,
  "seq_id": "scaffold_190",
  "regions": []
 },
 {
  "length": 7364,
  "seq_id": "scaffold_191",
  "regions": []
 },
 {
  "length": 7137,
  "seq_id": "scaffold_192",
  "regions": []
 },
 {
  "length": 7059,
  "seq_id": "scaffold_193",
  "regions": []
 },
 {
  "length": 6995,
  "seq_id": "scaffold_194",
  "regions": []
 },
 {
  "length": 6962,
  "seq_id": "scaffold_195",
  "regions": []
 },
 {
  "length": 6918,
  "seq_id": "scaffold_196",
  "regions": []
 },
 {
  "length": 6500,
  "seq_id": "scaffold_197",
  "regions": []
 },
 {
  "length": 6476,
  "seq_id": "scaffold_198",
  "regions": []
 },
 {
  "length": 6215,
  "seq_id": "scaffold_199",
  "regions": []
 },
 {
  "length": 6146,
  "seq_id": "scaffold_200",
  "regions": []
 },
 {
  "length": 6068,
  "seq_id": "scaffold_201",
  "regions": []
 },
 {
  "length": 5864,
  "seq_id": "scaffold_202",
  "regions": []
 },
 {
  "length": 5775,
  "seq_id": "scaffold_203",
  "regions": []
 },
 {
  "length": 5658,
  "seq_id": "scaffold_204",
  "regions": []
 },
 {
  "length": 5511,
  "seq_id": "scaffold_205",
  "regions": []
 },
 {
  "length": 5390,
  "seq_id": "scaffold_206",
  "regions": []
 },
 {
  "length": 5369,
  "seq_id": "scaffold_207",
  "regions": []
 },
 {
  "length": 5046,
  "seq_id": "scaffold_208",
  "regions": []
 },
 {
  "length": 4934,
  "seq_id": "scaffold_209",
  "regions": []
 },
 {
  "length": 4019,
  "seq_id": "scaffold_210",
  "regions": []
 },
 {
  "length": 3955,
  "seq_id": "scaffold_211",
  "regions": []
 },
 {
  "length": 3762,
  "seq_id": "scaffold_212",
  "regions": []
 },
 {
  "length": 3481,
  "seq_id": "scaffold_213",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r9c1",
  "r40c1",
  "r52c1",
  "r75c1",
  "r93c1",
  "r127c1"
 ],
 "r9c1": {
  "start": 55904,
  "end": 76871,
  "idx": 1,
  "orfs": [
   {
    "start": 56215,
    "end": 56496,
    "strand": 1,
    "locus_tag": "MARS14BIN71_000715",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000715</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000715</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000715-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,215 - 56,496,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000715 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01910.20 (Thiamine-binding protein): [0:86](score: 83.4, e-value: 8.8e-24)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000715 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00106 (TIGR00106: uncharacterized protein, MTH1187 family): [0:88](score: 86.0, e-value: 4.8e-25)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000715\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000715\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGACCTCGTCGCCGTCCGTCACACAGCATGTGGCGCGAGTACAGGTCTACTTTTCCGAGTGCGCTGGCATTGAATTCCACATGCACTCCTACGGCACAACCATCGAAGGGGAGTGGGACGACGTGATGCGCGCCATTGGAGGCGCCCATCAGTGCCTGCACGAGGCGGGCGTCGTCCGGATTGCAAGCGATATACGCGTCGGCACACGCACTGACAAGGCACAGACGTCGCAGCAAAAGGTAGACAGCGTACAAGACTTTCTCGCCACAGACAAGTAG",
    "translation": "MGTSSPSVTQHVARVQVYFSECAGIEFHMHSYGTTIEGEWDDVMRAIGGAHQCLHEAGVVRIASDIRVGTRTDKAQTSQQKVDSVQDFLATDK",
    "product": "hypothetical protein"
   },
   {
    "start": 56551,
    "end": 57765,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000716",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000716</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000716</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000716-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,551 - 57,765,\n (total: 1215 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000716 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08202.14 (Mis12-Mtw1 protein family): [109:400](score: 165.2, e-value: 2.3e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000716 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000716\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000716\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAGAAATGAGCGGCCCGAGAAACGAAAGGCGCACGCCGTTGTAGATATCGAGCCTTCGCCAGATGCGCGCAAAAGGCGAACACAACCTGATCGCAAGGCGAGGAGAAGTCTACAAAATGAAGAGGATGATGGGTTTCAATTTGCGCGTGGGAAGGGAAAACCCCGAAATGATCAGCAACCTGGCGAGGCGAAAAGCGGGAAGCAGGCCACTCGAAGGAAGGTTGTAGACCTTTCCGATACTCCGAAAGGCGAGCGGTCAAATTCTTCGCATGGTAGCGGCGAGGGCTCGACGATGATGGATTCTGTGATCCCACTCTCGACCCGTGATACGCCTATGATTCGAAAGAACAAGGAGCTACGCCAGCAATCGCGTGCCGGAGGACACCGAAGAAGCAGCTCTGGTCTACGTGGGAAACGCGCGAGTTCCATTGGCAATGGTTTCAGGGCGGTCCCCCATCCTGATATCGATGCACGAGATTTCTACAAGCATATTGCCGACGATTTACCAGATCCACTTCGAATGCGACAGCTCCTTGCGTGGTGTGCGCGCCGGGCCTTCGATGAGCAAAAAGTGAGATTGGATGCTGCTCCGCCTGAGAAGGGCCAAGTGATGGATAGGAATGCAGCTACGATTGCACAAGTCGTGAAGCAGGAAGTGCTCATGGATTTGATTGAGAGTCGGATTGAAACGAGCTGGTACCATCGTCCTGAAGGACCACCCAAAACACCTACCAAACCCAATCCTCAAAACGAAGAGAACCGAGCAAAAATTGAACACTTGCAAACTGTCTTGGAGAGGCTGAGAACCGAGGAGCGACAGTGGAAGGCACTGATCACCAATCCGCCAACCTCACAAGCAACCATGACAAATGATAAAGATATCCAACCTGAGGACCTGTCCCTTCTGAGACCGAGGGAGCGAGCATTTTGGGAGAATGTACAGCAGCAGGATTCAAGGGATGCGGAGCGCGTCCAAGAATGGATGGGCGGGGAGGAGAGCAAGCTGGAGTTGCAAGTGGATAAGCTCTTTCATATGCTGCATTCCGTGCGCATGCTTGGAAAGGCAGCCGAGGGGTTCAGCGAGCAGGCGCTGTCCCAAGCTGCTGAGGCGTTTGATGCACGTCGTGAGCGTGCCCAGGAAGAGGCCCGCACAACAGATGTCTCACCGCGCGACATTCTCCGCACCCTGTCACGGCGATCGGATGTATAA",
    "translation": "MNRNERPEKRKAHAVVDIEPSPDARKRRTQPDRKARRSLQNEEDDGFQFARGKGKPRNDQQPGEAKSGKQATRRKVVDLSDTPKGERSNSSHGSGEGSTMMDSVIPLSTRDTPMIRKNKELRQQSRAGGHRRSSSGLRGKRASSIGNGFRAVPHPDIDARDFYKHIADDLPDPLRMRQLLAWCARRAFDEQKVRLDAAPPEKGQVMDRNAATIAQVVKQEVLMDLIESRIETSWYHRPEGPPKTPTKPNPQNEENRAKIEHLQTVLERLRTEERQWKALITNPPTSQATMTNDKDIQPEDLSLLRPRERAFWENVQQQDSRDAERVQEWMGGEESKLELQVDKLFHMLHSVRMLGKAAEGFSEQALSQAAEAFDARRERAQEEARTTDVSPRDILRTLSRRSDV",
    "product": "hypothetical protein"
   },
   {
    "start": 57998,
    "end": 61162,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000717",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000717</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000717</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000717-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,998 - 61,162,\n (total: 3099 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00168.33 (C2 domain): [51:153](score: 78.7, e-value: 3.6e-22)<br>\n \n  PF00168.33 (C2 domain): [248:346](score: 61.0, e-value: 1.2e-16)<br>\n \n  PF02666.18 (Phosphatidylserine decarboxylase): [778:986](score: 194.6, e-value: 1.4e-57)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00163 (PS_decarb: phosphatidylserine decarboxylase): [772:977](score: 123.1, e-value: 2.2e-36)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000717 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity<br>\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000717\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000717\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTATCGCCTCAAAGATCAAAGGGGCGATTGCGTCTCGAAACCCTTCGCGGCAGAATTCGAGATCGACAACGCCGCAGAGCGAATTGCAGCAGCCATCGCCGAAGAGGGCGGAGACCGGAAGTTCAATTGGCTCCGCAAAGGACTCCATCTACCTACGTGTGGAGGTGATCCAAGCGAGAAATCTCGCGCCTAAAGATCTGAATAAACAATCTGACCCGTATATTGTGGCACAGCTCGACGACTATCATGAGCAGTCTCATGCAGTTCAAAAAACACTCAATCCGGTGTGGAATCACCATTTTCAAATCCCAATTGATCCATCCATGCTGTCCTCGACATTGAAGCTGGTGTGTTGGGACAAGGACAGGTACGGTAAAGACTACATGGGTGAGATTGAAATCACTCTTGAAGAATTGCTGTCGGAAGACCGCGAGAAAGCACAATGGTTTCCGTTGGTATCGTCCAGGAATAGCAAGATCTCTGGTGAGGTTGAGCTAAGCTTCGGATTACACGATCCTCTAAGCCCGAATGCGACCTTTTCCGATCTTGTAAAGGAGTGGACGAGTATGCTTACGGATACATCAGAACTTGGTAGTGATGCTGATAATGACGATTCAGAGATCGACATTTCTGCTGATGCTACGCCGCAACAAAAGGCACGGAAGCGTAGACTGAGGCGAAGAAGGAAATTGCAAAAGCCTTATGAATTCACCCAAAACAAAGTGTCAGGAGTAGCTGGAATTGTCTATTTTGAGGTCACGTCGTGCTCGGATTTACCACCCGAGAGGAATGTGACTCGAACATCTTTCGATATGGATCCATTTGTGATCATCTCTTTTGGAAAGAAGACTTTACGAACAAAGTCTTTGCGCCATACTCTTAATCCTGTATTCAACGAGAAAATGATCTTTCAGGTGTTGATGTTTGAGCAAGCATATACAATCTCTCTGAGGGTTGTCGATAAAGATAAGTTTTCATCCAATGACTTTGTTGCAGAAGCTGTACTGGACGTAAAAGAATTGATCGATACCGGCCCGACTGCAAACAGCGAGACTGGCTTGTATGATTTACCTGATCCCGAAAGCAACCTACAGTTAACCAAGTCAAAACAATCGACGCTGTCTAAGAGCAATACCAGTGAGAGATTGCATCGAGCAGCGAGCAGTAATTCATTGTCACAAGCACAGCCTCAGAAAGTTACAAAGACTGAAACAAGTGTCGCTTCGTCGCTGAACGGGGAAGATGCGCAGTCGACTGAAGGAAGGACCATGGTTCCTCAACTAAGCGAATCTATCGACTATGATCTGAAAAGCTTTACACTCCCGCTAAATATGGCGAAAAAAGAGCGATGGGAGGAAAAGCACACTCCACAGATCAAGATCAAAGCGCGTTTTGTCCCATACCCTGCACTGCGGCAACAGTTTTGGAGATGTATGTTTCGTCAATATGATAGTGACGATACCGGGCGCATTAGTCGCGTGGAAATGACAACTATGTTGGATACTTTGGGCTCGACTCTCACTGACGCCAGCATCGACGAGCTTTTTGAGCGATATAATTTAGGAACTGACGCCAAGTCGAAGGACGAGTATGAAATGACAATAGACCAGGCAATTGTCTGTCTTGAAGAAGAACTTCGCAAAATCGATGCTACGATTCCAGCTGGAGGTGAAAAGACTCCATCTGATGACGAGGAAGACTCTGAGGTCACAGGAGATGCGCACTCCTTGTCAGAAAGCTCTGAATCCAATAACTTCAAGCCTCCGACAGTGTCTTTCAAAGGGACAGAGATTGCCAAGGATGAAATGTTGCATGATGAAGGCAGACGGGAGCATGTTATCGCGATCAAGGAATGTCCACTTTGCCACCAACCGCGGTTGAATAAGCGATCCGATACAGACATTATAACCCATCTCGCAACCTGTGCAAGTCAGGACTGGCGGAGTGTTGATCGAATAGTCATGGGAGATTTCGTTACATCGAGCCAAGCCCAACGCAAATGGTACTCTAAAGTGATATCGAAAGTAGGCTATGGCGGCTACCGGCTCGGAGCAAACTCTGCCAATATTCTGGTGCAAGATCGTTTGACAGGCCAGATCCAGGAAGAGCGCATGAGTATTTATGTGCGCTTGGGCATACGCCTCTTCTACAAAGGATTGAAGAGTGGGGAAATGGAGAAGAAACGGATGCGCCGTCTGCTCTACTCGTTGAGCGTGAAGCAAGGACGCAAGTATGACGCTCCGCCTTCTGCTCGAGACATCAAGAGTTTCATTGCATTTCACAAGCTTAATATGGCTGAGGTGAAGCTACCGATTGAACAGTTCCAGACCTTCAACCAGTTCTTTTACCGCGAGTTGAAACCTGACGCAAGGCCCTGTACAGCACCGGACAATCACTGGATTGCAGTATCCCCAGCAGATTGCCGATGCGTTCTTTTCGATCGGGTTGATAAGGCTAGCGAAATCTGGGTCAAAGGCCGAGATTTCTCCGTGGCCCGATTGCTTGGCAGTGCGTATCCTGAGGATGCCGCAAAGTTCGAGAACGGATCCATTGGCATATTCCGCTTGGCACCACAAGATTACCATCGCTTCCACTGTCCGGTGGAGGGAGTCCTGCAGGAACCCAAAACGATTGATGGTCAGTACTACACGGTCAATCCGATGGCTGTCCGCTCCTCGCTGGATGTATTTGGCGAGAATGTCCGAGTGGTCTGCCCCATCGACTCCGAGGCGTTTGGGCGCGTGATGGTTGTGTGCATTGGAGCTATGATGGTGGGTAGCACTGTCATCACTGCCAAGACCGGCAGTAAGCTGTCTAGAACCCAAGAACTCGGGTACTTCAAATTTGGCGGAAGCACCCTTGTAGTCTTGTTTCAGCCAGGCAAGCTGAAATTTGACGATGACGTTGTGGGCAACTCGAAATCTTCACTCGAGACGCTGATGCGTGTAGGCATGTCTATTGGCCACCATCCGCAAGAGCCGTCCCAAGCACCTAGCAAGAAGGACCGTGAGAACGCCACACTGGAAGATCGCCAACGTGCAAGTATTGCAATTGGTGGAAGTCTGAAGCCGCCACGTGGTTTAGAACAAGATTAG",
    "translation": "MTIASKIKGAIASRNPSRQNSRSTTPQSELQQPSPKRAETGSSIGSAKDSIYLRVEVIQARNLAPKDLNKQSDPYIVAQLDDYHEQSHAVQKTLNPVWNHHFQIPIDPSMLSSTLKLVCWDKDRYGKDYMGEIEITLEELLSEDREKAQWFPLVSSRNSKISGEVELSFGLHDPLSPNATFSDLVKEWTSMLTDTSELGSDADNDDSEIDISADATPQQKARKRRLRRRRKLQKPYEFTQNKVSGVAGIVYFEVTSCSDLPPERNVTRTSFDMDPFVIISFGKKTLRTKSLRHTLNPVFNEKMIFQVLMFEQAYTISLRVVDKDKFSSNDFVAEAVLDVKELIDTGPTANSETGLYDLPDPESNLQLTKSKQSTLSKSNTSERLHRAASSNSLSQAQPQKVTKTETSVASSLNGEDAQSTEGRTMVPQLSESIDYDLKSFTLPLNMAKKERWEEKHTPQIKIKARFVPYPALRQQFWRCMFRQYDSDDTGRISRVEMTTMLDTLGSTLTDASIDELFERYNLGTDAKSKDEYEMTIDQAIVCLEEELRKIDATIPAGGEKTPSDDEEDSEVTGDAHSLSESSESNNFKPPTVSFKGTEIAKDEMLHDEGRREHVIAIKECPLCHQPRLNKRSDTDIITHLATCASQDWRSVDRIVMGDFVTSSQAQRKWYSKVISKVGYGGYRLGANSANILVQDRLTGQIQEERMSIYVRLGIRLFYKGLKSGEMEKKRMRRLLYSLSVKQGRKYDAPPSARDIKSFIAFHKLNMAEVKLPIEQFQTFNQFFYRELKPDARPCTAPDNHWIAVSPADCRCVLFDRVDKASEIWVKGRDFSVARLLGSAYPEDAAKFENGSIGIFRLAPQDYHRFHCPVEGVLQEPKTIDGQYYTVNPMAVRSSLDVFGENVRVVCPIDSEAFGRVMVVCIGAMMVGSTVITAKTGSKLSRTQELGYFKFGGSTLVVLFQPGKLKFDDDVVGNSKSSLETLMRVGMSIGHHPQEPSQAPSKKDRENATLEDRQRASIAIGGSLKPPRGLEQD",
    "product": "hypothetical protein"
   },
   {
    "start": 61375,
    "end": 62502,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000718",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000718</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000718</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000718-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 61,375 - 62,502,\n (total: 1128 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000718 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [15:266](score: 295.4, e-value: 3.1e-88)<br>\n \n  PF08669.14 (Glycine cleavage T-protein C-terminal barrel domain): [292:369](score: 67.5, e-value: 7.5e-19)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000718 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [11:370](score: 382.3, e-value: 4.7e-115)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000718\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000718-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000718\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGACGGTACGCCACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACGGTGTTGCAGCAGTTTGGGGAAGGAGTAAAACGTCGGCGCATTGGACTCACAGTCGAAGGAGCGCCCGCCCGCTCGGCTGCCCCTATTGAGTCCGAGAAACAAGATGTTGGAGTCGTGACAAGCGGGTGCCCATCGCCAACAACCGGGACCAATATTGCCATGGGGTATATTACGCACGGGTTGCACAAGTCTGGCACTGAGATCGCGGTCAAAGTGAGGGGCAGGGAACGGAAAGCCATTGTCACCAAAATGCCCTTTGTGCAGACCAAGTACTATAAATAA",
    "translation": "MRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQTVLQQFGEGVKRRRIGLTVEGAPARSAAPIESEKQDVGVVTSGCPSPTTGTNIAMGYITHGLHKSGTEIAVKVRGRERKAIVTKMPFVQTKYYK",
    "product": "hypothetical protein"
   },
   {
    "start": 62726,
    "end": 63763,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000719",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000719</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000719</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000719-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,726 - 63,763,\n (total: 1038 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000719 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 89.3, e-value: 4.6e-25)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000719 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 95.5, e-value: 9.5e-28)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 65.4, e-value: 1.4e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000719\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000719\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATCTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCCAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGACGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGGTTATTGCAAGGACGCCAGTGGAGGAGCGGATGTATTACTGGCCCGAATTTAGCAGTGTGCCTCGTAATGCCACTGCTATACGATGA",
    "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMVIARTPVEERMYYWPEFSSVPRNATAIR",
    "product": "hypothetical protein"
   },
   {
    "start": 65064,
    "end": 65789,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000720",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000720</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000720</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000720-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,064 - 65,789,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000720 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000720\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000720\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
    "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
    "product": "hypothetical protein"
   },
   {
    "start": 65904,
    "end": 66871,
    "strand": 1,
    "locus_tag": "MARS14BIN71_000721",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000721</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000721</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000721-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,904 - 66,871,\n (total: 948 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 233.7; E-value: 4.1e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000721 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 224.9, e-value: 9.5e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000721 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000721\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000721-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000721\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGCTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGATCCTTAA",
    "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNAWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGDP",
    "product": "hypothetical protein"
   },
   {
    "start": 67009,
    "end": 67803,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000722",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000722</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000722</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000722-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67,009 - 67,803,\n (total: 795 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000722 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [186:250](score: 47.7, e-value: 1.1e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000722\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000722\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGGTCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
    "translation": "MIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
    "product": "hypothetical protein"
   },
   {
    "start": 68082,
    "end": 68348,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000723",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000723</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000723</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000723-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,082 - 68,348,\n (total: 267 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000723\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000723\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGAAGGAGGAGGACAGGGAGGAGCGAGAGAGGGAGGAAGCGTTCTCGTATGAGTACTCCCCGGAAGAGCTGACGAGGCGCTTTCTGAACCAGCAGTCATCTGAGTCGACTGTGCATGTATCAACTCCGGCACACGATGAAGGGCCTTGCATTTCATTTCATGTGGAGCAGAAGCCCAACAGCAACCAGGTCAGGCTGGTGCCGAATACCTACATTGAAGACGACGGACCCGCGTGGAGAAATACCCGCGTGGCCACGGAATGA",
    "translation": "MAKEEDREEREREEAFSYEYSPEELTRRFLNQQSSESTVHVSTPAHDEGPCISFHVEQKPNSNQVRLVPNTYIEDDGPAWRNTRVATE",
    "product": "hypothetical protein"
   },
   {
    "start": 68600,
    "end": 69374,
    "strand": 1,
    "locus_tag": "MARS14BIN71_000724",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000724</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000724</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000724-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 68,600 - 69,374,\n (total: 738 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000724 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01738.21 (Dienelactone hydrolase family): [34:231](score: 46.1, e-value: 4.4e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000724 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01738.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000724\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000724-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000724\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTGACAAATGCTGCCCCTCAGACCTCCCTGCTTTTCAGAGCGACTACAAGCCTCTCGGCCAGACAGTCAAGCTGACAAAGGCGGCGGGCCGTGCATTAGAGACGTACGTGTATCAGCCAGGCGGGAAGGTTGAGCTGGGAATCATCTACTATGCCGACGTCTTTGGCCTCTTGCCCAATGCTCTACAAGGGGCAGACTTGCTGGCAAGGAGTCTAAATGCGCGAGTGTACGTGCCAGACCTCTACGAAGGTCAGCCGTGGGAAACGTCCAATATGCCGCCAAAGGAAGGCTATGAAGCAATGTTTGCCCACTTCGGTAAAGTGGCGCCTCCTGAAAAAATCCGTGAGCTCACAATTGAATTGATCGAGCAACTCCGGGGAGATGGCATTGAACGGGTGGGCGCAATTGGGTTTTGTTTAGGCGCCAAACTCCTTGCAGCAAATTCCGCACTTGTAGGTGCCACAGCCTATATTCATCCGTCAGGCTTCACTGTTGAGGAAGCGAAAGGCTATCGTGGACCGGTCGCTCTCCTTCCATCACAGGACGAGGACAAAGAGCTCATGAAAAACTTTTGGGCAGCTCTCTCAGAGACCGCAAAGAAGGATGGCGTCTTCCAGACCTTCCCTGTCCATCACGGCTTTGCAGCAGGAAGATCAGACTGGAATGACCCTGAGCTTGGCAAGCATGCCCACGAGGCTTTTGAGCTTGCTGCATCAGTCCTGGCAAAGGCCTGA",
    "translation": "MSDKCCPSDLPAFQSDYKPLGQTVKLTKAAGRALETYVYQPGGKVELGIIYYADVFGLLPNALQGADLLARSLNARVYVPDLYEGQPWETSNMPPKEGYEAMFAHFGKVAPPEKIRELTIELIEQLRGDGIERVGAIGFCLGAKLLAANSALVGATAYIHPSGFTVEEAKGYRGPVALLPSQDEDKELMKNFWAALSETAKKDGVFQTFPVHHGFAAGRSDWNDPELGKHAHEAFELAASVLAKA",
    "product": "hypothetical protein"
   },
   {
    "start": 69492,
    "end": 70838,
    "strand": 1,
    "locus_tag": "MARS14BIN71_000725",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000725</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000725</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000725-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 69,492 - 70,838,\n (total: 1347 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000725 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05743.16 (UEV domain): [24:142](score: 112.9, e-value: 8.3e-33)<br>\n \n  PF09454.13 (Vps23 core domain): [377:440](score: 79.5, e-value: 1.5e-22)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_000725 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport<br>\n  \n   PF05743.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000725\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000725\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCAACCAGAAGTCGCGCAATGGCTCCAACGAGTCGTCTCTCGAGACTACTCGGACAAGAAACGAGTGTATGGGGATGTCATCGACCTCTTGACGCGCTACCCGTCATTATCTCCCCGCACCAAAGTGTTCTCCTTTGAAGACGGGCGGTCAGAGCTCTTGCTTTGCATTCACGGCACGCTACCGGTACGATTTCGAAATGCAGACTACAACACGCCAATCACTCTGTGGGTAGACAAGGTATACCCTGTGTCACGTCCTTTGGCATTTGTCACTCCTTCTCCGGAAATGGGTATTCGCGCAGGGAATCACGTAGACCCAAATGGTGCCATCTACCACCCCTTATTGGCGTACTGGGATGCGAAAAAGACAATAGTGGAGCTCGCAGAGCTGTTACGTGAAGTCTTTGGTGCCGAAATGCCAGCATATGCACGCACGGCGAAACAAAATGGAGACAAGGATTTCTACGGCTCCACTTCTCCTCCCCCGCCTCCTCTACCCCCAGCCCCTCACCGAGCAAACTCACCTACTTCTCCAATTCATCCCTCTTCACCCATACCACCACCTCGGCCAAACTACAACGCACCTCCACCGAAACCACCTTTACCTCCACGACTTCAGCCAGGCCCTTCTACCGCATACTCAACTTCTCCAACACCTCCATCACCTCGTGAGTACAGCCCATCTTTCGAGAGACCGCCTACCACACAACTACAACCCAGACCGTCCTCTACACAGTTACCGCCCTCATGGCAAGCTCCAGCACGGCGGCCATCGCCGACACGGCCAACGATAGATATTCTAGATCTCCAGGACGCACTACCTGCAACCTCTGCACCTCCGCTACCCGAGAACCCGGCTCGAAGGGCCCAATTTGAAGAACTAAATAAACGCTTATGCCGTCGAGCGGAGACGTCCACTGAAAAGACTACGACGATGCTGGAGTCAGCCAAGCAAGTTCGCGAGCGGCTTGTTGCTACCGAAACTAGGCTGGAGCTCGAGACCAGCGAACTCCGGCGAATTGAAGAAGCATGCACGCGGGATACTGCGATTCTGCAGGAGCGGATCAATGCTGCAGAGGGAGTCACGAGGGATGCACTTCAATCAGACGAAGTAGACATCGACAAGATCCTCGTCGGATCGAGAGTCGTATACAACCAAATCTACGATCTCGTCTGCGCCGACTTGGCAATTGACGATACGATCTACGCGTTGGGGATAGCGCACGAGCGGGAATGCATCACGTTTGATGTCTTTCTGCGGCATGTCCGCATCCTCGCTCGAGAGCAATTCCTCAAGAAGGCACTGCTGGCAAAGATTAGGGAGCAGACCAAGCTCCAATAA",
    "translation": "MLQPEVAQWLQRVVSRDYSDKKRVYGDVIDLLTRYPSLSPRTKVFSFEDGRSELLLCIHGTLPVRFRNADYNTPITLWVDKVYPVSRPLAFVTPSPEMGIRAGNHVDPNGAIYHPLLAYWDAKKTIVELAELLREVFGAEMPAYARTAKQNGDKDFYGSTSPPPPPLPPAPHRANSPTSPIHPSSPIPPPRPNYNAPPPKPPLPPRLQPGPSTAYSTSPTPPSPREYSPSFERPPTTQLQPRPSSTQLPPSWQAPARRPSPTRPTIDILDLQDALPATSAPPLPENPARRAQFEELNKRLCRRAETSTEKTTTMLESAKQVRERLVATETRLELETSELRRIEEACTRDTAILQERINAAEGVTRDALQSDEVDIDKILVGSRVVYNQIYDLVCADLAIDDTIYALGIAHERECITFDVFLRHVRILAREQFLKKALLAKIREQTKLQ",
    "product": "hypothetical protein"
   },
   {
    "start": 71639,
    "end": 73111,
    "strand": -1,
    "locus_tag": "MARS14BIN71_000726",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000726</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000726</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000726-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 71,639 - 73,111,\n (total: 1473 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_5<br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1139:aminotransferase class V (Score: 313.6; E-value: 2.9e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_000726 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00266.22 (Aminotransferase class-V): [92:455](score: 297.3, e-value: 1.6e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000726\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_000726-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000726\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTGGTGTGGCCCATTACTCGTATCAATTTTTATCACATCGTCATCAATCAAACTCAACCCATGAGGCAAGCGCTGTGTGGAAGAGCTTTCAATACTAGTGCGCCGCGTTATGCCAACGTGCTCTACAAGAGGACCAGCTGTGCTCGCACCTGGTGCGCTGCAACCTATGTGACGCAAAGCAAACCCGCCGAAGCAGCTATCGTTGAATCGAAGCTGCCGCATGGCACGGGAATCCTGAAGCAAACCGTCGAGCCCAAGGCAGAAGGTCGCCCAATCTACTTGGACATGCAGGCTACTACGCCGTTGGATCCACGCGTGCTTGACATCATGCTGCCGTTCATGACTGGAATGTATGGAAATCCTCATTCGAGGACACATGCATATGGATGGGAGACGAATGAAGCGAGCGAGATAGCACGCACGCACGTTGCAAATCTTATTGGAGCGGATCCAAAGGAAATCATCTTCACCTCCGGTGCCACCGAGTCGAACAATATGAGTATCAAGGGAGTAGCTCGATTTTACAAAGGGACAAAAAATCACATCATCACCTGCCAAACAGAACACAAATGCGTGCTGGATTCATGCAGACATTTGCAAAATGAGGGTTTTGATGTCACCTACCTCCCCGTTCAACAGAACGGCTTAATCTCGCTCGAGCAGTTGGAGAAGGAGATTCGACCGGATACGGCTCTAGTGTCCATCATGGCTGTAAACAATGAAATTGGAGTCATTCAGCCGATCGATGAGATTGGCCGATTGTGCCGGAAGAATAAGATCTTTTTCCACACCGACGCTGCACAAGCTGTTGGGAAGATCTGTATGGATGTAAACAAATCCAACATTGATCTCATGTCTATCTCGAGTCATAAGATATATGGTCCCAAGGGCATGGGTGCATGTTATGTGCGGAGACGCCCGCGAGTGCGTCTCGATCCCATTATCTCTGGTGGCGGCCAAGAAAGAGGTTTACGAAGCGGCACGCTCGCGCCTAATCTAGTCGTCGGCTTTGGAGAGGCGTCGCGTCTTGCATTGCAAGAATTCCCCTATGACGAAAAAAGAATCAAAAGCCTGTCAGATCGTTTGGTCAATGGTCTACTTGCCCTTGATCACGTTCATCAAAATGGTGCCCCTGATCGATTCTACCCTGGATGTGTCAATATGTCATTCGCCTATGTCGAGGGCGAATCTCTATTGATGGCACTGAAGGACATTGCTCTCAGCTCCGGTTCCGCCTGCACGTCTGCCTCACTGGAGCCTTCCTATGTGCTGCGGGCTCTAGGCGCTGCGGACGACATGGCCCATTCTTCCATTCGGTTCGGTCTTGGACGGTTCACTACCGAAGACGAGGTGGAGTATGTATTAAAGGCGGTCCGTGATCGCGTGACTTGGCTTCGCGATATGTCTCCGCTTTATGAAATGGTGCAGGATGGAATCGACCTGAAATCAATCCAATGGAGTCAACATTGA",
    "translation": "MVVWPITRINFYHIVINQTQPMRQALCGRAFNTSAPRYANVLYKRTSCARTWCAATYVTQSKPAEAAIVESKLPHGTGILKQTVEPKAEGRPIYLDMQATTPLDPRVLDIMLPFMTGMYGNPHSRTHAYGWETNEASEIARTHVANLIGADPKEIIFTSGATESNNMSIKGVARFYKGTKNHIITCQTEHKCVLDSCRHLQNEGFDVTYLPVQQNGLISLEQLEKEIRPDTALVSIMAVNNEIGVIQPIDEIGRLCRKNKIFFHTDAAQAVGKICMDVNKSNIDLMSISSHKIYGPKGMGACYVRRRPRVRLDPIISGGGQERGLRSGTLAPNLVVGFGEASRLALQEFPYDEKRIKSLSDRLVNGLLALDHVHQNGAPDRFYPGCVNMSFAYVEGESLLMALKDIALSSGSACTSASLEPSYVLRALGAADDMAHSSIRFGLGRFTTEDEVEYVLKAVRDRVTWLRDMSPLYEMVQDGIDLKSIQWSQH",
    "product": "hypothetical protein"
   },
   {
    "start": 74237,
    "end": 76035,
    "strand": 1,
    "locus_tag": "MARS14BIN71_000727",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_000727</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_000727</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_000727-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 74,237 - 76,035,\n (total: 906 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_000727\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_000727\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGAGGCTTTGGCAGATGGCAACAGCAACTCGACTGACTTGTCAGCTCCCGAATGTATTCCCGGAACTGTAAGTACCAAAACAGTGACAGCAACGACCTTTGTTATAGTTGATGGACTTGCACATAGCATTTCAGAGGTTCCTCAAATAGCCAGTGCCACCAAAGAATATGCAACAGCCACAGACTCTGTCGCAGTGACAATTGAGACATCAGCAATTGAGGATCCGGTAAATCAAAGCACACAAGATTACAACGAAAAGCCCCTTCGAGAAAATATGCACCCCACTGAGAAGTCTGTTATAACGTCTGCAATGACCATTCCAGGAACTAGTTCTCACACGGGAATGCTTCACGGATCCCAGGCAACACCAGTGTCCGCTATTGCTCGAAACAATGACGTCGGTCCTGACACAGAGGACCCGTTTTGGCAGACTCCCTTCACAAAAGATCTTTTGAAAGATCCCTGGTCACCAGAAAACTGGAGAGAGGGAGGTAATCGAGCAGCTCAGGTTTCTATGTCTGAAGGCACTGCTGGAAGCTTAGGCATGGAGCCTACAACTGAGTTCGTTTCATTTTGTCCAGAAGTGACTACTGGTGTTATGGTCCCACAAACGCTCAATTCTTCGGAGCCAAAGTTATCAACAGTACCAAGCCTAGTGGGCCACGAGGAAGCCCAGAAACCAAAATATTTTTCAGTAGCTCATATGCACCCTACCGAGCAATGTATGCGGAATTGCTCCATGAACCACGACTATTGGACCGATTGCATTGAGCATGCCATTATGTCCCCAGCTCACGATAAATGTGCTCTGGCTAGTATAGGAAAAGCAAACGATTGCTGCTTGACAAAGTGCCAGCACGAATGCAGCCACATTTCAGACTTTCTTGACTTCTACAAATAG",
    "translation": "MQEALADGNSNSTDLSAPECIPGTVSTKTVTATTFVIVDGLAHSISEVPQIASATKEYATATDSVAVTIETSAIEDPVNQSTQDYNEKPLRENMHPTEKSVITSAMTIPGTSSHTGMLHGSQATPVSAIARNNDVGPDTEDPFWQTPFTKDLLKDPWSPENWREGGNRAAQVSMSEGTAGSLGMEPTTEFVSFCPEVTTGVMVPQTLNSSEPKLSTVPSLVGHEEAQKPKYFSVAHMHPTEQCMRNCSMNHDYWTDCIEHAIMSPAHDKCALASIGKANDCCLTKCQHECSHISDFLDFYK",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 65903,
    "end": 66871,
    "tool": "rule-based-clusters",
    "neighbouring_start": 55903,
    "neighbouring_end": 76871,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r9c1"
 },
 "r40c1": {
  "start": 5421,
  "end": 26364,
  "idx": 1,
  "orfs": [
   {
    "start": 8277,
    "end": 10989,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002019",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002019</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002019</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002019-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,277 - 10,989,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002019 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.3e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 55.3, e-value: 6.4e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002019\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002019\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACGATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGTTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTAAGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTCGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGAATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAGGCAGCCAGATTTAGGCTCTTCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCGGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGTGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAAATTTTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTTCACATATTGGAAAGCTCTATGTCAGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAAGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAAGCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCGCGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAGTTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
    "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKRQPDLGSSLLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVVMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKKFFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKSVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATSLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSSFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
    "product": "hypothetical protein"
   },
   {
    "start": 11090,
    "end": 14356,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002020",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002020</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002020</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002020-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,090 - 14,356,\n (total: 3159 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:315](score: 195.2, e-value: 8.7e-58)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [583:647](score: 28.0, e-value: 1.8e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [917:998](score: 50.2, e-value: 2.2e-13)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 49.9, e-value: 7e-14)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002020 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002020\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002020\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATGTTTGTCCAATTCGTACTCGAAAACATATGGGCGGTTTATGATTGTACAATTATCCGAAAGGACCCAATAAAAATAGATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTAAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGACGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCCAGCGTTGGAATGAATCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAAGCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCGTAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAGAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTCTTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCAGTCTGTCGGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTGGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTCATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
    "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPMFVQFVLENIWAVYDCTIIRKDPIKIDKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEDAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQADPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSVSGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLLADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSSLSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
    "product": "hypothetical protein"
   },
   {
    "start": 14426,
    "end": 15367,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002021",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002021</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002021</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002021-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,426 - 15,367,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002021 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002021\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002021\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
    "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
    "product": "hypothetical protein"
   },
   {
    "start": 15421,
    "end": 16364,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002022",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002022</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002022</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002022-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,421 - 16,364,\n (total: 912 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002022 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [29:285](score: 173.0, e-value: 8.9e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002022 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002022\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002022\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTGTGAAACGAATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
    "translation": "MLVKRMSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
    "product": "hypothetical protein"
   },
   {
    "start": 16714,
    "end": 17238,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002023",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002023</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002023</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002023-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,714 - 17,238,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002023 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.7, e-value: 8.6e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002023 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002023\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002023\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAGGACATAAAGTGTAATGAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAACGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
    "translation": "MDEDIKCNEVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
    "product": "hypothetical protein"
   },
   {
    "start": 17942,
    "end": 18991,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002024",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002024</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002024</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002024-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,942 - 18,991,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002024 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 208.0, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002024\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002024\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
    "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
    "product": "hypothetical protein"
   },
   {
    "start": 19033,
    "end": 19734,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002025",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002025</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002025</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002025-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,033 - 19,734,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002025 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002025\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002025\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
    "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
    "product": "hypothetical protein"
   },
   {
    "start": 20261,
    "end": 21283,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002026",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002026</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002026</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002026-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,261 - 21,283,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002026 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002026\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002026\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCGGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACAGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
    "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
    "product": "hypothetical protein"
   },
   {
    "start": 21338,
    "end": 21778,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002027",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002027</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002027</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002027-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,338 - 21,778,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002027\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002027\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
    "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
    "product": "hypothetical protein"
   },
   {
    "start": 22551,
    "end": 23855,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002028",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002028</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002028</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002028-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,551 - 23,855,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325; E-value: 1.4e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002028 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.8, e-value: 2.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002028 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002028\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002028-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002028\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGTAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCATGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
    "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTVEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVMAMDKEQVKRKRKLRAG",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 15420,
    "end": 16364,
    "tool": "rule-based-clusters",
    "neighbouring_start": 5420,
    "neighbouring_end": 26364,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r40c1"
 },
 "r52c1": {
  "start": 15683,
  "end": 37295,
  "idx": 1,
  "orfs": [
   {
    "start": 16031,
    "end": 18746,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002405",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002405</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002405</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002405-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,031 - 18,746,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002405 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [8:195](score: 129.6, e-value: 1e-37)<br>\n \n  PF00106.28 (short chain dehydrogenase): [313:496](score: 146.2, e-value: 8.9e-43)<br>\n \n  PF01575.22 (MaoC like domain): [769:879](score: 113.0, e-value: 6.8e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002405\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002405-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002405\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCGATCTACGGTTCGATGACCAGGTAGTCGTAGTCACTGGTGCTGGTGGAGGCTTGGGCAAGGCGTACGCGCTTTTCTTCGCCAGCCGAGGTGCGAACGTGGTTGTTAATGATTTGGGTGGCAGCTTTCACGGAGAAGGACAGAGCTCAAAGGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCATGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGCATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGTAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCCCTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAGAAGACTCAGAGAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTATTGAAAATATAAGTAATCGTTCCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTGTTTGAAGGCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTGAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
    "translation": "MPDLRFDDQVVVVTGAGGGLGKAYALFFASRGANVVVNDLGGSFHGEGQSSKAADLVVDEIKKAGGHAVADYNNVQNGDQIIETAVKAFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQRMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIIENISNRSGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEGSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
    "product": "hypothetical protein"
   },
   {
    "start": 18858,
    "end": 20968,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002406",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002406</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002406</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002406-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,858 - 20,968,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002406 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:339](score: 57.8, e-value: 1.4e-15)<br>\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [366:569](score: 290.8, e-value: 5.4e-87)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002406 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002406\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002406\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCCGTCTCGCCTGAAATCGCCAAACGTGTCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACGTTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTCGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAAACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGCGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGGCATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
    "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRVEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKTLATTSLALSLCLVCGVVAQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
    "product": "hypothetical protein"
   },
   {
    "start": 21067,
    "end": 24899,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002407",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002407</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002407</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002407-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,067 - 24,899,\n (total: 3702 nt, excluding introns)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 54.7; E-value: 1.2e-16)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002407 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [131:159](score: 22.3, e-value: 0.00019)<br>\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [1075:1199](score: 115.0, e-value: 2.7e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002407 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002407\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002407\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGAGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGTGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGCTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGGAATCTATCGCATTCTGTTGCTCGTATCACGCACGATCTTGTTGCAGCCTCCTTCTCTCTTGTTGGTGTCGCGTTGATCTTCGTAGTCCACGTACGTGTTGGTAGCCGCAGGCAAAACATGAATAGACCACCCTCTATCCATCCACATATCAGACCGGCGCCCGGGCTGAGTGCGCCTGCCCAGCCATCTGCTCCTCCGACACTGCAGCCCCCCAAGCAACCACGAAGCCAGAGCTCGCTGCCTCCGCCCCAACTGGCAGGGACGCTTCGCATCCCAAACGGCAAGTTTCCGGCTCGAACATCGTCTCAGTCAAGTAACGGGCAATTGAATATGCCGAGAGCGCCGCCAAGTTGGAATAGCAGCACCTCTGGATCGATGGGCGCTTCCGAAGTGCCGCGAATCCCACCTGGCCCTTCGGGATCGTCCTTTGCACAGTCGCTCGGCCACCCGCAACCGACCACCCCGCTGGACATGTCTGAGTTCCCGGCTTTGGGGGGAGGTAGTGCTGGGATGAATGCTGGTGCAAGTGCGAATCCATCGCATAGCTCCGCAGGACCAATATCAGCGAATACCGGCTCGATGAATAATGCTGGCAGCTATGCGTTCAGAGCGGCCACTGCGTCACCGGGACAAGGGTTACGGCAGGCGTCAGGGTCTTTGGGCACGCTGCATTCACGCGGTGTAGAGGAAGATGATGGGACTATGAATGACTTTCCTGCTCTTCCAGCAGACCCGGACAAGATCGCCAGCTCGTCGTCGTATGTTCCCGTCTCAGACTCTGGCGCGCAGGATGACTGGAGCCAGCAAAATTCCCACCTCCACCAACAGAGACATGGGCCTCAGCAGCAGCAACAGCAGGAACAGCATAGATCCGCCTTATTAGGAGTAATGACCGGCGCATTTGGCCAATCTAGTATACCCCAATCTGTACCAGAACCAACCTCCCCAGCTCCTTCTAATGCCGCCGCAACCCCTCAATCTATCTCCAACAACGCTGTAGCCGCCTCACACATGCAGCCTGCTCTCACCAGTGAGCAGGACACGAGTGAACTAATGAAAGCGAACGCCACGTCACTAATGCCAGTGGGAGCTCCTGGCATGCCCACTAATTTCGACAACTCAAACCTTCACAAAAGTCAAGCTTCTTTCCCCCCGTCTTCGCCTGCTGGCTCTCTGCAAGGCAACAATACGAGCATATCGGTCCAAGACCGATATGGGTTGCGTGGCCTCTTAAGTATCATTCGCATGGACAATCCGGATGCGAGCATGCTGTCTCTAGGCAGCGACCTGACTAGCCTTGGCCTGAATTTGAATCAGCCCGACGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAACAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
    "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKSRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQRNLSHSVARITHDLVAASFSLVGVALIFVVHVRVGSRRQNMNRPPSIHPHIRPAPGLSAPAQPSAPPTLQPPKQPRSQSSLPPPQLAGTLRIPNGKFPARTSSQSSNGQLNMPRAPPSWNSSTSGSMGASEVPRIPPGPSGSSFAQSLGHPQPTTPLDMSEFPALGGGSAGMNAGASANPSHSSAGPISANTGSMNNAGSYAFRAATASPGQGLRQASGSLGTLHSRGVEEDDGTMNDFPALPADPDKIASSSSYVPVSDSGAQDDWSQQNSHLHQQRHGPQQQQQQEQHRSALLGVMTGAFGQSSIPQSVPEPTSPAPSNAAATPQSISNNAVAASHMQPALTSEQDTSELMKANATSLMPVGAPGMPTNFDNSNLHKSQASFPPSSPAGSLQGNNTSISVQDRYGLRGLLSIIRMDNPDASMLSLGSDLTSLGLNLNQPDDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
    "product": "hypothetical protein"
   },
   {
    "start": 25257,
    "end": 25680,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002408",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002408</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002408</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002408-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,257 - 25,680,\n (total: 390 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002408\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002408-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002408\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGGACTCGTGGCCTGGCTCTGTGGTGCGAGAATGGATCTCGCATTCAAAGCGGTCCGCACCATGAACTTCACAGCTCCTTCAGCACATGAGCTGTAG",
    "translation": "MQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMGLVAWLCGARMDLAFKAVRTMNFTAPSAHEL",
    "product": "hypothetical protein"
   },
   {
    "start": 25683,
    "end": 27295,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002409",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002409</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002409</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002409-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,683 - 27,295,\n (total: 1152 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [77:368](score: 129.5, e-value: 1.7e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [67:377](score: 390.9, e-value: 1.2e-117)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002409 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002409\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002409-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002409\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCCGGGACATAGCCAAGGAGAGCGAGAATATCCGAAAGTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCTCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTATAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTGTATGCATTTTCTCAGAGGCATCTAATGTTAGTTGA",
    "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETRDIAKESENIRKCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACAVCIFSEASNVS",
    "product": "hypothetical protein"
   },
   {
    "start": 27379,
    "end": 29358,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002410",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002410</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002410</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002410-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 27,379 - 29,358,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002410 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 204.3, e-value: 3.7e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002410 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002410\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002410\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTTCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTTCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
    "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSSTNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
    "product": "hypothetical protein"
   },
   {
    "start": 29891,
    "end": 30652,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002411",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002411</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002411</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002411-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,891 - 30,652,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002411 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [0:145](score: 44.1, e-value: 2.3e-11)<br>\n \n  PF03129.23 (Anticodon binding domain): [165:212](score: 21.7, e-value: 0.00018)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002411 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002411\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002411\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
    "translation": "MNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
    "product": "hypothetical protein"
   },
   {
    "start": 30922,
    "end": 32226,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002412",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002412</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002412</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002412-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,922 - 32,226,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002412 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002412\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002412\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTACGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
    "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGMGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLTTPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
    "product": "hypothetical protein"
   },
   {
    "start": 32439,
    "end": 33350,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002413",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002413</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002413</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002413-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,439 - 33,350,\n (total: 912 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002413 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [3:111](score: 50.9, e-value: 1.4e-13)<br>\n \n  PF03473.20 (MOSC domain): [161:290](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002413 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002413\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002413\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATAGCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGCGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAGAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTCGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTCGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
    "translation": "MTMHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDSEELVLAFDGIAQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
    "product": "hypothetical protein"
   },
   {
    "start": 33417,
    "end": 34091,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002414",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002414</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002414</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002414-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,417 - 34,091,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002414\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002414\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCCATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
    "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
    "product": "hypothetical protein"
   },
   {
    "start": 34101,
    "end": 35669,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002415",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002415</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002415</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002415-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,101 - 35,669,\n (total: 1569 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002415\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002415\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTCGTTCATTGGCGATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACTGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAGGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACGATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATCCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
    "translation": "MSRSLAMNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRLRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYRNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIRWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIASCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 25682,
    "end": 27295,
    "tool": "rule-based-clusters",
    "neighbouring_start": 15682,
    "neighbouring_end": 37295,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r52c1"
 },
 "r75c1": {
  "start": 10844,
  "end": 35875,
  "idx": 1,
  "orfs": [
   {
    "start": 11467,
    "end": 12148,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002913",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002913</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002913</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002913-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,467 - 12,148,\n (total: 648 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00071.25 (Ras family): [10:167](score: 167.2, e-value: 2.4e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [8:158](score: 76.9, e-value: 3.6e-22)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002913 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00071.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00071.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002913\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002913\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGACAAGCCGCAAGTCCCAACCTTCAAGCTCGTCCTCGTCGGAGATGGTGGCACAGGCAAAACCACGTTTGTGAAGAGGCATTTGACGGGGGAGTTTGAAAAGAAGTACATTGCCACCCTCGGCGTCGAAGTCCATCCCCTTAAATTCCACACCAATTTTGGTGAGATCCAGTTCGATGTGTGGGATACGGCAGGGCAAGAGAAGTTCGGCGGGCTGCGCGACGGGTACTACATCAATGGCCAATGCGGGATCATCATGTTTGACGTGACCTCGCGCATCACGTACAAGCAGGTGAGCAACTGGCATCGCGACCTCGTGCGGGTATGCGAAAACATCCCCATCGTGCTCTGCGGGAATAAAGTCGACGTGAAGGAGCGCAAAGTGAAGGCCAAGACAATCACCTTCCATAGGAAAAAGAACTTGCAGTACTACGATATCTCAGCCAAGAGCAACTACAACTTTGAGAAGCCGTTTCTCTGGCTCGCGAGGAAGCTGGCGGGGAATGCTACGCTCGAGTTTGTGGCGGCGCCCGCGCTCGCGCCGCCTGAAGTGCAGGTGGACGCGAATCTGATGGCGCAGTACCAAAATGAAATGGAAAATGCACAGAAAATGCCCTTGCCGGACGAAGACGAGGATTTCTAA",
    "translation": "MTDKPQVPTFKLVLVGDGGTGKTTFVKRHLTGEFEKKYIATLGVEVHPLKFHTNFGEIQFDVWDTAGQEKFGGLRDGYYINGQCGIIMFDVTSRITYKQVSNWHRDLVRVCENIPIVLCGNKVDVKERKVKAKTITFHRKKNLQYYDISAKSNYNFEKPFLWLARKLAGNATLEFVAAPALAPPEVQVDANLMAQYQNEMENAQKMPLPDEDEDF",
    "product": "hypothetical protein"
   },
   {
    "start": 12243,
    "end": 13946,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002914",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002914</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002914</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002914-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,243 - 13,946,\n (total: 1704 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 90; E-value: 2.4e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002914 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [394:419](score: 18.6, e-value: 0.0027)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002914 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002914\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002914\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATGTTTGTTGTGCCGCCTCCGCCAATGCGCGTCCCAAATGGCCAGGGAGCGTACGGCAGCAGCGCGGCCATGCAGTCCTTCCAGATGCAGGCGCAGCAGTCCTATCTGCCGCCGCCCTCCAGCCTGGAAAGCTCCAACAGCCTCAAAAATCCCGACGAGCTCTTTTCCCTCGCAGAAGGGCGGTATGTCTTGCGAGACGAGATCAGCCTGGCCTGCCCGCCGCCGCACCCGTCCGAGCCCCCGCCGTTGCAGCCCAATCCGCTGGCGTCCGCCCCGTGGGTCGAGTCCAACGGCACCTACATCTCGATATGCGCCGTGCAGGATCCAAAGGCCTTCATCCGCCCAACCTACATGCCGCCCGTCTCCAAAGACTCGAGCTCTGCAGACTCGGATGCCGACTCTGCGACAAGCGACGCCCAGCCCACGCAGCCGCTCTTCGGGATGCAGGCGCGCGGGGAGATGAAGCGGCGCAAGCCCAAGAACAACATGGCAAAGTCGAATTCGTCCTTCATCTCGCGCATCATTACACACGAGCACTTGGCGAAACGGGTCGCGGAACGGTCGCCCGAGGGCCTCTACGGCTTCATCAACATCAACCGCTCCTTCCAATGGCTGGACCTCTCTGCGCCAAACAAGGCAGAACCGCTGGCAAAGATCCTGTTTACAAAAGCCCATCCCTTGTGCTCGGATGTGAATCAATACAACAAAGCACCAAACCACCTCGATGTACTTATTGGGTTTAATACAGGCGACATCATGTGGTACGACCCGGTTGGCTCAAAGTACGCTCGTATCAATAAAAATGGAGTCTTTAATGGATCGGCAGTGTATGACATTCGGTGGATTCCCGGGAGCGAGTCGCTTTTCATGGTGGCGCACAAGGACGGACGAATCATGATCTATGATACGGAAAAGGAAGACGGACCGGCAAACATGAGCTCAGACGAGTTGGTTACCGGCACCACCTCCTTTCGCATCGTGAAGCGCTTCTCCTCTGGCAGATTGAGCAAAACCAATCCCGTGGGTGCATGGGAAATTTCCTCCAACCCGGTCTACAAGATCGCATTTTCCCCGGATGCGACGTGTCTGGCGATCGCCTCGGAAGACGGAAAGCTGCGTGTGGTGGACCTTCGCAAGGAGCGTCTGATTGATCTCTACGTCTCCTATTACGGCGGCTTCTCAAGTGTGGCATGGTCACCCGACGGCCGCTACCTCCTATCTGGGGGTCAGGATGATCTCATCACCATTTGGAGCGTGAGTGAGCGGCGGGTGGTGGCTCGATGCCCGGGCCATACCTCGTGGGTGACAGACATCGCCTTTGACCCGTGGGGCTGCGAGCACGGACAGTATCGCTTTGGATCCGTCGGCCAGGATTGCCGGCTCCTGCTCTGGGACTTCACCTTGAGCGCCCTCCACCGGCCAAAGACGCTCCTGCACAGCACCCGGATGGGCAAGACCGCACCGCGGCCGCGCGCCAACTCCAACATGTCGGCTGCGGAAGCGAGTGTGCGGCTGCACGCGCCGGAGTCGCGTGGCCAGGTCGCCACGCTGATGCCAATCGTGAGCAAGCAGATCGATGCCTCGCCACTCCTCTGTCTGCACTTCCGCAAAGACTGCTTAGTCACGAGTTCACGGCTGGGCAAGATCCGGACGTGGGACCGGCCCAAAGACGAAGACAATGGACGTGTATGGGATGACTAG",
    "translation": "MMFVVPPPPMRVPNGQGAYGSSAAMQSFQMQAQQSYLPPPSSLESSNSLKNPDELFSLAEGRYVLRDEISLACPPPHPSEPPPLQPNPLASAPWVESNGTYISICAVQDPKAFIRPTYMPPVSKDSSSADSDADSATSDAQPTQPLFGMQARGEMKRRKPKNNMAKSNSSFISRIITHEHLAKRVAERSPEGLYGFININRSFQWLDLSAPNKAEPLAKILFTKAHPLCSDVNQYNKAPNHLDVLIGFNTGDIMWYDPVGSKYARINKNGVFNGSAVYDIRWIPGSESLFMVAHKDGRIMIYDTEKEDGPANMSSDELVTGTTSFRIVKRFSSGRLSKTNPVGAWEISSNPVYKIAFSPDATCLAIASEDGKLRVVDLRKERLIDLYVSYYGGFSSVAWSPDGRYLLSGGQDDLITIWSVSERRVVARCPGHTSWVTDIAFDPWGCEHGQYRFGSVGQDCRLLLWDFTLSALHRPKTLLHSTRMGKTAPRPRANSNMSAAEASVRLHAPESRGQVATLMPIVSKQIDASPLLCLHFRKDCLVTSSRLGKIRTWDRPKDEDNGRVWDD",
    "product": "hypothetical protein"
   },
   {
    "start": 14003,
    "end": 14500,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002915",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002915</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002915</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002915-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,003 - 14,500,\n (total: 498 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002915 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17110.8 (Subunit 11 of the general transcription factor TFIIH): [48:143](score: 31.5, e-value: 1.5e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002915\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002915\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAGGAAGAAGGAGGCGATGGAGGGCGGAGATGGAGGGCAAGGGCTCACCCCGCGTCAGCTGACCAACCTGGCCACCTTCCTCGACACCAGACTGCTGCAAGTGTCGCGCAGGTTCAACAAGAAGTTCAGCGCAGACGACGGCTACACCAGCTTCCGCCAGATTGCCAGCGACGCAAAGCCCATTCTGGAGATCTTGGAGCAGTCCCCGGTTTACATACGCGTACAATATGCCCTGACACTCACGGGCAGTCTGTTCTCCTATCTGCCCGCCTTCCCGCCTACAGCAGTCCTCTTCCCCCTCTCCAGGCGGCTCGACACCCTCTTTGTAGGTCTGTGTGGCCGGGTGGACTCCACCTCCAAGGTGCGGATTGCGAGTGTCGTGAATGATGCACGCACCATTGCTGTGTGTGTCTACAATCGTGAATGGAGTATTCAAGCAGGCATGCTCTTTGAGGATACCATCGAAGAGCTCGGAAAGACTACCCTGTTTTAA",
    "translation": "MSRKKEAMEGGDGGQGLTPRQLTNLATFLDTRLLQVSRRFNKKFSADDGYTSFRQIASDAKPILEILEQSPVYIRVQYALTLTGSLFSYLPAFPPTAVLFPLSRRLDTLFVGLCGRVDSTSKVRIASVVNDARTIAVCVYNREWSIQAGMLFEDTIEELGKTTLF",
    "product": "hypothetical protein"
   },
   {
    "start": 14573,
    "end": 15630,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002916",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002916</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002916</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002916-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,573 - 15,630,\n (total: 1008 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002916 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13813.9 (Membrane bound O-acyl transferase family): [226:309](score: 51.7, e-value: 8.8e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002916\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002916\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACTTCATGAATACAAATGAAGCAAGGATGGCATTCTCGTTTTGGACGCAGCTATTTATAGACGCAGGATGGCCGGTCGACGTGGACGACCAGCCCCGCGAAATACTGTGGTCTAGGCCGCTGCCGCTGGTGGCTTCCGTCTTTCCATTCCTCATCTGCGTGCTGACTCTAGCATATCACCCGCTGCTCATCCAGCCAGAGCCGTCGCGTCTCGAAATCCTCCTGTGTCTGCTCGTTGGCCTCTTTCCCGTCATTTGGGGAGCGCAAGGCAGCGGATCTGCTGTTTTTGAATTTGCGCTATCGACAATCACGAGCGTGGTCGGTCTTCGCATGGTTCGACTGTCGTTCTTTCGACGCCGCACCAGACGGAGCAGGCTGGATATGTGGACAGAGCTGATCAGCCTGCCACTCCCCGACCAAACAACTCATTCGCAAGCACAGGCTCCTTCATCTGCACGACGCCAGAATGCAATTCAAGCCATGCAAGCTTTGCCCCAGGCTGTGCTGGTTCCTACCTTACTTCGATGCATACCACCCCCTGAGTCCTTAATACACATGTCCTTCATCCAGGCCAGGCTTTATCACATGCTGGCTGGGCTGGCCATCCTTTTTGTCTTGCAGGGCTCCGTGCAACTCTGCCTATCCAGCTGGGGAATTGTCATGAACTCTCGGCAAAAGCCCATGTTCAGGAATCCATTGGGAGCTCGCACCTTGCAGGAGCTTTGGGGCCAGAGGTGGAACCGAGTTGTTCAAGAGCAGCTACACTTTCTCTTTGCATGCCTCGCTGGAAATAAAGTCAAAGGGGGAAGGCGTCGGCGGACACTGGCTGCACTGGCAACCTTTCTCCTGTCTGGCCTCTTTCACGAGTACCTGGCCTACCAGTCTTTTGGAACTGCTTCCTTTCAGCAGTTCTGGTTCTTCATGATTCAGGGTGTTCTTTGCAGTATGGAGCCATACATTCCCAAAGGCGCCACCTACGCCTGGCTCGTTCAGCCACTTCTTTGA",
    "translation": "MDFMNTNEARMAFSFWTQLFIDAGWPVDVDDQPREILWSRPLPLVASVFPFLICVLTLAYHPLLIQPEPSRLEILLCLLVGLFPVIWGAQGSGSAVFEFALSTITSVVGLRMVRLSFFRRRTRRSRLDMWTELISLPLPDQTTHSQAQAPSSARRQNAIQAMQALPQAVLVPTLLRCIPPPESLIHMSFIQARLYHMLAGLAILFVLQGSVQLCLSSWGIVMNSRQKPMFRNPLGARTLQELWGQRWNRVVQEQLHFLFACLAGNKVKGGRRRRTLAALATFLLSGLFHEYLAYQSFGTASFQQFWFFMIQGVLCSMEPYIPKGATYAWLVQPLL",
    "product": "hypothetical protein"
   },
   {
    "start": 15779,
    "end": 17044,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002917",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002917</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002917</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002917-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,779 - 17,044,\n (total: 1266 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002917\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002917\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGTGAAGCGGAGACTGTCCTCCACATCGCGGTCGTCCGCTGACGCAGACGCGCCAGATTCATCGGCCGCGATCTGGCCCGCGCCGCAACGAGACTTGGAGAGCGCGCGAGCCTTCATTCAAGAGGCGGCCAGATCGCAGCGCAAGATTGTGATTGCACCGGATCGCGACGCTGATGGGCTCTGCTCTGGCGCACAGCTACGACATACCCTTCTACACCTGGGTGCGGCACCCGACCAGATCGCCATCAAGTTTGTCGCCAAAGGACGGAATGTGCATTGTGATGAAGAGCGCGCGGACTTAGAGCGGTATCAGGCGGAGTATATCTTTGTTCTCGATCATGGAAGTCGAGGCGGTGGGCCCATAGCAGATGGGAAGGTGCTCATCCTAGATCATCACTGGAGCGAGGACTTCCCAGACGACGCGCAGGTGGTGAGTGCATGCAAGTATCTACCCGTGGCCACGGCGTCACTATTGACGTATGTCGTCTGCCTCGCCATCAATGAGCACCTCCCGGCCTGGCTCGCAGTCACTGGCACCGTTGGCGATCTCGGCACTACCGTTACGTTTGAGCCCCCATTTCCAACAAGTTTGGCGCAGACATTCAAGGCGCAAGGCAAGAAGCAGATCGCAGAGGTTGTCGCCCTGTTGAATGCACCTCGACGCACTCCAGCCTGCGACCCGACCGAGGCGTGGCAGCTGCTGATTGCAAGCGCGTCTGCCCGAGACTTCCTCGCATCACCGAGCACGCGCTCGCTGGACGACGCGCGCGTATATATCCAAAGAGAGACAGAGCGATGCACGCATGCGGCCCCCAGATTCACAAAGGACGGTCGGATGGCCATTTTGGAGATGTCGTCGCCTGCACAGATCCATCAGCTCATTGCGACGCGCTGGGCCGGCTTCCTGAAATCCAAAGCGCTGCTTGCAGTCGGTGTTGCTAATCGGGGGTACGCTCCCGACAAAGTTCATCTGTCCTGCCGCCTTGTCAAGAGTAGGCGGAGTGAAGAGCCGCCCGTCAACTTGATTGCCCTGCTTAACGAATACCTCGCCCGAGACGCAGATCTGGCAAAGACCATTGGACCCGATTTTGCGCATGGTCACAAGGAAGCTGCAGGGGGCCACATGTCTCCTGAGCAATGGGACAGGCTAGTCGCGGCGATGGAAATTGGAAATTGGAAGTCGCCCAACAAGGACAGCCCCAAAAAGCCCTCCGTGGACGCGAAGCAATCCAACTTGACAGGTTATTTCAAGCGTGTCTAG",
    "translation": "MGVKRRLSSTSRSSADADAPDSSAAIWPAPQRDLESARAFIQEAARSQRKIVIAPDRDADGLCSGAQLRHTLLHLGAAPDQIAIKFVAKGRNVHCDEERADLERYQAEYIFVLDHGSRGGGPIADGKVLILDHHWSEDFPDDAQVVSACKYLPVATASLLTYVVCLAINEHLPAWLAVTGTVGDLGTTVTFEPPFPTSLAQTFKAQGKKQIAEVVALLNAPRRTPACDPTEAWQLLIASASARDFLASPSTRSLDDARVYIQRETERCTHAAPRFTKDGRMAILEMSSPAQIHQLIATRWAGFLKSKALLAVGVANRGYAPDKVHLSCRLVKSRRSEEPPVNLIALLNEYLARDADLAKTIGPDFAHGHKEAAGGHMSPEQWDRLVAAMEIGNWKSPNKDSPKKPSVDAKQSNLTGYFKRV",
    "product": "hypothetical protein"
   },
   {
    "start": 17081,
    "end": 18976,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002918",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002918</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002918</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002918-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,081 - 18,976,\n (total: 1896 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002918 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02990.19 (Endomembrane protein 70): [51:587](score: 650.5, e-value: 2.1e-195)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002918 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02990.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002918\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002918\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCATCGGATCCAACGGAGGCTGCTGCTGCTGCTGCTCCTCCTCCGCCAGGCAAGCGGCTTCTACATCCCCGGCTGGAGCATCCGCTCGTACGCCGACGGGGACGCAATCCCCCTGCAGACCAACAAGGTCTCCTCTGACGCCACCTCCCTGCCCTACGCCTACTCCGAGCTGCCCTTTGTCTGCGATGCCCCGGGGCGCAGCAGCAGGCGGGTCGCCCTCAACCTGGGCGAGGTTCTGCGCGGCGACCGCATCGCGACGTCCGGCTACGAGATCGAGATGGGCAAGGACGTGGCCTGTGCGCACCTGTGCGACGCGGCCGTCGATGCTGCCGGCATCGCGCGCGCCACCCAGCTCATCCGCAACGGCTACTCGGCCGAATGGATCGTGGACAACCTGCCCGGCGCCACCTCCTTCGTCACCGTCGACCGCACCAAAAAGTACTACGCGGCCGGCTTCAAGCTGGGCGGGTTTGAGAATGACGTGGCAAAGTTTCATAATCACGTCAGCCTGGTCTTCCGGTGGCGCCGGCTGGAGGCAGACAGCGACCGCAAGGTCATTGTGGCCTTTGAAGTCTACCCAAAGTCTATCAAAACAAAGGCCGGCGCATGCCCCACCTCGCTCGACAATCAGCCCCCGCTGGAGCTCCCGGAGACGAGCACAGTAGGGGTGGACGGCTTCACAATTCCCTACACCTACAGCATATTTTGGAAGGAAGACGACACCATCGAATGGTCGTCGAGATGGGACCTCTACTTTGTCAACAACGAAGATGCGCACCAGATCCATTGGCTGGCCATTGTAAACTCTACCGTCATTGTCATGGTGCTCAGTGGCGTGGTCTTCCTCATCCTGGTGCGAACCCTCTCGCGCGACATTCAATCCTACAACACGCCCGACGGCGACGACGACAAGGATACAGATGCCGACATAACTGGCTGGAAACTTGTGCATGGGGACGTCTTCCGACCGCCGCCGGCTGGCGGTCTGTTCTCCCCCCTTATCGGAGCGGGTGTGCAATTGCTCGTCATGATGTTGGCCCTCCTCATTTTGTCCGCGGCCGGGATCCTCAATCCCTCCTACCGGGGCGGCTTTCTCTCTTTTGCCCTCTTCCTCTTCGTCTTTGCGGGTGTCTTTTCCGGATTGCATTCCACAAAGATCTACAAAACGTTTGGAGGGTCCCAGTGGGTCAAGAATGGGTTGATGACTGCGCTCTTAGTGCCGGGAAGTGTCTTCCTGACCGTCTTTATCCTCAATTTGTTCGTCTGGGCGGAAGCGTCGTCTTCGGCCCTTCCATTTGGAACGTTGGTTGCGCTGTTGGCCATGTGGCTGCTTATCTCTCTTCCCCTAGTCTTGCTGGGAAGTTTCATTGGCTTCCGACGTCCGGCCGTGGAGCATCCTACGAAAGCCAACCAGATACCACGCCAGATCCCCGAACAGCCTCGCCACCTCCGATTCTTTCCCTCGCTGCTCATCACCGGCGTCGTTCCCTTTGCAGTCATCTTTATTGAACTTTTGTTTGTCTTCCGATCCGTGTGGGCGGAAAAGTCGGGCTACTACTACGTCTATGGATTCCTTGGGCTCATCACGCTCATCCTCCTGATTACGACGGTCGAAATAACACTCATTCATGTCTACTTTATGCTCTGTGCCGAGAACTACCATTGGTGGTGGCGATCGTTCTTTGTGGGTGGTGCGAGCGCCATCTACGTCTTTGGCTACTGCGTTTGGTACTACCTTTTCAAGCTCCAGCTGCACGGGTGGGTGAGCGGCCTGCTCTTCTTAGGCTACTCCCTGCTCGGCTGTGCCTTGTATGGGGTCTTCCTCGGGACGGTAGGGTCTCTGTCGGCATATGTCTTTGTGAGGAAGATATATGCCGCAGTCAAGGTGGATTAG",
    "translation": "MHRIQRRLLLLLLLLRQASGFYIPGWSIRSYADGDAIPLQTNKVSSDATSLPYAYSELPFVCDAPGRSSRRVALNLGEVLRGDRIATSGYEIEMGKDVACAHLCDAAVDAAGIARATQLIRNGYSAEWIVDNLPGATSFVTVDRTKKYYAAGFKLGGFENDVAKFHNHVSLVFRWRRLEADSDRKVIVAFEVYPKSIKTKAGACPTSLDNQPPLELPETSTVGVDGFTIPYTYSIFWKEDDTIEWSSRWDLYFVNNEDAHQIHWLAIVNSTVIVMVLSGVVFLILVRTLSRDIQSYNTPDGDDDKDTDADITGWKLVHGDVFRPPPAGGLFSPLIGAGVQLLVMMLALLILSAAGILNPSYRGGFLSFALFLFVFAGVFSGLHSTKIYKTFGGSQWVKNGLMTALLVPGSVFLTVFILNLFVWAEASSSALPFGTLVALLAMWLLISLPLVLLGSFIGFRRPAVEHPTKANQIPRQIPEQPRHLRFFPSLLITGVVPFAVIFIELLFVFRSVWAEKSGYYYVYGFLGLITLILLITTVEITLIHVYFMLCAENYHWWWRSFFVGGASAIYVFGYCVWYYLFKLQLHGWVSGLLFLGYSLLGCALYGVFLGTVGSLSAYVFVRKIYAAVKVD",
    "product": "hypothetical protein"
   },
   {
    "start": 19032,
    "end": 21845,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002919",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002919</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002919</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002919-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,032 - 21,845,\n (total: 2775 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_N<br>\n \n  biosynthetic-additional (rule-based-clusters) ADH_zinc_N<br>\n \n  biosynthetic-additional (smcogs) SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase (Score: 278.3; E-value: 1.3e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002919 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01544.21 (CorA-like Mg2+ transporter protein): [288:592](score: 159.3, e-value: 1.4e-46)<br>\n \n  PF08240.15 (Alcohol dehydrogenase GroES-like domain): [625:689](score: 39.4, e-value: 4.9e-10)<br>\n \n  PF00107.29 (Zinc-binding dehydrogenase): [747:870](score: 92.4, e-value: 2.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002919 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n   PF01544.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002919\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002919-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002919\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCGAGAGCAGCAGAGAGGCGATCCCAGCGCGCCGGCGACGGTCCAGCGCCAGCAAGGGTTTTGCCCCGCCCTTCCAGCAGCGACGCGCGCAGTTCGTGCAGCAGGAGCAGCAGCAGCAGCGCAGTCTCAGCCCCAGCTCCCTCGACTCGAACGCCCTCTTGGACCACCGCTCCCAGCCAGAGAGCATCCCCCGGCCCTCCTTCCTGCGCAACCGCAGCGACAGGACCGGCGGCGAGCGGGAGGAGCGACGGGGCAAGGGCAGAAGGGAGAGCCGCGACCGCCACCATGAGCAGACACCTCTGTTGGAGGGCGAGGGAGAAGGGGGGGCGGGGCCCAGCTCGGGGGAGCAGGCGGACCAGCACCCCTTTGTGCACTACCAGCCAAACTACGGGTCCGGGGCCCATGGAGACGCAGTCATCACTATCGAGGGCGCCGGCGATGGGAGCTCCACGGACGACTTCACCAACGACCCCACCAGCGATGAGGCCTCCGACAACTCCGAGGCCCTGGACGACGTCTGCTTCCCACAGGACGTGGGCGACGACGGCGAGCGCAAGTGGCCGGATATCGCCGTGCTCGAGGAGTGGGCCGAGGAGGAGAAGAAGGAGAGCGGAGACGGAGGGGGCGTGGGAAATGCAGAGTGGCTGAGATCGCGCCAGACCAGCGAGCCAGAGCGCATTAATGGGCGGCTGCGTGGCGTGCACCAAACCAAGGAGGAGAGCGACCGGCCCTACCGTTTCACCTACTTCTCCGACTCCCTCCCCGCTACCATCCATTCCCAAAACATCTCCGGGCTCGTGCAGTCCGATCTCTCCTTTACAGACCTCTTCTCCCCCAAGGCGGACTTGGCGCCCACCTTCTGGCTGGACTGCCTAACCCCCACAGACTCTGAAATGAAAGTCCTGGCGCGTGCATTCGGCATCCACCCGCTGACGGCCGAGGATATCACCATGGGAGAGACGCGCGAAAAGGTGGAACTCTTTCGAAACTACTATCTCGTCTCCTTCCGATCCTTTGAACAGGATCCCAAGGCGGAGGAGTATCTTGAAGGCCTGGACTTCTACATCATTGTCTTCCGCCAAGGTGTCATTTCCTTCCATCACTCCCTCACCCCTCATCCGGCAAATGTCCGCAGGCGCATACGCCAGCTAAAGGATTACATCACCGTGACATCCGACTGGATCTCATACGCATTGATTGATGACATTACAGACGCCTTCCAGCCCCTCATCTACTCCATCGAGACAGAGGTGGACGATATCGACGACTCCATCCTATCTTTTCATTCCGACAACTCTGTGGCGGACGACAGCGAGATGCTTCGGCGCATTGGCGAGTGCCGAAAGAAAGTGATGGGTCTGCTTCGTCTGCTCGGATCCAAAGCGGATGTCATCAAAGGCTTCTCCAAGCGCTGCAACGAGCATTGGGACATTGCCCCACGTTCGGAGATTGGGCTATATCTCGGAGACATCCAAGACCACATCGTCACGATGGTCCAGAATCTGGGCCACTATGAAAAGATGATGTCGCGGTCCCACTCCAACTACCTTGCCCAGATAAATATCCAGATGACGCGAGTCAACAACAACATGAACGACGTGCTCTCTCGCCTGACGGTGCTGGGGACAATCGTGCTCCCAATGAACATCATCACTGGCCTGTGGGGCATGAACGTCAAGGTCCCCGGGCAGGAAATCGACAACCTCAACTGGTACTTTGGCATCACGGTGGGGCTGGTCATGTTTGGCGTGATGAGTTATTTGTTCTTCATGAAGACCTCGGTACATATGCGAGCAATTCAAATCACAGAACGCGTAGATTCGCCGTCCAAGCTGCGGCCCTCTGACATCGCACAGCCCCGGCCGAGTGCAGAGCAAGTGCTGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCGTCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATTAAAATCGACCATCCTTCTCCCAAACTTTAG",
    "translation": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASDNSEALDDVCFPQDVGDDGERKWPDIAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMKTSVHMRAIQITERVDSPSKLRPSDIAQPRPSAEQVLVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARVIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
    "product": "hypothetical protein"
   },
   {
    "start": 22240,
    "end": 25599,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002920",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002920</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002920</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002920-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,240 - 25,599,\n (total: 3360 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002920 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00176.26 (SNF2-related domain): [448:755](score: 211.8, e-value: 1.2e-62)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [933:1048](score: 50.8, e-value: 2e-13)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002920 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00176.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002920\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002920-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002920\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATAGATGTATTAGAACAGGTAGCGATTTACAGATCGCTCTTAGATACCATCTCGCCGGGGCCGAGTGAACACCGTACTGCGATAGAGCGTAAGCTACGAGATGTTGAGGCCAAGGTGGATCAAAATGAGCTACAAAGTAGCGAACGGAACAAGCGTCGGAAATTAGAACAAGAGCAGGAGGATGAGATATTTGCATGGACCTTGGAGATGCAAGAGAAGGGCAGCAACACGAGCGAAAATTTCGATTATGAAACGATTGATCTGACTGAGCAAATTGAGAACGATGCAGCTCTAGCACGAGAGCTAGCGGATGAGGAAGGCGCAAGGCCTGCACAGTCTGCTCCTCCTGCTCCCTATTTAGGAGCAACTCCCAAGCTCGAACATGGTTCGAACGCGGTTCAGCTGGATGACTCGGTAAATGTTATTGCGGGCACTATACCAGCATTCACAATTGTTGGAACCGATACCGTGGGGCCTAATAATGCAACGGCGAACACCGAAGCTCCCAATACATTATCAATGACCGATCAGGATCTAGCTAATTTTTTCATGACAATTGAGGATCGTGTTTCCAAAGTATATGGAAAAAAAGAGGTCCGACCGCTACACTTTGTTCGAGGTCCCTTCAATTTGTTCAAGAGATCAGCACTTGAAAATCTGAAGAAGCGCGGTCTAGACTATTTGGTTCAAGATACAGATAACGAAATAGCACAAACGTATGAAGACTCCATATCCCTTACCATGCAGAGACTAGAGGCAGCTGAGTGGCAGCAAGTACTTTACCGGAATCTTCGTCGCAAAACGCAGCCAACTCCTGCCCTACCAATGGACGAACCAAAAACGGCAAACGCCGAGCCTGTTCAACCACAAGCGCCTGCACCTACACCTGCAGGGATTTCTGAACAGCGACTCATGGAGCTACGAATTGCAGCAGATGCTAAACTTCTACGAATCCATGGACCTCCACAGCTTTTCACCGGGAGCATGCTCACGTCCTACGAGAAACTGCGAAAGGCATATCGTGACGAAGCTATTATGAATGAGAAAGTCAACGCTCTCAAAAATATAAAGCCCGCACAGAATACACTCTGGCCAGATTCGATGGCAGCGGGCCCGTCTACAACAGCAAGTATTGGCCTCCCTTCGAGCTATTATGACTACAGCCACAGCTACTCGATGCGATTCGATGCTGAAAAGAACCGTGAAGATCTTAAGAAACTTATCGAGAGTATTCAGCCGGACGCTGATATTGAACCACACGCACGAAGAGGGACTCCAAGTGCCATGACTTTCGTGTTGATGGAACATCAAAAAGTTGGACTTACCTGGATGCGACGTATGGAAGAAGGTAACAATAAAGGAGGTTTATTGGCCGATGACATGGGGCTTGGAAAGACAATCCAAGCCCTTGCTCTAATAATGTCTCATCAGCCCGAAGACCCATCTATCAAGACTACACTTATAGTTGCGCCACTCGCGTTGCTTAAACAATGGCATCGAGAAATTGAATCAAAAATCAAGCCAATGTATGCACAGAAGGTGTGTATTTACCACAGTATTGGAAGACGCAACATGACGTGGGTCGATCTTCGAAAGTATGACATTGTCTTGACCACGTATGGTATGATTGCATCCGACTATAAAGCACAAGTTAAATGGGAGGCCGACGTGAAGATTGATGCGAGAAATGAAGTTTACAAGCCAGAGTCACCTCTCCTTGACAAAGATAGCCAATTTGATCGAATAATCCTAGATGAGGCTCAAATGATTAAAAATAGAAATGCACTGGCATCGAGGGGTGTCGCAATTCTCCATGCAAAGTATCGCTGGGGCCTCAGTGGTACACCTGCACAAAACAACATTGACGAGTTTTATGCAATCATTCGCTTCTTACGTGTACGCCCTTTCTGCGACTGGGATGAATTTCGAACTCAGCTGTCTAATGCAGCGAGATCAAGGGATCTCAAAAGAGTTGACAAAAGTACGCGATTGCTGCAGGGTGTGTTGCGGGCAATCATGTTACGAAGAACGAAAGATTCAAAGATCGATGGCGAAAGTATACTTGACCTCCCACCCAAGACCATCGAAGAGACTCATGTTGTTTTTAACGTAGACCAGCAAGCATTCTACAACAATTTGGAACACAAATCTCAGATGTTAATGAATCGCTACGAGCAAAACAACACCATTGGGAAAAACTATGCAAACATATTGGTCCTTTTGCTTAGACTCCGTCAGGCATGTTGCCACCCACATCTCATTCCTGACACCGGTACATCTACTGGAATTTCTTATGAAGCTGGAGTTGTCCCCAAATCGGCCGAGGAAATGGAGGCGATGGCCCGGCAGATGCCTAGTGATGTAGTCAATCGTCTCAAGAATGACAAAGAAATGCTTTGCCCTGTCTGCTGGGACACACCAACCGACATGAAAATTATCCTCTTTTGTGGTCATTATGGATGTGGCGAATGCGTCAACAAGCTATTCACGCTGCAGACTCAAGTGAATCAGTCTCATGATGAGCTTGAGCCAGCACTGTGTCCGACGTGCCGCAGCGCAATGAGTAGCGACAAATTGCTGGGCTTTAATCTGTTCAAAAAGGTCCACATGCCAGAAGCGCTTACTCCGGAACCGCAACCGGAAGCTGTCAAGGATGAAAGCTCGGCTGTCGGAGGGAGTGGGACGAAAGGCAAAGAGAAAGCGGTGATTCCCGAAAGAGAGGAGACTCCGCTCGAGGACTTGGCGCCCCGCCAAAGGATTTTGCGAAGACTAAAGAAAGACTGGATCTCCTCTGCAAAGATTGACAAATGCTTGGAAATCCTGGAGACCGTCAAAGCGCGGGACCCGACGGAGAAGACCGTCGTGTTTTCCCAATTCATTCTGCTGCTTGACTTTTTGGAGATTCCGTTGGCGGACATGGGATTTAAGTGGAAGCGGTATGAAGGTTCCATGTCTGCCGTTGCTCGGGACGATGCCGTGCTTGACTTTATGAAGAGCCCAGATATCAACATCATGCTTGTTTCCTTGAAGGCCGGCAATGTTGGCCTCAACCTGACCTGTGCATCTCAGTGCATTGTGATGGATCCCTTTTGGAATCCGTTTGTGGAATTACAAGCCATTGATCGTACGCATCGAATTGGACAGTCACGGCCAGTCTGCGTGCACCGCATCTGCGTTGCGGGGACAGTCGAAGACAGGATTCTGGAGCTGCAAAATCAAAAGCAGGAGCTCATTGAGACGGCCCTGGATGATCAGGCGGCAAAGTCAATCCAACGGCTGAGTCCTCGTGAATTGATGTATCTTTTCGGGATCAACGACCCCAACAGTCAGAACAGCCAGAACAACCAGCATATTTAA",
    "translation": "MIDVLEQVAIYRSLLDTISPGPSEHRTAIERKLRDVEAKVDQNELQSSERNKRRKLEQEQEDEIFAWTLEMQEKGSNTSENFDYETIDLTEQIENDAALARELADEEGARPAQSAPPAPYLGATPKLEHGSNAVQLDDSVNVIAGTIPAFTIVGTDTVGPNNATANTEAPNTLSMTDQDLANFFMTIEDRVSKVYGKKEVRPLHFVRGPFNLFKRSALENLKKRGLDYLVQDTDNEIAQTYEDSISLTMQRLEAAEWQQVLYRNLRRKTQPTPALPMDEPKTANAEPVQPQAPAPTPAGISEQRLMELRIAADAKLLRIHGPPQLFTGSMLTSYEKLRKAYRDEAIMNEKVNALKNIKPAQNTLWPDSMAAGPSTTASIGLPSSYYDYSHSYSMRFDAEKNREDLKKLIESIQPDADIEPHARRGTPSAMTFVLMEHQKVGLTWMRRMEEGNNKGGLLADDMGLGKTIQALALIMSHQPEDPSIKTTLIVAPLALLKQWHREIESKIKPMYAQKVCIYHSIGRRNMTWVDLRKYDIVLTTYGMIASDYKAQVKWEADVKIDARNEVYKPESPLLDKDSQFDRIILDEAQMIKNRNALASRGVAILHAKYRWGLSGTPAQNNIDEFYAIIRFLRVRPFCDWDEFRTQLSNAARSRDLKRVDKSTRLLQGVLRAIMLRRTKDSKIDGESILDLPPKTIEETHVVFNVDQQAFYNNLEHKSQMLMNRYEQNNTIGKNYANILVLLLRLRQACCHPHLIPDTGTSTGISYEAGVVPKSAEEMEAMARQMPSDVVNRLKNDKEMLCPVCWDTPTDMKIILFCGHYGCGECVNKLFTLQTQVNQSHDELEPALCPTCRSAMSSDKLLGFNLFKKVHMPEALTPEPQPEAVKDESSAVGGSGTKGKEKAVIPEREETPLEDLAPRQRILRRLKKDWISSAKIDKCLEILETVKARDPTEKTVVFSQFILLLDFLEIPLADMGFKWKRYEGSMSAVARDDAVLDFMKSPDINIMLVSLKAGNVGLNLTCASQCIVMDPFWNPFVELQAIDRTHRIGQSRPVCVHRICVAGTVEDRILELQNQKQELIETALDDQAAKSIQRLSPRELMYLFGINDPNSQNSQNNQHI",
    "product": "hypothetical protein"
   },
   {
    "start": 25871,
    "end": 27304,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002921",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002921</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002921</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002921-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,871 - 27,304,\n (total: 1398 nt, excluding introns)<br>\n <br>\n \n  transport (smcogs) SMCOG1137:Major facilitator superfamily MFS 1 (Score: 376.9; E-value: 1.6e-114)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002921 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07690.19 (Major Facilitator Superfamily): [80:360](score: 73.9, e-value: 1.2e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002921 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity<br>\n  \n   PF07690.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002921\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002921-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKTAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLIVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFIFLGLLVIANLGVKSRLPPRGGSMPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002921\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCAACATGAACTCTAACGAAGCAGCAATCGCTAAGCCCCGTGATGTTGAAGCAGGCACACTATCTACACGTACCAGCTTTTCCAGTGCTCATGAGCAATTATCAGACCATACCACTGTTGCCAATGAGTCACCCGTGAATGAAAAGGTCGAAGAAGAGAAAGTCAAGACTGCGATGCCGCCCCCTTCGGATTTCCCAGATGGAGGCCTTCGAGCTTGGATGTGCGTTGTGGGTGGATGGTGTGCAATGTTTTGCACTTTTGGCTTTGTGAACAATGTTGGTGTATTCCAAAACTACTACCAAACGACTTTCCTCAGACAGTATACACCCTCTACGGTAGGATGGATCGCTTCGCTTCAACTCTTTCTGCAGTTTTTCATGGGCTTTCCAGTGGGTCGCGTATACGACGCCTACGGTCCTGCTTGGTTGTTGCGCATCGGAAGTTTCCTTATTGTATTTGGACTCATGATGGCTTCCTTGAGTACGAAATACTACCAGCTGCTTCTTTCACAGGCCGTAGTCTTCGGAATAGGTGCATCTATGGTCTTCTTTCCGGTCATAACTGCGACGTCTACATGGTTTTTCAAGAAGCGAGCTCTGGCGATCGGTTTGGCGAGTGTGGGCAGCTCTATGGGGGGTATTATACAGCCAATCATGATTACCAATCTCATACCGCAGATAGGCTTCGGATGGACCATGCGAACTATAGCCTTCATCTTCCTCGGCTTATTAGTGATTGCAAATCTTGGAGTAAAGTCACGTTTGCCGCCGAGGGGTGGCAGCATGCCAAAAATATCTGAAATTACAGCTGTACTTACAGACAAGGACTGGGCCCTACTGACGGCTGGCTACTTCATCTTTGTTTGGGGCATGTTCACGCCATTCACTTATATTCCGGATTATGGATTGTACTATGGGATGTCTCAACATTTGAGCATCTACCTTGTGTCCATTCTCAATGCTGGTTCGGTCTTTGGTCGGACTATTCCAGCTGGGCTTGGTGACCGTTTTGGACGGTTCAATGTGTTCACATTGATGAGCTTCTTCAGTGGTATCATCACGTTGGCAATGTGGATTCCGTCAAGGAGCCATGCTGTTATCATTGCGTACTCGGCACTATTTGGATTCAGTAGTGGTGCGTTTGTAAGCTTAGGACCGGCTTGCATTGCACAAATATCTGATATTCGCCAGCTCGGACTGCGTGTTGGGGTTTGTTTTGCAATATTTGCAATTGCGGCACTGACCGGCGTGCCCATTGCCGGAGCGCTCTTAGGACACAACAATAATTGGGTGCATGTTCAAATCTGGGCAGGCGTGACAATGATCGCTGGGAGCTCTATTATGTTATTCTTACGCTTCAAATTGGCCGGGTACAAGTTAATGGTGAAGGTCTAA",
    "translation": "MSNMNSNEAAIAKPRDVEAGTLSTRTSFSSAHEQLSDHTTVANESPVNEKVEEEKVKTAMPPPSDFPDGGLRAWMCVVGGWCAMFCTFGFVNNVGVFQNYYQTTFLRQYTPSTVGWIASLQLFLQFFMGFPVGRVYDAYGPAWLLRIGSFLIVFGLMMASLSTKYYQLLLSQAVVFGIGASMVFFPVITATSTWFFKKRALAIGLASVGSSMGGIIQPIMITNLIPQIGFGWTMRTIAFIFLGLLVIANLGVKSRLPPRGGSMPKISEITAVLTDKDWALLTAGYFIFVWGMFTPFTYIPDYGLYYGMSQHLSIYLVSILNAGSVFGRTIPAGLGDRFGRFNVFTLMSFFSGIITLAMWIPSRSHAVIIAYSALFGFSSGAFVSLGPACIAQISDIRQLGLRVGVCFAIFAIAALTGVPIAGALLGHNNNWVHVQIWAGVTMIAGSSIMLFLRFKLAGYKLMVKV",
    "product": "hypothetical protein"
   },
   {
    "start": 29181,
    "end": 30839,
    "strand": 1,
    "locus_tag": "MARS14BIN71_002922",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002922</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002922</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002922-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,181 - 30,839,\n (total: 1659 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002922 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04082.21 (Fungal specific transcription factor domain): [91:317](score: 92.0, e-value: 3.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002922 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002922\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002922\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGATACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTAATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
    "translation": "MQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
    "product": "hypothetical protein"
   },
   {
    "start": 30844,
    "end": 33894,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002923",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002923</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002923</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002923-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,844 - 33,894,\n (total: 3051 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.3; E-value: 4e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002923 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 125.8, e-value: 1.8e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 31.7, e-value: 1.5e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.8, e-value: 5.5e-42)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002923 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [654:1015](score: 214.1, e-value: 8.4e-64)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002923\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002923-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002923\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGTAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGGAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGCGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGTACCCAAAGAGTGCAGCAGGACTCAAAAACATTCAGGCAAATTGCTGCTATTGATGGATCATTAGTCGGAAAGTTTGTGTCTGCATGGAAGGAGGTGGGGTTTTTGTCATGA",
    "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFVKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
    "product": "hypothetical protein"
   },
   {
    "start": 34072,
    "end": 35535,
    "strand": -1,
    "locus_tag": "MARS14BIN71_002924",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_002924</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_002924</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_002924-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,072 - 35,535,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_002924 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_002924 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_002924\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_002924-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_002924\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
    "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 30843,
    "end": 33894,
    "tool": "rule-based-clusters",
    "neighbouring_start": 10843,
    "neighbouring_end": 35875,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r75c1"
 },
 "r93c1": {
  "start": 11566,
  "end": 28278,
  "idx": 1,
  "orfs": [
   {
    "start": 13222,
    "end": 13728,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003216",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003216</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003216</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003216-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,222 - 13,728,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003216 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04588.16 (Hypoxia induced protein conserved region): [59:111](score: 71.4, e-value: 5.3e-20)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003216\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003216\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACATCTCCAGGGAGGAGTGACGACGGTGACGCCTCTCCCAAAGCCAACAGGATGGAGAGATTTGACGATAACTCAATCATTCGGATGCCCTCGTCTTTTGATTTTGGAGATGAAGGAATGACAGGCCAAAAACCTGAGCCGCAAGGTCTAAACAAAATCTTACAGCGTTGCAAAGAGGAACCGCTTGTGCCCATTGGGTGCCTACTAACATGCGGAGCCCTGTTTGGATCTGCAGTTGGGCTAAGAAAGGGAAATAAAGATATGGCTCAGCGGATGTTTCGTTATAGAATTGGTTTTCAATTCGCGACTCTGGGATTTGTTATCGCTGGTGCACTGTACTATGGCAATGATCGAGCATCGCGGAAGCAGGAAGATCAAGCAGTACAGCAGCAGAAAGCAATGGATCGTCGGGCAGCCTGGCTACGGGAGCTAGACAGTCGTGACCGATTGCTCAAGGAACGAAGTCGACGGTTGGCAGAGAAGAAGGAACAGCCGCACCAGTAA",
    "translation": "MTSPGRSDDGDASPKANRMERFDDNSIIRMPSSFDFGDEGMTGQKPEPQGLNKILQRCKEEPLVPIGCLLTCGALFGSAVGLRKGNKDMAQRMFRYRIGFQFATLGFVIAGALYYGNDRASRKQEDQAVQQQKAMDRRAAWLRELDSRDRLLKERSRRLAEKKEQPHQ",
    "product": "hypothetical protein"
   },
   {
    "start": 13962,
    "end": 14561,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003217",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003217</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003217</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003217-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,962 - 14,561,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003217 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00581.23 (Rhodanese-like domain): [11:123](score: 22.8, e-value: 0.00011)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003217\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003217\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCAATTGCCAACGCTTCGATCATAACTTCCGAGCAATTGAGTACAAGATTAAAGCAAGGCAGAATTCTACCTGTAGATGCAACATGGTACTTGCCAAACGTTCAGAGGAACGCTCGGGCCGAGTTCATACAGAAAAGGCTGCCAGGAGCGCGCTTTTTTGATCTGGATAAAATCAAAGACACAGAGTCATCACTCCCACATATGCTCCCATCAGGCGAGCTCTTTTCTACGGAAATGCGTAAAATGGGTATTTCTCGCAGTGATGAGATCGTTGTTTACGACACCTCAGCTCTGGGTATATTTAGCGCTGCACGCGCTTATTGGATGTTTAAAATCTTCGGTCACTCTAGTGTGATGCTTTTGAATTCGCTTTCACATTACAGTGGCCCATATGAAGAGGGTATTCCTAATGGTGTTACCCCAACGAAATATCCAGTTGTGGATGCAGATCAAAATCGAGTAGCCACATACGAAGAGGTCCTCGAAAACATTCAGAGACACGACGACGTACAGATTCTGGATGCTCGCCCATCCGGTCGTTTCGAAGGCGTCGATCCTGAACCTCGACCTGGTGAGCCCAACTACCGAATTTTCTAA",
    "translation": "MSIANASIITSEQLSTRLKQGRILPVDATWYLPNVQRNARAEFIQKRLPGARFFDLDKIKDTESSLPHMLPSGELFSTEMRKMGISRSDEIVVYDTSALGIFSAARAYWMFKIFGHSSVMLLNSLSHYSGPYEEGIPNGVTPTKYPVVDADQNRVATYEEVLENIQRHDDVQILDARPSGRFEGVDPEPRPGEPNYRIF",
    "product": "hypothetical protein"
   },
   {
    "start": 14966,
    "end": 17905,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003218",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003218</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003218</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003218-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,966 - 17,905,\n (total: 2940 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003218\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003218\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGACTTTCTCACTGTCAAACTGCATTGGACTCTCTACAATGCTACATATAATCAATATATCCGACTAGGGATCGATCCAGCTTTGCAAATCGTACCCATCAGGAAACTCGATATTATTGGTTCAAATGCGAATCAGAAACCCCTCCGAGTTGCGCAATGCAGTCTATATGATATGATAGTACGAGGACCAAAGAATTCAAGAACTTATAAAGTGGTAATTCTCGGCCGTCTCAATATGGTGGATCAAAGTACGCTTGATGAATACGGTACCATTAGTGGCGTCCTTCGACTGAGTGCGATATTAAATCCAAGGGTAATTAAAAAAGAGAGGAGTCGGAAATTCGAGGTTGCAAGCGCAAACTTCGGTCAGATTAGCTTTCTTTCTGAGGAGGTGACTATCATAAGACCACAACTGCAAAGATCCTGCACCTGGATACCTGTTCCTGATGGCGCTCGAACCTTGTTCTTCACTTGCACACTTACCCTTCCTACTGGTTATCAGTGGTCCAAACTTGTTCTTTCCGATGAGATCGTGAGAGGAAACGCCACCTTTGTCAGCGCTACATTCATAGAAGAAGATATAGCCAATCAACACAAGCCAAAGCTTGTGTCATTGAGTTTGTACGACGAAAATACTAGCAAGAACTATGAGTTACGTATGCGAAGTCTCACTTTAGATGGGTCGAGAAACCGATACCATCTCGAAATCACGTACCAATCACACCCTGATCCTGATAAACCTAGAAGTTTTGTGGGAATAGCAAAAGTCACAAGTACACATTACAGATTCCATCGAGAATCTTACCTGCATCCGTATACGGCGAGAATTCCTTTAATAACCCAAGAAGAATTACTGAATCAAACAAAATGGGCCCCGTCTGAGCATCTCCCAATACCGGCGTATATAATAATGGACGCAGATCACGAAGGCCTTGCACCAAGACCACTATTAGTTGGTCCGGAGGATCAAAGTAATGGAACAAATAACTCAATCCCGGTAGGGTCAGCAGAAGAACATCTCCAAAATTCCAAGAGTAAGCATACTTTCTCTCCTCTATACCATCATGTCGACATAATAACGTTGCATGAGTCCACGAATGAAACAAAAGCGACAGATTCATCCAGAAATGAATTGCACACGGATTCGATCACGACGCCATTTACGGAGAAGACTTTTACGGTAAACACAACAACCAGGGACGTCGAGCCTCCTCATTCTGTGCTTCCTATACCAGGCTTCCTAACTTCGAACCAAACGGCTTATAACCCTTCTTTGCAAAACGCAGAGGAACGTATTAATATGATCAACACGATGCTACCTATAAGTGGTGCAAATGAAACGCGTACCATGAAAGAGACTATTGAGTCGACGACTTCTGTGAATTCTGGCAGTGGGGTGCGTAACACCCATCATTCTTCAGATCTTTTTGTATTGTCTCCTACAACTCGATTTCACTCCGGGACTACACCAAATTCTGACTTCCCGTCAACGAATTTTGGCGCCCCTACTCTATCAGTATTTGCCCATAGCACAGATTCTGCTAATTATCCACTCCATATTCCTTCAAGTAAGTGGATATCTTCACTCACGGCGCAACCGTCTCCAGGACCGGTAGGTCTTCCAATATCTACGTCCACATCTTTGCACTTCGAGTCAAGATCTGCAAAACAGTCAATATATGACCCACAGTCACAAAAATTGGACTCTATCGCCTCACAAAGCACTGGGAGTGGCACATCTGAGAGTTTTGAAGCCATGTTCGAGACAGCTAGGAGTGAGGAGACTCCCGCTTATCTGGAAAAAATCGGCCACTCATCCGACACTACTACCAAGTCATCATGCGGGATAGCCCACAGAGAAACACTGGTCATCACAGGTATGCGTGGTAGACTTGTTGATCAGAATGTCGTCATAAGAACGAGTCAGGTTGAAGATGGAAAAGGGCCAGACGCAACATTCTCCCCGATCTACAGAGTCCAAAATTCTGAGGACTATACGACAAGCAAAATGAAGACTAGCATTTTGACGAACAAAGGGTTTCCACAAGTAATGAGAACAGACGCAACTCTAAGAGAGACCAAAGAAACTGAAACAATATGGGGACTCAAGCCGACCAATACGATCCGACAGCGTCCTGCACAAATTTCCCACCTGAGCGCGGAGCCTGCACTGCCTTCACTTCCTACTTCATCTCAAAGCATCCCATGGAATGAAGAACAAAGTGAAAGTTCAACAGGGCATACACCGCAATTGGCAATGTTTTCTAACGATACCCTCTCTATTTTTTATGCAGAGCCGCAAAGCGCTTATAAGGCTTCAACAGACAAAGATAAACATGCCAAAGGTATAGCCACAATAATTCGATCTGTTCAGTTGAGTTTAATCACCGAGTCAAATTTTGCACCTGGCAGGTATAGCCAAAAACCTAGAACTGCAGCAAGCATAGATGGTGATTTGAAATCTGATTTTGATCTTATTGATTGGCAAGCTTCTCGACACGGCAAAGTTGACGTCGGCCATAAGTGTGATATGAATTCGACAGTCTGTACAGCAAACGCGAGTATCGAAGCCGATGTCAATATTGGACTCCTCGGCGCTCCGTCTGACGCGTCTACTGCTGCTGCAGGCAATCCTTCTGTGGAGGACATAAATACCCCAGCCATAGAAGACTCATATAGTACAACCTCAATCTTTGTAAAAGTACACAATGAATTCACCGCGGCATCAATGCCGGTAGAAAGCGCAAAGCCACAAAAAACTGGTCATGTCGAGTCAGCGATTCACATGTCTCATACACGATCCAAAAACTCGATTTTTCTTCCACAACCAACATCACAGCCATCGGGACTGCAGCACAGCATCGCTGCTCAAGCACCACCGGCTATACGGCAAACCCTAGTGCTGCTTCTAACTTTATTTGTATTCTTTAACTAA",
    "translation": "MDDFLTVKLHWTLYNATYNQYIRLGIDPALQIVPIRKLDIIGSNANQKPLRVAQCSLYDMIVRGPKNSRTYKVVILGRLNMVDQSTLDEYGTISGVLRLSAILNPRVIKKERSRKFEVASANFGQISFLSEEVTIIRPQLQRSCTWIPVPDGARTLFFTCTLTLPTGYQWSKLVLSDEIVRGNATFVSATFIEEDIANQHKPKLVSLSLYDENTSKNYELRMRSLTLDGSRNRYHLEITYQSHPDPDKPRSFVGIAKVTSTHYRFHRESYLHPYTARIPLITQEELLNQTKWAPSEHLPIPAYIIMDADHEGLAPRPLLVGPEDQSNGTNNSIPVGSAEEHLQNSKSKHTFSPLYHHVDIITLHESTNETKATDSSRNELHTDSITTPFTEKTFTVNTTTRDVEPPHSVLPIPGFLTSNQTAYNPSLQNAEERINMINTMLPISGANETRTMKETIESTTSVNSGSGVRNTHHSSDLFVLSPTTRFHSGTTPNSDFPSTNFGAPTLSVFAHSTDSANYPLHIPSSKWISSLTAQPSPGPVGLPISTSTSLHFESRSAKQSIYDPQSQKLDSIASQSTGSGTSESFEAMFETARSEETPAYLEKIGHSSDTTTKSSCGIAHRETLVITGMRGRLVDQNVVIRTSQVEDGKGPDATFSPIYRVQNSEDYTTSKMKTSILTNKGFPQVMRTDATLRETKETETIWGLKPTNTIRQRPAQISHLSAEPALPSLPTSSQSIPWNEEQSESSTGHTPQLAMFSNDTLSIFYAEPQSAYKASTDKDKHAKGIATIIRSVQLSLITESNFAPGRYSQKPRTAASIDGDLKSDFDLIDWQASRHGKVDVGHKCDMNSTVCTANASIEADVNIGLLGAPSDASTAAAGNPSVEDINTPAIEDSYSTTSIFVKVHNEFTAASMPVESAKPQKTGHVESAIHMSHTRSKNSIFLPQPTSQPSGLQHSIAAQAPPAIRQTLVLLLTLFVFFN",
    "product": "hypothetical protein"
   },
   {
    "start": 19617,
    "end": 21035,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003219",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003219</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003219</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003219-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,617 - 21,035,\n (total: 1419 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003219\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003219\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTGTTTTGACCTTGGGTTTATGGGTCTTCATACAAAGCGCTTTCGCGCAAAGTAGTTACCCTGCTAATTTTTCAATTGAGAGGGCTGAAATATATAAGCATCCAAAACAAGATAATAATCATACCTCACCAATTCACATTAGTGATATTCTTACAGTGAAACTTCACTGGAGTCTCTACAATGCGACATTGGACAACTATGTCGCATTACAACTTGATCGAGCTCTGCAAATAATTCAGCCCCAAACACTTGAAATGATTGGTAGAAGTGGGGATCAAAAACCTGTTTTAAAGCTTGCGACATGCAACGAATTTCAATTAAGTGCAGGGGTGATTTTTTGCCCGCTCGATGAAGTCCCGCAGAAAATATTGAATGAGTACGGCACCTTGAACGGTTTCATTCATGTGGAGGCGACGCTGAACTCAAACTTCATCGGTGATGGCACCCATAGAGTTTTTGAATTCGCAAACGCGAATTTCGATCAGGAATACGCTTATTCTGCGGATATAGCTATCGCTAGACCAGAGAATTATGAGAAAGTCACTATACCTGAATCGAAAATGCAGAGAACTTGCTCCTGGGGACTTCCGGCCGATGGCTACTACGACAAGGTTTTCGTTTGCACAATTAGCTTTCCTATCGGATATAATCTGTCCCGAGTCTTGGTTTCCGACAACATTCTGAGAGGAAACGCTAGACCTGTCGGCGCCGTATTCATACAAGAAGATGTGAATGATCTTAAAAAGCAAACCTTTGTGTCGATTGTGCGGTACAAAGAGACCTATGCACGTCGTGGTTACGAATTACGTATGCGGCCCCTCGTTGACGAGACTTTAGATGGATCGAAATACCGATATCGCCTTGCTATAACATACGAGTCACATCACGGTACTGATGATGTCAAAGGTTTTGTGGGAATAGCGAAAATCAGAAGTAAGGATTACGGCTTTGAGCAAAAATCTTATCTGCCTCCATTTTCAACGTGGAAGCGAATTTCCCCCCACATATGCAAGAATGATCATGAAGAATGGTTGTCTGCCTCCATTCAATATCCTTTGATCCCATCCGAACAAATTCAATTGCCGGCATATTCAGTCATGGCTGGGTCTCATAGGGACCAGCTATCATTTCCACTCTCAATTGGTTCAGAGGAGCAAGGTGAGTGGACCACCCCTAAATCAACGACGAATTCGTCGGACAGAGACCCACAAAGTATCGAGATCAAGCATAGTCTGTCCCCTCTACATTTCCACATGAATCGTACAATGTTGTATGAAGCCCCAAAAGGTAAAATAACAGCCACGACCCACTCTAGAATGGAGTTTTCACATGTGCGGTCTCGGCGTTCACAGGTGACACAAGGCCGACAAGCACGACACCAAAAGCTCAAAACAGTCAATCTCAATCTTTCTTGA",
    "translation": "MGVLTLGLWVFIQSAFAQSSYPANFSIERAEIYKHPKQDNNHTSPIHISDILTVKLHWSLYNATLDNYVALQLDRALQIIQPQTLEMIGRSGDQKPVLKLATCNEFQLSAGVIFCPLDEVPQKILNEYGTLNGFIHVEATLNSNFIGDGTHRVFEFANANFDQEYAYSADIAIARPENYEKVTIPESKMQRTCSWGLPADGYYDKVFVCTISFPIGYNLSRVLVSDNILRGNARPVGAVFIQEDVNDLKKQTFVSIVRYKETYARRGYELRMRPLVDETLDGSKYRYRLAITYESHHGTDDVKGFVGIAKIRSKDYGFEQKSYLPPFSTWKRISPHICKNDHEEWLSASIQYPLIPSEQIQLPAYSVMAGSHRDQLSFPLSIGSEEQGEWTTPKSTTNSSDRDPQSIEIKHSLSPLHFHMNRTMLYEAPKGKITATTHSRMEFSHVRSRRSQVTQGRQARHQKLKTVNLNLS",
    "product": "hypothetical protein"
   },
   {
    "start": 21566,
    "end": 22900,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003220",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003220</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003220</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003220-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,566 - 22,900,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 158.6, e-value: 2.3e-46)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.3, e-value: 7.3e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003220 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003220\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003220\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGAAGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACTATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGAACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGTAACTCCACTGCTCCTGAGCAGTAAAAAGTACGAAAATAACGAAAATACTTGGAGTCGCGCCTAA",
    "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWEGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDYDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLNLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKVTPLLLSSKKYENNENTWSRA",
    "product": "hypothetical protein"
   },
   {
    "start": 23584,
    "end": 25221,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003221",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003221</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003221</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003221-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,584 - 25,221,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003221 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 64.0, e-value: 1.8e-17)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003221\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003221\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATCTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGGTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAAAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACACAGAGGGAGCCATGGGTGCAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTGTTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACTGCATGGAATCATACTACACAAGGTACATTTGGTGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGCCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATACTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
    "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLVVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFKTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHTEGAMGASVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTAWNHTTQGTFGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
    "product": "hypothetical protein"
   },
   {
    "start": 26135,
    "end": 27887,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003222",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003222</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003222</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003222-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,135 - 27,887,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75; E-value: 7.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003222 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.1e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.8e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003222 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 666.0, e-value: 7.5e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003222\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003222-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003222\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATTGCAGCATACGTGAAACGTATTGCACCGCACGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTCGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCTCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
    "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPHVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSSSDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 21565,
    "end": 22900,
    "tool": "rule-based-clusters",
    "neighbouring_start": 11565,
    "neighbouring_end": 28278,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r93c1"
 },
 "r127c1": {
  "start": 1,
  "end": 17749,
  "idx": 1,
  "orfs": [
   {
    "start": 287,
    "end": 856,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003603",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003603</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003603</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003603-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 287 - 856,\n (total: 570 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003603 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [113:186](score: 57.6, e-value: 1.7e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003603 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003603\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003603\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGACTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAAAACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
    "translation": "MVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSDSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEENPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
    "product": "hypothetical protein"
   },
   {
    "start": 1613,
    "end": 3828,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003604",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003604</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003604</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003604-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,613 - 3,828,\n (total: 2058 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [13:138](score: 171.0, e-value: 2.3e-50)<br>\n \n  PF00290.23 (Tryptophan synthase alpha chain): [140:232](score: 74.0, e-value: 9.3e-21)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [335:659](score: 166.8, e-value: 7.8e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [289:671](score: 577.7, e-value: 2.6e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [14:138](score: 128.8, e-value: 3.7e-38)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003604 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003604\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003604-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003604\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCAAGCGATTAAGGAGACATTCAGCAGATGCAGGCGAGAAAGTAAGCATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTGAGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTACCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCATTGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
    "translation": "MQAIKETFSRCRRESKHRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIPDSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVSTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTTADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEALRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
    "product": "hypothetical protein"
   },
   {
    "start": 4010,
    "end": 5494,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003605",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003605</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003605</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003605-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,010 - 5,494,\n (total: 1485 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003605 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [158:220](score: 52.1, e-value: 4.6e-14)<br>\n \n  PF00013.32 (KH domain): [253:318](score: 55.5, e-value: 4.1e-15)<br>\n \n  PF00013.32 (KH domain): [343:409](score: 55.9, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003605 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003605\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003605\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGACCAGAGCTCTTTGGCTTCGATCTTAGCAGCGCTGAGTCAAGCGCAGGCAGCTCAGCAGAGACAAAGCGGGGGTAACTTGTCTGACTCAAGACCTGCCCCCCCGATGCAACAACAACTCGGTGCGACAAATTCAGGCGGAGCAATGGGCAATAGCTACGGCTACCCGCCTCCCCCTTCCTCATCGGGTGCTATTGATCTGTCTACTCTCAAACCGTCAAATTCTGGTAGCATGTCCTTTGCAGACCCACGATTTGGCGCCTCTGGGCTCAACTCAACGTCGCCAATGATGTCTTCCAACTATTATGACCAGGGAAGAAATGGTGGTTATGATGATAGTCGTAGGCGAAGGCGGTCTAGGTCTCGATCAGGAAGTAGAGAGAGGAGTCCTTATGGCTACAGACGAAGGGACCGTGAAAGATCATACAGCCCTCCGCGACGGGGTGGAGGATCTTCTCCAGATAGGGATACAATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGATACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
    "translation": "MADQSSLASILAALSQAQAAQQRQSGGNLSDSRPAPPMQQQLGATNSGGAMGNSYGYPPPPSSSGAIDLSTLKPSNSGSMSFADPRFGASGLNSTSPMMSSNYYDQGRNGGYDDSRRRRRSRSRSGSRERSPYGYRRRDRERSYSPPRRGGGSSPDRDTMVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
    "product": "hypothetical protein"
   },
   {
    "start": 5947,
    "end": 8628,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003606",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003606</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003606</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003606-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,947 - 8,628,\n (total: 2682 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003606 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [631:761](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [784:819](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003606 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003606\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003606-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003606\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAATCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTGATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGATCAGGTGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTCAAGATCGTATTATATTTACCCCTGCAGACGTGATTTCGAAAGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
    "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLDEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRSGDASGRKLTPVHLLTGQDRIIFTPADVISKEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
    "product": "hypothetical protein"
   },
   {
    "start": 8648,
    "end": 10255,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003607",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003607</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003607</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003607-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,648 - 10,255,\n (total: 1488 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003607\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003607\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCTGCTGGTCACCAGAAGAAGCACAAGATCGAGGAAGCGCGACTGGCTACAATGCACTATTTGAGAATCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAAAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCATCTCTATATTTGCTTCAAAGTTGCACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGGGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
    "translation": "MACWSPEEAQDRGSATGYNALFENLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWKKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLGRLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
    "product": "hypothetical protein"
   },
   {
    "start": 10410,
    "end": 14477,
    "strand": 1,
    "locus_tag": "MARS14BIN71_003608",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003608</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003608</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003608-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,410 - 14,477,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.3; E-value: 1.3e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003608 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 222.1, e-value: 1.1e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.6, e-value: 3.5e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 254.2, e-value: 1.2e-75)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003608 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1894.1, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 377.5, e-value: 1.6e-113)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 342.8, e-value: 6.2e-103)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003608\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003608-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003608\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCGGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACTTTCCTAGATCACACCAATGGGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAGAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAACTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAACTAAGTACAATTGGAGGACGCGGAGGAAATAAGATAGAATCAGGCTAG",
    "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRREFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
    "product": "hypothetical protein"
   },
   {
    "start": 14491,
    "end": 16151,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003609",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003609</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003609</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003609-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,491 - 16,151,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 962.1, e-value: 8.8e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS14BIN71_003609 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003609\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003609-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003609\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAGAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
    "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDRGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
    "product": "hypothetical protein"
   },
   {
    "start": 16637,
    "end": 17605,
    "strand": -1,
    "locus_tag": "MARS14BIN71_003610",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS14BIN71_003610</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS14BIN71_003610</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS14BIN71_003610-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,637 - 17,605,\n (total: 969 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS14BIN71_003610 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:269](score: 204.0, e-value: 2.5e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS14BIN71_003610\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS14BIN71_003610-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS14BIN71_003610\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTCAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGGATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTCGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGGCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
    "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 10409,
    "end": 14477,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 17749,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r127c1"
 }
};
var details_data = {
 "nrpspks": {
  "r75c1": {
   "id": "r75c1",
   "orfs": [
    {
     "id": "MARS14BIN71_002919",
     "sequence": "MSESSREAIPARRRRSSASKGFAPPFQQRRAQFVQQEQQQQRSLSPSSLDSNALLDHRSQPESIPRPSFLRNRSDRTGGEREERRGKGRRESRDRHHEQTPLLEGEGEGGAGPSSGEQADQHPFVHYQPNYGSGAHGDAVITIEGAGDGSSTDDFTNDPTSDEASDNSEALDDVCFPQDVGDDGERKWPDIAVLEEWAEEEKKESGDGGGVGNAEWLRSRQTSEPERINGRLRGVHQTKEESDRPYRFTYFSDSLPATIHSQNISGLVQSDLSFTDLFSPKADLAPTFWLDCLTPTDSEMKVLARAFGIHPLTAEDITMGETREKVELFRNYYLVSFRSFEQDPKAEEYLEGLDFYIIVFRQGVISFHHSLTPHPANVRRRIRQLKDYITVTSDWISYALIDDITDAFQPLIYSIETEVDDIDDSILSFHSDNSVADDSEMLRRIGECRKKVMGLLRLLGSKADVIKGFSKRCNEHWDIAPRSEIGLYLGDIQDHIVTMVQNLGHYEKMMSRSHSNYLAQINIQMTRVNNNMNDVLSRLTVLGTIVLPMNIITGLWGMNVKVPGQEIDNLNWYFGITVGLVMFGVMSYLFFMKTSVHMRAIQITERVDSPSKLRPSDIAQPRPSAEQVLVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARVIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTIKIDHPSPKL",
     "domains": [
      {
       "type": "PKS_ER",
       "start": 615,
       "end": 915,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SDIAQPRPSAEQVLVQIHAAAANFFDGLQIRGRYQVKPKLPYVLGAEFAGQITEVGTQVKRWKVGDRVFGSAQGSFAQYVCAEEGMCLPVPSGWSYEAACGLFVTAPTSYCGLVTRANVQRGETVLVHAAAGGVSLAAVQIAKACGARVIATASTPEKLHIAARYGADHVVNYREEDWVAQVNALGGADVIYDPVGEIEKDMRVVKWNGRILVIGFAGGNIPNPPLNRVLLKNCSIVGVHWGAYSKNEKEMIPVIWRTLFELIAQGKFRPTTYKVLYGLSDVGKALDALESRRTWGKVTI",
       "dna_sequence": "TCTGACATCGCACAGCCCCGGCCGAGTGCAGAGCAAGTGCTGGTGCAGATTCACGCAGCGGCCGCCAACTTCTTTGATGGCCTGCAGATTCGCGGGCGCTACCAGGTGAAGCCCAAGCTGCCGTACGTGCTGGGCGCTGAATTTGCCGGACAAATCACCGAGGTGGGGACACAGGTCAAGCGATGGAAGGTGGGCGACCGGGTGTTTGGGTCGGCGCAGGGGTCCTTTGCGCAGTATGTCTGCGCCGAGGAGGGAATGTGTCTGCCTGTGCCCTCTGGATGGAGCTACGAAGCAGCCTGCGGTCTCTTCGTCACGGCCCCAACCAGCTACTGCGGGCTGGTCACACGCGCAAACGTACAGCGCGGGGAGACGGTTCTTGTGCATGCAGCCGCCGGCGGAGTTTCACTTGCCGCGGTCCAAATTGCAAAGGCATGCGGAGCCCGCGTCATTGCGACAGCCTCGACGCCAGAGAAGCTGCACATAGCCGCTCGTTATGGCGCAGATCATGTGGTGAACTATCGCGAGGAGGACTGGGTGGCGCAGGTCAACGCGCTGGGTGGCGCCGATGTCATTTACGATCCGGTGGGCGAGATCGAGAAGGATATGCGGGTGGTCAAATGGAACGGGAGGATCCTCGTGATTGGGTTCGCGGGCGGGAACATTCCCAATCCGCCGCTCAACAGGGTCCTCTTGAAGAACTGCTCTATTGTGGGCGTCCATTGGGGCGCGTACAGCAAGAATGAAAAGGAGATGATCCCGGTGATTTGGAGAACCCTATTTGAACTTATCGCCCAGGGGAAGTTCCGGCCAACGACCTACAAGGTGCTCTATGGTCTGTCTGATGTCGGCAAAGCATTGGACGCGCTCGAGAGCCGCAGGACCTGGGGGAAGGTGACTATT",
       "abbreviation": "ER",
       "html_class": "jsdomain-mod-er"
      }
     ],
     "modules": []
    },
    {
     "id": "MARS14BIN71_002923",
     "sequence": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFVKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEEKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSASEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 30,
       "end": 341,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "NYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVR",
       "dna_sequence": "AACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 535,
       "end": 606,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFI",
       "dna_sequence": "TATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "TD",
       "start": 655,
       "end": 891,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLASPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKII",
       "dna_sequence": "ATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACATAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCAGTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATT",
       "abbreviation": "TD",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 30,
       "end": 891,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r127c1": {
   "id": "r127c1",
   "orfs": [
    {
     "id": "MARS14BIN71_003608",
     "sequence": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRREFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 223,
       "end": 688,
       "predictions": [
        [
         "substrate consensus",
         "Aad"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIR",
       "dna_sequence": "TTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 821,
       "end": 888,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRREFRMDVPIGIVFQNPSIRSLSDEID",
       "dna_sequence": "GCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAGAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 944,
       "end": 1194,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVI",
       "dna_sequence": "CTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 223,
       "end": 1194,
       "complete": true,
       "iterative": false,
       "monomer": "Aad",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r9c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ANIA_01592",
         "query_loc": 66387,
         "subject_loc": 5346
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "PCH_Pc20g10860",
         "query_loc": 66387,
         "subject_loc": 1400
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002716: 0-53197": {
       "start": 0,
       "end": 53197,
       "links": [
        {
         "query": "MARS14BIN71_000726",
         "subject": "PluTT01m_16900",
         "query_loc": 72374,
         "subject_loc": 51233
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PluTT01m_16730",
         "start": 0,
         "end": 1080,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16735",
         "start": 1099,
         "end": 1321,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16740",
         "start": 1339,
         "end": 1573,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16745",
         "start": 1660,
         "end": 2767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16750",
         "start": 2888,
         "end": 3980,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16755",
         "start": 3972,
         "end": 5583,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16760",
         "start": 5585,
         "end": 8114,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16765",
         "start": 8290,
         "end": 8782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16770",
         "start": 8800,
         "end": 10528,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16775",
         "start": 10524,
         "end": 10812,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16780",
         "start": 10840,
         "end": 11206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16785",
         "start": 11199,
         "end": 11535,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16790",
         "start": 11598,
         "end": 13104,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16795",
         "start": 13153,
         "end": 13546,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16800",
         "start": 13542,
         "end": 14892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16805",
         "start": 14907,
         "end": 16434,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16810",
         "start": 16465,
         "end": 16963,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16815",
         "start": 18118,
         "end": 33769,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16820",
         "start": 34943,
         "end": 35918,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16825",
         "start": 35974,
         "end": 37000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16830",
         "start": 37014,
         "end": 37485,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16835",
         "start": 37600,
         "end": 39217,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16840",
         "start": 39584,
         "end": 40598,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16845",
         "start": 41671,
         "end": 42633,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16850",
         "start": 42616,
         "end": 42868,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16855",
         "start": 42854,
         "end": 44651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16860",
         "start": 44742,
         "end": 45165,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16865",
         "start": 45200,
         "end": 46496,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16870",
         "start": 46804,
         "end": 47005,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16875",
         "start": 47023,
         "end": 47359,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16880",
         "start": 47361,
         "end": 49212,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16885",
         "start": 49223,
         "end": 49745,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16890",
         "start": 49782,
         "end": 50106,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16895",
         "start": 50215,
         "end": 50602,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16900",
         "start": 50626,
         "end": 51841,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000726"
         }
        },
        {
         "locus_tag": "PluTT01m_16905",
         "start": 51890,
         "end": 52385,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16910",
         "start": 52471,
         "end": 53197,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ctg1_orf003",
         "query_loc": 66387,
         "subject_loc": 5272
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "PbGGS",
         "query_loc": 66387,
         "subject_loc": 1137
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "aspC",
         "query_loc": 66387,
         "subject_loc": 6426
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "MAA_07498",
         "query_loc": 66387,
         "subject_loc": 14238
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "paxG",
         "query_loc": 66387,
         "subject_loc": 647
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "sre2",
         "query_loc": 66387,
         "subject_loc": 3093
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002736: 3-5057": {
       "start": 3,
       "end": 5057,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ATEG_03568",
         "query_loc": 66387,
         "subject_loc": 3751
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ATEG_03567",
         "start": 3,
         "end": 1533,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03568",
         "start": 2446,
         "end": 5057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ANIA_01592",
         "query_loc": 66387,
         "subject_loc": 5346
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "PCH_Pc20g10860",
         "query_loc": 66387,
         "subject_loc": 1400
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002716: 0-53197": {
       "start": 0,
       "end": 53197,
       "links": [
        {
         "query": "MARS14BIN71_000726",
         "subject": "PluTT01m_16900",
         "query_loc": 72374,
         "subject_loc": 51233
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PluTT01m_16730",
         "start": 0,
         "end": 1080,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16735",
         "start": 1099,
         "end": 1321,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16740",
         "start": 1339,
         "end": 1573,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16745",
         "start": 1660,
         "end": 2767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16750",
         "start": 2888,
         "end": 3980,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16755",
         "start": 3972,
         "end": 5583,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16760",
         "start": 5585,
         "end": 8114,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16765",
         "start": 8290,
         "end": 8782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16770",
         "start": 8800,
         "end": 10528,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16775",
         "start": 10524,
         "end": 10812,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16780",
         "start": 10840,
         "end": 11206,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16785",
         "start": 11199,
         "end": 11535,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16790",
         "start": 11598,
         "end": 13104,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16795",
         "start": 13153,
         "end": 13546,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16800",
         "start": 13542,
         "end": 14892,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16805",
         "start": 14907,
         "end": 16434,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16810",
         "start": 16465,
         "end": 16963,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16815",
         "start": 18118,
         "end": 33769,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16820",
         "start": 34943,
         "end": 35918,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16825",
         "start": 35974,
         "end": 37000,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16830",
         "start": 37014,
         "end": 37485,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16835",
         "start": 37600,
         "end": 39217,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16840",
         "start": 39584,
         "end": 40598,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16845",
         "start": 41671,
         "end": 42633,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16850",
         "start": 42616,
         "end": 42868,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16855",
         "start": 42854,
         "end": 44651,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16860",
         "start": 44742,
         "end": 45165,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16865",
         "start": 45200,
         "end": 46496,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16870",
         "start": 46804,
         "end": 47005,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16875",
         "start": 47023,
         "end": 47359,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16880",
         "start": 47361,
         "end": 49212,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16885",
         "start": 49223,
         "end": 49745,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16890",
         "start": 49782,
         "end": 50106,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16895",
         "start": 50215,
         "end": 50602,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16900",
         "start": 50626,
         "end": 51841,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000726"
         }
        },
        {
         "locus_tag": "PluTT01m_16905",
         "start": 51890,
         "end": 52385,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PluTT01m_16910",
         "start": 52471,
         "end": 53197,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ctg1_orf003",
         "query_loc": 66387,
         "subject_loc": 5272
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "PbGGS",
         "query_loc": 66387,
         "subject_loc": 1137
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "aspC",
         "query_loc": 66387,
         "subject_loc": 6426
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "MAA_07498",
         "query_loc": 66387,
         "subject_loc": 14238
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "paxG",
         "query_loc": 66387,
         "subject_loc": 647
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "sre2",
         "query_loc": 66387,
         "subject_loc": 3093
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002736: 3-5057": {
       "start": 3,
       "end": 5057,
       "links": [
        {
         "query": "MARS14BIN71_000721",
         "subject": "ATEG_03568",
         "query_loc": 66387,
         "subject_loc": 3751
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ATEG_03567",
         "start": 3,
         "end": 1533,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_03568",
         "start": 2446,
         "end": 5057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS14BIN71_000721"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_000715": {
     "functions": []
    },
    "MARS14BIN71_000716": {
     "functions": []
    },
    "MARS14BIN71_000717": {
     "functions": []
    },
    "MARS14BIN71_000718": {
     "functions": []
    },
    "MARS14BIN71_000719": {
     "functions": []
    },
    "MARS14BIN71_000720": {
     "functions": []
    },
    "MARS14BIN71_000721": {
     "functions": [
      {
       "description": "fung_ggpps",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_000722": {
     "functions": []
    },
    "MARS14BIN71_000723": {
     "functions": []
    },
    "MARS14BIN71_000724": {
     "functions": []
    },
    "MARS14BIN71_000725": {
     "functions": []
    },
    "MARS14BIN71_000726": {
     "functions": [
      {
       "description": "Aminotran_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "DegT_DnrJ_EryC1",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1139:aminotransferase class V ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_000727": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_000715",
      "seqLength": 93,
      "domains": [
       {
        "start": 0,
        "end": 86,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Thiamine_BP",
        "accession": "PF01910",
        "description": "Thiamine-binding protein",
        "evalue": "8.8e-24",
        "score": "83.4"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000716",
      "seqLength": 404,
      "domains": [
       {
        "start": 109,
        "end": 400,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex"
        ],
        "html_class": "generic-type-other",
        "name": "MIS13",
        "accession": "PF08202",
        "description": "Mis12-Mtw1 protein family",
        "evalue": "2.3e-48",
        "score": "165.2"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000717",
      "seqLength": 1032,
      "domains": [
       {
        "start": 51,
        "end": 153,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "C2",
        "accession": "PF00168",
        "description": "C2 domain",
        "evalue": "3.6e-22",
        "score": "78.7"
       },
       {
        "start": 248,
        "end": 346,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "C2",
        "accession": "PF00168",
        "description": "C2 domain",
        "evalue": "1.2e-16",
        "score": "61.0"
       },
       {
        "start": 778,
        "end": 986,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "PS_Dcarbxylase",
        "accession": "PF02666",
        "description": "Phosphatidylserine decarboxylase",
        "evalue": "1.4e-57",
        "score": "194.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000718",
      "seqLength": 375,
      "domains": [
       {
        "start": 15,
        "end": 266,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "GCV_T",
        "accession": "PF01571",
        "description": "Aminomethyltransferase folate-binding domain",
        "evalue": "3.1e-88",
        "score": "295.4"
       },
       {
        "start": 292,
        "end": 369,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "GCV_T_C",
        "accession": "PF08669",
        "description": "Glycine cleavage T-protein C-terminal barrel domain",
        "evalue": "7.5e-19",
        "score": "67.5"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000719",
      "seqLength": 345,
      "domains": [
       {
        "start": 59,
        "end": 242,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "HAD",
        "accession": "PF12710",
        "description": "haloacid dehalogenase-like hydrolase",
        "evalue": "4.6e-25",
        "score": "89.3"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000720",
      "seqLength": 241,
      "domains": [
       {
        "start": 0,
        "end": 38,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "3.8e-07",
        "score": "29.6"
       },
       {
        "start": 39,
        "end": 235,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "1.2e-56",
        "score": "192.1"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000721",
      "seqLength": 315,
      "domains": [
       {
        "start": 42,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "9.5e-67",
        "score": "224.9"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000722",
      "seqLength": 264,
      "domains": [
       {
        "start": 186,
        "end": 250,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GST_C_6",
        "accession": "PF17171",
        "description": "Glutathione S-transferase, C-terminal domain",
        "evalue": "1.1e-12",
        "score": "47.7"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000724",
      "seqLength": 245,
      "domains": [
       {
        "start": 34,
        "end": 231,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "DLH",
        "accession": "PF01738",
        "description": "Dienelactone hydrolase family",
        "evalue": "4.4e-12",
        "score": "46.1"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000725",
      "seqLength": 448,
      "domains": [
       {
        "start": 24,
        "end": 142,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0015031' target='_blank'>GO:0015031</a>: protein transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0036211' target='_blank'>GO:0036211</a>: protein modification process"
        ],
        "html_class": "generic-type-other",
        "name": "UEV",
        "accession": "PF05743",
        "description": "UEV domain",
        "evalue": "8.3e-33",
        "score": "112.9"
       },
       {
        "start": 377,
        "end": 440,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Vps23_core",
        "accession": "PF09454",
        "description": "Vps23 core domain",
        "evalue": "1.5e-22",
        "score": "79.5"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000726",
      "seqLength": 490,
      "domains": [
       {
        "start": 92,
        "end": 455,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Aminotran_5",
        "accession": "PF00266",
        "description": "Aminotransferase class-V",
        "evalue": "1.6e-88",
        "score": "297.3"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_000715",
      "seqLength": 93,
      "domains": [
       {
        "start": 0,
        "end": 88,
        "name": "TIGR00106",
        "description": "TIGR00106: uncharacterized protein, MTH1187 family",
        "accession": "TIGR00106",
        "evalue": "4.8e-25",
        "score": "86.0",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000717",
      "seqLength": 1032,
      "domains": [
       {
        "start": 772,
        "end": 977,
        "name": "TIGR00163",
        "description": "PS_decarb: phosphatidylserine decarboxylase",
        "accession": "TIGR00163",
        "evalue": "2.2e-36",
        "score": "123.1",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000718",
      "seqLength": 375,
      "domains": [
       {
        "start": 11,
        "end": 370,
        "name": "TIGR00528",
        "description": "gcvT: glycine cleavage system T protein",
        "accession": "TIGR00528",
        "evalue": "4.7e-115",
        "score": "382.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_000719",
      "seqLength": 345,
      "domains": [
       {
        "start": 57,
        "end": 251,
        "name": "TIGR01489",
        "description": "DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase",
        "accession": "TIGR01489",
        "evalue": "9.5e-28",
        "score": "95.5",
        "html_class": "generic-type-other"
       },
       {
        "start": 58,
        "end": 242,
        "name": "TIGR01488",
        "description": "HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB",
        "accession": "TIGR01488",
        "evalue": "1.4e-18",
        "score": "65.4",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r40c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78746.1",
         "query_loc": 23202,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78731.1",
         "query_loc": 23202,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78758.1",
         "query_loc": 23202,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78811.1",
         "query_loc": 23202,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "AQM37586.1",
         "query_loc": 23202,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78797.1",
         "query_loc": 23202,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78771.1",
         "query_loc": 23202,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78784.1",
         "query_loc": 23202,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78746.1",
         "query_loc": 23202,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78731.1",
         "query_loc": 23202,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78758.1",
         "query_loc": 23202,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78811.1",
         "query_loc": 23202,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "AQM37586.1",
         "query_loc": 23202,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78797.1",
         "query_loc": 23202,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78771.1",
         "query_loc": 23202,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS14BIN71_002028",
         "subject": "APZ78784.1",
         "query_loc": 23202,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002028"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_002019": {
     "functions": []
    },
    "MARS14BIN71_002020": {
     "functions": []
    },
    "MARS14BIN71_002021": {
     "functions": []
    },
    "MARS14BIN71_002022": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS14BIN71_002023": {
     "functions": []
    },
    "MARS14BIN71_002024": {
     "functions": []
    },
    "MARS14BIN71_002025": {
     "functions": []
    },
    "MARS14BIN71_002026": {
     "functions": []
    },
    "MARS14BIN71_002027": {
     "functions": []
    },
    "MARS14BIN71_002028": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_002019",
      "seqLength": 893,
      "domains": [
       {
        "start": 228,
        "end": 403,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_N",
        "accession": "PF00350",
        "description": "Dynamin family",
        "evalue": "8.3e-42",
        "score": "143.2"
       },
       {
        "start": 410,
        "end": 541,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_M",
        "accession": "PF01031",
        "description": "Dynamin central region",
        "evalue": "6.4e-15",
        "score": "55.3"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002020",
      "seqLength": 1052,
      "domains": [
       {
        "start": 18,
        "end": 315,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GTP_EFTU",
        "accession": "PF00009",
        "description": "Elongation factor Tu GTP binding domain",
        "evalue": "8.7e-58",
        "score": "195.2"
       },
       {
        "start": 583,
        "end": 647,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_III",
        "accession": "PF14492",
        "description": "Elongation Factor G, domain III",
        "evalue": "1.8e-06",
        "score": "28.0"
       },
       {
        "start": 917,
        "end": 998,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_C",
        "accession": "PF00679",
        "description": "Elongation factor G C-terminus",
        "evalue": "2.2e-13",
        "score": "50.2"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002021",
      "seqLength": 313,
      "domains": [
       {
        "start": 9,
        "end": 99,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.6e-14",
        "score": "54.4"
       },
       {
        "start": 214,
        "end": 306,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.1e-16",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002022",
      "seqLength": 303,
      "domains": [
       {
        "start": 29,
        "end": 285,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "8.9e-51",
        "score": "173.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002023",
      "seqLength": 174,
      "domains": [
       {
        "start": 1,
        "end": 68,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation"
        ],
        "html_class": "generic-type-other",
        "name": "IF3_N",
        "accession": "PF05198",
        "description": "Translation initiation factor IF-3, N-terminal domain",
        "evalue": "8.6e-09",
        "score": "35.7"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002024",
      "seqLength": 349,
      "domains": [
       {
        "start": 109,
        "end": 313,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MFAP1",
        "accession": "PF06991",
        "description": "Microfibril-associated/Pre-mRNA processing",
        "evalue": "1.7e-61",
        "score": "208.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002025",
      "seqLength": 233,
      "domains": [
       {
        "start": 68,
        "end": 221,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TRAPP",
        "accession": "PF04051",
        "description": "Transport protein particle (TRAPP) component",
        "evalue": "2.3e-43",
        "score": "147.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002026",
      "seqLength": 340,
      "domains": [
       {
        "start": 57,
        "end": 300,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PP2C",
        "accession": "PF00481",
        "description": "Protein phosphatase 2C",
        "evalue": "2.9e-67",
        "score": "227.2"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002028",
      "seqLength": 434,
      "domains": [
       {
        "start": 38,
        "end": 209,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "DEAD",
        "accession": "PF00270",
        "description": "DEAD/DEAH box helicase",
        "evalue": "1e-42",
        "score": "146.0"
       },
       {
        "start": 253,
        "end": 362,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "2.1e-27",
        "score": "95.8"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_002020",
      "seqLength": 1052,
      "domains": [
       {
        "start": 19,
        "end": 165,
        "name": "TIGR00231",
        "description": "small_GTP: small GTP-binding protein domain",
        "accession": "TIGR00231",
        "evalue": "7e-14",
        "score": "49.9",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r52c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS14BIN71_002409",
         "subject": "gene2",
         "query_loc": 26488,
         "subject_loc": 10607
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002409"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS14BIN71_002409",
         "subject": "mfR6",
         "query_loc": 26488,
         "subject_loc": 67091
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002409"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS14BIN71_002405",
         "subject": "ABC42561.1",
         "query_loc": 17388,
         "subject_loc": 27217
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002405"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS14BIN71_002409",
         "subject": "gene2",
         "query_loc": 26488,
         "subject_loc": 10607
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002409"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS14BIN71_002409",
         "subject": "mfR6",
         "query_loc": 26488,
         "subject_loc": 67091
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002409"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS14BIN71_002405",
         "subject": "ABC42561.1",
         "query_loc": 17388,
         "subject_loc": 27217
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS14BIN71_002405"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_002405": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS14BIN71_002406": {
     "functions": []
    },
    "MARS14BIN71_002407": {
     "functions": [
      {
       "description": "SMCOG1173:WD-40 repeat-containing protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_002408": {
     "functions": []
    },
    "MARS14BIN71_002409": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS14BIN71_002410": {
     "functions": []
    },
    "MARS14BIN71_002411": {
     "functions": []
    },
    "MARS14BIN71_002412": {
     "functions": []
    },
    "MARS14BIN71_002413": {
     "functions": []
    },
    "MARS14BIN71_002414": {
     "functions": []
    },
    "MARS14BIN71_002415": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_002405",
      "seqLength": 893,
      "domains": [
       {
        "start": 8,
        "end": 195,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "1e-37",
        "score": "129.6"
       },
       {
        "start": 313,
        "end": 496,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "8.9e-43",
        "score": "146.2"
       },
       {
        "start": 769,
        "end": 879,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "MaoC_dehydratas",
        "accession": "PF01575",
        "description": "MaoC like domain",
        "evalue": "6.8e-33",
        "score": "113.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002406",
      "seqLength": 572,
      "domains": [
       {
        "start": 235,
        "end": 339,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport"
        ],
        "html_class": "generic-type-other",
        "name": "Ran_BP1",
        "accession": "PF00638",
        "description": "RanBP1 domain",
        "evalue": "1.4e-15",
        "score": "57.8"
       },
       {
        "start": 366,
        "end": 569,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum"
        ],
        "html_class": "generic-type-other",
        "name": "Rot1",
        "accession": "PF10681",
        "description": "Chaperone for protein-folding within the ER, fungal",
        "evalue": "5.4e-87",
        "score": "290.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002407",
      "seqLength": 1233,
      "domains": [
       {
        "start": 131,
        "end": 159,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "WD40",
        "accession": "PF00400",
        "description": "WD domain, G-beta repeat",
        "evalue": "0.00019",
        "score": "22.3"
       },
       {
        "start": 1075,
        "end": 1199,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "NOT2_3_5",
        "accession": "PF04153",
        "description": "NOT2 / NOT3 / NOT5 family",
        "evalue": "2.7e-33",
        "score": "115.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002409",
      "seqLength": 383,
      "domains": [
       {
        "start": 77,
        "end": 368,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "1.7e-37",
        "score": "129.5"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002410",
      "seqLength": 659,
      "domains": [
       {
        "start": 90,
        "end": 406,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GCP_N_terminal",
        "accession": "PF17681",
        "description": "Gamma tubulin complex component N-terminal",
        "evalue": "3.7e-60",
        "score": "204.3"
       },
       {
        "start": 410,
        "end": 657,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding"
        ],
        "html_class": "generic-type-other",
        "name": "GCP_C_terminal",
        "accession": "PF04130",
        "description": "Gamma tubulin complex component C-terminal",
        "evalue": "2.8e-50",
        "score": "171.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002411",
      "seqLength": 253,
      "domains": [
       {
        "start": 0,
        "end": 145,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation"
        ],
        "html_class": "generic-type-other",
        "name": "tRNA-synt_2b",
        "accession": "PF00587",
        "description": "tRNA synthetase class II core domain (G, H, P, S and T)",
        "evalue": "2.3e-11",
        "score": "44.1"
       },
       {
        "start": 165,
        "end": 212,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HGTP_anticodon",
        "accession": "PF03129",
        "description": "Anticodon binding domain",
        "evalue": "0.00018",
        "score": "21.7"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002412",
      "seqLength": 434,
      "domains": [
       {
        "start": 23,
        "end": 46,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00041",
        "score": "20.8"
       },
       {
        "start": 52,
        "end": 76,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00088",
        "score": "19.7"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002413",
      "seqLength": 303,
      "domains": [
       {
        "start": 3,
        "end": 111,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MOSC_N",
        "accession": "PF03476",
        "description": "MOSC N-terminal beta barrel domain",
        "evalue": "1.4e-13",
        "score": "50.9"
       },
       {
        "start": 161,
        "end": 290,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "MOSC",
        "accession": "PF03473",
        "description": "MOSC domain",
        "evalue": "1.2e-24",
        "score": "87.1"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_002409",
      "seqLength": 383,
      "domains": [
       {
        "start": 67,
        "end": 377,
        "name": "TIGR01559",
        "description": "squal_synth: farnesyl-diphosphate farnesyltransferase",
        "accession": "TIGR01559",
        "evalue": "1.2e-117",
        "score": "390.9",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r75c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001516: 0-14978": {
       "start": 0,
       "end": 14978,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "AFLA_023050",
         "query_loc": 26587,
         "subject_loc": 13316
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AFLA_023000",
         "start": 0,
         "end": 1069,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023010",
         "start": 2762,
         "end": 3758,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023020",
         "start": 4299,
         "end": 7365,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023030",
         "start": 7979,
         "end": 9639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023040",
         "start": 9846,
         "end": 11965,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023050",
         "start": 12565,
         "end": 14067,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "AFLA_023060",
         "start": 14709,
         "end": 14978,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002602: 406-14432": {
       "start": 406,
       "end": 14432,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "AZL87947.1",
         "query_loc": 26587,
         "subject_loc": 13682
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AZL87942.1",
         "start": 406,
         "end": 1475,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87943.1",
         "start": 3167,
         "end": 4163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87944.1",
         "start": 4677,
         "end": 7743,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AZL87945.1",
         "start": 8332,
         "end": 10007,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AZL87946.1",
         "start": 10377,
         "end": 12334,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87947.1",
         "start": 12932,
         "end": 14432,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        }
       ]
      },
      "BGC0002158: 177-13328": {
       "start": 177,
       "end": 13328,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "MGG_07802",
         "query_loc": 26587,
         "subject_loc": 4761
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MGG_07800",
         "start": 177,
         "end": 2585,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MGG_07802",
         "start": 4043,
         "end": 5480,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "MGG_07803",
         "start": 7152,
         "end": 13328,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MGG_16932",
         "start": 3001,
         "end": 3236,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001305: 0-24253": {
       "start": 0,
       "end": 24253,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "FFUJ_12242",
         "query_loc": 26587,
         "subject_loc": 13661
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "FFUJ_12239",
         "start": 0,
         "end": 7646,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12240",
         "start": 8284,
         "end": 9379,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12241",
         "start": 10274,
         "end": 11368,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12242",
         "start": 12857,
         "end": 14466,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "FFUJ_12243",
         "start": 15419,
         "end": 16774,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12244",
         "start": 22521,
         "end": 24253,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "ADH01663.1",
         "query_loc": 32368,
         "subject_loc": 4052
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        }
       ]
      },
      "BGC0002227: 270-18409": {
       "start": 270,
       "end": 18409,
       "links": [
        {
         "query": "MARS14BIN71_002919",
         "subject": "AKAW_03689",
         "query_loc": 20438,
         "subject_loc": 3962
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AKAW_03689",
         "start": 270,
         "end": 7654,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002919"
         }
        },
        {
         "locus_tag": "AKAW_03690",
         "start": 9680,
         "end": 10680,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AKAW_03691",
         "start": 10850,
         "end": 13994,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AKAW_03692",
         "start": 16541,
         "end": 18409,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0002213: 0-33851": {
       "start": 0,
       "end": 33851,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "PUNSTDRAFT_51778",
         "query_loc": 26587,
         "subject_loc": 15277
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PUNSTDRAFT_101387",
         "start": 0,
         "end": 1870,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_101403",
         "start": 32203,
         "end": 33851,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143067",
         "start": 6011,
         "end": 13646,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143069",
         "start": 17866,
         "end": 20360,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143070",
         "start": 22036,
         "end": 24200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143071",
         "start": 24847,
         "end": 26040,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51778",
         "start": 14240,
         "end": 16314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "PUNSTDRAFT_51779",
         "start": 17422,
         "end": 17642,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51781",
         "start": 27435,
         "end": 27922,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51782",
         "start": 28627,
         "end": 28873,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51783",
         "start": 30604,
         "end": 31659,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_85939",
         "start": 2443,
         "end": 4527,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002268: 0-26854": {
       "start": 0,
       "end": 26854,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "QNH68022.1",
         "query_loc": 26587,
         "subject_loc": 9229
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "QNH68018.1",
         "start": 0,
         "end": 1901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68019.1",
         "start": 2450,
         "end": 4076,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68020.1",
         "start": 4498,
         "end": 6351,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68021.1",
         "start": 6671,
         "end": 7713,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68022.1",
         "start": 8463,
         "end": 9996,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "QNH68023.1",
         "start": 11606,
         "end": 13995,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68024.1",
         "start": 14697,
         "end": 26854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002206: 173-38907": {
       "start": 173,
       "end": 38907,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "A0O28_0102340",
         "query_loc": 32368,
         "subject_loc": 32600
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "A0O28_0102260",
         "start": 173,
         "end": 1871,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102270",
         "start": 2896,
         "end": 3364,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102280",
         "start": 4587,
         "end": 12720,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102290",
         "start": 12955,
         "end": 15367,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102300",
         "start": 17903,
         "end": 18962,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102310",
         "start": 20097,
         "end": 22175,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102320",
         "start": 23118,
         "end": 25543,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102330",
         "start": 26450,
         "end": 27860,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102340",
         "start": 28525,
         "end": 36676,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        },
        {
         "locus_tag": "A0O28_0102350",
         "start": 37521,
         "end": 38907,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001722: 0-18441": {
       "start": 0,
       "end": 18441,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "ANIA_03230",
         "query_loc": 32368,
         "subject_loc": 3390
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ANIA_03225",
         "start": 16613,
         "end": 18441,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03226",
         "start": 14468,
         "end": 15491,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03227",
         "start": 12261,
         "end": 13862,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03228",
         "start": 10381,
         "end": 11311,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03229",
         "start": 7702,
         "end": 9641,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03230",
         "start": 0,
         "end": 6781,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001516: 0-14978": {
       "start": 0,
       "end": 14978,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "AFLA_023050",
         "query_loc": 26587,
         "subject_loc": 13316
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AFLA_023000",
         "start": 0,
         "end": 1069,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023010",
         "start": 2762,
         "end": 3758,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023020",
         "start": 4299,
         "end": 7365,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023030",
         "start": 7979,
         "end": 9639,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023040",
         "start": 9846,
         "end": 11965,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AFLA_023050",
         "start": 12565,
         "end": 14067,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "AFLA_023060",
         "start": 14709,
         "end": 14978,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0002602: 406-14432": {
       "start": 406,
       "end": 14432,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "AZL87947.1",
         "query_loc": 26587,
         "subject_loc": 13682
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AZL87942.1",
         "start": 406,
         "end": 1475,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87943.1",
         "start": 3167,
         "end": 4163,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87944.1",
         "start": 4677,
         "end": 7743,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "AZL87945.1",
         "start": 8332,
         "end": 10007,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AZL87946.1",
         "start": 10377,
         "end": 12334,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AZL87947.1",
         "start": 12932,
         "end": 14432,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        }
       ]
      },
      "BGC0002158: 177-13328": {
       "start": 177,
       "end": 13328,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "MGG_07802",
         "query_loc": 26587,
         "subject_loc": 4761
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MGG_07800",
         "start": 177,
         "end": 2585,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MGG_07802",
         "start": 4043,
         "end": 5480,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "MGG_07803",
         "start": 7152,
         "end": 13328,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MGG_16932",
         "start": 3001,
         "end": 3236,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001305: 0-24253": {
       "start": 0,
       "end": 24253,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "FFUJ_12242",
         "query_loc": 26587,
         "subject_loc": 13661
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "FFUJ_12239",
         "start": 0,
         "end": 7646,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12240",
         "start": 8284,
         "end": 9379,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12241",
         "start": 10274,
         "end": 11368,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12242",
         "start": 12857,
         "end": 14466,
         "strand": -1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "FFUJ_12243",
         "start": 15419,
         "end": 16774,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FFUJ_12244",
         "start": 22521,
         "end": 24253,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "ADH01663.1",
         "query_loc": 32368,
         "subject_loc": 4052
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        }
       ]
      },
      "BGC0002227: 270-18409": {
       "start": 270,
       "end": 18409,
       "links": [
        {
         "query": "MARS14BIN71_002919",
         "subject": "AKAW_03689",
         "query_loc": 20438,
         "subject_loc": 3962
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AKAW_03689",
         "start": 270,
         "end": 7654,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002919"
         }
        },
        {
         "locus_tag": "AKAW_03690",
         "start": 9680,
         "end": 10680,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AKAW_03691",
         "start": 10850,
         "end": 13994,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AKAW_03692",
         "start": 16541,
         "end": 18409,
         "strand": 1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0002213: 0-33851": {
       "start": 0,
       "end": 33851,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "PUNSTDRAFT_51778",
         "query_loc": 26587,
         "subject_loc": 15277
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PUNSTDRAFT_101387",
         "start": 0,
         "end": 1870,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_101403",
         "start": 32203,
         "end": 33851,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143067",
         "start": 6011,
         "end": 13646,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143069",
         "start": 17866,
         "end": 20360,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143070",
         "start": 22036,
         "end": 24200,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_143071",
         "start": 24847,
         "end": 26040,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51778",
         "start": 14240,
         "end": 16314,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "PUNSTDRAFT_51779",
         "start": 17422,
         "end": 17642,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51781",
         "start": 27435,
         "end": 27922,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51782",
         "start": 28627,
         "end": 28873,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_51783",
         "start": 30604,
         "end": 31659,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PUNSTDRAFT_85939",
         "start": 2443,
         "end": 4527,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002268: 0-26854": {
       "start": 0,
       "end": 26854,
       "links": [
        {
         "query": "MARS14BIN71_002921",
         "subject": "QNH68022.1",
         "query_loc": 26587,
         "subject_loc": 9229
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "QNH68018.1",
         "start": 0,
         "end": 1901,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68019.1",
         "start": 2450,
         "end": 4076,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68020.1",
         "start": 4498,
         "end": 6351,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QNH68021.1",
         "start": 6671,
         "end": 7713,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68022.1",
         "start": 8463,
         "end": 9996,
         "strand": 1,
         "function": "transport",
         "linked": {
          "1": "MARS14BIN71_002921"
         }
        },
        {
         "locus_tag": "QNH68023.1",
         "start": 11606,
         "end": 13995,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QNH68024.1",
         "start": 14697,
         "end": 26854,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002206: 173-38907": {
       "start": 173,
       "end": 38907,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "A0O28_0102340",
         "query_loc": 32368,
         "subject_loc": 32600
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "A0O28_0102260",
         "start": 173,
         "end": 1871,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102270",
         "start": 2896,
         "end": 3364,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102280",
         "start": 4587,
         "end": 12720,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102290",
         "start": 12955,
         "end": 15367,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102300",
         "start": 17903,
         "end": 18962,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102310",
         "start": 20097,
         "end": 22175,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102320",
         "start": 23118,
         "end": 25543,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102330",
         "start": 26450,
         "end": 27860,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "A0O28_0102340",
         "start": 28525,
         "end": 36676,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        },
        {
         "locus_tag": "A0O28_0102350",
         "start": 37521,
         "end": 38907,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001722: 0-18441": {
       "start": 0,
       "end": 18441,
       "links": [
        {
         "query": "MARS14BIN71_002923",
         "subject": "ANIA_03230",
         "query_loc": 32368,
         "subject_loc": 3390
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ANIA_03225",
         "start": 16613,
         "end": 18441,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03226",
         "start": 14468,
         "end": 15491,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03227",
         "start": 12261,
         "end": 13862,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03228",
         "start": 10381,
         "end": 11311,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03229",
         "start": 7702,
         "end": 9641,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03230",
         "start": 0,
         "end": 6781,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_002923"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_002923",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 30,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_002923",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 535,
        "terminalDocking": ""
       },
       {
        "name": "TD",
        "description": "TD",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_002923",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 655,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_002913": {
     "functions": []
    },
    "MARS14BIN71_002914": {
     "functions": [
      {
       "description": "SMCOG1173:WD-40 repeat-containing protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_002915": {
     "functions": []
    },
    "MARS14BIN71_002916": {
     "functions": []
    },
    "MARS14BIN71_002917": {
     "functions": []
    },
    "MARS14BIN71_002918": {
     "functions": []
    },
    "MARS14BIN71_002919": {
     "functions": [
      {
       "description": "ADH_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "ADH_zinc_N",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1028:crotonyl-CoA reductase / alcohol dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_002920": {
     "functions": []
    },
    "MARS14BIN71_002921": {
     "functions": [
      {
       "description": "SMCOG1137:Major facilitator superfamily MFS 1 ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_002922": {
     "functions": []
    },
    "MARS14BIN71_002923": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_002924": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1034:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_002913",
      "seqLength": 215,
      "domains": [
       {
        "start": 10,
        "end": 167,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Ras",
        "accession": "PF00071",
        "description": "Ras family",
        "evalue": "2.4e-49",
        "score": "167.2"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002914",
      "seqLength": 567,
      "domains": [
       {
        "start": 394,
        "end": 419,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "WD40",
        "accession": "PF00400",
        "description": "WD domain, G-beta repeat",
        "evalue": "0.0027",
        "score": "18.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002915",
      "seqLength": 165,
      "domains": [
       {
        "start": 48,
        "end": 143,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "TFB6",
        "accession": "PF17110",
        "description": "Subunit 11 of the general transcription factor TFIIH",
        "evalue": "1.5e-07",
        "score": "31.5"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002916",
      "seqLength": 335,
      "domains": [
       {
        "start": 226,
        "end": 309,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MBOAT_2",
        "accession": "PF13813",
        "description": "Membrane bound O-acyl transferase family",
        "evalue": "8.8e-14",
        "score": "51.7"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002918",
      "seqLength": 631,
      "domains": [
       {
        "start": 51,
        "end": 587,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "EMP70",
        "accession": "PF02990",
        "description": "Endomembrane protein 70",
        "evalue": "2.1e-195",
        "score": "650.5"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002919",
      "seqLength": 924,
      "domains": [
       {
        "start": 288,
        "end": 592,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046873' target='_blank'>GO:0046873</a>: metal ion transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030001' target='_blank'>GO:0030001</a>: metal ion transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016020' target='_blank'>GO:0016020</a>: membrane"
        ],
        "html_class": "generic-type-other",
        "name": "CorA",
        "accession": "PF01544",
        "description": "CorA-like Mg2+ transporter protein",
        "evalue": "1.4e-46",
        "score": "159.3"
       },
       {
        "start": 625,
        "end": 689,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ADH_N",
        "accession": "PF08240",
        "description": "Alcohol dehydrogenase GroES-like domain",
        "evalue": "4.9e-10",
        "score": "39.4"
       },
       {
        "start": 747,
        "end": 870,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ADH_zinc_N",
        "accession": "PF00107",
        "description": "Zinc-binding dehydrogenase",
        "evalue": "2.4e-26",
        "score": "92.4"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002920",
      "seqLength": 1119,
      "domains": [
       {
        "start": 448,
        "end": 755,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0140658' target='_blank'>GO:0140658</a>: ATP-dependent chromatin remodeler activity"
        ],
        "html_class": "generic-type-other",
        "name": "SNF2-rel_dom",
        "accession": "PF00176",
        "description": "SNF2-related domain",
        "evalue": "1.2e-62",
        "score": "211.8"
       },
       {
        "start": 933,
        "end": 1048,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "2e-13",
        "score": "50.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002921",
      "seqLength": 465,
      "domains": [
       {
        "start": 80,
        "end": 360,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0022857' target='_blank'>GO:0022857</a>: transmembrane transporter activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
        ],
        "html_class": "generic-type-transport",
        "name": "MFS_1",
        "accession": "PF07690",
        "description": "Major Facilitator Superfamily",
        "evalue": "1.2e-20",
        "score": "73.9"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002922",
      "seqLength": 552,
      "domains": [
       {
        "start": 91,
        "end": 317,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Fungal_trans",
        "accession": "PF04082",
        "description": "Fungal specific transcription factor domain",
        "evalue": "3.4e-26",
        "score": "92.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002923",
      "seqLength": 1016,
      "domains": [
       {
        "start": 24,
        "end": 321,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.8e-36",
        "score": "125.8"
       },
       {
        "start": 536,
        "end": 606,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.5e-07",
        "score": "31.7"
       },
       {
        "start": 657,
        "end": 891,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "5.5e-42",
        "score": "143.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002924",
      "seqLength": 487,
      "domains": [
       {
        "start": 34,
        "end": 426,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "1.8e-40",
        "score": "139.2"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_002913",
      "seqLength": 215,
      "domains": [
       {
        "start": 8,
        "end": 158,
        "name": "TIGR00231",
        "description": "small_GTP: small GTP-binding protein domain",
        "accession": "TIGR00231",
        "evalue": "3.6e-22",
        "score": "76.9",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_002923",
      "seqLength": 1016,
      "domains": [
       {
        "start": 654,
        "end": 1015,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "8.4e-64",
        "score": "214.1",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r93c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {}
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_003216": {
     "functions": []
    },
    "MARS14BIN71_003217": {
     "functions": []
    },
    "MARS14BIN71_003218": {
     "functions": []
    },
    "MARS14BIN71_003219": {
     "functions": []
    },
    "MARS14BIN71_003220": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS14BIN71_003221": {
     "functions": []
    },
    "MARS14BIN71_003222": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1081:cysteine synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_003216",
      "seqLength": 168,
      "domains": [
       {
        "start": 59,
        "end": 111,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HIG_1_N",
        "accession": "PF04588",
        "description": "Hypoxia induced protein conserved region",
        "evalue": "5.3e-20",
        "score": "71.4"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003217",
      "seqLength": 199,
      "domains": [
       {
        "start": 11,
        "end": 123,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Rhodanese",
        "accession": "PF00581",
        "description": "Rhodanese-like domain",
        "evalue": "0.00011",
        "score": "22.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003220",
      "seqLength": 444,
      "domains": [
       {
        "start": 134,
        "end": 418,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "2.3e-46",
        "score": "158.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003221",
      "seqLength": 545,
      "domains": [
       {
        "start": 305,
        "end": 491,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TLD",
        "accession": "PF07534",
        "description": "TLD",
        "evalue": "1.8e-17",
        "score": "64.0"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003222",
      "seqLength": 572,
      "domains": [
       {
        "start": 79,
        "end": 372,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "4.1e-77",
        "score": "259.6"
       },
       {
        "start": 385,
        "end": 476,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "9.6e-16",
        "score": "57.5"
       },
       {
        "start": 487,
        "end": 569,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "2.8e-20",
        "score": "72.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_003220",
      "seqLength": 444,
      "domains": [
       {
        "start": 1,
        "end": 74,
        "name": "TIGR03462",
        "description": "CarR_dom_SF: lycopene cyclase domain",
        "accession": "TIGR03462",
        "evalue": "7.3e-15",
        "score": "53.3",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003222",
      "seqLength": 572,
      "domains": [
       {
        "start": 65,
        "end": 568,
        "name": "TIGR01124",
        "description": "ilvA_2Cterm: threonine ammonia-lyase, biosynthetic",
        "accession": "TIGR01124",
        "evalue": "7.5e-201",
        "score": "666.0",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r127c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "perA",
         "query_loc": 12443,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "icoS",
         "query_loc": 12443,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "XNC1_2022",
         "query_loc": 12443,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "plu3123",
         "query_loc": 12443,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "plu3263",
         "query_loc": 12443,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "PLU_RS13235",
         "query_loc": 12443,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "X797_010654",
         "query_loc": 12443,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0000307: 505-35485": {
       "start": 505,
       "end": 35485,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "aba1",
         "query_loc": 12443,
         "subject_loc": 17995
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "aba1",
         "start": 505,
         "end": 35485,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "AN5318.2",
         "query_loc": 12443,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 12443,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "perA",
         "query_loc": 12443,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "icoS",
         "query_loc": 12443,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "XNC1_2022",
         "query_loc": 12443,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "plu3123",
         "query_loc": 12443,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "plu3263",
         "query_loc": 12443,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "PLU_RS13235",
         "query_loc": 12443,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "X797_010654",
         "query_loc": 12443,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0000307: 505-35485": {
       "start": 505,
       "end": 35485,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "aba1",
         "query_loc": 12443,
         "subject_loc": 17995
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "aba1",
         "start": 505,
         "end": 35485,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "AN5318.2",
         "query_loc": 12443,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS14BIN71_003608",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 12443,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS14BIN71_003608"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_003608",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 223,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_003608",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 821,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "MARS14BIN71_003608",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 944,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Aad"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS14BIN71_003603": {
     "functions": []
    },
    "MARS14BIN71_003604": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS14BIN71_003605": {
     "functions": []
    },
    "MARS14BIN71_003606": {
     "functions": []
    },
    "MARS14BIN71_003607": {
     "functions": []
    },
    "MARS14BIN71_003608": {
     "functions": [
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS14BIN71_003609": {
     "functions": []
    },
    "MARS14BIN71_003610": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS14BIN71_003603",
      "seqLength": 189,
      "domains": [
       {
        "start": 113,
        "end": 186,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding"
        ],
        "html_class": "generic-type-other",
        "name": "PX",
        "accession": "PF00787",
        "description": "PX domain",
        "evalue": "1.7e-15",
        "score": "57.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003604",
      "seqLength": 685,
      "domains": [
       {
        "start": 13,
        "end": 138,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Trp_syntA",
        "accession": "PF00290",
        "description": "Tryptophan synthase alpha chain",
        "evalue": "2.3e-50",
        "score": "171.0"
       },
       {
        "start": 140,
        "end": 232,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Trp_syntA",
        "accession": "PF00290",
        "description": "Tryptophan synthase alpha chain",
        "evalue": "9.3e-21",
        "score": "74.0"
       },
       {
        "start": 335,
        "end": 659,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "7.8e-49",
        "score": "166.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003605",
      "seqLength": 494,
      "domains": [
       {
        "start": 158,
        "end": 220,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "4.6e-14",
        "score": "52.1"
       },
       {
        "start": 253,
        "end": 318,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "4.1e-15",
        "score": "55.5"
       },
       {
        "start": 343,
        "end": 409,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "3e-15",
        "score": "55.9"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003606",
      "seqLength": 893,
      "domains": [
       {
        "start": 631,
        "end": 761,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity"
        ],
        "html_class": "generic-type-other",
        "name": "AAA",
        "accession": "PF00004",
        "description": "ATPase family associated with various cellular activities (AAA)",
        "evalue": "3.1e-40",
        "score": "137.8"
       },
       {
        "start": 784,
        "end": 819,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_lid_3",
        "accession": "PF17862",
        "description": "AAA+ lid domain",
        "evalue": "4.3e-07",
        "score": "29.8"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003608",
      "seqLength": 1355,
      "domains": [
       {
        "start": 223,
        "end": 688,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.1e-65",
        "score": "222.1"
       },
       {
        "start": 822,
        "end": 887,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "3.5e-12",
        "score": "46.6"
       },
       {
        "start": 944,
        "end": 1194,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "1.2e-75",
        "score": "254.2"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003609",
      "seqLength": 528,
      "domains": [
       {
        "start": 36,
        "end": 102,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab_N",
        "accession": "PF02874",
        "description": "ATP synthase alpha/beta family, beta-barrel domain",
        "evalue": "2.2e-14",
        "score": "53.9"
       },
       {
        "start": 158,
        "end": 386,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab",
        "accession": "PF00006",
        "description": "ATP synthase alpha/beta family, nucleotide-binding domain",
        "evalue": "6.7e-64",
        "score": "215.6"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003610",
      "seqLength": 322,
      "domains": [
       {
        "start": 27,
        "end": 269,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF1295",
        "accession": "PF06966",
        "description": "Protein of unknown function (DUF1295)",
        "evalue": "2.5e-60",
        "score": "204.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS14BIN71_003604",
      "seqLength": 685,
      "domains": [
       {
        "start": 289,
        "end": 671,
        "name": "TIGR00263",
        "description": "trpB: tryptophan synthase, beta subunit",
        "accession": "TIGR00263",
        "evalue": "2.6e-174",
        "score": "577.7",
        "html_class": "generic-type-other"
       },
       {
        "start": 14,
        "end": 138,
        "name": "TIGR00262",
        "description": "trpA: tryptophan synthase, alpha subunit",
        "accession": "TIGR00262",
        "evalue": "3.7e-38",
        "score": "128.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003608",
      "seqLength": 1355,
      "domains": [
       {
        "start": 6,
        "end": 1350,
        "name": "TIGR03443",
        "description": "alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase",
        "accession": "TIGR03443",
        "evalue": "0",
        "score": "1894.1",
        "html_class": "generic-type-other"
       },
       {
        "start": 253,
        "end": 711,
        "name": "TIGR01733",
        "description": "AA-adenyl-dom: amino acid adenylation domain",
        "accession": "TIGR01733",
        "evalue": "1.6e-113",
        "score": "377.5",
        "html_class": "generic-type-other"
       },
       {
        "start": 941,
        "end": 1317,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "6.2e-103",
        "score": "342.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS14BIN71_003609",
      "seqLength": 528,
      "domains": [
       {
        "start": 32,
        "end": 495,
        "name": "TIGR01040",
        "description": "V-ATPase_V1_B: V-type ATPase, B subunit",
        "accession": "TIGR01040",
        "evalue": "8.8e-291",
        "score": "962.1",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};

var recordData = [
 {
  "length": 49406,
  "seq_id": "scaffold_1",
  "regions": []
 },
 {
  "length": 45250,
  "seq_id": "scaffold_2",
  "regions": []
 },
 {
  "length": 35081,
  "seq_id": "scaffold_3",
  "regions": []
 },
 {
  "length": 33959,
  "seq_id": "scaffold_4",
  "regions": []
 },
 {
  "length": 33672,
  "seq_id": "scaffold_5",
  "regions": []
 },
 {
  "length": 31243,
  "seq_id": "scaffold_6",
  "regions": []
 },
 {
  "length": 31167,
  "seq_id": "scaffold_7",
  "regions": []
 },
 {
  "length": 30717,
  "seq_id": "scaffold_8",
  "regions": []
 },
 {
  "length": 30357,
  "seq_id": "scaffold_9",
  "regions": []
 },
 {
  "length": 30225,
  "seq_id": "scaffold_10",
  "regions": []
 },
 {
  "length": 29878,
  "seq_id": "scaffold_11",
  "regions": []
 },
 {
  "length": 29630,
  "seq_id": "scaffold_12",
  "regions": []
 },
 {
  "length": 28764,
  "seq_id": "scaffold_13",
  "regions": []
 },
 {
  "length": 28725,
  "seq_id": "scaffold_14",
  "regions": []
 },
 {
  "length": 27649,
  "seq_id": "scaffold_15",
  "regions": []
 },
 {
  "length": 27358,
  "seq_id": "scaffold_16",
  "regions": []
 },
 {
  "length": 27148,
  "seq_id": "scaffold_17",
  "regions": []
 },
 {
  "length": 26864,
  "seq_id": "scaffold_18",
  "regions": []
 },
 {
  "length": 26760,
  "seq_id": "scaffold_19",
  "regions": []
 },
 {
  "length": 26496,
  "seq_id": "scaffold_20",
  "regions": []
 },
 {
  "length": 26243,
  "seq_id": "scaffold_21",
  "regions": []
 },
 {
  "length": 25402,
  "seq_id": "scaffold_22",
  "regions": []
 },
 {
  "length": 25371,
  "seq_id": "scaffold_23",
  "regions": []
 },
 {
  "length": 25139,
  "seq_id": "scaffold_24",
  "regions": []
 },
 {
  "length": 24701,
  "seq_id": "scaffold_25",
  "regions": []
 },
 {
  "length": 23754,
  "seq_id": "scaffold_26",
  "regions": []
 },
 {
  "length": 23376,
  "seq_id": "scaffold_27",
  "regions": []
 },
 {
  "length": 23254,
  "seq_id": "scaffold_28",
  "regions": []
 },
 {
  "length": 23238,
  "seq_id": "scaffold_29",
  "regions": []
 },
 {
  "length": 23221,
  "seq_id": "scaffold_30",
  "regions": []
 },
 {
  "length": 23052,
  "seq_id": "scaffold_31",
  "regions": []
 },
 {
  "length": 22968,
  "seq_id": "scaffold_32",
  "regions": []
 },
 {
  "length": 22960,
  "seq_id": "scaffold_33",
  "regions": []
 },
 {
  "length": 22902,
  "seq_id": "scaffold_34",
  "regions": []
 },
 {
  "length": 22869,
  "seq_id": "scaffold_35",
  "regions": []
 },
 {
  "length": 22688,
  "seq_id": "scaffold_36",
  "regions": []
 },
 {
  "length": 22650,
  "seq_id": "scaffold_37",
  "regions": [
   {
    "start": 1,
    "end": 12412,
    "idx": 1,
    "orfs": [
     {
      "start": 451,
      "end": 1311,
      "strand": 1,
      "locus_tag": "MARS19BIN38_000556",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000556</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000556</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000556-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 451 - 1,311,\n (total: 861 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000556 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [208:272](score: 47.5, e-value: 1.3e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000556\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ACACAAATTTCAGATTTCCTTCGTGGTGCTGTCTACTTCGTAAGTCTGCCCTCTGGTCTTTACGGTATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGGTCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
      "translation": "MQISDFLRGAVYFVSLPSGLYGMIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
      "product": "hypothetical protein"
     },
     {
      "start": 1411,
      "end": 2412,
      "strand": -1,
      "locus_tag": "MARS19BIN38_000557",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000557</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000557</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000557-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,411 - 2,412,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 234.8; E-value: 1.9e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000557 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 224.6, e-value: 1.1e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000557 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000557\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_000557-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGCTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGGTAATACTGCATTGATGGAGATCCTTAACAGTTGGCATAGTTCTTTGTGTGGCACAGATTAG",
      "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNAWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGGNTALMEILNSWHSSLCGTD",
      "product": "hypothetical protein"
     },
     {
      "start": 2527,
      "end": 3252,
      "strand": 1,
      "locus_tag": "MARS19BIN38_000558",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000558</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000558</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000558-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,527 - 3,252,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000558 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 191.7, e-value: 1.5e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000558\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGGTTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
      "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVVVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
      "product": "hypothetical protein"
     },
     {
      "start": 4553,
      "end": 6941,
      "strand": 1,
      "locus_tag": "MARS19BIN38_000559",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000559</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000559</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000559-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,553 - 6,941,\n (total: 2220 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000559 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 87.0, e-value: 2.4e-24)<br>\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [379:630](score: 293.1, e-value: 1.7e-87)<br>\n \n  PF08669.14 (Glycine cleavage T-protein C-terminal barrel domain): [656:733](score: 66.1, e-value: 2.1e-18)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000559 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [375:734](score: 379.3, e-value: 3.9e-114)<br>\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 93.1, e-value: 5.1e-27)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 63.1, e-value: 7.4e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000559\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_000559-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATTTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCGAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGATGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGGTTATTGCAAGGACGCCAGTGGAGGAGCGGATGTATTACTGGCCCGAATTTAGCATGAACCTATTTACGTACTTCCAGATTCCTGAGGGAACCGTCGCGGATATCGGTGATTATCGAAGGCAGATAGATACATGCAAGATGATGAGACGGTACGCGACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACGGTGTTGCAGCAGTTTGGGGAAGGAGTAAAACGTCGGCGCATTGGACTCACAGTCGAAGGAGCGCCCGCCCGCTCGGCTGCCCCTATTGAGTCCGAGAAACAAGATGTTGGAGTCGTGACAAGCGGGTGCCCATCGCCAACAACCGGGACCAATATTGCCATGGGGTATATTACGCACGGGTTGCACAAGTCTGGCACTGAGATCGCGGTCAAAGTGAGGGGCAGGGAACGGAAAGCCATTGTCACCAAAATGCCCTTTGTGCAGACCAAGTACTATAAATAA",
      "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMVIARTPVEERMYYWPEFSMNLFTYFQIPEGTVADIGDYRRQIDTCKMMRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQTVLQQFGEGVKRRRIGLTVEGAPARSAAPIESEKQDVGVVTSGCPSPTTGTNIAMGYITHGLHKSGTEIAVKVRGRERKAIVTKMPFVQTKYYK",
      "product": "hypothetical protein"
     },
     {
      "start": 7438,
      "end": 10318,
      "strand": 1,
      "locus_tag": "MARS19BIN38_000560",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000560</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000560</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000560-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,438 - 10,318,\n (total: 2838 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00168.33 (C2 domain): [2:66](score: 42.5, e-value: 7e-11)<br>\n \n  PF00168.33 (C2 domain): [161:259](score: 61.2, e-value: 1e-16)<br>\n \n  PF02666.18 (Phosphatidylserine decarboxylase): [691:899](score: 194.8, e-value: 1.2e-57)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00163 (PS_decarb: phosphatidylserine decarboxylase): [685:890](score: 123.4, e-value: 1.9e-36)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity<br>\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000560\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCATTCAAAAAACACTCAATCCGGTGTGGAATCACCATTTTCAAATCCCAATTGATCCATCCATGCTGTCCTCGACATTGAAGCTGGTGTGTTGGGACAAGGACAGGTACGGTAAAGACTACATGGGTGAGATTGAAATCACTCTTGAAGAATTGCTGTCGGAAGACCGCGAGAAAGCACAATGGTTTCCGTTGGTATCGTCCAGGAATAGCAAGATCTCTGGTGAGGTTGAGCTAAGCTTCGGATTACACGATCCTCTAAGCCCGAATGCGACCTTTTCCGATCTTGTAAAGGAGTGGACGAGTATGCTTACGGATACATCAGAACTTGGTAGTGATGCTGATAATGACGATTCAGAGATCGACATTTCTGCTGATGCTACGCCGCAACAAAAGGCACGGAAGCGTAGACTGAGGCGAAGAAGGAAATTGCAAAAGCCTTATGAATTCACCCAAAACAAAGTGTCAGGAGTAGCTGGAATTGTCTATTTTGAGGTCACGTCGTGCTCGGATTTACCACCCGAGAGGAATGTGACTCGAACATCTTTCGATATGGATCCATTTGTGATCATCTCTTTTGGAAAGAAGACTTTACGAACAAAGTCTTTGCGCCATACTCTTAATCCTGTATTCAACGAGAAAATGATCTTTCAGGTGTTGATGTTTGAGCAAGCATATACAATCTCTCTGAGGGTTGTCGATAAAGATAAGTTTTCATCCAATGACTTTGTTGCAGAAGCTGTACTGGACGTAAAAGAATTGATCGATACCGGCCCGACTGCAAACAGCGAGACTGGCTTGTATGATTTACCTGATCCCGAAAGCAACCTACAGTTAACCAAGTCAAAACAATCGACGCTGTCTAAGAGCAATACCAGTGAGAGATTGCATCGAGCAGCGAGCAGTAATTCATTGTCACAAGCACAGCCTCAGAAAGTTACAAAGACTGAAACAAGTGTCGCTTCGTCGCTGAACGGGGAAGATGCGCAGTCGACTGAAGGAAGGACCATGGTTCCTCAACTAAGCGAATCTATCGACTATGATCTGAAAAGCTTTACACTCCCGCTAAATATGGCGAAAAAAGAGCGATGGGAGGAAAAGCACACTCCACAGATCAAGATCAAAGCGCGTTTTGTCCCATACCCTGCACTGCGGCAACAGTTTTGGAGATGTATGTTTCGTCAATATGATAGTGACGATACCGGGCGCATTAGTCGCGTGGAAATGACAACTATGTTGGATACTTTGGGCTCGACTCTCACTGACGCCAGCATCGACGAGCTTTTTGAGCGATATAATTTAGGAACTGACGCCAAGTCGAAGGACGAGTATGAAATGACAATAGACCAGGCAATTGTCTGTCTTGAAGAAGAACTTCGCAAAATCGATGCTACGATTCCAGCTGGAGGTGAAAAGACTCCATCTGATGACGAGGAAGACTCTGAGGTCACAGGAGATGCGCACTCCTTGTCAGAAAGCTCTGAATCCAATAACTTCAAGCCTCCGACAGTGTCTTTCAAAGGGACAGAGATTGCCAAGGATGAAATGTTGCATGATGAAGGCAGACGGGAGCATGTTATCGCGATCAAGGAATGTCCACTTTGCCACCAACCGCGGTTGAATAAGCGATCCGATACAGACATTATAACCCATCTCGCAACCTGTGCAAGTCAGGACTGGCGGAGTGTTGATCGAATAGTCATGGGAGATTTCGTTACATCGAGCCAAGCCCAACGCAAATGGTACTCTAAAGTGATATCGAAAGTAGGCTATGGCGGCTACCGGCTCGGAGCAAACTCTGCCAATATTCTGGTGCAAGATCGTTTGACAGGCCAGATCCAGGAAGAGCGCATGAGTATTTATGTGCGCTTGGGCATACGCCTCTTCTACAAAGGATTGAAGAGTGGGGAAATGGAGAAGAAACGGATGCGCCGTCTGCTCTACTCGTTGAGCGTGAAGCAAGGACGCAAGTATGACGCTCCGCCTTCTGCTCGAGACATCAAGAGTTTCATTGCATTTCACAAGCTTAATATGGCTGAGGTGAAGCTACCGATTGAACAGTTCCAGACCTTCAACCAGTTCTTTTACCGCGAGTTGAAACCTGACGCAAGGCCCTGTACAGCACCGGACAATCACTGGATTGCAGTATCCCCAGCAGATTGCCGATGCGTTCTTTTCGATCGGGTTGATAAGGCTAGCGAAATCTGGGTCAAAGGCCGAGATTTCTCCGTGGCCCGATTGCTTGGCAGTGCGTATCCTGAGGATGCCGCAAAGTTCGAGAACGGATCCATTGGCATATTCCGCTTGGCACCACAAGATTACCATCGCTTCCACTGTCCGGTGGAGGGAGTCCTGCAGGAACCCAAAACGATTGATGGTCAGTACTACACGGTCAATCCGATGGCTGTCCGCTCCTCGCTGGATGTATTTGGCGAGAATGTCCGAGTGGTCTGCCCCATCGACTCCGAGGCGTTTGGGCGCGTGATGGTTGTGTGCATTGGAGCTATGATGGTGGGTAGCACTGTCATCACTGCCAAGACCGGCAGTAAGCTGTCTAGAACCCAAGAACTCGGGTACTTCAAATTTGGCGGAAGCACCCTTGTAGTCTTGTTTCAGCCAGGCAAGCTGAAATTTGACGATGACGTTGTGGGCAACTCGAAATCTTCACTCGAGACGCTGATGCGTGTAGGCATGTCTATTGGCCACCATCCGCAAGAGCCGTCCCAAGCACCTAGCAAGAAGGACCGTGAGAACGCCACACTGGAAGATCGCCAACGTGCAAGTATTGCAATTGGTGGAAGTCTGAAGCCGCCACGTGGTTTAGAACAAGATTAG",
      "translation": "MSIQKTLNPVWNHHFQIPIDPSMLSSTLKLVCWDKDRYGKDYMGEIEITLEELLSEDREKAQWFPLVSSRNSKISGEVELSFGLHDPLSPNATFSDLVKEWTSMLTDTSELGSDADNDDSEIDISADATPQQKARKRRLRRRRKLQKPYEFTQNKVSGVAGIVYFEVTSCSDLPPERNVTRTSFDMDPFVIISFGKKTLRTKSLRHTLNPVFNEKMIFQVLMFEQAYTISLRVVDKDKFSSNDFVAEAVLDVKELIDTGPTANSETGLYDLPDPESNLQLTKSKQSTLSKSNTSERLHRAASSNSLSQAQPQKVTKTETSVASSLNGEDAQSTEGRTMVPQLSESIDYDLKSFTLPLNMAKKERWEEKHTPQIKIKARFVPYPALRQQFWRCMFRQYDSDDTGRISRVEMTTMLDTLGSTLTDASIDELFERYNLGTDAKSKDEYEMTIDQAIVCLEEELRKIDATIPAGGEKTPSDDEEDSEVTGDAHSLSESSESNNFKPPTVSFKGTEIAKDEMLHDEGRREHVIAIKECPLCHQPRLNKRSDTDIITHLATCASQDWRSVDRIVMGDFVTSSQAQRKWYSKVISKVGYGGYRLGANSANILVQDRLTGQIQEERMSIYVRLGIRLFYKGLKSGEMEKKRMRRLLYSLSVKQGRKYDAPPSARDIKSFIAFHKLNMAEVKLPIEQFQTFNQFFYRELKPDARPCTAPDNHWIAVSPADCRCVLFDRVDKASEIWVKGRDFSVARLLGSAYPEDAAKFENGSIGIFRLAPQDYHRFHCPVEGVLQEPKTIDGQYYTVNPMAVRSSLDVFGENVRVVCPIDSEAFGRVMVVCIGAMMVGSTVITAKTGSKLSRTQELGYFKFGGSTLVVLFQPGKLKFDDDVVGNSKSSLETLMRVGMSIGHHPQEPSQAPSKKDRENATLEDRQRASIAIGGSLKPPRGLEQD",
      "product": "hypothetical protein"
     },
     {
      "start": 10548,
      "end": 11762,
      "strand": 1,
      "locus_tag": "MARS19BIN38_000561",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000561</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000561</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000561-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,548 - 11,762,\n (total: 1215 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000561 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08202.14 (Mis12-Mtw1 protein family): [109:400](score: 165.2, e-value: 2.3e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000561 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000561\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACAGAAATGAGCGGCCCGAGAAACGAAAGGCGCACGCCGTTGTAGATATCGAGCCTTCGCCAGATGCGCGCAAAAGGCGAACACAACCTGATCGCAAGGCGAGGGGAAGTCTACAAAATGAAGAGGATGATGGGTTTCAATTTGCGCGTGGGAAGGGAAAACCCCGAAATGATCAGCAACCTGGCGAGGCGAAAAGCGGGAAGCAGGCCACTCGAAGGAAGGTTGTAGACCTTTCCGATACTCCGAAAGGCGAGCGGTCAAATTCTTCGCATGGTAGCGGCGAGGGCTCGACGATGATGGATTCTGTGATCCCACTCTCGACCCGTGATACGCCTATGATTCGAAAGAACAAGGAGCTACGCCAGCAATCGCGTGCCGGAGGACACCGAAGAAGCAGCTCTGGTCTACGTGGGAAACGCGCGAGTTCCATTGGCAATGGTTTCAGGGCGGTCCCCCATCCTGATATCGATGCACGAGATTTCTACAAGCATATTGCCGACGATTTACCAGATCCACTTCGAATGCGACAGCTCCTTGCGTGGTGTGCGCGCCGGGCCTTCGATGAGCAAAAAGTGAGATTGGATGCTGCTCCGCCTGAGAAGGGCCAAGTGATGGATAGGAATGCAGCTACGATTGCACAAGTCGTGAAGCAGGAAGTGCTCATGGATTTGATTGAGAGTCGGATTGAAACGAGCTGGTACCATCGTCCTGAAGGACCACCCAAAACACCTACCAAACCCAATCCTCAAAACGAAGAGAACCGAGCAAAAATTGAACACTTGCAAACTGTCTTGGAGAGGCTGAGAACCGAGGAGCGACAGTGGAAGGCACTGATCACCAATCCGCCAACCTCACAAGCAACCATGACAAATGATAAAGATATCCAACCTGAGGACCTGTCCCTTCTGAGACCGAGGGAGCGAGCATTTTGGGAGAATGTACAGCAGCAGGATTCAAGGGATGCGGAGCGCGTCCAAGAATGGATGGGCGGGGAGGAGAGCAAGCTGGAGTTGCAAGTGGATAAGCTCTTTCATATGCTGCATTCCGTGCGCATGCTTGGAAAGGCAGCCGAGGGGTTCAGCGAGCAGGCGCTGTCCCAAGCTGCTGAGGCGTTTGATGCACGTCGTGAGCGTGCCCAGGAAGAGGCCCGCACAACAGATGTCTCACCGCGCGACATTCTCCGCACCCTGTCACGGCGATCGGATGTATAA",
      "translation": "MNRNERPEKRKAHAVVDIEPSPDARKRRTQPDRKARGSLQNEEDDGFQFARGKGKPRNDQQPGEAKSGKQATRRKVVDLSDTPKGERSNSSHGSGEGSTMMDSVIPLSTRDTPMIRKNKELRQQSRAGGHRRSSSGLRGKRASSIGNGFRAVPHPDIDARDFYKHIADDLPDPLRMRQLLAWCARRAFDEQKVRLDAAPPEKGQVMDRNAATIAQVVKQEVLMDLIESRIETSWYHRPEGPPKTPTKPNPQNEENRAKIEHLQTVLERLRTEERQWKALITNPPTSQATMTNDKDIQPEDLSLLRPRERAFWENVQQQDSRDAERVQEWMGGEESKLELQVDKLFHMLHSVRMLGKAAEGFSEQALSQAAEAFDARRERAQEEARTTDVSPRDILRTLSRRSDV",
      "product": "hypothetical protein"
     },
     {
      "start": 11817,
      "end": 12098,
      "strand": -1,
      "locus_tag": "MARS19BIN38_000562",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000562</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000562</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000562-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,817 - 12,098,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000562 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01910.20 (Thiamine-binding protein): [0:86](score: 83.4, e-value: 8.8e-24)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000562 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00106 (TIGR00106: uncharacterized protein, MTH1187 family): [0:88](score: 86.0, e-value: 4.8e-25)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000562\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGACCTCGTCGCCGTCCGTCACACAGCATGTGGCGCGAGTACAGGTCTACTTTTCCGAGTGCGCTGGCATTGAATTCCACATGCACTCCTACGGCACAACCATCGAAGGGGAGTGGGACGACGTGATGCGCGCCATTGGAGGCGCCCATCAGTGCCTGCACGAGGCGGGCGTCGTCCGGATTGCAAGCGATATACGCGTCGGCACACGCACTGACAAGGCACAGACGTCGCAGCAAAAGGTAGACAGCGTACAAGACTTTCTCGCCACAGACAAGTAG",
      "translation": "MGTSSPSVTQHVARVQVYFSECAGIEFHMHSYGTTIEGEWDDVMRAIGGAHQCLHEAGVVRIASDIRVGTRTDKAQTSQQKVDSVQDFLATDK",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 1410,
      "end": 2412,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 12412,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r37c1"
   }
  ]
 },
 {
  "length": 22575,
  "seq_id": "scaffold_38",
  "regions": []
 },
 {
  "length": 22355,
  "seq_id": "scaffold_39",
  "regions": []
 },
 {
  "length": 22216,
  "seq_id": "scaffold_40",
  "regions": []
 },
 {
  "length": 22108,
  "seq_id": "scaffold_41",
  "regions": []
 },
 {
  "length": 21937,
  "seq_id": "scaffold_42",
  "regions": []
 },
 {
  "length": 21924,
  "seq_id": "scaffold_43",
  "regions": []
 },
 {
  "length": 21893,
  "seq_id": "scaffold_44",
  "regions": []
 },
 {
  "length": 21792,
  "seq_id": "scaffold_45",
  "regions": []
 },
 {
  "length": 21265,
  "seq_id": "scaffold_46",
  "regions": []
 },
 {
  "length": 21157,
  "seq_id": "scaffold_47",
  "regions": []
 },
 {
  "length": 21096,
  "seq_id": "scaffold_48",
  "regions": []
 },
 {
  "length": 21038,
  "seq_id": "scaffold_49",
  "regions": []
 },
 {
  "length": 21002,
  "seq_id": "scaffold_50",
  "regions": []
 },
 {
  "length": 20898,
  "seq_id": "scaffold_51",
  "regions": []
 },
 {
  "length": 20787,
  "seq_id": "scaffold_52",
  "regions": []
 },
 {
  "length": 20775,
  "seq_id": "scaffold_53",
  "regions": []
 },
 {
  "length": 20769,
  "seq_id": "scaffold_54",
  "regions": []
 },
 {
  "length": 20645,
  "seq_id": "scaffold_55",
  "regions": []
 },
 {
  "length": 20592,
  "seq_id": "scaffold_56",
  "regions": []
 },
 {
  "length": 20093,
  "seq_id": "scaffold_57",
  "regions": []
 },
 {
  "length": 19620,
  "seq_id": "scaffold_58",
  "regions": []
 },
 {
  "length": 19470,
  "seq_id": "scaffold_59",
  "regions": []
 },
 {
  "length": 19006,
  "seq_id": "scaffold_60",
  "regions": []
 },
 {
  "length": 18932,
  "seq_id": "scaffold_61",
  "regions": []
 },
 {
  "length": 18812,
  "seq_id": "scaffold_62",
  "regions": []
 },
 {
  "length": 18791,
  "seq_id": "scaffold_63",
  "regions": []
 },
 {
  "length": 18783,
  "seq_id": "scaffold_64",
  "regions": []
 },
 {
  "length": 18738,
  "seq_id": "scaffold_65",
  "regions": []
 },
 {
  "length": 18563,
  "seq_id": "scaffold_66",
  "regions": []
 },
 {
  "length": 18506,
  "seq_id": "scaffold_67",
  "regions": []
 },
 {
  "length": 18448,
  "seq_id": "scaffold_68",
  "regions": []
 },
 {
  "length": 18383,
  "seq_id": "scaffold_69",
  "regions": []
 },
 {
  "length": 18244,
  "seq_id": "scaffold_70",
  "regions": []
 },
 {
  "length": 18243,
  "seq_id": "scaffold_71",
  "regions": []
 },
 {
  "length": 18228,
  "seq_id": "scaffold_72",
  "regions": []
 },
 {
  "length": 18057,
  "seq_id": "scaffold_73",
  "regions": []
 },
 {
  "length": 17930,
  "seq_id": "scaffold_74",
  "regions": []
 },
 {
  "length": 17902,
  "seq_id": "scaffold_75",
  "regions": []
 },
 {
  "length": 17837,
  "seq_id": "scaffold_76",
  "regions": []
 },
 {
  "length": 17774,
  "seq_id": "scaffold_77",
  "regions": []
 },
 {
  "length": 17772,
  "seq_id": "scaffold_78",
  "regions": []
 },
 {
  "length": 17413,
  "seq_id": "scaffold_79",
  "regions": []
 },
 {
  "length": 17319,
  "seq_id": "scaffold_80",
  "regions": []
 },
 {
  "length": 17279,
  "seq_id": "scaffold_81",
  "regions": []
 },
 {
  "length": 17077,
  "seq_id": "scaffold_82",
  "regions": []
 },
 {
  "length": 17048,
  "seq_id": "scaffold_83",
  "regions": []
 },
 {
  "length": 16930,
  "seq_id": "scaffold_84",
  "regions": []
 },
 {
  "length": 16820,
  "seq_id": "scaffold_85",
  "regions": []
 },
 {
  "length": 16776,
  "seq_id": "scaffold_86",
  "regions": []
 },
 {
  "length": 16741,
  "seq_id": "scaffold_87",
  "regions": []
 },
 {
  "length": 16737,
  "seq_id": "scaffold_88",
  "regions": []
 },
 {
  "length": 16557,
  "seq_id": "scaffold_89",
  "regions": []
 },
 {
  "length": 16464,
  "seq_id": "scaffold_90",
  "regions": []
 },
 {
  "length": 16455,
  "seq_id": "scaffold_91",
  "regions": []
 },
 {
  "length": 16345,
  "seq_id": "scaffold_92",
  "regions": []
 },
 {
  "length": 16343,
  "seq_id": "scaffold_93",
  "regions": []
 },
 {
  "length": 16325,
  "seq_id": "scaffold_94",
  "regions": []
 },
 {
  "length": 16291,
  "seq_id": "scaffold_95",
  "regions": []
 },
 {
  "length": 16287,
  "seq_id": "scaffold_96",
  "regions": []
 },
 {
  "length": 16278,
  "seq_id": "scaffold_97",
  "regions": []
 },
 {
  "length": 16257,
  "seq_id": "scaffold_98",
  "regions": []
 },
 {
  "length": 16081,
  "seq_id": "scaffold_99",
  "regions": []
 },
 {
  "length": 16062,
  "seq_id": "scaffold_100",
  "regions": []
 },
 {
  "length": 15960,
  "seq_id": "scaffold_101",
  "regions": []
 },
 {
  "length": 15949,
  "seq_id": "scaffold_102",
  "regions": []
 },
 {
  "length": 15744,
  "seq_id": "scaffold_103",
  "regions": []
 },
 {
  "length": 15673,
  "seq_id": "scaffold_104",
  "regions": []
 },
 {
  "length": 15644,
  "seq_id": "scaffold_105",
  "regions": []
 },
 {
  "length": 15641,
  "seq_id": "scaffold_106",
  "regions": [
   {
    "start": 1,
    "end": 15641,
    "idx": 1,
    "orfs": [
     {
      "start": 552,
      "end": 1142,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001263",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001263</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001263</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001263-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 552 - 1,142,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001263 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [120:193](score: 57.5, e-value: 1.8e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001263 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001263\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "CTCAGCCAAGCGAAGGACGCGATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGACTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAAAACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
      "translation": "MSQAKDAMVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSDSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEENPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
      "product": "hypothetical protein"
     },
     {
      "start": 1863,
      "end": 4114,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001264",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001264</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001264</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001264-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,863 - 4,114,\n (total: 2109 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [1:249](score: 294.9, e-value: 3.6e-88)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [352:676](score: 166.7, e-value: 8.3e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [306:688](score: 577.6, e-value: 2.8e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [1:249](score: 222.7, e-value: 8.5e-67)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001264\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001264-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCGTTTTCGCGGTCTTTGCAAAACCCACTCGATGAGTTATGTTCCTTTGATTGCACCAAGTACAAATGAGTCCAGGCTTGCCCTTTTGTGTTCGATAGCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTGAGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTGCCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCATTGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
      "translation": "MNRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIRFRGLCKTHSMSYVPLIAPSTNESRLALLCSIADSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVSTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTAADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEALRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
      "product": "hypothetical protein"
     },
     {
      "start": 4296,
      "end": 5780,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001265",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001265</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001265</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001265-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,296 - 5,780,\n (total: 1485 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001265 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [158:220](score: 52.1, e-value: 4.6e-14)<br>\n \n  PF00013.32 (KH domain): [253:318](score: 55.5, e-value: 4.1e-15)<br>\n \n  PF00013.32 (KH domain): [343:409](score: 55.9, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001265 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001265\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGACCAGAGCTCTTTGGCTTCGATCTTAGCAGCGCTGAGTCAAGCGCAGGCAGCTCAGCAGAGACAAAGCGGGGGTAACTTGTCTGACTCAAGACCTGCCCCCCCGATGCAACAACAACTCGGTGCGACAAATTCAGGCGGAGCAATGGGCAATAGCTACGGCTACCCGCCTCCCCCTTCCTCATCGGGTGCTATTGATCTGTCTACTCTCAAACCGTCAAATTCTGGTAGCATGTCCTTTGCAGACCCACGATTTGGCGCCTCTGGGCTCAACTCAACGTCGCCAATGATGTCTTCCAACTATTATGACCAGGGAAGAAATGGTGGTTATGATGATAGTCGTAGGCGAAGGCGGTCTAGGTCTCGATCAGGAAGTAGAGAGAGGAGTCCTTATGGCTACAGACGAAGGGACCGCGAAAGATCATACAGCCCTCCGCGACGGGGTGGAGGATCTTCTCCAGATAGGGATACAATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGATACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
      "translation": "MADQSSLASILAALSQAQAAQQRQSGGNLSDSRPAPPMQQQLGATNSGGAMGNSYGYPPPPSSSGAIDLSTLKPSNSGSMSFADPRFGASGLNSTSPMMSSNYYDQGRNGGYDDSRRRRRSRSRSGSRERSPYGYRRRDRERSYSPPRRGGGSSPDRDTMVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
      "product": "hypothetical protein"
     },
     {
      "start": 6228,
      "end": 8909,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001266",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001266</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001266</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001266-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,228 - 8,909,\n (total: 2682 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001266 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [631:761](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [784:819](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001266 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001266\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001266-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAACCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTGATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGACCAGGTGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTCAAGATCGTATTATAGTTACCCCTGCAGACGTGGTTTCGAACGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
      "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLDEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRPGDASGRKLTPVHLLTGQDRIIVTPADVVSNEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
      "product": "hypothetical protein"
     },
     {
      "start": 8929,
      "end": 10419,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001267",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001267</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001267</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001267-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,929 - 10,419,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001267\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGGTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
      "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILGFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
      "product": "hypothetical protein"
     },
     {
      "start": 10691,
      "end": 14758,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001268",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001268</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001268</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001268-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,691 - 14,758,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.4; E-value: 1.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.9, e-value: 1.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1899.2, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001268\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001268-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAACCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAGGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACGATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
      "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
      "product": "hypothetical protein"
     },
     {
      "start": 14772,
      "end": 15355,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001269",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001269</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001269</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001269-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,772 - 15,355,\n (total: 546 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [0:39](score: 33.5, e-value: 3.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001269 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001269\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001269-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
      "translation": "MTHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 10690,
      "end": 14758,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 15641,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r106c1"
   }
  ]
 },
 {
  "length": 15561,
  "seq_id": "scaffold_107",
  "regions": []
 },
 {
  "length": 15536,
  "seq_id": "scaffold_108",
  "regions": []
 },
 {
  "length": 15464,
  "seq_id": "scaffold_109",
  "regions": []
 },
 {
  "length": 15433,
  "seq_id": "scaffold_110",
  "regions": []
 },
 {
  "length": 15417,
  "seq_id": "scaffold_111",
  "regions": []
 },
 {
  "length": 15338,
  "seq_id": "scaffold_112",
  "regions": []
 },
 {
  "length": 15293,
  "seq_id": "scaffold_113",
  "regions": []
 },
 {
  "length": 15276,
  "seq_id": "scaffold_114",
  "regions": []
 },
 {
  "length": 15137,
  "seq_id": "scaffold_115",
  "regions": []
 },
 {
  "length": 15124,
  "seq_id": "scaffold_116",
  "regions": []
 },
 {
  "length": 15066,
  "seq_id": "scaffold_117",
  "regions": []
 },
 {
  "length": 15058,
  "seq_id": "scaffold_118",
  "regions": []
 },
 {
  "length": 14993,
  "seq_id": "scaffold_119",
  "regions": []
 },
 {
  "length": 14855,
  "seq_id": "scaffold_120",
  "regions": []
 },
 {
  "length": 14772,
  "seq_id": "scaffold_121",
  "regions": []
 },
 {
  "length": 14763,
  "seq_id": "scaffold_122",
  "regions": []
 },
 {
  "length": 14739,
  "seq_id": "scaffold_123",
  "regions": []
 },
 {
  "length": 14685,
  "seq_id": "scaffold_124",
  "regions": []
 },
 {
  "length": 14664,
  "seq_id": "scaffold_125",
  "regions": []
 },
 {
  "length": 14656,
  "seq_id": "scaffold_126",
  "regions": []
 },
 {
  "length": 14591,
  "seq_id": "scaffold_127",
  "regions": []
 },
 {
  "length": 14520,
  "seq_id": "scaffold_128",
  "regions": []
 },
 {
  "length": 14502,
  "seq_id": "scaffold_129",
  "regions": []
 },
 {
  "length": 14500,
  "seq_id": "scaffold_130",
  "regions": []
 },
 {
  "length": 14418,
  "seq_id": "scaffold_131",
  "regions": []
 },
 {
  "length": 14342,
  "seq_id": "scaffold_132",
  "regions": []
 },
 {
  "length": 14309,
  "seq_id": "scaffold_133",
  "regions": []
 },
 {
  "length": 14282,
  "seq_id": "scaffold_134",
  "regions": []
 },
 {
  "length": 14124,
  "seq_id": "scaffold_135",
  "regions": []
 },
 {
  "length": 14121,
  "seq_id": "scaffold_136",
  "regions": []
 },
 {
  "length": 14111,
  "seq_id": "scaffold_137",
  "regions": []
 },
 {
  "length": 14086,
  "seq_id": "scaffold_138",
  "regions": []
 },
 {
  "length": 14047,
  "seq_id": "scaffold_139",
  "regions": []
 },
 {
  "length": 13993,
  "seq_id": "scaffold_140",
  "regions": []
 },
 {
  "length": 13993,
  "seq_id": "scaffold_141",
  "regions": []
 },
 {
  "length": 13933,
  "seq_id": "scaffold_142",
  "regions": []
 },
 {
  "length": 13927,
  "seq_id": "scaffold_143",
  "regions": []
 },
 {
  "length": 13884,
  "seq_id": "scaffold_144",
  "regions": []
 },
 {
  "length": 13882,
  "seq_id": "scaffold_145",
  "regions": []
 },
 {
  "length": 13876,
  "seq_id": "scaffold_146",
  "regions": []
 },
 {
  "length": 13866,
  "seq_id": "scaffold_147",
  "regions": []
 },
 {
  "length": 13822,
  "seq_id": "scaffold_148",
  "regions": []
 },
 {
  "length": 13769,
  "seq_id": "scaffold_149",
  "regions": []
 },
 {
  "length": 13707,
  "seq_id": "scaffold_150",
  "regions": []
 },
 {
  "length": 13624,
  "seq_id": "scaffold_151",
  "regions": []
 },
 {
  "length": 13615,
  "seq_id": "scaffold_152",
  "regions": []
 },
 {
  "length": 13549,
  "seq_id": "scaffold_153",
  "regions": []
 },
 {
  "length": 13505,
  "seq_id": "scaffold_154",
  "regions": []
 },
 {
  "length": 13465,
  "seq_id": "scaffold_155",
  "regions": []
 },
 {
  "length": 13443,
  "seq_id": "scaffold_156",
  "regions": []
 },
 {
  "length": 13394,
  "seq_id": "scaffold_157",
  "regions": []
 },
 {
  "length": 13377,
  "seq_id": "scaffold_158",
  "regions": []
 },
 {
  "length": 13325,
  "seq_id": "scaffold_159",
  "regions": []
 },
 {
  "length": 13230,
  "seq_id": "scaffold_160",
  "regions": []
 },
 {
  "length": 13161,
  "seq_id": "scaffold_161",
  "regions": []
 },
 {
  "length": 13159,
  "seq_id": "scaffold_162",
  "regions": []
 },
 {
  "length": 13019,
  "seq_id": "scaffold_163",
  "regions": []
 },
 {
  "length": 12939,
  "seq_id": "scaffold_164",
  "regions": []
 },
 {
  "length": 12894,
  "seq_id": "scaffold_165",
  "regions": []
 },
 {
  "length": 12823,
  "seq_id": "scaffold_166",
  "regions": []
 },
 {
  "length": 12768,
  "seq_id": "scaffold_167",
  "regions": []
 },
 {
  "length": 12749,
  "seq_id": "scaffold_168",
  "regions": []
 },
 {
  "length": 12652,
  "seq_id": "scaffold_169",
  "regions": []
 },
 {
  "length": 12593,
  "seq_id": "scaffold_170",
  "regions": []
 },
 {
  "length": 12586,
  "seq_id": "scaffold_171",
  "regions": []
 },
 {
  "length": 12511,
  "seq_id": "scaffold_172",
  "regions": []
 },
 {
  "length": 12381,
  "seq_id": "scaffold_173",
  "regions": []
 },
 {
  "length": 12377,
  "seq_id": "scaffold_174",
  "regions": []
 },
 {
  "length": 12374,
  "seq_id": "scaffold_175",
  "regions": []
 },
 {
  "length": 12356,
  "seq_id": "scaffold_176",
  "regions": [
   {
    "start": 1,
    "end": 12356,
    "idx": 1,
    "orfs": [
     {
      "start": 146,
      "end": 1933,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001801",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001801</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001801</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001801-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 146 - 1,933,\n (total: 1524 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001801 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [114:140](score: 22.3, e-value: 0.00011)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [142:182](score: 41.8, e-value: 7.4e-11)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [184:223](score: 30.3, e-value: 3.1e-07)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [224:264](score: 49.4, e-value: 3.2e-13)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [279:308](score: 23.6, e-value: 4.1e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [313:348](score: 23.4, e-value: 4.9e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [354:391](score: 31.8, e-value: 1.1e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001801 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00514.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001801\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGAAATTGTTGCAGCTGCTGCAGTTGCTGCGGAGGTATCCTTCTATCTGGATTTTGGGCTTACGTGGAAGGTGACTCCCAGGATGCAGGATACGACCCCATCCTTGCTGAGAGCGAAAGAGAAGCTGTCGCAGACCTTCTCCAGTACCTTGAAAATCGGAATGAGGTGGATTTCTTCAGCAGAGGACCGTTGGGAGCGCTGAGTACACTCGTGTATTCTGATAACGTCGATCTGCAGAGAAGCGCGGCCTTGGCTTTCGCTGAAATCACAGAAAAGGGTACGCATGCATATGACATTCTATCTAACGACCCAGATGTACGGGAGGTCGACCGAGACACGTTGGAACCTATTTTGTCTTTATTGCAGAGCCAGGATATTGAGGTTCAACGTGCTGCCAGCGCGGCTCTTGGGAACCTCGGCGTAAACAACGAAAACAAAGTAGCCATTGTCAAACTCGGAGGATTGGATCCTTTGATCAAGCAAATGATGTCATCAAATGTAGAAGTTCAATGTAATGCTGTGGGGTGTATCACAAACCTGGCGACGCATGACGAGAACAAATCGAAAATCGCGCGTTCTGGGGCACTTGTACCCCTTACTAGACTAGCCAAGTCAAGGGACCTGCGCGTTCAACGAAATGCTACAGGAGCTCTATTGAATATGACTCATTCCGATGAAAACAGGCAGCAGCTTGTCAATGCCGGCGCAATACCAGTGCTCGTCCACCTCTTAACTTCTCAAGACTCTGATGTCCAATACTACTGCACTACTGCGCTAAGCAACATCGCAGTTGACGCTTCGAACCGCAAGAAACTGGCAAATTCCGAGCCTAGGTTGGTGCAAGCGCTCATCGCTTTGATGGAGTCATCTAGCCCAAAAGTGCAATGCCAATCAGCTCTGGCGCTGCGCAATCTCGCGTCGGACGAGAAATATCAACTCGATATTGTGCGGTCTAATGGGTTGCCTGCTCTCTTACGTTTATTACAATCTTCCTTCCTAGCTCTGATACTTTCAGCAGTCGCTTGTATACGCAATATCTCTATTCACCCGCTAAACGAGTCGCCTATCATTGATGCTGGTTTCCTAAGGCCTTTGGTCGAACTTCTTGGTTCGACGGATAATGAAGAGATTCAATGTCATGCCATCTCCACCTTACGGAATCTAGCGGCAAGCTCAGAACGAAATAAAAAAGCCATTGTTGAAGCGGGAGCAATTCAGAAATTGAGCGACTACACACCTCTCTTGAATGCATGGAAGGAACCAGACGGAGGTTTCAAAGGCTACCTAGAGCACTTTCTCTCTAGTGGTGATGGTGCGTTTCAGCACATTGCCACATGGACCGTCCTACAGCTCCTGGAAGCTGACGAGCCGGATGTCAAAGCCCTGATTGTGGAAAGTCCGGAAATTGTGCGGGCGATTCGTCAGACGGCTGAGCGAGAACCGCAAACTGATGACGATCCCGAAGGAGAAGGCGAAATTGTGCCTCTTGTCAGGCGGGTTGTGGAACTAATCGACCAGTGA",
      "translation": "MGNCCSCCSCCGGILLSGFWAYVEGDSQDAGYDPILAESEREAVADLLQYLENRNEVDFFSRGPLGALSTLVYSDNVDLQRSAALAFAEITEKGTHAYDILSNDPDVREVDRDTLEPILSLLQSQDIEVQRAASAALGNLGVNNENKVAIVKLGGLDPLIKQMMSSNVEVQCNAVGCITNLATHDENKSKIARSGALVPLTRLAKSRDLRVQRNATGALLNMTHSDENRQQLVNAGAIPVLVHLLTSQDSDVQYYCTTALSNIAVDASNRKKLANSEPRLVQALIALMESSSPKVQCQSALALRNLASDEKYQLDIVRSNGLPALLRLLQSSFLALILSAVACIRNISIHPLNESPIIDAGFLRPLVELLGSTDNEEIQCHAISTLRNLAASSERNKKAIVEAGAIQKLSDYTPLLNAWKEPDGGFKGYLEHFLSSGDGAFQHIATWTVLQLLEADEPDVKALIVESPEIVRAIRQTAEREPQTDDDPEGEGEIVPLVRRVVELIDQ",
      "product": "hypothetical protein"
     },
     {
      "start": 2024,
      "end": 3328,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001802",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001802</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001802</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001802-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,024 - 3,328,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325.2; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001802 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.3, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001802 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001802\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001802-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGCAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCGTGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
      "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTAEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVVAMDKEQVKRKRKLRAG",
      "product": "hypothetical protein"
     },
     {
      "start": 4101,
      "end": 4541,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001803",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001803</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001803</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001803-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,101 - 4,541,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001803\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
      "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
      "product": "hypothetical protein"
     },
     {
      "start": 4596,
      "end": 5618,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001804",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001804</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001804</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001804-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,596 - 5,618,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001804 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001804\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
      "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
      "product": "hypothetical protein"
     },
     {
      "start": 6145,
      "end": 6846,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001805",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001805</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001805</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001805-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,145 - 6,846,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001805 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001805\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
      "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
      "product": "hypothetical protein"
     },
     {
      "start": 6888,
      "end": 7937,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001806",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001806</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001806</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001806-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,888 - 7,937,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001806 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 207.4, e-value: 2.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001806\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTCGGGAAGCGCGGCCGCTCCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
      "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRSKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
      "product": "hypothetical protein"
     },
     {
      "start": 8539,
      "end": 9063,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001807",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001807</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001807</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001807-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,539 - 9,063,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001807 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001807 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001807\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
      "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
      "product": "hypothetical protein"
     },
     {
      "start": 9428,
      "end": 10356,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001808",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001808</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001808</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001808-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,428 - 10,356,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001808 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001808 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001808\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
      "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
      "product": "hypothetical protein"
     },
     {
      "start": 10410,
      "end": 11351,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001809",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001809</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001809</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001809-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,410 - 11,351,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001809 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001809\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
      "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
      "product": "hypothetical protein"
     },
     {
      "start": 11421,
      "end": 12288,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001810",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001810</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001810</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001810-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,421 - 12,288,\n (total: 868 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:251](score: 198.3, e-value: 1e-58)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 53.6, e-value: 5.1e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001810\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001810-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCCCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGA",
      "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQ",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 9427,
      "end": 10356,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 12356,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r176c1"
   }
  ]
 },
 {
  "length": 12350,
  "seq_id": "scaffold_177",
  "regions": []
 },
 {
  "length": 12256,
  "seq_id": "scaffold_178",
  "regions": []
 },
 {
  "length": 12220,
  "seq_id": "scaffold_179",
  "regions": []
 },
 {
  "length": 12206,
  "seq_id": "scaffold_180",
  "regions": []
 },
 {
  "length": 12202,
  "seq_id": "scaffold_181",
  "regions": [
   {
    "start": 1,
    "end": 12202,
    "idx": 1,
    "orfs": [
     {
      "start": 1534,
      "end": 2052,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001837",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001837</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001837</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001837-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,534 - 2,052,\n (total: 519 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001837\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTCAGCGAATTGCAGCAAAGTGGACTATCAGAAATGACCCAATTAGTGGATCTGCCCTCTTTCGAACTCAAAACACATGAGAATGTGCAAGCATGTGAAATGGCAACAGCGTACTTCTTGGCTTGTATATCTATACGGAGAATCATGAACCGTGTACATGGCCTGCTCTATCAAGACGACAGCAGTAGAGAGCAAAATATGACGGCCATCGTGCAAGAACTCGACCATCAGCTCGAAGAATGGTACGAACTGCTTCCTCCGCACATGCAATTTCGAAGAGGTCTCGGACCTTGTCAGAATGACTTGCAAGCCCATCTTAGTCAACGTCACAATGCCTGTAAGTCTACGCTCTTTCGATTCATCCTCCAACAAACTATCCAATTTGATCATGACTTTACAGATGGATATGTGCGGGAAGCTTGCAAAAGCTGCCTTGATGCGTGTTGTTTGCACATATTGAACGTAGATCTATGGCCTCAGGTCGTCTTTGTGGATGTTTGGATTTGTGCATTAGCGTGA",
      "translation": "MSELQQSGLSEMTQLVDLPSFELKTHENVQACEMATAYFLACISIRRIMNRVHGLLYQDDSSREQNMTAIVQELDHQLEEWYELLPPHMQFRRGLGPCQNDLQAHLSQRHNACKSTLFRFILQQTIQFDHDFTDGYVREACKSCLDACCLHILNVDLWPQVVFVDVWICALA",
      "product": "hypothetical protein"
     },
     {
      "start": 2455,
      "end": 3744,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001838",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001838</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001838</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001838-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,455 - 3,744,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1100:3-hydroxyisobutyrate dehydrogenase (Score: 206.6; E-value: 9.1e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001838 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [7:104](score: 45.7, e-value: 7.3e-12)<br>\n \n  PF03446.18 (NAD binding domain of 6-phosphogluconate dehydrogenase): [133:287](score: 117.6, e-value: 6.2e-34)<br>\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [299:420](score: 92.5, e-value: 2.3e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001838 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03446.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding<br>\n  \n   PF14833.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001838\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001838-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAACAGACTGAGAAACATCTCAGGGCCCTCCACTTGGCAACAGCGTTTGAAGCCATTGCACTTGGAACTGCTTCAGGGCTGAATGGCTCCCAACTGTACACTATCTTTTCCACATCCGCTGCGCAGTCATGGACGTTCAACTACGTCATTCCGAATCTATTAAGTGGGAAAGCTTTACCCTTTGATGTAGATGAAGCTCTAGACGATATTCAGGAAATACTAAAGCAAGCGAATGAATGTGGATTCTTCAGTCCAATGACTAGCGTAGTTGAACAATATCTTTTATCGGTCAAAGCATCTGGGGGCGTTCACAAGTACTATGAGACACTTGGCGTCTCTTCTTTGAAACAGAAGAATTTTACTCCCTCTCGACTCCCTTCATCTTCCAGAAAACCGACCGTTGGATTTGTTGGCCTTGGAGCTATGGGTCTGGGTATGGCTAGTATTCTATATAAAGCAGGGTTTGCTGTCAAAGGATTCGATGTGTTTCCGCAAAGTGTTGAAAAGTTCGTGACTGTGGGAGGACAAAGGGCTGCTTCTGCTGCTGAAGCGGCCATTGGAGTTGAAGTACTGTTGATCATGTGCGCTACTTCTGCACAAGCTGACACTATTCTTTTCGGGGAAGATGGAGCTGCCTCCAAAATGAGTAAAGGAGCGGTTGTTCTCCTCTGTGCAACTGTCGCACCATCATATATAACAGAATTAAATCAGAAGCTCGCCCGCAGTGCCATTAAGCTAGTGGACGCGCCTGTCTCGGGCGGTACTTATCGCGCCGCCAGTGGCGAGCTTTCCATTATGTGCTCCGGCGATACGGAAACGCTACAAATTGTTTCCCCCGTACTAAATGCATTAGCCGGCAAAGAAGAGAATGTCTACGTTATTGAAGGCAAAGTAGGGTCTGGTTGCAAAGTCAAAATGGTGAATCAAGTTCTTGCTGGTACACAATGTGTCTGCACCGCGGAAGCACTTGCCTTTTCAGTGGCTAGGGGACTGGTTGCAATGGACGTATATGAATGGATTTCATCGTCTCGTGGAGCTTCATGGATGTGGTCAAATCGAGGTCATCATATGGTAACTGGAGACTTTTCCCCATTATCGGCTACAACTATCTTCATCAAAGACATGAACATTGTTGTCTCAGAAGCAAGAAGGCTTGGGCTGCCATCGGTTTGCTCTTCCATGGCACAGCAGTTATTTATTCTGTCCGCCGCAGCTGGACATTCAAAAGATGACGATTCAAGTGTTGTAAAAGTATGGGAAAAAGCATGTGGAATTAAGACCTACTAA",
      "translation": "MEQTEKHLRALHLATAFEAIALGTASGLNGSQLYTIFSTSAAQSWTFNYVIPNLLSGKALPFDVDEALDDIQEILKQANECGFFSPMTSVVEQYLLSVKASGGVHKYYETLGVSSLKQKNFTPSRLPSSSRKPTVGFVGLGAMGLGMASILYKAGFAVKGFDVFPQSVEKFVTVGGQRAASAAEAAIGVEVLLIMCATSAQADTILFGEDGAASKMSKGAVVLLCATVAPSYITELNQKLARSAIKLVDAPVSGGTYRAASGELSIMCSGDTETLQIVSPVLNALAGKEENVYVIEGKVGSGCKVKMVNQVLAGTQCVCTAEALAFSVARGLVAMDVYEWISSSRGASWMWSNRGHHMVTGDFSPLSATTIFIKDMNIVVSEARRLGLPSVCSSMAQQLFILSAAAGHSKDDDSSVVKVWEKACGIKTY",
      "product": "hypothetical protein"
     },
     {
      "start": 4008,
      "end": 5471,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001839",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001839</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001839</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001839-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,008 - 5,471,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001839 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001839 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001839\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001839-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
      "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
      "product": "hypothetical protein"
     },
     {
      "start": 5649,
      "end": 8699,
      "strand": 1,
      "locus_tag": "MARS19BIN38_001840",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001840</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001840</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001840-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,649 - 8,699,\n (total: 3051 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.3; E-value: 4e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001840 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 125.8, e-value: 1.8e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 31.7, e-value: 1.5e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.6, e-value: 6.5e-42)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001840 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [654:1015](score: 213.5, e-value: 1.2e-63)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001840\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001840-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGAAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGTGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGTACCCAAAGAGTGCAGCAGGACTCAAAAACATTCAGGCAAATTGCTGCTATTGATGGATCATTAGTCGGAAAGTTTGTGTCTGCATGGAAGGAGGTGGGGTTTTTGTCATGA",
      "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSVSEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
      "product": "hypothetical protein"
     },
     {
      "start": 8704,
      "end": 10566,
      "strand": -1,
      "locus_tag": "MARS19BIN38_001841",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001841</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001841</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001841-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,704 - 10,566,\n (total: 1863 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001841 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00172.21 (Fungal Zn(2)-Cys(6) binuclear cluster domain): [13:45](score: 37.8, e-value: 1.6e-09)<br>\n \n  PF04082.21 (Fungal specific transcription factor domain): [159:385](score: 91.6, e-value: 4.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001841 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001841\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001841-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "AAGCCTCGCTTATGCGAAGATGCGAGGGTGCGGGTAACCCGTGCGTGTGATGCGTGCAAGAGGAAGAAAGTGCGCTGTGACGGGACAGCACCGTGCGGCAGGTGTATCAGCCATAATGTCGTTTGCCGGTACGAAGCACCATACCTGCGTCGGAAGCAGTCTCACATCAGCACGGAGGTGGAGAAGCGCGAAGATGATGAGTCTATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGATACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTAATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
      "translation": "MPRLCEDARVRVTRACDACKRKKVRCDGTAPCGRCISHNVVCRYEAPYLRRKQSHISTEVEKREDDESMQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 5648,
      "end": 8699,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 12202,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r181c1"
   }
  ]
 },
 {
  "length": 12165,
  "seq_id": "scaffold_182",
  "regions": []
 },
 {
  "length": 12124,
  "seq_id": "scaffold_183",
  "regions": []
 },
 {
  "length": 12107,
  "seq_id": "scaffold_184",
  "regions": []
 },
 {
  "length": 12097,
  "seq_id": "scaffold_185",
  "regions": []
 },
 {
  "length": 12075,
  "seq_id": "scaffold_186",
  "regions": []
 },
 {
  "length": 12063,
  "seq_id": "scaffold_187",
  "regions": []
 },
 {
  "length": 12038,
  "seq_id": "scaffold_188",
  "regions": []
 },
 {
  "length": 12017,
  "seq_id": "scaffold_189",
  "regions": []
 },
 {
  "length": 11998,
  "seq_id": "scaffold_190",
  "regions": []
 },
 {
  "length": 11992,
  "seq_id": "scaffold_191",
  "regions": []
 },
 {
  "length": 11937,
  "seq_id": "scaffold_192",
  "regions": []
 },
 {
  "length": 11853,
  "seq_id": "scaffold_193",
  "regions": []
 },
 {
  "length": 11839,
  "seq_id": "scaffold_194",
  "regions": []
 },
 {
  "length": 11707,
  "seq_id": "scaffold_195",
  "regions": []
 },
 {
  "length": 11672,
  "seq_id": "scaffold_196",
  "regions": []
 },
 {
  "length": 11656,
  "seq_id": "scaffold_197",
  "regions": []
 },
 {
  "length": 11646,
  "seq_id": "scaffold_198",
  "regions": []
 },
 {
  "length": 11638,
  "seq_id": "scaffold_199",
  "regions": []
 },
 {
  "length": 11622,
  "seq_id": "scaffold_200",
  "regions": []
 },
 {
  "length": 11535,
  "seq_id": "scaffold_201",
  "regions": []
 },
 {
  "length": 11532,
  "seq_id": "scaffold_202",
  "regions": []
 },
 {
  "length": 11531,
  "seq_id": "scaffold_203",
  "regions": []
 },
 {
  "length": 11519,
  "seq_id": "scaffold_204",
  "regions": []
 },
 {
  "length": 11512,
  "seq_id": "scaffold_205",
  "regions": []
 },
 {
  "length": 11459,
  "seq_id": "scaffold_206",
  "regions": []
 },
 {
  "length": 11421,
  "seq_id": "scaffold_207",
  "regions": []
 },
 {
  "length": 11397,
  "seq_id": "scaffold_208",
  "regions": []
 },
 {
  "length": 11387,
  "seq_id": "scaffold_209",
  "regions": []
 },
 {
  "length": 11370,
  "seq_id": "scaffold_210",
  "regions": []
 },
 {
  "length": 11349,
  "seq_id": "scaffold_211",
  "regions": []
 },
 {
  "length": 11342,
  "seq_id": "scaffold_212",
  "regions": []
 },
 {
  "length": 11342,
  "seq_id": "scaffold_213",
  "regions": []
 },
 {
  "length": 11288,
  "seq_id": "scaffold_214",
  "regions": []
 },
 {
  "length": 11174,
  "seq_id": "scaffold_215",
  "regions": []
 },
 {
  "length": 11148,
  "seq_id": "scaffold_216",
  "regions": []
 },
 {
  "length": 11140,
  "seq_id": "scaffold_217",
  "regions": []
 },
 {
  "length": 11108,
  "seq_id": "scaffold_218",
  "regions": []
 },
 {
  "length": 11078,
  "seq_id": "scaffold_219",
  "regions": []
 },
 {
  "length": 11068,
  "seq_id": "scaffold_220",
  "regions": []
 },
 {
  "length": 11046,
  "seq_id": "scaffold_221",
  "regions": []
 },
 {
  "length": 11042,
  "seq_id": "scaffold_222",
  "regions": []
 },
 {
  "length": 11039,
  "seq_id": "scaffold_223",
  "regions": []
 },
 {
  "length": 11027,
  "seq_id": "scaffold_224",
  "regions": []
 },
 {
  "length": 11002,
  "seq_id": "scaffold_225",
  "regions": []
 },
 {
  "length": 10997,
  "seq_id": "scaffold_226",
  "regions": []
 },
 {
  "length": 10982,
  "seq_id": "scaffold_227",
  "regions": []
 },
 {
  "length": 10887,
  "seq_id": "scaffold_228",
  "regions": []
 },
 {
  "length": 10870,
  "seq_id": "scaffold_229",
  "regions": []
 },
 {
  "length": 10868,
  "seq_id": "scaffold_230",
  "regions": []
 },
 {
  "length": 10858,
  "seq_id": "scaffold_231",
  "regions": []
 },
 {
  "length": 10849,
  "seq_id": "scaffold_232",
  "regions": []
 },
 {
  "length": 10833,
  "seq_id": "scaffold_233",
  "regions": []
 },
 {
  "length": 10819,
  "seq_id": "scaffold_234",
  "regions": []
 },
 {
  "length": 10817,
  "seq_id": "scaffold_235",
  "regions": []
 },
 {
  "length": 10816,
  "seq_id": "scaffold_236",
  "regions": []
 },
 {
  "length": 10816,
  "seq_id": "scaffold_237",
  "regions": []
 },
 {
  "length": 10771,
  "seq_id": "scaffold_238",
  "regions": []
 },
 {
  "length": 10733,
  "seq_id": "scaffold_239",
  "regions": []
 },
 {
  "length": 10713,
  "seq_id": "scaffold_240",
  "regions": []
 },
 {
  "length": 10705,
  "seq_id": "scaffold_241",
  "regions": []
 },
 {
  "length": 10696,
  "seq_id": "scaffold_242",
  "regions": []
 },
 {
  "length": 10680,
  "seq_id": "scaffold_243",
  "regions": []
 },
 {
  "length": 10657,
  "seq_id": "scaffold_244",
  "regions": []
 },
 {
  "length": 10641,
  "seq_id": "scaffold_245",
  "regions": []
 },
 {
  "length": 10622,
  "seq_id": "scaffold_246",
  "regions": []
 },
 {
  "length": 10620,
  "seq_id": "scaffold_247",
  "regions": []
 },
 {
  "length": 10604,
  "seq_id": "scaffold_248",
  "regions": []
 },
 {
  "length": 10594,
  "seq_id": "scaffold_249",
  "regions": []
 },
 {
  "length": 10573,
  "seq_id": "scaffold_250",
  "regions": []
 },
 {
  "length": 10542,
  "seq_id": "scaffold_251",
  "regions": []
 },
 {
  "length": 10541,
  "seq_id": "scaffold_252",
  "regions": []
 },
 {
  "length": 10518,
  "seq_id": "scaffold_253",
  "regions": []
 },
 {
  "length": 10508,
  "seq_id": "scaffold_254",
  "regions": []
 },
 {
  "length": 10489,
  "seq_id": "scaffold_255",
  "regions": []
 },
 {
  "length": 10434,
  "seq_id": "scaffold_256",
  "regions": []
 },
 {
  "length": 10422,
  "seq_id": "scaffold_257",
  "regions": []
 },
 {
  "length": 10364,
  "seq_id": "scaffold_258",
  "regions": []
 },
 {
  "length": 10361,
  "seq_id": "scaffold_259",
  "regions": []
 },
 {
  "length": 10328,
  "seq_id": "scaffold_260",
  "regions": []
 },
 {
  "length": 10320,
  "seq_id": "scaffold_261",
  "regions": []
 },
 {
  "length": 10315,
  "seq_id": "scaffold_262",
  "regions": []
 },
 {
  "length": 10303,
  "seq_id": "scaffold_263",
  "regions": []
 },
 {
  "length": 10296,
  "seq_id": "scaffold_264",
  "regions": []
 },
 {
  "length": 10290,
  "seq_id": "scaffold_265",
  "regions": []
 },
 {
  "length": 10233,
  "seq_id": "scaffold_266",
  "regions": []
 },
 {
  "length": 10223,
  "seq_id": "scaffold_267",
  "regions": []
 },
 {
  "length": 10214,
  "seq_id": "scaffold_268",
  "regions": []
 },
 {
  "length": 10178,
  "seq_id": "scaffold_269",
  "regions": []
 },
 {
  "length": 10168,
  "seq_id": "scaffold_270",
  "regions": []
 },
 {
  "length": 10160,
  "seq_id": "scaffold_271",
  "regions": []
 },
 {
  "length": 10158,
  "seq_id": "scaffold_272",
  "regions": []
 },
 {
  "length": 10154,
  "seq_id": "scaffold_273",
  "regions": []
 },
 {
  "length": 10151,
  "seq_id": "scaffold_274",
  "regions": []
 },
 {
  "length": 10031,
  "seq_id": "scaffold_275",
  "regions": []
 },
 {
  "length": 10027,
  "seq_id": "scaffold_276",
  "regions": []
 },
 {
  "length": 10000,
  "seq_id": "scaffold_277",
  "regions": []
 },
 {
  "length": 9998,
  "seq_id": "scaffold_278",
  "regions": []
 },
 {
  "length": 9977,
  "seq_id": "scaffold_279",
  "regions": []
 },
 {
  "length": 9950,
  "seq_id": "scaffold_280",
  "regions": []
 },
 {
  "length": 9911,
  "seq_id": "scaffold_281",
  "regions": []
 },
 {
  "length": 9906,
  "seq_id": "scaffold_282",
  "regions": []
 },
 {
  "length": 9894,
  "seq_id": "scaffold_283",
  "regions": []
 },
 {
  "length": 9884,
  "seq_id": "scaffold_284",
  "regions": []
 },
 {
  "length": 9854,
  "seq_id": "scaffold_285",
  "regions": []
 },
 {
  "length": 9850,
  "seq_id": "scaffold_286",
  "regions": []
 },
 {
  "length": 9814,
  "seq_id": "scaffold_287",
  "regions": []
 },
 {
  "length": 9755,
  "seq_id": "scaffold_288",
  "regions": []
 },
 {
  "length": 9751,
  "seq_id": "scaffold_289",
  "regions": []
 },
 {
  "length": 9734,
  "seq_id": "scaffold_290",
  "regions": []
 },
 {
  "length": 9714,
  "seq_id": "scaffold_291",
  "regions": []
 },
 {
  "length": 9678,
  "seq_id": "scaffold_292",
  "regions": []
 },
 {
  "length": 9620,
  "seq_id": "scaffold_293",
  "regions": []
 },
 {
  "length": 9610,
  "seq_id": "scaffold_294",
  "regions": []
 },
 {
  "length": 9606,
  "seq_id": "scaffold_295",
  "regions": []
 },
 {
  "length": 9598,
  "seq_id": "scaffold_296",
  "regions": []
 },
 {
  "length": 9577,
  "seq_id": "scaffold_297",
  "regions": []
 },
 {
  "length": 9572,
  "seq_id": "scaffold_298",
  "regions": []
 },
 {
  "length": 9555,
  "seq_id": "scaffold_299",
  "regions": []
 },
 {
  "length": 9538,
  "seq_id": "scaffold_300",
  "regions": []
 },
 {
  "length": 9534,
  "seq_id": "scaffold_301",
  "regions": []
 },
 {
  "length": 9486,
  "seq_id": "scaffold_302",
  "regions": []
 },
 {
  "length": 9472,
  "seq_id": "scaffold_303",
  "regions": []
 },
 {
  "length": 9457,
  "seq_id": "scaffold_304",
  "regions": []
 },
 {
  "length": 9448,
  "seq_id": "scaffold_305",
  "regions": []
 },
 {
  "length": 9441,
  "seq_id": "scaffold_306",
  "regions": []
 },
 {
  "length": 9430,
  "seq_id": "scaffold_307",
  "regions": []
 },
 {
  "length": 9372,
  "seq_id": "scaffold_308",
  "regions": []
 },
 {
  "length": 9319,
  "seq_id": "scaffold_309",
  "regions": []
 },
 {
  "length": 9287,
  "seq_id": "scaffold_310",
  "regions": []
 },
 {
  "length": 9277,
  "seq_id": "scaffold_311",
  "regions": []
 },
 {
  "length": 9274,
  "seq_id": "scaffold_312",
  "regions": []
 },
 {
  "length": 9272,
  "seq_id": "scaffold_313",
  "regions": []
 },
 {
  "length": 9246,
  "seq_id": "scaffold_314",
  "regions": []
 },
 {
  "length": 9203,
  "seq_id": "scaffold_315",
  "regions": []
 },
 {
  "length": 9187,
  "seq_id": "scaffold_316",
  "regions": []
 },
 {
  "length": 9134,
  "seq_id": "scaffold_317",
  "regions": []
 },
 {
  "length": 9074,
  "seq_id": "scaffold_318",
  "regions": []
 },
 {
  "length": 9049,
  "seq_id": "scaffold_319",
  "regions": []
 },
 {
  "length": 9026,
  "seq_id": "scaffold_320",
  "regions": []
 },
 {
  "length": 8995,
  "seq_id": "scaffold_321",
  "regions": []
 },
 {
  "length": 8987,
  "seq_id": "scaffold_322",
  "regions": []
 },
 {
  "length": 8980,
  "seq_id": "scaffold_323",
  "regions": []
 },
 {
  "length": 8965,
  "seq_id": "scaffold_324",
  "regions": []
 },
 {
  "length": 8963,
  "seq_id": "scaffold_325",
  "regions": []
 },
 {
  "length": 8949,
  "seq_id": "scaffold_326",
  "regions": []
 },
 {
  "length": 8940,
  "seq_id": "scaffold_327",
  "regions": []
 },
 {
  "length": 8929,
  "seq_id": "scaffold_328",
  "regions": []
 },
 {
  "length": 8925,
  "seq_id": "scaffold_329",
  "regions": []
 },
 {
  "length": 8923,
  "seq_id": "scaffold_330",
  "regions": []
 },
 {
  "length": 8870,
  "seq_id": "scaffold_331",
  "regions": []
 },
 {
  "length": 8852,
  "seq_id": "scaffold_332",
  "regions": []
 },
 {
  "length": 8846,
  "seq_id": "scaffold_333",
  "regions": []
 },
 {
  "length": 8846,
  "seq_id": "scaffold_334",
  "regions": []
 },
 {
  "length": 8820,
  "seq_id": "scaffold_335",
  "regions": []
 },
 {
  "length": 8719,
  "seq_id": "scaffold_336",
  "regions": []
 },
 {
  "length": 8699,
  "seq_id": "scaffold_337",
  "regions": []
 },
 {
  "length": 8629,
  "seq_id": "scaffold_338",
  "regions": []
 },
 {
  "length": 8621,
  "seq_id": "scaffold_339",
  "regions": []
 },
 {
  "length": 8609,
  "seq_id": "scaffold_340",
  "regions": []
 },
 {
  "length": 8597,
  "seq_id": "scaffold_341",
  "regions": []
 },
 {
  "length": 8582,
  "seq_id": "scaffold_342",
  "regions": []
 },
 {
  "length": 8576,
  "seq_id": "scaffold_343",
  "regions": []
 },
 {
  "length": 8568,
  "seq_id": "scaffold_344",
  "regions": []
 },
 {
  "length": 8539,
  "seq_id": "scaffold_345",
  "regions": []
 },
 {
  "length": 8527,
  "seq_id": "scaffold_346",
  "regions": []
 },
 {
  "length": 8491,
  "seq_id": "scaffold_347",
  "regions": []
 },
 {
  "length": 8489,
  "seq_id": "scaffold_348",
  "regions": []
 },
 {
  "length": 8482,
  "seq_id": "scaffold_349",
  "regions": []
 },
 {
  "length": 8469,
  "seq_id": "scaffold_350",
  "regions": []
 },
 {
  "length": 8410,
  "seq_id": "scaffold_351",
  "regions": []
 },
 {
  "length": 8385,
  "seq_id": "scaffold_352",
  "regions": []
 },
 {
  "length": 8380,
  "seq_id": "scaffold_353",
  "regions": []
 },
 {
  "length": 8373,
  "seq_id": "scaffold_354",
  "regions": []
 },
 {
  "length": 8372,
  "seq_id": "scaffold_355",
  "regions": []
 },
 {
  "length": 8351,
  "seq_id": "scaffold_356",
  "regions": []
 },
 {
  "length": 8334,
  "seq_id": "scaffold_357",
  "regions": []
 },
 {
  "length": 8241,
  "seq_id": "scaffold_358",
  "regions": []
 },
 {
  "length": 8175,
  "seq_id": "scaffold_359",
  "regions": []
 },
 {
  "length": 8166,
  "seq_id": "scaffold_360",
  "regions": []
 },
 {
  "length": 8132,
  "seq_id": "scaffold_361",
  "regions": []
 },
 {
  "length": 8127,
  "seq_id": "scaffold_362",
  "regions": []
 },
 {
  "length": 8086,
  "seq_id": "scaffold_363",
  "regions": []
 },
 {
  "length": 8080,
  "seq_id": "scaffold_364",
  "regions": []
 },
 {
  "length": 8073,
  "seq_id": "scaffold_365",
  "regions": []
 },
 {
  "length": 8010,
  "seq_id": "scaffold_366",
  "regions": []
 },
 {
  "length": 8003,
  "seq_id": "scaffold_367",
  "regions": []
 },
 {
  "length": 7984,
  "seq_id": "scaffold_368",
  "regions": []
 },
 {
  "length": 7955,
  "seq_id": "scaffold_369",
  "regions": []
 },
 {
  "length": 7944,
  "seq_id": "scaffold_370",
  "regions": []
 },
 {
  "length": 7940,
  "seq_id": "scaffold_371",
  "regions": []
 },
 {
  "length": 7932,
  "seq_id": "scaffold_372",
  "regions": []
 },
 {
  "length": 7902,
  "seq_id": "scaffold_373",
  "regions": []
 },
 {
  "length": 7891,
  "seq_id": "scaffold_374",
  "regions": []
 },
 {
  "length": 7865,
  "seq_id": "scaffold_375",
  "regions": []
 },
 {
  "length": 7847,
  "seq_id": "scaffold_376",
  "regions": []
 },
 {
  "length": 7830,
  "seq_id": "scaffold_377",
  "regions": []
 },
 {
  "length": 7812,
  "seq_id": "scaffold_378",
  "regions": []
 },
 {
  "length": 7792,
  "seq_id": "scaffold_379",
  "regions": []
 },
 {
  "length": 7784,
  "seq_id": "scaffold_380",
  "regions": []
 },
 {
  "length": 7783,
  "seq_id": "scaffold_381",
  "regions": []
 },
 {
  "length": 7751,
  "seq_id": "scaffold_382",
  "regions": []
 },
 {
  "length": 7736,
  "seq_id": "scaffold_383",
  "regions": []
 },
 {
  "length": 7706,
  "seq_id": "scaffold_384",
  "regions": []
 },
 {
  "length": 7696,
  "seq_id": "scaffold_385",
  "regions": []
 },
 {
  "length": 7691,
  "seq_id": "scaffold_386",
  "regions": []
 },
 {
  "length": 7676,
  "seq_id": "scaffold_387",
  "regions": []
 },
 {
  "length": 7666,
  "seq_id": "scaffold_388",
  "regions": []
 },
 {
  "length": 7662,
  "seq_id": "scaffold_389",
  "regions": []
 },
 {
  "length": 7636,
  "seq_id": "scaffold_390",
  "regions": []
 },
 {
  "length": 7629,
  "seq_id": "scaffold_391",
  "regions": []
 },
 {
  "length": 7627,
  "seq_id": "scaffold_392",
  "regions": []
 },
 {
  "length": 7603,
  "seq_id": "scaffold_393",
  "regions": []
 },
 {
  "length": 7578,
  "seq_id": "scaffold_394",
  "regions": []
 },
 {
  "length": 7573,
  "seq_id": "scaffold_395",
  "regions": []
 },
 {
  "length": 7563,
  "seq_id": "scaffold_396",
  "regions": []
 },
 {
  "length": 7560,
  "seq_id": "scaffold_397",
  "regions": []
 },
 {
  "length": 7548,
  "seq_id": "scaffold_398",
  "regions": []
 },
 {
  "length": 7541,
  "seq_id": "scaffold_399",
  "regions": []
 },
 {
  "length": 7510,
  "seq_id": "scaffold_400",
  "regions": []
 },
 {
  "length": 7479,
  "seq_id": "scaffold_401",
  "regions": []
 },
 {
  "length": 7451,
  "seq_id": "scaffold_402",
  "regions": []
 },
 {
  "length": 7449,
  "seq_id": "scaffold_403",
  "regions": []
 },
 {
  "length": 7433,
  "seq_id": "scaffold_404",
  "regions": []
 },
 {
  "length": 7403,
  "seq_id": "scaffold_405",
  "regions": []
 },
 {
  "length": 7384,
  "seq_id": "scaffold_406",
  "regions": []
 },
 {
  "length": 7322,
  "seq_id": "scaffold_407",
  "regions": []
 },
 {
  "length": 7316,
  "seq_id": "scaffold_408",
  "regions": []
 },
 {
  "length": 7291,
  "seq_id": "scaffold_409",
  "regions": []
 },
 {
  "length": 7273,
  "seq_id": "scaffold_410",
  "regions": []
 },
 {
  "length": 7262,
  "seq_id": "scaffold_411",
  "regions": []
 },
 {
  "length": 7262,
  "seq_id": "scaffold_412",
  "regions": []
 },
 {
  "length": 7259,
  "seq_id": "scaffold_413",
  "regions": []
 },
 {
  "length": 7256,
  "seq_id": "scaffold_414",
  "regions": []
 },
 {
  "length": 7254,
  "seq_id": "scaffold_415",
  "regions": []
 },
 {
  "length": 7253,
  "seq_id": "scaffold_416",
  "regions": []
 },
 {
  "length": 7253,
  "seq_id": "scaffold_417",
  "regions": []
 },
 {
  "length": 7247,
  "seq_id": "scaffold_418",
  "regions": []
 },
 {
  "length": 7247,
  "seq_id": "scaffold_419",
  "regions": [
   {
    "start": 1,
    "end": 7247,
    "idx": 1,
    "orfs": [
     {
      "start": 130,
      "end": 1434,
      "strand": -1,
      "locus_tag": "MARS19BIN38_003094",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003094</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003094</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003094-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 130 - 1,434,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003094 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003094\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCAGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTTCAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCAATCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCAACAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTGCGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
      "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGSGGSAINPYASGNEIGQGAGGMGQPAAFSGEIRSAPTSHGGSPNTSPPLLSDHAPVIQSTLSPFARDSGMSASSTPTGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLATPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
      "product": "hypothetical protein"
     },
     {
      "start": 1704,
      "end": 2735,
      "strand": -1,
      "locus_tag": "MARS19BIN38_003095",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003095</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003095</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003095-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704 - 2,735,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003095 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [27:235](score: 122.2, e-value: 2.5e-35)<br>\n \n  PF03129.23 (Anticodon binding domain): [255:302](score: 21.1, e-value: 0.00029)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003095 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003095\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCCTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTTCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
      "translation": "MTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSEFISRDLEFGTDRNGDQHPKKKDTK",
      "product": "hypothetical protein"
     },
     {
      "start": 2998,
      "end": 4977,
      "strand": 1,
      "locus_tag": "MARS19BIN38_003096",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003096</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003096</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003096-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,998 - 4,977,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003096 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003096 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003096\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCGTCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTTCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCATGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
      "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
      "product": "hypothetical protein"
     },
     {
      "start": 5816,
      "end": 6996,
      "strand": 1,
      "locus_tag": "MARS19BIN38_003097",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003097</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003097</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003097-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,816 - 6,996,\n (total: 1125 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [1:270](score: 108.6, e-value: 4.1e-31)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [0:312](score: 354.6, e-value: 1.2e-106)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003097\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_003097-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTATAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTAGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTGTATGCATTTTCTCAGAGGCATCTAATTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
      "translation": "MLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACAVCIFSEASNYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 5815,
      "end": 6996,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 7247,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r419c1"
   }
  ]
 },
 {
  "length": 7220,
  "seq_id": "scaffold_420",
  "regions": []
 },
 {
  "length": 7214,
  "seq_id": "scaffold_421",
  "regions": []
 },
 {
  "length": 7204,
  "seq_id": "scaffold_422",
  "regions": []
 },
 {
  "length": 7202,
  "seq_id": "scaffold_423",
  "regions": []
 },
 {
  "length": 7199,
  "seq_id": "scaffold_424",
  "regions": []
 },
 {
  "length": 7198,
  "seq_id": "scaffold_425",
  "regions": []
 },
 {
  "length": 7195,
  "seq_id": "scaffold_426",
  "regions": []
 },
 {
  "length": 7164,
  "seq_id": "scaffold_427",
  "regions": []
 },
 {
  "length": 7159,
  "seq_id": "scaffold_428",
  "regions": []
 },
 {
  "length": 7156,
  "seq_id": "scaffold_429",
  "regions": []
 },
 {
  "length": 7147,
  "seq_id": "scaffold_430",
  "regions": []
 },
 {
  "length": 7132,
  "seq_id": "scaffold_431",
  "regions": []
 },
 {
  "length": 7117,
  "seq_id": "scaffold_432",
  "regions": []
 },
 {
  "length": 7116,
  "seq_id": "scaffold_433",
  "regions": []
 },
 {
  "length": 7111,
  "seq_id": "scaffold_434",
  "regions": []
 },
 {
  "length": 7101,
  "seq_id": "scaffold_435",
  "regions": []
 },
 {
  "length": 7097,
  "seq_id": "scaffold_436",
  "regions": []
 },
 {
  "length": 7073,
  "seq_id": "scaffold_437",
  "regions": []
 },
 {
  "length": 7067,
  "seq_id": "scaffold_438",
  "regions": []
 },
 {
  "length": 7064,
  "seq_id": "scaffold_439",
  "regions": []
 },
 {
  "length": 7049,
  "seq_id": "scaffold_440",
  "regions": []
 },
 {
  "length": 7047,
  "seq_id": "scaffold_441",
  "regions": []
 },
 {
  "length": 7020,
  "seq_id": "scaffold_442",
  "regions": []
 },
 {
  "length": 7011,
  "seq_id": "scaffold_443",
  "regions": []
 },
 {
  "length": 7010,
  "seq_id": "scaffold_444",
  "regions": []
 },
 {
  "length": 7003,
  "seq_id": "scaffold_445",
  "regions": []
 },
 {
  "length": 7000,
  "seq_id": "scaffold_446",
  "regions": []
 },
 {
  "length": 6999,
  "seq_id": "scaffold_447",
  "regions": []
 },
 {
  "length": 6994,
  "seq_id": "scaffold_448",
  "regions": []
 },
 {
  "length": 6990,
  "seq_id": "scaffold_449",
  "regions": []
 },
 {
  "length": 6989,
  "seq_id": "scaffold_450",
  "regions": []
 },
 {
  "length": 6966,
  "seq_id": "scaffold_451",
  "regions": []
 },
 {
  "length": 6950,
  "seq_id": "scaffold_452",
  "regions": []
 },
 {
  "length": 6929,
  "seq_id": "scaffold_453",
  "regions": []
 },
 {
  "length": 6877,
  "seq_id": "scaffold_454",
  "regions": []
 },
 {
  "length": 6862,
  "seq_id": "scaffold_455",
  "regions": []
 },
 {
  "length": 6856,
  "seq_id": "scaffold_456",
  "regions": []
 },
 {
  "length": 6844,
  "seq_id": "scaffold_457",
  "regions": []
 },
 {
  "length": 6813,
  "seq_id": "scaffold_458",
  "regions": []
 },
 {
  "length": 6805,
  "seq_id": "scaffold_459",
  "regions": []
 },
 {
  "length": 6793,
  "seq_id": "scaffold_460",
  "regions": []
 },
 {
  "length": 6791,
  "seq_id": "scaffold_461",
  "regions": []
 },
 {
  "length": 6780,
  "seq_id": "scaffold_462",
  "regions": []
 },
 {
  "length": 6779,
  "seq_id": "scaffold_463",
  "regions": [
   {
    "start": 1,
    "end": 6779,
    "idx": 1,
    "orfs": [
     {
      "start": 67,
      "end": 1401,
      "strand": -1,
      "locus_tag": "MARS19BIN38_003267",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003267</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003267</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003267-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67 - 1,401,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 159.4, e-value: 1.3e-46)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.4, e-value: 6.7e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003267\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGATGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACTATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGGACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGTAACTCCACTGCTCCTGAGCAGTAAAAAGTACGAAAATAACGAAAATACTTGGAGTCGCGCCTAA",
      "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWDGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDYDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLDLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKVTPLLLSSKKYENNENTWSRA",
      "product": "hypothetical protein"
     },
     {
      "start": 2085,
      "end": 3722,
      "strand": -1,
      "locus_tag": "MARS19BIN38_003268",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003268</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003268</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003268-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,085 - 3,722,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 61.0, e-value: 1.5e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003268\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATTTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGGTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAAAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACACAGAGGGAGCCATGGGTGCAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTGTTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACGGCATGGAATCATACTACACACGGTACAATTGGTGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGCCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATACTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
      "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLVVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFKTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHTEGAMGASVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTAWNHTTHGTIGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
      "product": "hypothetical protein"
     },
     {
      "start": 4636,
      "end": 6388,
      "strand": -1,
      "locus_tag": "MARS19BIN38_003269",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003269</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003269</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003269-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,636 - 6,388,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75; E-value: 7.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.1e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.8e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 666.0, e-value: 7.5e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003269\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_003269-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATAGCAGCATACGTGAAACGTATTGCACCGCACGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTCGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCTCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
      "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPHVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSSSDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 66,
      "end": 1401,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 6779,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r463c1"
   }
  ]
 },
 {
  "length": 6748,
  "seq_id": "scaffold_464",
  "regions": []
 },
 {
  "length": 6682,
  "seq_id": "scaffold_465",
  "regions": []
 },
 {
  "length": 6616,
  "seq_id": "scaffold_466",
  "regions": []
 },
 {
  "length": 6615,
  "seq_id": "scaffold_467",
  "regions": []
 },
 {
  "length": 6562,
  "seq_id": "scaffold_468",
  "regions": []
 },
 {
  "length": 6550,
  "seq_id": "scaffold_469",
  "regions": []
 },
 {
  "length": 6523,
  "seq_id": "scaffold_470",
  "regions": []
 },
 {
  "length": 6487,
  "seq_id": "scaffold_471",
  "regions": []
 },
 {
  "length": 6480,
  "seq_id": "scaffold_472",
  "regions": []
 },
 {
  "length": 6463,
  "seq_id": "scaffold_473",
  "regions": []
 },
 {
  "length": 6459,
  "seq_id": "scaffold_474",
  "regions": []
 },
 {
  "length": 6455,
  "seq_id": "scaffold_475",
  "regions": []
 },
 {
  "length": 6444,
  "seq_id": "scaffold_476",
  "regions": []
 },
 {
  "length": 6427,
  "seq_id": "scaffold_477",
  "regions": []
 },
 {
  "length": 6426,
  "seq_id": "scaffold_478",
  "regions": []
 },
 {
  "length": 6425,
  "seq_id": "scaffold_479",
  "regions": []
 },
 {
  "length": 6408,
  "seq_id": "scaffold_480",
  "regions": []
 },
 {
  "length": 6372,
  "seq_id": "scaffold_481",
  "regions": []
 },
 {
  "length": 6364,
  "seq_id": "scaffold_482",
  "regions": []
 },
 {
  "length": 6347,
  "seq_id": "scaffold_483",
  "regions": []
 },
 {
  "length": 6343,
  "seq_id": "scaffold_484",
  "regions": []
 },
 {
  "length": 6322,
  "seq_id": "scaffold_485",
  "regions": []
 },
 {
  "length": 6307,
  "seq_id": "scaffold_486",
  "regions": []
 },
 {
  "length": 6307,
  "seq_id": "scaffold_487",
  "regions": []
 },
 {
  "length": 6276,
  "seq_id": "scaffold_488",
  "regions": []
 },
 {
  "length": 6273,
  "seq_id": "scaffold_489",
  "regions": []
 },
 {
  "length": 6267,
  "seq_id": "scaffold_490",
  "regions": []
 },
 {
  "length": 6267,
  "seq_id": "scaffold_491",
  "regions": []
 },
 {
  "length": 6265,
  "seq_id": "scaffold_492",
  "regions": []
 },
 {
  "length": 6233,
  "seq_id": "scaffold_493",
  "regions": []
 },
 {
  "length": 6216,
  "seq_id": "scaffold_494",
  "regions": []
 },
 {
  "length": 6211,
  "seq_id": "scaffold_495",
  "regions": []
 },
 {
  "length": 6194,
  "seq_id": "scaffold_496",
  "regions": []
 },
 {
  "length": 6169,
  "seq_id": "scaffold_497",
  "regions": []
 },
 {
  "length": 6161,
  "seq_id": "scaffold_498",
  "regions": []
 },
 {
  "length": 6157,
  "seq_id": "scaffold_499",
  "regions": []
 },
 {
  "length": 6155,
  "seq_id": "scaffold_500",
  "regions": []
 },
 {
  "length": 6119,
  "seq_id": "scaffold_501",
  "regions": []
 },
 {
  "length": 6107,
  "seq_id": "scaffold_502",
  "regions": []
 },
 {
  "length": 6105,
  "seq_id": "scaffold_503",
  "regions": []
 },
 {
  "length": 6105,
  "seq_id": "scaffold_504",
  "regions": []
 },
 {
  "length": 6094,
  "seq_id": "scaffold_505",
  "regions": []
 },
 {
  "length": 6083,
  "seq_id": "scaffold_506",
  "regions": []
 },
 {
  "length": 6067,
  "seq_id": "scaffold_507",
  "regions": []
 },
 {
  "length": 6048,
  "seq_id": "scaffold_508",
  "regions": []
 },
 {
  "length": 6021,
  "seq_id": "scaffold_509",
  "regions": []
 },
 {
  "length": 6018,
  "seq_id": "scaffold_510",
  "regions": []
 },
 {
  "length": 5977,
  "seq_id": "scaffold_511",
  "regions": []
 },
 {
  "length": 5973,
  "seq_id": "scaffold_512",
  "regions": []
 },
 {
  "length": 5969,
  "seq_id": "scaffold_513",
  "regions": []
 },
 {
  "length": 5965,
  "seq_id": "scaffold_514",
  "regions": []
 },
 {
  "length": 5961,
  "seq_id": "scaffold_515",
  "regions": []
 },
 {
  "length": 5958,
  "seq_id": "scaffold_516",
  "regions": []
 },
 {
  "length": 5939,
  "seq_id": "scaffold_517",
  "regions": []
 },
 {
  "length": 5923,
  "seq_id": "scaffold_518",
  "regions": []
 },
 {
  "length": 5922,
  "seq_id": "scaffold_519",
  "regions": []
 },
 {
  "length": 5920,
  "seq_id": "scaffold_520",
  "regions": []
 },
 {
  "length": 5905,
  "seq_id": "scaffold_521",
  "regions": []
 },
 {
  "length": 5859,
  "seq_id": "scaffold_522",
  "regions": []
 },
 {
  "length": 5855,
  "seq_id": "scaffold_523",
  "regions": []
 },
 {
  "length": 5851,
  "seq_id": "scaffold_524",
  "regions": []
 },
 {
  "length": 5840,
  "seq_id": "scaffold_525",
  "regions": []
 },
 {
  "length": 5814,
  "seq_id": "scaffold_526",
  "regions": []
 },
 {
  "length": 5805,
  "seq_id": "scaffold_527",
  "regions": []
 },
 {
  "length": 5805,
  "seq_id": "scaffold_528",
  "regions": []
 },
 {
  "length": 5783,
  "seq_id": "scaffold_529",
  "regions": []
 },
 {
  "length": 5776,
  "seq_id": "scaffold_530",
  "regions": []
 },
 {
  "length": 5769,
  "seq_id": "scaffold_531",
  "regions": []
 },
 {
  "length": 5769,
  "seq_id": "scaffold_532",
  "regions": []
 },
 {
  "length": 5763,
  "seq_id": "scaffold_533",
  "regions": []
 },
 {
  "length": 5744,
  "seq_id": "scaffold_534",
  "regions": []
 },
 {
  "length": 5741,
  "seq_id": "scaffold_535",
  "regions": []
 },
 {
  "length": 5708,
  "seq_id": "scaffold_536",
  "regions": []
 },
 {
  "length": 5698,
  "seq_id": "scaffold_537",
  "regions": []
 },
 {
  "length": 5689,
  "seq_id": "scaffold_538",
  "regions": []
 },
 {
  "length": 5668,
  "seq_id": "scaffold_539",
  "regions": []
 },
 {
  "length": 5634,
  "seq_id": "scaffold_540",
  "regions": []
 },
 {
  "length": 5619,
  "seq_id": "scaffold_541",
  "regions": []
 },
 {
  "length": 5618,
  "seq_id": "scaffold_542",
  "regions": []
 },
 {
  "length": 5611,
  "seq_id": "scaffold_543",
  "regions": []
 },
 {
  "length": 5604,
  "seq_id": "scaffold_544",
  "regions": []
 },
 {
  "length": 5575,
  "seq_id": "scaffold_545",
  "regions": []
 },
 {
  "length": 5554,
  "seq_id": "scaffold_546",
  "regions": []
 },
 {
  "length": 5522,
  "seq_id": "scaffold_547",
  "regions": []
 },
 {
  "length": 5484,
  "seq_id": "scaffold_548",
  "regions": []
 },
 {
  "length": 5483,
  "seq_id": "scaffold_549",
  "regions": []
 },
 {
  "length": 5482,
  "seq_id": "scaffold_550",
  "regions": []
 },
 {
  "length": 5480,
  "seq_id": "scaffold_551",
  "regions": []
 },
 {
  "length": 5478,
  "seq_id": "scaffold_552",
  "regions": []
 },
 {
  "length": 5468,
  "seq_id": "scaffold_553",
  "regions": []
 },
 {
  "length": 5462,
  "seq_id": "scaffold_554",
  "regions": []
 },
 {
  "length": 5384,
  "seq_id": "scaffold_555",
  "regions": []
 },
 {
  "length": 5371,
  "seq_id": "scaffold_556",
  "regions": []
 },
 {
  "length": 5370,
  "seq_id": "scaffold_557",
  "regions": []
 },
 {
  "length": 5369,
  "seq_id": "scaffold_558",
  "regions": []
 },
 {
  "length": 5355,
  "seq_id": "scaffold_559",
  "regions": []
 },
 {
  "length": 5348,
  "seq_id": "scaffold_560",
  "regions": []
 },
 {
  "length": 5345,
  "seq_id": "scaffold_561",
  "regions": []
 },
 {
  "length": 5340,
  "seq_id": "scaffold_562",
  "regions": []
 },
 {
  "length": 5338,
  "seq_id": "scaffold_563",
  "regions": []
 },
 {
  "length": 5330,
  "seq_id": "scaffold_564",
  "regions": []
 },
 {
  "length": 5329,
  "seq_id": "scaffold_565",
  "regions": []
 },
 {
  "length": 5322,
  "seq_id": "scaffold_566",
  "regions": []
 },
 {
  "length": 5308,
  "seq_id": "scaffold_567",
  "regions": []
 },
 {
  "length": 5306,
  "seq_id": "scaffold_568",
  "regions": []
 },
 {
  "length": 5294,
  "seq_id": "scaffold_569",
  "regions": []
 },
 {
  "length": 5276,
  "seq_id": "scaffold_570",
  "regions": []
 },
 {
  "length": 5267,
  "seq_id": "scaffold_571",
  "regions": []
 },
 {
  "length": 5262,
  "seq_id": "scaffold_572",
  "regions": []
 },
 {
  "length": 5260,
  "seq_id": "scaffold_573",
  "regions": []
 },
 {
  "length": 5256,
  "seq_id": "scaffold_574",
  "regions": []
 },
 {
  "length": 5244,
  "seq_id": "scaffold_575",
  "regions": []
 },
 {
  "length": 5217,
  "seq_id": "scaffold_576",
  "regions": []
 },
 {
  "length": 5202,
  "seq_id": "scaffold_577",
  "regions": []
 },
 {
  "length": 5200,
  "seq_id": "scaffold_578",
  "regions": []
 },
 {
  "length": 5198,
  "seq_id": "scaffold_579",
  "regions": []
 },
 {
  "length": 5195,
  "seq_id": "scaffold_580",
  "regions": []
 },
 {
  "length": 5168,
  "seq_id": "scaffold_581",
  "regions": []
 },
 {
  "length": 5164,
  "seq_id": "scaffold_582",
  "regions": []
 },
 {
  "length": 5162,
  "seq_id": "scaffold_583",
  "regions": []
 },
 {
  "length": 5147,
  "seq_id": "scaffold_584",
  "regions": []
 },
 {
  "length": 5127,
  "seq_id": "scaffold_585",
  "regions": []
 },
 {
  "length": 5098,
  "seq_id": "scaffold_586",
  "regions": []
 },
 {
  "length": 5081,
  "seq_id": "scaffold_587",
  "regions": []
 },
 {
  "length": 5074,
  "seq_id": "scaffold_588",
  "regions": []
 },
 {
  "length": 5028,
  "seq_id": "scaffold_589",
  "regions": []
 },
 {
  "length": 5015,
  "seq_id": "scaffold_590",
  "regions": []
 },
 {
  "length": 5003,
  "seq_id": "scaffold_591",
  "regions": []
 },
 {
  "length": 4992,
  "seq_id": "scaffold_592",
  "regions": []
 },
 {
  "length": 4979,
  "seq_id": "scaffold_593",
  "regions": []
 },
 {
  "length": 4972,
  "seq_id": "scaffold_594",
  "regions": []
 },
 {
  "length": 4970,
  "seq_id": "scaffold_595",
  "regions": []
 },
 {
  "length": 4966,
  "seq_id": "scaffold_596",
  "regions": []
 },
 {
  "length": 4949,
  "seq_id": "scaffold_597",
  "regions": []
 },
 {
  "length": 4935,
  "seq_id": "scaffold_598",
  "regions": []
 },
 {
  "length": 4934,
  "seq_id": "scaffold_599",
  "regions": []
 },
 {
  "length": 4933,
  "seq_id": "scaffold_600",
  "regions": []
 },
 {
  "length": 4917,
  "seq_id": "scaffold_601",
  "regions": []
 },
 {
  "length": 4891,
  "seq_id": "scaffold_602",
  "regions": []
 },
 {
  "length": 4887,
  "seq_id": "scaffold_603",
  "regions": []
 },
 {
  "length": 4886,
  "seq_id": "scaffold_604",
  "regions": []
 },
 {
  "length": 4883,
  "seq_id": "scaffold_605",
  "regions": []
 },
 {
  "length": 4877,
  "seq_id": "scaffold_606",
  "regions": []
 },
 {
  "length": 4876,
  "seq_id": "scaffold_607",
  "regions": []
 },
 {
  "length": 4861,
  "seq_id": "scaffold_608",
  "regions": []
 },
 {
  "length": 4848,
  "seq_id": "scaffold_609",
  "regions": []
 },
 {
  "length": 4848,
  "seq_id": "scaffold_610",
  "regions": []
 },
 {
  "length": 4838,
  "seq_id": "scaffold_611",
  "regions": []
 },
 {
  "length": 4836,
  "seq_id": "scaffold_612",
  "regions": []
 },
 {
  "length": 4809,
  "seq_id": "scaffold_613",
  "regions": []
 },
 {
  "length": 4805,
  "seq_id": "scaffold_614",
  "regions": []
 },
 {
  "length": 4804,
  "seq_id": "scaffold_615",
  "regions": []
 },
 {
  "length": 4790,
  "seq_id": "scaffold_616",
  "regions": []
 },
 {
  "length": 4789,
  "seq_id": "scaffold_617",
  "regions": []
 },
 {
  "length": 4777,
  "seq_id": "scaffold_618",
  "regions": []
 },
 {
  "length": 4772,
  "seq_id": "scaffold_619",
  "regions": []
 },
 {
  "length": 4739,
  "seq_id": "scaffold_620",
  "regions": []
 },
 {
  "length": 4738,
  "seq_id": "scaffold_621",
  "regions": []
 },
 {
  "length": 4737,
  "seq_id": "scaffold_622",
  "regions": []
 },
 {
  "length": 4733,
  "seq_id": "scaffold_623",
  "regions": []
 },
 {
  "length": 4703,
  "seq_id": "scaffold_624",
  "regions": []
 },
 {
  "length": 4701,
  "seq_id": "scaffold_625",
  "regions": []
 },
 {
  "length": 4697,
  "seq_id": "scaffold_626",
  "regions": []
 },
 {
  "length": 4689,
  "seq_id": "scaffold_627",
  "regions": []
 },
 {
  "length": 4686,
  "seq_id": "scaffold_628",
  "regions": []
 },
 {
  "length": 4682,
  "seq_id": "scaffold_629",
  "regions": []
 },
 {
  "length": 4671,
  "seq_id": "scaffold_630",
  "regions": []
 },
 {
  "length": 4659,
  "seq_id": "scaffold_631",
  "regions": []
 },
 {
  "length": 4591,
  "seq_id": "scaffold_632",
  "regions": []
 },
 {
  "length": 4575,
  "seq_id": "scaffold_633",
  "regions": []
 },
 {
  "length": 4570,
  "seq_id": "scaffold_634",
  "regions": []
 },
 {
  "length": 4560,
  "seq_id": "scaffold_635",
  "regions": []
 },
 {
  "length": 4544,
  "seq_id": "scaffold_636",
  "regions": []
 },
 {
  "length": 4523,
  "seq_id": "scaffold_637",
  "regions": []
 },
 {
  "length": 4513,
  "seq_id": "scaffold_638",
  "regions": []
 },
 {
  "length": 4498,
  "seq_id": "scaffold_639",
  "regions": []
 },
 {
  "length": 4473,
  "seq_id": "scaffold_640",
  "regions": []
 },
 {
  "length": 4469,
  "seq_id": "scaffold_641",
  "regions": []
 },
 {
  "length": 4465,
  "seq_id": "scaffold_642",
  "regions": []
 },
 {
  "length": 4456,
  "seq_id": "scaffold_643",
  "regions": []
 },
 {
  "length": 4436,
  "seq_id": "scaffold_644",
  "regions": []
 },
 {
  "length": 4395,
  "seq_id": "scaffold_645",
  "regions": []
 },
 {
  "length": 4394,
  "seq_id": "scaffold_646",
  "regions": []
 },
 {
  "length": 4381,
  "seq_id": "scaffold_647",
  "regions": []
 },
 {
  "length": 4374,
  "seq_id": "scaffold_648",
  "regions": []
 },
 {
  "length": 4356,
  "seq_id": "scaffold_649",
  "regions": []
 },
 {
  "length": 4355,
  "seq_id": "scaffold_650",
  "regions": []
 },
 {
  "length": 4334,
  "seq_id": "scaffold_651",
  "regions": []
 },
 {
  "length": 4316,
  "seq_id": "scaffold_652",
  "regions": []
 },
 {
  "length": 4287,
  "seq_id": "scaffold_653",
  "regions": []
 },
 {
  "length": 4282,
  "seq_id": "scaffold_654",
  "regions": []
 },
 {
  "length": 4249,
  "seq_id": "scaffold_655",
  "regions": []
 },
 {
  "length": 4240,
  "seq_id": "scaffold_656",
  "regions": []
 },
 {
  "length": 4240,
  "seq_id": "scaffold_657",
  "regions": []
 },
 {
  "length": 4237,
  "seq_id": "scaffold_658",
  "regions": []
 },
 {
  "length": 4214,
  "seq_id": "scaffold_659",
  "regions": []
 },
 {
  "length": 4196,
  "seq_id": "scaffold_660",
  "regions": []
 },
 {
  "length": 4192,
  "seq_id": "scaffold_661",
  "regions": []
 },
 {
  "length": 4183,
  "seq_id": "scaffold_662",
  "regions": []
 },
 {
  "length": 4161,
  "seq_id": "scaffold_663",
  "regions": []
 },
 {
  "length": 4159,
  "seq_id": "scaffold_664",
  "regions": []
 },
 {
  "length": 4148,
  "seq_id": "scaffold_665",
  "regions": []
 },
 {
  "length": 4143,
  "seq_id": "scaffold_666",
  "regions": []
 },
 {
  "length": 4131,
  "seq_id": "scaffold_667",
  "regions": []
 },
 {
  "length": 4120,
  "seq_id": "scaffold_668",
  "regions": []
 },
 {
  "length": 4112,
  "seq_id": "scaffold_669",
  "regions": []
 },
 {
  "length": 4095,
  "seq_id": "scaffold_670",
  "regions": []
 },
 {
  "length": 4044,
  "seq_id": "scaffold_671",
  "regions": []
 },
 {
  "length": 4041,
  "seq_id": "scaffold_672",
  "regions": []
 },
 {
  "length": 4040,
  "seq_id": "scaffold_673",
  "regions": []
 },
 {
  "length": 4029,
  "seq_id": "scaffold_674",
  "regions": []
 },
 {
  "length": 4011,
  "seq_id": "scaffold_675",
  "regions": []
 },
 {
  "length": 4005,
  "seq_id": "scaffold_676",
  "regions": []
 },
 {
  "length": 3994,
  "seq_id": "scaffold_677",
  "regions": []
 },
 {
  "length": 3993,
  "seq_id": "scaffold_678",
  "regions": []
 },
 {
  "length": 3983,
  "seq_id": "scaffold_679",
  "regions": []
 },
 {
  "length": 3980,
  "seq_id": "scaffold_680",
  "regions": []
 },
 {
  "length": 3977,
  "seq_id": "scaffold_681",
  "regions": []
 },
 {
  "length": 3973,
  "seq_id": "scaffold_682",
  "regions": []
 },
 {
  "length": 3965,
  "seq_id": "scaffold_683",
  "regions": []
 },
 {
  "length": 3944,
  "seq_id": "scaffold_684",
  "regions": []
 },
 {
  "length": 3917,
  "seq_id": "scaffold_685",
  "regions": []
 },
 {
  "length": 3898,
  "seq_id": "scaffold_686",
  "regions": []
 },
 {
  "length": 3897,
  "seq_id": "scaffold_687",
  "regions": []
 },
 {
  "length": 3877,
  "seq_id": "scaffold_688",
  "regions": []
 },
 {
  "length": 3875,
  "seq_id": "scaffold_689",
  "regions": []
 },
 {
  "length": 3853,
  "seq_id": "scaffold_690",
  "regions": []
 },
 {
  "length": 3844,
  "seq_id": "scaffold_691",
  "regions": []
 },
 {
  "length": 3843,
  "seq_id": "scaffold_692",
  "regions": []
 },
 {
  "length": 3842,
  "seq_id": "scaffold_693",
  "regions": []
 },
 {
  "length": 3827,
  "seq_id": "scaffold_694",
  "regions": []
 },
 {
  "length": 3812,
  "seq_id": "scaffold_695",
  "regions": []
 },
 {
  "length": 3803,
  "seq_id": "scaffold_696",
  "regions": []
 },
 {
  "length": 3792,
  "seq_id": "scaffold_697",
  "regions": []
 },
 {
  "length": 3792,
  "seq_id": "scaffold_698",
  "regions": []
 },
 {
  "length": 3670,
  "seq_id": "scaffold_699",
  "regions": []
 },
 {
  "length": 3594,
  "seq_id": "scaffold_700",
  "regions": []
 },
 {
  "length": 3531,
  "seq_id": "scaffold_701",
  "regions": []
 },
 {
  "length": 3508,
  "seq_id": "scaffold_702",
  "regions": []
 },
 {
  "length": 3492,
  "seq_id": "scaffold_703",
  "regions": []
 },
 {
  "length": 3489,
  "seq_id": "scaffold_704",
  "regions": []
 },
 {
  "length": 3464,
  "seq_id": "scaffold_705",
  "regions": []
 },
 {
  "length": 3425,
  "seq_id": "scaffold_706",
  "regions": []
 },
 {
  "length": 3405,
  "seq_id": "scaffold_707",
  "regions": []
 },
 {
  "length": 3383,
  "seq_id": "scaffold_708",
  "regions": []
 },
 {
  "length": 3352,
  "seq_id": "scaffold_709",
  "regions": []
 },
 {
  "length": 3325,
  "seq_id": "scaffold_710",
  "regions": []
 },
 {
  "length": 3299,
  "seq_id": "scaffold_711",
  "regions": []
 },
 {
  "length": 3281,
  "seq_id": "scaffold_712",
  "regions": []
 },
 {
  "length": 3227,
  "seq_id": "scaffold_713",
  "regions": []
 },
 {
  "length": 3213,
  "seq_id": "scaffold_714",
  "regions": []
 },
 {
  "length": 3196,
  "seq_id": "scaffold_715",
  "regions": []
 },
 {
  "length": 3132,
  "seq_id": "scaffold_716",
  "regions": []
 },
 {
  "length": 3107,
  "seq_id": "scaffold_717",
  "regions": []
 },
 {
  "length": 3083,
  "seq_id": "scaffold_718",
  "regions": []
 },
 {
  "length": 3064,
  "seq_id": "scaffold_719",
  "regions": []
 },
 {
  "length": 3056,
  "seq_id": "scaffold_720",
  "regions": []
 },
 {
  "length": 3038,
  "seq_id": "scaffold_721",
  "regions": []
 },
 {
  "length": 3029,
  "seq_id": "scaffold_722",
  "regions": []
 },
 {
  "length": 3023,
  "seq_id": "scaffold_723",
  "regions": []
 },
 {
  "length": 3021,
  "seq_id": "scaffold_724",
  "regions": []
 },
 {
  "length": 2993,
  "seq_id": "scaffold_725",
  "regions": []
 },
 {
  "length": 2969,
  "seq_id": "scaffold_726",
  "regions": []
 },
 {
  "length": 2944,
  "seq_id": "scaffold_727",
  "regions": []
 },
 {
  "length": 2919,
  "seq_id": "scaffold_728",
  "regions": []
 },
 {
  "length": 2856,
  "seq_id": "scaffold_729",
  "regions": []
 },
 {
  "length": 2821,
  "seq_id": "scaffold_730",
  "regions": []
 },
 {
  "length": 2787,
  "seq_id": "scaffold_731",
  "regions": []
 },
 {
  "length": 2745,
  "seq_id": "scaffold_732",
  "regions": []
 },
 {
  "length": 2732,
  "seq_id": "scaffold_733",
  "regions": []
 },
 {
  "length": 2673,
  "seq_id": "scaffold_734",
  "regions": []
 },
 {
  "length": 2517,
  "seq_id": "scaffold_735",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r37c1",
  "r106c1",
  "r176c1",
  "r181c1",
  "r419c1",
  "r463c1"
 ],
 "r37c1": {
  "start": 1,
  "end": 12412,
  "idx": 1,
  "orfs": [
   {
    "start": 451,
    "end": 1311,
    "strand": 1,
    "locus_tag": "MARS19BIN38_000556",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000556</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000556</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000556-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 451 - 1,311,\n (total: 861 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000556 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17171.7 (Glutathione S-transferase, C-terminal domain): [208:272](score: 47.5, e-value: 1.3e-12)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000556\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000556\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ACACAAATTTCAGATTTCCTTCGTGGTGCTGTCTACTTCGTAAGTCTGCCCTCTGGTCTTTACGGTATGATTGCAACTCCACCGATCGTGAAGAAACTATTCGATCGATTCCCACTAACTACTTATGAGCATGCAGGTCTACCATTGAGGTCAAGAGAACGCCAAGTTGAGATACCAACTCTGCTTGTGTACGCCTATCGTGGACAGACAATACATCCGGACTGTTTGCTATGGGAGACTCTTTTGCAGATCCACGGCACAGAGAATTTCAAGAGCCTCGCTTCCTCACCCCATGCTAGTGTCAGTGGGCTTCCCCTTCTTCTTTTGCCGAGTGGTGGAAAGGTCCACGCTGCGAAATTGGACGAATGGGCTGGTATTGATCCATTGACCATGGAGCAAAAGGTATTCAGAGTAATGCTCAATGCAAATATTCGTCGAGCATACCTCTTTACAATGTATATGGAGCCACGCAATGCAGGTTTGGCATCTCGATTGTTCATCGATGGCGATGTAGCGTGGCCGGCCAGTCTGCTTGTAAGACACTCCACCCGCTCCTCAGTGCATGAGGTCTTGGCTGGTGGGTTGGCTACATACTACAGCAAAGAAGAAATATACGCAGACGCTGATGCGGCATGGGCAGCACTGTCAGCACTGTTGGGAAATGACGACTATTTTGCGTCGCCGCCAGGATTGCTTGATGCAGCAGTCTTCTCATATACGCATCTCATACTCTCTCTTCCGCTTGACTTCTCAGCAAGAGATATTCGAATTTCTTTAAGCCAATACAAAAATCTTATCGCCCATCATGAACGAATTGATCAACTCCGGTCACAATCTAATATCGAGCTTCGACAAAACTGA",
    "translation": "MQISDFLRGAVYFVSLPSGLYGMIATPPIVKKLFDRFPLTTYEHAGLPLRSRERQVEIPTLLVYAYRGQTIHPDCLLWETLLQIHGTENFKSLASSPHASVSGLPLLLLPSGGKVHAAKLDEWAGIDPLTMEQKVFRVMLNANIRRAYLFTMYMEPRNAGLASRLFIDGDVAWPASLLVRHSTRSSVHEVLAGGLATYYSKEEIYADADAAWAALSALLGNDDYFASPPGLLDAAVFSYTHLILSLPLDFSARDIRISLSQYKNLIAHHERIDQLRSQSNIELRQN",
    "product": "hypothetical protein"
   },
   {
    "start": 1411,
    "end": 2412,
    "strand": -1,
    "locus_tag": "MARS19BIN38_000557",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000557</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000557</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000557-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,411 - 2,412,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 234.8; E-value: 1.9e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000557 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 224.6, e-value: 1.1e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000557 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000557\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_000557-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000557\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGGACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGCTTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAGGTAATACTGCATTGATGGAGATCCTTAACAGTTGGCATAGTTCTTTGTGTGGCACAGATTAG",
    "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNAWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLGGNTALMEILNSWHSSLCGTD",
    "product": "hypothetical protein"
   },
   {
    "start": 2527,
    "end": 3252,
    "strand": 1,
    "locus_tag": "MARS19BIN38_000558",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000558</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000558</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000558-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,527 - 3,252,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000558 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.6, e-value: 3.8e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 191.7, e-value: 1.5e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000558\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000558\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCACCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGGTTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
    "translation": "MERLIISALEELSSYDASTVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVVVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
    "product": "hypothetical protein"
   },
   {
    "start": 4553,
    "end": 6941,
    "strand": 1,
    "locus_tag": "MARS19BIN38_000559",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000559</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000559</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000559-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,553 - 6,941,\n (total: 2220 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000559 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 87.0, e-value: 2.4e-24)<br>\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [379:630](score: 293.1, e-value: 1.7e-87)<br>\n \n  PF08669.14 (Glycine cleavage T-protein C-terminal barrel domain): [656:733](score: 66.1, e-value: 2.1e-18)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000559 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [375:734](score: 379.3, e-value: 3.9e-114)<br>\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 93.1, e-value: 5.1e-27)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 63.1, e-value: 7.4e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000559\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_000559-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000559\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATTTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCGAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGATGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGGTTATTGCAAGGACGCCAGTGGAGGAGCGGATGTATTACTGGCCCGAATTTAGCATGAACCTATTTACGTACTTCCAGATTCCTGAGGGAACCGTCGCGGATATCGGTGATTATCGAAGGCAGATAGATACATGCAAGATGATGAGACGGTACGCGACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACGGTGTTGCAGCAGTTTGGGGAAGGAGTAAAACGTCGGCGCATTGGACTCACAGTCGAAGGAGCGCCCGCCCGCTCGGCTGCCCCTATTGAGTCCGAGAAACAAGATGTTGGAGTCGTGACAAGCGGGTGCCCATCGCCAACAACCGGGACCAATATTGCCATGGGGTATATTACGCACGGGTTGCACAAGTCTGGCACTGAGATCGCGGTCAAAGTGAGGGGCAGGGAACGGAAAGCCATTGTCACCAAAATGCCCTTTGTGCAGACCAAGTACTATAAATAA",
    "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMVIARTPVEERMYYWPEFSMNLFTYFQIPEGTVADIGDYRRQIDTCKMMRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQTVLQQFGEGVKRRRIGLTVEGAPARSAAPIESEKQDVGVVTSGCPSPTTGTNIAMGYITHGLHKSGTEIAVKVRGRERKAIVTKMPFVQTKYYK",
    "product": "hypothetical protein"
   },
   {
    "start": 7438,
    "end": 10318,
    "strand": 1,
    "locus_tag": "MARS19BIN38_000560",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000560</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000560</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000560-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,438 - 10,318,\n (total: 2838 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00168.33 (C2 domain): [2:66](score: 42.5, e-value: 7e-11)<br>\n \n  PF00168.33 (C2 domain): [161:259](score: 61.2, e-value: 1e-16)<br>\n \n  PF02666.18 (Phosphatidylserine decarboxylase): [691:899](score: 194.8, e-value: 1.2e-57)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00163 (PS_decarb: phosphatidylserine decarboxylase): [685:890](score: 123.4, e-value: 1.9e-36)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000560 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity<br>\n  \n   PF02666.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000560\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000560\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCATTCAAAAAACACTCAATCCGGTGTGGAATCACCATTTTCAAATCCCAATTGATCCATCCATGCTGTCCTCGACATTGAAGCTGGTGTGTTGGGACAAGGACAGGTACGGTAAAGACTACATGGGTGAGATTGAAATCACTCTTGAAGAATTGCTGTCGGAAGACCGCGAGAAAGCACAATGGTTTCCGTTGGTATCGTCCAGGAATAGCAAGATCTCTGGTGAGGTTGAGCTAAGCTTCGGATTACACGATCCTCTAAGCCCGAATGCGACCTTTTCCGATCTTGTAAAGGAGTGGACGAGTATGCTTACGGATACATCAGAACTTGGTAGTGATGCTGATAATGACGATTCAGAGATCGACATTTCTGCTGATGCTACGCCGCAACAAAAGGCACGGAAGCGTAGACTGAGGCGAAGAAGGAAATTGCAAAAGCCTTATGAATTCACCCAAAACAAAGTGTCAGGAGTAGCTGGAATTGTCTATTTTGAGGTCACGTCGTGCTCGGATTTACCACCCGAGAGGAATGTGACTCGAACATCTTTCGATATGGATCCATTTGTGATCATCTCTTTTGGAAAGAAGACTTTACGAACAAAGTCTTTGCGCCATACTCTTAATCCTGTATTCAACGAGAAAATGATCTTTCAGGTGTTGATGTTTGAGCAAGCATATACAATCTCTCTGAGGGTTGTCGATAAAGATAAGTTTTCATCCAATGACTTTGTTGCAGAAGCTGTACTGGACGTAAAAGAATTGATCGATACCGGCCCGACTGCAAACAGCGAGACTGGCTTGTATGATTTACCTGATCCCGAAAGCAACCTACAGTTAACCAAGTCAAAACAATCGACGCTGTCTAAGAGCAATACCAGTGAGAGATTGCATCGAGCAGCGAGCAGTAATTCATTGTCACAAGCACAGCCTCAGAAAGTTACAAAGACTGAAACAAGTGTCGCTTCGTCGCTGAACGGGGAAGATGCGCAGTCGACTGAAGGAAGGACCATGGTTCCTCAACTAAGCGAATCTATCGACTATGATCTGAAAAGCTTTACACTCCCGCTAAATATGGCGAAAAAAGAGCGATGGGAGGAAAAGCACACTCCACAGATCAAGATCAAAGCGCGTTTTGTCCCATACCCTGCACTGCGGCAACAGTTTTGGAGATGTATGTTTCGTCAATATGATAGTGACGATACCGGGCGCATTAGTCGCGTGGAAATGACAACTATGTTGGATACTTTGGGCTCGACTCTCACTGACGCCAGCATCGACGAGCTTTTTGAGCGATATAATTTAGGAACTGACGCCAAGTCGAAGGACGAGTATGAAATGACAATAGACCAGGCAATTGTCTGTCTTGAAGAAGAACTTCGCAAAATCGATGCTACGATTCCAGCTGGAGGTGAAAAGACTCCATCTGATGACGAGGAAGACTCTGAGGTCACAGGAGATGCGCACTCCTTGTCAGAAAGCTCTGAATCCAATAACTTCAAGCCTCCGACAGTGTCTTTCAAAGGGACAGAGATTGCCAAGGATGAAATGTTGCATGATGAAGGCAGACGGGAGCATGTTATCGCGATCAAGGAATGTCCACTTTGCCACCAACCGCGGTTGAATAAGCGATCCGATACAGACATTATAACCCATCTCGCAACCTGTGCAAGTCAGGACTGGCGGAGTGTTGATCGAATAGTCATGGGAGATTTCGTTACATCGAGCCAAGCCCAACGCAAATGGTACTCTAAAGTGATATCGAAAGTAGGCTATGGCGGCTACCGGCTCGGAGCAAACTCTGCCAATATTCTGGTGCAAGATCGTTTGACAGGCCAGATCCAGGAAGAGCGCATGAGTATTTATGTGCGCTTGGGCATACGCCTCTTCTACAAAGGATTGAAGAGTGGGGAAATGGAGAAGAAACGGATGCGCCGTCTGCTCTACTCGTTGAGCGTGAAGCAAGGACGCAAGTATGACGCTCCGCCTTCTGCTCGAGACATCAAGAGTTTCATTGCATTTCACAAGCTTAATATGGCTGAGGTGAAGCTACCGATTGAACAGTTCCAGACCTTCAACCAGTTCTTTTACCGCGAGTTGAAACCTGACGCAAGGCCCTGTACAGCACCGGACAATCACTGGATTGCAGTATCCCCAGCAGATTGCCGATGCGTTCTTTTCGATCGGGTTGATAAGGCTAGCGAAATCTGGGTCAAAGGCCGAGATTTCTCCGTGGCCCGATTGCTTGGCAGTGCGTATCCTGAGGATGCCGCAAAGTTCGAGAACGGATCCATTGGCATATTCCGCTTGGCACCACAAGATTACCATCGCTTCCACTGTCCGGTGGAGGGAGTCCTGCAGGAACCCAAAACGATTGATGGTCAGTACTACACGGTCAATCCGATGGCTGTCCGCTCCTCGCTGGATGTATTTGGCGAGAATGTCCGAGTGGTCTGCCCCATCGACTCCGAGGCGTTTGGGCGCGTGATGGTTGTGTGCATTGGAGCTATGATGGTGGGTAGCACTGTCATCACTGCCAAGACCGGCAGTAAGCTGTCTAGAACCCAAGAACTCGGGTACTTCAAATTTGGCGGAAGCACCCTTGTAGTCTTGTTTCAGCCAGGCAAGCTGAAATTTGACGATGACGTTGTGGGCAACTCGAAATCTTCACTCGAGACGCTGATGCGTGTAGGCATGTCTATTGGCCACCATCCGCAAGAGCCGTCCCAAGCACCTAGCAAGAAGGACCGTGAGAACGCCACACTGGAAGATCGCCAACGTGCAAGTATTGCAATTGGTGGAAGTCTGAAGCCGCCACGTGGTTTAGAACAAGATTAG",
    "translation": "MSIQKTLNPVWNHHFQIPIDPSMLSSTLKLVCWDKDRYGKDYMGEIEITLEELLSEDREKAQWFPLVSSRNSKISGEVELSFGLHDPLSPNATFSDLVKEWTSMLTDTSELGSDADNDDSEIDISADATPQQKARKRRLRRRRKLQKPYEFTQNKVSGVAGIVYFEVTSCSDLPPERNVTRTSFDMDPFVIISFGKKTLRTKSLRHTLNPVFNEKMIFQVLMFEQAYTISLRVVDKDKFSSNDFVAEAVLDVKELIDTGPTANSETGLYDLPDPESNLQLTKSKQSTLSKSNTSERLHRAASSNSLSQAQPQKVTKTETSVASSLNGEDAQSTEGRTMVPQLSESIDYDLKSFTLPLNMAKKERWEEKHTPQIKIKARFVPYPALRQQFWRCMFRQYDSDDTGRISRVEMTTMLDTLGSTLTDASIDELFERYNLGTDAKSKDEYEMTIDQAIVCLEEELRKIDATIPAGGEKTPSDDEEDSEVTGDAHSLSESSESNNFKPPTVSFKGTEIAKDEMLHDEGRREHVIAIKECPLCHQPRLNKRSDTDIITHLATCASQDWRSVDRIVMGDFVTSSQAQRKWYSKVISKVGYGGYRLGANSANILVQDRLTGQIQEERMSIYVRLGIRLFYKGLKSGEMEKKRMRRLLYSLSVKQGRKYDAPPSARDIKSFIAFHKLNMAEVKLPIEQFQTFNQFFYRELKPDARPCTAPDNHWIAVSPADCRCVLFDRVDKASEIWVKGRDFSVARLLGSAYPEDAAKFENGSIGIFRLAPQDYHRFHCPVEGVLQEPKTIDGQYYTVNPMAVRSSLDVFGENVRVVCPIDSEAFGRVMVVCIGAMMVGSTVITAKTGSKLSRTQELGYFKFGGSTLVVLFQPGKLKFDDDVVGNSKSSLETLMRVGMSIGHHPQEPSQAPSKKDRENATLEDRQRASIAIGGSLKPPRGLEQD",
    "product": "hypothetical protein"
   },
   {
    "start": 10548,
    "end": 11762,
    "strand": 1,
    "locus_tag": "MARS19BIN38_000561",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000561</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000561</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000561-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,548 - 11,762,\n (total: 1215 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000561 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08202.14 (Mis12-Mtw1 protein family): [109:400](score: 165.2, e-value: 2.3e-48)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_000561 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division<br>\n  \n   PF08202.14: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000561\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000561\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACAGAAATGAGCGGCCCGAGAAACGAAAGGCGCACGCCGTTGTAGATATCGAGCCTTCGCCAGATGCGCGCAAAAGGCGAACACAACCTGATCGCAAGGCGAGGGGAAGTCTACAAAATGAAGAGGATGATGGGTTTCAATTTGCGCGTGGGAAGGGAAAACCCCGAAATGATCAGCAACCTGGCGAGGCGAAAAGCGGGAAGCAGGCCACTCGAAGGAAGGTTGTAGACCTTTCCGATACTCCGAAAGGCGAGCGGTCAAATTCTTCGCATGGTAGCGGCGAGGGCTCGACGATGATGGATTCTGTGATCCCACTCTCGACCCGTGATACGCCTATGATTCGAAAGAACAAGGAGCTACGCCAGCAATCGCGTGCCGGAGGACACCGAAGAAGCAGCTCTGGTCTACGTGGGAAACGCGCGAGTTCCATTGGCAATGGTTTCAGGGCGGTCCCCCATCCTGATATCGATGCACGAGATTTCTACAAGCATATTGCCGACGATTTACCAGATCCACTTCGAATGCGACAGCTCCTTGCGTGGTGTGCGCGCCGGGCCTTCGATGAGCAAAAAGTGAGATTGGATGCTGCTCCGCCTGAGAAGGGCCAAGTGATGGATAGGAATGCAGCTACGATTGCACAAGTCGTGAAGCAGGAAGTGCTCATGGATTTGATTGAGAGTCGGATTGAAACGAGCTGGTACCATCGTCCTGAAGGACCACCCAAAACACCTACCAAACCCAATCCTCAAAACGAAGAGAACCGAGCAAAAATTGAACACTTGCAAACTGTCTTGGAGAGGCTGAGAACCGAGGAGCGACAGTGGAAGGCACTGATCACCAATCCGCCAACCTCACAAGCAACCATGACAAATGATAAAGATATCCAACCTGAGGACCTGTCCCTTCTGAGACCGAGGGAGCGAGCATTTTGGGAGAATGTACAGCAGCAGGATTCAAGGGATGCGGAGCGCGTCCAAGAATGGATGGGCGGGGAGGAGAGCAAGCTGGAGTTGCAAGTGGATAAGCTCTTTCATATGCTGCATTCCGTGCGCATGCTTGGAAAGGCAGCCGAGGGGTTCAGCGAGCAGGCGCTGTCCCAAGCTGCTGAGGCGTTTGATGCACGTCGTGAGCGTGCCCAGGAAGAGGCCCGCACAACAGATGTCTCACCGCGCGACATTCTCCGCACCCTGTCACGGCGATCGGATGTATAA",
    "translation": "MNRNERPEKRKAHAVVDIEPSPDARKRRTQPDRKARGSLQNEEDDGFQFARGKGKPRNDQQPGEAKSGKQATRRKVVDLSDTPKGERSNSSHGSGEGSTMMDSVIPLSTRDTPMIRKNKELRQQSRAGGHRRSSSGLRGKRASSIGNGFRAVPHPDIDARDFYKHIADDLPDPLRMRQLLAWCARRAFDEQKVRLDAAPPEKGQVMDRNAATIAQVVKQEVLMDLIESRIETSWYHRPEGPPKTPTKPNPQNEENRAKIEHLQTVLERLRTEERQWKALITNPPTSQATMTNDKDIQPEDLSLLRPRERAFWENVQQQDSRDAERVQEWMGGEESKLELQVDKLFHMLHSVRMLGKAAEGFSEQALSQAAEAFDARRERAQEEARTTDVSPRDILRTLSRRSDV",
    "product": "hypothetical protein"
   },
   {
    "start": 11817,
    "end": 12098,
    "strand": -1,
    "locus_tag": "MARS19BIN38_000562",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_000562</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_000562</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_000562-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,817 - 12,098,\n (total: 282 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000562 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF01910.20 (Thiamine-binding protein): [0:86](score: 83.4, e-value: 8.8e-24)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_000562 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00106 (TIGR00106: uncharacterized protein, MTH1187 family): [0:88](score: 86.0, e-value: 4.8e-25)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_000562\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_000562\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGACCTCGTCGCCGTCCGTCACACAGCATGTGGCGCGAGTACAGGTCTACTTTTCCGAGTGCGCTGGCATTGAATTCCACATGCACTCCTACGGCACAACCATCGAAGGGGAGTGGGACGACGTGATGCGCGCCATTGGAGGCGCCCATCAGTGCCTGCACGAGGCGGGCGTCGTCCGGATTGCAAGCGATATACGCGTCGGCACACGCACTGACAAGGCACAGACGTCGCAGCAAAAGGTAGACAGCGTACAAGACTTTCTCGCCACAGACAAGTAG",
    "translation": "MGTSSPSVTQHVARVQVYFSECAGIEFHMHSYGTTIEGEWDDVMRAIGGAHQCLHEAGVVRIASDIRVGTRTDKAQTSQQKVDSVQDFLATDK",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 1410,
    "end": 2412,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 12412,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r37c1"
 },
 "r106c1": {
  "start": 1,
  "end": 15641,
  "idx": 1,
  "orfs": [
   {
    "start": 552,
    "end": 1142,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001263",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001263</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001263</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001263-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 552 - 1,142,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001263 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00787.27 (PX domain): [120:193](score: 57.5, e-value: 1.8e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001263 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00787.27: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001263\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001263\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "CTCAGCCAAGCGAAGGACGCGATGGTATACGATCGACAAAGGTCCTCACTCGACTCGTCGCGTACGCCTAGTTCTTTTCGAGTGCATATAGGTGAAAGCAGTGATGAAGACGAGGGTTCACAGCTCATGGTGTCGTCAGACTCAGAGCTGACCTCACGCCAGCCATGGGAAGGTCATGGGAGTATCAGCCTTGTGGACCGCACACAGCAACCAGATGATTTTGCAGGCCATACATGGGCAAGAGATGTGAGGGTCACGGATCATACGATCGTTCGCGGTGGTGACAAGATCGCGGCCTACGTTGTTTGGATAATATGGGTTGCTGTCGAGTCGGTCAGTGAGGAAAACCCTACTGGCATTCAGATCAGGAAACGGTACTCAGAGTTTGCAAGGCTTAGGAGTGATCTTCTTTCGGCTTTTCCTACACTGAGTGGCGCTCTTCCCAAATTGCCGCCTAAATCTGTCGTCTCCAAGTTTCGACCTTCCTTTTTGGAAAAGAGAAGACGTGGTCTGGAGTACTTTCTTTCATGTGTGCTTCTCAATCCTCAATTTGGGACGACGCCGATTGTGCGCTCCTGGTTCTTTTCTTAA",
    "translation": "MSQAKDAMVYDRQRSSLDSSRTPSSFRVHIGESSDEDEGSQLMVSSDSELTSRQPWEGHGSISLVDRTQQPDDFAGHTWARDVRVTDHTIVRGGDKIAAYVVWIIWVAVESVSEENPTGIQIRKRYSEFARLRSDLLSAFPTLSGALPKLPPKSVVSKFRPSFLEKRRRGLEYFLSCVLLNPQFGTTPIVRSWFFS",
    "product": "hypothetical protein"
   },
   {
    "start": 1863,
    "end": 4114,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001264",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001264</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001264</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001264-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,863 - 4,114,\n (total: 2109 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00290.23 (Tryptophan synthase alpha chain): [1:249](score: 294.9, e-value: 3.6e-88)<br>\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [352:676](score: 166.7, e-value: 8.3e-49)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00263 (trpB: tryptophan synthase, beta subunit): [306:688](score: 577.6, e-value: 2.8e-174)<br>\n \n  TIGR00262 (trpA: tryptophan synthase, alpha subunit): [1:249](score: 222.7, e-value: 8.5e-67)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001264 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity<br>\n  \n   PF00290.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001264\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001264-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001264\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAATCGCTCTGCTCTTGTGACGTATGTCACTGCTGGCTTCCCAAAGGTCGAAGCCACTACAGATATCCTAGTGGCTATGGAAGACGGAGGTGCCGACATCATCGAATTGGGAATCCCATTCACAGATCCAATTGCCGACGGCCCTACGATACAAAAATCAAACACCCAAGCCTTAGCGCAGGGAGCGAACCTGAAATCTACATTGGAGACTGTGAGACAAGCCAGGGCAAAAAATGTCAAAGCGCCCATCATTCTAATGGGTTATTACAACCCTTTGCTAATGCATGGAGAGGAAAAAATTGTTACAGAAGCTAAGGACGCTGGTGCTAATGGATTTATCGTGGTGGATCTTCCTCCTGAAGAGGCTATCCGTTTTCGCGGTCTTTGCAAAACCCACTCGATGAGTTATGTTCCTTTGATTGCACCAAGTACAAATGAGTCCAGGCTTGCCCTTTTGTGTTCGATAGCCGATTCTTTCATCTATGTGGTCTCACGGATGAGTACGACTGGTGCATCTGCGGGATCGATGAGTGCTTCTTTACCTCAGTTATGTGCTCGCGTGCGGAGAGTATCTAATAATGCACCCATCGCGGTTGGGTTTGGCGTGAGCACAAGGGATCATTTTTTGTCTGTGGGGGAGATTGCTGATGGTGTTGTCATCGGTAGTCAAATTGTGAATGTCCTCAACTCTGCAATTGCCGATAACAGAGACTTGTGTAGAGCAGTACAAGAGTATTGTACCGGGATTACCACGCGAACCGAGTCCACCACCAGAATTGTCGGCCTCGTCGAATCCATAGATAAAGCAATCAATACGCAGGAGACAACCCCGTCCGCGGTCGTGACTGCCGCAGATGTTCCGAACGGAGTGCACACGTCTAATGGTAGTTTCGCTGATGGCTCTACGGCATCTACCCGATTTGGAGAGTTCGGTGGCCAGTACGTTCCTGAGTCACTTATAGATTGTCTCGCAGAATTGGAGAAGGGGTCAAACGACGCTTTTAAAGATCCAGAATATTGGAAGGATTTTAGGTCGTATTACCCATACATGAGTCGACCCAGCTCACTCCACTTAGCCGAGAGACTGACTAAGCACGCTGGAGGTGCCAAAATTTGGCTCAAACGAGAAGACCTGAATCACACTGGAAGCCACAAGATAAATAACGCAATTGGCCAAATTCTTATCGCGCGTAGACTTGGAAAGTCGGAAATCATTGCAGAGACCGGAGCTGGCCAGCACGGCGTTGCCACTGCAACTGTTTGTGCAAAGTTTGGCATGAAGTGTACAGTTTACATGGGAGCAGAAGATGTGCGTCGACAGGCCTTAAATGTATTTCGGATGAAGCTACTTGGTGCTCAGGTAGTGGCTGTTGAAATAGGCTCACGGACGCTTCGGGATGCTGTCAATGAGGCATTGCGGGCATGGGTCGAAAGATTAGATACCACTCACTACCTCATTGGGTCCGCAATTGGACCGCACCCATTTCCAAAAATTGTTCGTGTTCTGCAAAGCGTTATTGGTCAGGAAACAAAGTTGCAAATGGCCGAGTACCGCGGCAAACTTCCCGACGCTGTTATCGCATGTGTTGGTGGAGGCAGTAACGCAGCCGGAATGTTCTCTCCATTTGCGGACGATGCCTCCGTAAAGTTACTAGGTGTTGAAGCGGGAGGCGATGGTGTTGATACGGCTCGTCACAGCGCTACCCTTGTGGGTGGATCTAAAGGAGTACTGCATGGAGTTCGGACGTATATCCTACAAAATGAGGACGGCCAGATAAGCGAAACGCACTCAGTCTCTGCAGGGCTAGATTATCCTGGAGTCGGTCCAGAACTCTCCATGTGGAAGGACTCGAATAGGGCGCAGTTTATCGCCGCCACAGACTCTCAAGCTTTCGAAGGCTTTCGTCTTTTAAGCCAGTTGGAAGGGATTATCCCAGCTCTTGAGTCTGCTCACGCTGTATATGGAGCTGTGGAACTTGCCAAAACCATGTCCGAAAATGAGGATATTGTCATTTGCGTTTCCGGAAGAGGAGATAAAGACGTGCAAAGTGTCGCCGAGGAACTTCCCCGGCTAGGACCCAAAATCGGTTGGGATTTACGATTCTAA",
    "translation": "MNRSALVTYVTAGFPKVEATTDILVAMEDGGADIIELGIPFTDPIADGPTIQKSNTQALAQGANLKSTLETVRQARAKNVKAPIILMGYYNPLLMHGEEKIVTEAKDAGANGFIVVDLPPEEAIRFRGLCKTHSMSYVPLIAPSTNESRLALLCSIADSFIYVVSRMSTTGASAGSMSASLPQLCARVRRVSNNAPIAVGFGVSTRDHFLSVGEIADGVVIGSQIVNVLNSAIADNRDLCRAVQEYCTGITTRTESTTRIVGLVESIDKAINTQETTPSAVVTAADVPNGVHTSNGSFADGSTASTRFGEFGGQYVPESLIDCLAELEKGSNDAFKDPEYWKDFRSYYPYMSRPSSLHLAERLTKHAGGAKIWLKREDLNHTGSHKINNAIGQILIARRLGKSEIIAETGAGQHGVATATVCAKFGMKCTVYMGAEDVRRQALNVFRMKLLGAQVVAVEIGSRTLRDAVNEALRAWVERLDTTHYLIGSAIGPHPFPKIVRVLQSVIGQETKLQMAEYRGKLPDAVIACVGGGSNAAGMFSPFADDASVKLLGVEAGGDGVDTARHSATLVGGSKGVLHGVRTYILQNEDGQISETHSVSAGLDYPGVGPELSMWKDSNRAQFIAATDSQAFEGFRLLSQLEGIIPALESAHAVYGAVELAKTMSENEDIVICVSGRGDKDVQSVAEELPRLGPKIGWDLRF",
    "product": "hypothetical protein"
   },
   {
    "start": 4296,
    "end": 5780,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001265",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001265</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001265</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001265-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,296 - 5,780,\n (total: 1485 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001265 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00013.32 (KH domain): [158:220](score: 52.1, e-value: 4.6e-14)<br>\n \n  PF00013.32 (KH domain): [253:318](score: 55.5, e-value: 4.1e-15)<br>\n \n  PF00013.32 (KH domain): [343:409](score: 55.9, e-value: 3e-15)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001265 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00013.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001265\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001265\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGACCAGAGCTCTTTGGCTTCGATCTTAGCAGCGCTGAGTCAAGCGCAGGCAGCTCAGCAGAGACAAAGCGGGGGTAACTTGTCTGACTCAAGACCTGCCCCCCCGATGCAACAACAACTCGGTGCGACAAATTCAGGCGGAGCAATGGGCAATAGCTACGGCTACCCGCCTCCCCCTTCCTCATCGGGTGCTATTGATCTGTCTACTCTCAAACCGTCAAATTCTGGTAGCATGTCCTTTGCAGACCCACGATTTGGCGCCTCTGGGCTCAACTCAACGTCGCCAATGATGTCTTCCAACTATTATGACCAGGGAAGAAATGGTGGTTATGATGATAGTCGTAGGCGAAGGCGGTCTAGGTCTCGATCAGGAAGTAGAGAGAGGAGTCCTTATGGCTACAGACGAAGGGACCGCGAAAGATCATACAGCCCTCCGCGACGGGGTGGAGGATCTTCTCCAGATAGGGATACAATGGTCATTGACGTAGCGTTTGTGGGATTGATTATCGGGCGTGGTGGCGAGACTTTAAGACGGCTGGAGAATGATACTGGGGCGAGAGTTCAATTTGTTCCAGACGAAGCTAGAACTGCAAAATTTCGAACGTGCCATATCACGGGAACAAGTTCCCAAGTCCGAGCGGCTCGTCGGGCTCTACAATTTATTATCAATGAAAATCTTGCTGCAAAGACGGCGCAAGGAAAGACACATGGCACACCCTCAATTAAAACGACTCCTAGCGAGGGCCAAATAAGTGTGCAGATAAATGTCCCTGACCCTACAGTCGGTCTAGTTATTGGTAAGGGTGGCGACACTATAAAAGATCTGCAAGATCGCTCGGGCTGTCATATCAACATTGTCGATGAGAGTCAAAGCTCTGGCGGACTGCGTCCAGTAAATCTAATTGGATCTGACGCGGCCATAAAGAGAGCCCAAAAGCTTATTGAGGAGATAGTGAATAGCGACACGAATGGAAAACCAAGGATTTCAGTCACGAGCGATGTGGCAGGTTCTAGTGTGCAAGTTACTGAAGTCATCAGTGTTCCTATGGACTCGGTGGGGATGATAATAGGCAAAGGTGGTGAGACTGTGAAAGAAATGCAGCACAATACGCAATGCAAGATCAACGTCTCTAGTCAATACTCGCCTTCCGACCCTACACGCGATATTACACTAAGTGGTTCACCAGAAACTATAAGAAGGGCCAAAGAAGCCATACAAGAGAAAATCGAGGCCGTTAATTTGCGAAAACAGAGTATGCAATCACCGCCCCAAAATACCGGGAGCCAATACAATAACTCCACGAGCGCTGCAACTGGAACTAACTCTTTCGACGCTTCAAGCCTTGCGAACTTGTATGGTGCGGCTGGTACGGGGCCCTCGTCATCATCTACCCCAACTAACAACCAAGCTGACCCTTATGCCGCCTATGGAGGCTACCAAAACTATGTTGCAATGTGGCAACAATGGTATGTGTTTTGA",
    "translation": "MADQSSLASILAALSQAQAAQQRQSGGNLSDSRPAPPMQQQLGATNSGGAMGNSYGYPPPPSSSGAIDLSTLKPSNSGSMSFADPRFGASGLNSTSPMMSSNYYDQGRNGGYDDSRRRRRSRSRSGSRERSPYGYRRRDRERSYSPPRRGGGSSPDRDTMVIDVAFVGLIIGRGGETLRRLENDTGARVQFVPDEARTAKFRTCHITGTSSQVRAARRALQFIINENLAAKTAQGKTHGTPSIKTTPSEGQISVQINVPDPTVGLVIGKGGDTIKDLQDRSGCHINIVDESQSSGGLRPVNLIGSDAAIKRAQKLIEEIVNSDTNGKPRISVTSDVAGSSVQVTEVISVPMDSVGMIIGKGGETVKEMQHNTQCKINVSSQYSPSDPTRDITLSGSPETIRRAKEAIQEKIEAVNLRKQSMQSPPQNTGSQYNNSTSAATGTNSFDASSLANLYGAAGTGPSSSSTPTNNQADPYAAYGGYQNYVAMWQQWYVF",
    "product": "hypothetical protein"
   },
   {
    "start": 6228,
    "end": 8909,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001266",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001266</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001266</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001266-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,228 - 8,909,\n (total: 2682 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001266 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [631:761](score: 137.8, e-value: 3.1e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [784:819](score: 29.8, e-value: 4.3e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001266 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001266\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001266-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001266\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGCCAAAAGTCCCTGTGAATTGGGGTGTAGGTACACCAAACGGTCTATGTTACAAATGCCTTCGGTCTCTTTATGCAAAACGCACGATTTCATCACAGGTCTCCTCAAATGCCCTTGCTCTTGATCCTTCAAAGGTTACGACCGGGCAACCAGACGACGACGGCCCGTCTGATGAGAACAACCACGAAGATATAGCCCGCTCTAATCAGGCTTCAGAGTCGTTTGGTAGACCACGCAGGTCTCGGGGTCGACCAATTGGTTCGAAATCGCAATCACGGCGACCGAAGGTAAAATGTTCGCTTACATCAAATGGCCTCTACAAGCCATTGGTACCAAGATGGTTCATCGAAGAGAACGTCAAACTTGCGAAAATACTAAAGAAAACAGAAATCAGCACATCTGCGACCTCAATACTGGCTGATAATGCAATCGGAGATGTAAGTGAGACTAAATTGGGGCATCCGGACCTCGATAAGAATATCTGGCAAGAATTGATGGCTCATATACGGACAGCTCTAACTTTGGGAACTTCTATTTCTGGTCATCGATATCACAGAACATCTACGGACCGCAACGACAGTATCCTCCTTCTATGTCCACAAGAAGGAGGTACTTTTTACCTTGATGAAATAATAGAGCATGCGGGTGCTCATTTGGACGTTGACATTATCAGAATTGATCCTCAAGATCTTCAACAATTAGCCGGGAATTTGTACGAATCCGCAGAAACAAACGAACCCATGCCTCTCTCCTTTAGATCACTTGGCTACTTGGCCGCAAGACGTACCGAGCAGCACCAAACGACAGAGAACGAGGACTATGAGGATCCCTCGGAAGATATGGATGGCGAAACAGATGATTACAATGATCTCGGCGTACGACCAGGTGATGCTTCAGGGAGAAAGCTAACACCTGTGCACCTTTTGACTGGTCAAGATCGTATTATAGTTACCCCTGCAGACGTGGTTTCGAACGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAAGTTCGGAGACGGCGCTCGAGCCAATCATCGGAAAGCGGTTTGGGGATTTTCTGATCTGCACAACCTTGGCAACGGACGCATCAGAACATGA",
    "translation": "MTPKVPVNWGVGTPNGLCYKCLRSLYAKRTISSQVSSNALALDPSKVTTGQPDDDGPSDENNHEDIARSNQASESFGRPRRSRGRPIGSKSQSRRPKVKCSLTSNGLYKPLVPRWFIEENVKLAKILKKTEISTSATSILADNAIGDVSETKLGHPDLDKNIWQELMAHIRTALTLGTSISGHRYHRTSTDRNDSILLLCPQEGGTFYLDEIIEHAGAHLDVDIIRIDPQDLQQLAGNLYESAETNEPMPLSFRSLGYLAARRTEQHQTTENEDYEDPSEDMDGETDDYNDLGVRPGDASGRKLTPVHLLTGQDRIIVTPADVVSNEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDAKFGDGARANHRKAVWGFSDLHNLGNGRIRT",
    "product": "hypothetical protein"
   },
   {
    "start": 8929,
    "end": 10419,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001267",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001267</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001267</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001267-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,929 - 10,419,\n (total: 1491 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001267\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTTGCGCGTTAGTCCCCGACGAGTAGTTCTTTCTTTGGTACTCATCGGGGCTGTTTCTCTTTTCCTTTTCAGTCTTTTGCCGGCGCTAAAGTTCCTACTTGAGGCTGTGTTACGGTCATTTAAAAGGCAACGAAGTTACACAGACATTGAGCTTGATATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAGAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCTTCTCTATATTTGCTTCAAAGTTGTACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGAGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGGTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
    "translation": "MLRVSPRRVVLSLVLIGAVSLFLFSLLPALKFLLEAVLRSFKRQRSYTDIELDMPSLIPRCPIYTFHDTDTTSSTDELEVIAVWRKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLERLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILGFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
    "product": "hypothetical protein"
   },
   {
    "start": 10691,
    "end": 14758,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001268",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001268</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001268</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001268-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,691 - 14,758,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 242.4; E-value: 1.2e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.9, e-value: 1.2e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 257.1, e-value: 1.5e-76)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1899.2, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 379.2, e-value: 5.1e-114)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 347.9, e-value: 1.8e-104)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001268\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001268-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAACCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAGGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCCGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACCTTCCTAGATCACACCAATGAGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGGAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATTGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAATTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAATTAAGTACGATTGGAGGACGCGGAGGGAATAAAATAGAATCAGGCTAG",
    "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
    "product": "hypothetical protein"
   },
   {
    "start": 14772,
    "end": 15355,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001269",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001269</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001269</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001269-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,772 - 15,355,\n (total: 546 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [0:39](score: 33.5, e-value: 3.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001269 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001269\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001269-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
    "translation": "MTHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 10690,
    "end": 14758,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 15641,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r106c1"
 },
 "r176c1": {
  "start": 1,
  "end": 12356,
  "idx": 1,
  "orfs": [
   {
    "start": 146,
    "end": 1933,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001801",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001801</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001801</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001801-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 146 - 1,933,\n (total: 1524 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001801 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [114:140](score: 22.3, e-value: 0.00011)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [142:182](score: 41.8, e-value: 7.4e-11)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [184:223](score: 30.3, e-value: 3.1e-07)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [224:264](score: 49.4, e-value: 3.2e-13)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [279:308](score: 23.6, e-value: 4.1e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [313:348](score: 23.4, e-value: 4.9e-05)<br>\n \n  PF00514.26 (Armadillo/beta-catenin-like repeat): [354:391](score: 31.8, e-value: 1.1e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001801 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00514.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001801\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001801\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGAAATTGTTGCAGCTGCTGCAGTTGCTGCGGAGGTATCCTTCTATCTGGATTTTGGGCTTACGTGGAAGGTGACTCCCAGGATGCAGGATACGACCCCATCCTTGCTGAGAGCGAAAGAGAAGCTGTCGCAGACCTTCTCCAGTACCTTGAAAATCGGAATGAGGTGGATTTCTTCAGCAGAGGACCGTTGGGAGCGCTGAGTACACTCGTGTATTCTGATAACGTCGATCTGCAGAGAAGCGCGGCCTTGGCTTTCGCTGAAATCACAGAAAAGGGTACGCATGCATATGACATTCTATCTAACGACCCAGATGTACGGGAGGTCGACCGAGACACGTTGGAACCTATTTTGTCTTTATTGCAGAGCCAGGATATTGAGGTTCAACGTGCTGCCAGCGCGGCTCTTGGGAACCTCGGCGTAAACAACGAAAACAAAGTAGCCATTGTCAAACTCGGAGGATTGGATCCTTTGATCAAGCAAATGATGTCATCAAATGTAGAAGTTCAATGTAATGCTGTGGGGTGTATCACAAACCTGGCGACGCATGACGAGAACAAATCGAAAATCGCGCGTTCTGGGGCACTTGTACCCCTTACTAGACTAGCCAAGTCAAGGGACCTGCGCGTTCAACGAAATGCTACAGGAGCTCTATTGAATATGACTCATTCCGATGAAAACAGGCAGCAGCTTGTCAATGCCGGCGCAATACCAGTGCTCGTCCACCTCTTAACTTCTCAAGACTCTGATGTCCAATACTACTGCACTACTGCGCTAAGCAACATCGCAGTTGACGCTTCGAACCGCAAGAAACTGGCAAATTCCGAGCCTAGGTTGGTGCAAGCGCTCATCGCTTTGATGGAGTCATCTAGCCCAAAAGTGCAATGCCAATCAGCTCTGGCGCTGCGCAATCTCGCGTCGGACGAGAAATATCAACTCGATATTGTGCGGTCTAATGGGTTGCCTGCTCTCTTACGTTTATTACAATCTTCCTTCCTAGCTCTGATACTTTCAGCAGTCGCTTGTATACGCAATATCTCTATTCACCCGCTAAACGAGTCGCCTATCATTGATGCTGGTTTCCTAAGGCCTTTGGTCGAACTTCTTGGTTCGACGGATAATGAAGAGATTCAATGTCATGCCATCTCCACCTTACGGAATCTAGCGGCAAGCTCAGAACGAAATAAAAAAGCCATTGTTGAAGCGGGAGCAATTCAGAAATTGAGCGACTACACACCTCTCTTGAATGCATGGAAGGAACCAGACGGAGGTTTCAAAGGCTACCTAGAGCACTTTCTCTCTAGTGGTGATGGTGCGTTTCAGCACATTGCCACATGGACCGTCCTACAGCTCCTGGAAGCTGACGAGCCGGATGTCAAAGCCCTGATTGTGGAAAGTCCGGAAATTGTGCGGGCGATTCGTCAGACGGCTGAGCGAGAACCGCAAACTGATGACGATCCCGAAGGAGAAGGCGAAATTGTGCCTCTTGTCAGGCGGGTTGTGGAACTAATCGACCAGTGA",
    "translation": "MGNCCSCCSCCGGILLSGFWAYVEGDSQDAGYDPILAESEREAVADLLQYLENRNEVDFFSRGPLGALSTLVYSDNVDLQRSAALAFAEITEKGTHAYDILSNDPDVREVDRDTLEPILSLLQSQDIEVQRAASAALGNLGVNNENKVAIVKLGGLDPLIKQMMSSNVEVQCNAVGCITNLATHDENKSKIARSGALVPLTRLAKSRDLRVQRNATGALLNMTHSDENRQQLVNAGAIPVLVHLLTSQDSDVQYYCTTALSNIAVDASNRKKLANSEPRLVQALIALMESSSPKVQCQSALALRNLASDEKYQLDIVRSNGLPALLRLLQSSFLALILSAVACIRNISIHPLNESPIIDAGFLRPLVELLGSTDNEEIQCHAISTLRNLAASSERNKKAIVEAGAIQKLSDYTPLLNAWKEPDGGFKGYLEHFLSSGDGAFQHIATWTVLQLLEADEPDVKALIVESPEIVRAIRQTAEREPQTDDDPEGEGEIVPLVRRVVELIDQ",
    "product": "hypothetical protein"
   },
   {
    "start": 2024,
    "end": 3328,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001802",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001802</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001802</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001802-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,024 - 3,328,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325.2; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001802 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.3, e-value: 3.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001802 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001802\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001802-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001802\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAAATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGCAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCGTGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
    "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTAEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVVAMDKEQVKRKRKLRAG",
    "product": "hypothetical protein"
   },
   {
    "start": 4101,
    "end": 4541,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001803",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001803</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001803</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001803-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,101 - 4,541,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001803\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001803\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
    "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
    "product": "hypothetical protein"
   },
   {
    "start": 4596,
    "end": 5618,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001804",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001804</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001804</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001804-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,596 - 5,618,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001804 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001804\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001804\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCAGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACGGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
    "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
    "product": "hypothetical protein"
   },
   {
    "start": 6145,
    "end": 6846,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001805",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001805</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001805</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001805-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,145 - 6,846,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001805 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [68:221](score: 147.6, e-value: 2.3e-43)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001805\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001805\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGGCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
    "translation": "MTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEGKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
    "product": "hypothetical protein"
   },
   {
    "start": 6888,
    "end": 7937,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001806",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001806</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001806</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001806-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,888 - 7,937,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001806 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 207.4, e-value: 2.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001806\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001806\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCGAGGAAGCTCCTGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGACGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACACAGGCGTGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTCGGGAAGCGCGGCCGCTCCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
    "translation": "MSSRKLLSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDTGVSSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRSKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
    "product": "hypothetical protein"
   },
   {
    "start": 8539,
    "end": 9063,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001807",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001807</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001807</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001807-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,539 - 9,063,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001807 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.0, e-value: 1.4e-08)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001807 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001807\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001807\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAGGACATAAAGTGTAATAAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAATGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
    "translation": "MDEDIKCNKVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
    "product": "hypothetical protein"
   },
   {
    "start": 9428,
    "end": 10356,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001808",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001808</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001808</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001808-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,428 - 10,356,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001808 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001808 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001808\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001808\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
    "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
    "product": "hypothetical protein"
   },
   {
    "start": 10410,
    "end": 11351,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001809",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001809</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001809</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001809-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,410 - 11,351,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001809 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.4, e-value: 1.6e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001809\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001809\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGAACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGACAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
    "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKNEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVTGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
    "product": "hypothetical protein"
   },
   {
    "start": 11421,
    "end": 12288,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001810",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001810</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001810</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001810-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,421 - 12,288,\n (total: 868 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:251](score: 198.3, e-value: 1e-58)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 53.6, e-value: 5.1e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001810 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001810\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001810-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001810\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCCCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGA",
    "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQ",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 9427,
    "end": 10356,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 12356,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r176c1"
 },
 "r181c1": {
  "start": 1,
  "end": 12202,
  "idx": 1,
  "orfs": [
   {
    "start": 1534,
    "end": 2052,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001837",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001837</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001837</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001837-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,534 - 2,052,\n (total: 519 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001837\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001837\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTCAGCGAATTGCAGCAAAGTGGACTATCAGAAATGACCCAATTAGTGGATCTGCCCTCTTTCGAACTCAAAACACATGAGAATGTGCAAGCATGTGAAATGGCAACAGCGTACTTCTTGGCTTGTATATCTATACGGAGAATCATGAACCGTGTACATGGCCTGCTCTATCAAGACGACAGCAGTAGAGAGCAAAATATGACGGCCATCGTGCAAGAACTCGACCATCAGCTCGAAGAATGGTACGAACTGCTTCCTCCGCACATGCAATTTCGAAGAGGTCTCGGACCTTGTCAGAATGACTTGCAAGCCCATCTTAGTCAACGTCACAATGCCTGTAAGTCTACGCTCTTTCGATTCATCCTCCAACAAACTATCCAATTTGATCATGACTTTACAGATGGATATGTGCGGGAAGCTTGCAAAAGCTGCCTTGATGCGTGTTGTTTGCACATATTGAACGTAGATCTATGGCCTCAGGTCGTCTTTGTGGATGTTTGGATTTGTGCATTAGCGTGA",
    "translation": "MSELQQSGLSEMTQLVDLPSFELKTHENVQACEMATAYFLACISIRRIMNRVHGLLYQDDSSREQNMTAIVQELDHQLEEWYELLPPHMQFRRGLGPCQNDLQAHLSQRHNACKSTLFRFILQQTIQFDHDFTDGYVREACKSCLDACCLHILNVDLWPQVVFVDVWICALA",
    "product": "hypothetical protein"
   },
   {
    "start": 2455,
    "end": 3744,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001838",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001838</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001838</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001838-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,455 - 3,744,\n (total: 1290 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1100:3-hydroxyisobutyrate dehydrogenase (Score: 206.6; E-value: 9.1e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001838 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [7:104](score: 45.7, e-value: 7.3e-12)<br>\n \n  PF03446.18 (NAD binding domain of 6-phosphogluconate dehydrogenase): [133:287](score: 117.6, e-value: 6.2e-34)<br>\n \n  PF14833.9 (NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase): [299:420](score: 92.5, e-value: 2.3e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001838 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03446.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding<br>\n  \n   PF14833.9: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001838\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001838-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001838\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAACAGACTGAGAAACATCTCAGGGCCCTCCACTTGGCAACAGCGTTTGAAGCCATTGCACTTGGAACTGCTTCAGGGCTGAATGGCTCCCAACTGTACACTATCTTTTCCACATCCGCTGCGCAGTCATGGACGTTCAACTACGTCATTCCGAATCTATTAAGTGGGAAAGCTTTACCCTTTGATGTAGATGAAGCTCTAGACGATATTCAGGAAATACTAAAGCAAGCGAATGAATGTGGATTCTTCAGTCCAATGACTAGCGTAGTTGAACAATATCTTTTATCGGTCAAAGCATCTGGGGGCGTTCACAAGTACTATGAGACACTTGGCGTCTCTTCTTTGAAACAGAAGAATTTTACTCCCTCTCGACTCCCTTCATCTTCCAGAAAACCGACCGTTGGATTTGTTGGCCTTGGAGCTATGGGTCTGGGTATGGCTAGTATTCTATATAAAGCAGGGTTTGCTGTCAAAGGATTCGATGTGTTTCCGCAAAGTGTTGAAAAGTTCGTGACTGTGGGAGGACAAAGGGCTGCTTCTGCTGCTGAAGCGGCCATTGGAGTTGAAGTACTGTTGATCATGTGCGCTACTTCTGCACAAGCTGACACTATTCTTTTCGGGGAAGATGGAGCTGCCTCCAAAATGAGTAAAGGAGCGGTTGTTCTCCTCTGTGCAACTGTCGCACCATCATATATAACAGAATTAAATCAGAAGCTCGCCCGCAGTGCCATTAAGCTAGTGGACGCGCCTGTCTCGGGCGGTACTTATCGCGCCGCCAGTGGCGAGCTTTCCATTATGTGCTCCGGCGATACGGAAACGCTACAAATTGTTTCCCCCGTACTAAATGCATTAGCCGGCAAAGAAGAGAATGTCTACGTTATTGAAGGCAAAGTAGGGTCTGGTTGCAAAGTCAAAATGGTGAATCAAGTTCTTGCTGGTACACAATGTGTCTGCACCGCGGAAGCACTTGCCTTTTCAGTGGCTAGGGGACTGGTTGCAATGGACGTATATGAATGGATTTCATCGTCTCGTGGAGCTTCATGGATGTGGTCAAATCGAGGTCATCATATGGTAACTGGAGACTTTTCCCCATTATCGGCTACAACTATCTTCATCAAAGACATGAACATTGTTGTCTCAGAAGCAAGAAGGCTTGGGCTGCCATCGGTTTGCTCTTCCATGGCACAGCAGTTATTTATTCTGTCCGCCGCAGCTGGACATTCAAAAGATGACGATTCAAGTGTTGTAAAAGTATGGGAAAAAGCATGTGGAATTAAGACCTACTAA",
    "translation": "MEQTEKHLRALHLATAFEAIALGTASGLNGSQLYTIFSTSAAQSWTFNYVIPNLLSGKALPFDVDEALDDIQEILKQANECGFFSPMTSVVEQYLLSVKASGGVHKYYETLGVSSLKQKNFTPSRLPSSSRKPTVGFVGLGAMGLGMASILYKAGFAVKGFDVFPQSVEKFVTVGGQRAASAAEAAIGVEVLLIMCATSAQADTILFGEDGAASKMSKGAVVLLCATVAPSYITELNQKLARSAIKLVDAPVSGGTYRAASGELSIMCSGDTETLQIVSPVLNALAGKEENVYVIEGKVGSGCKVKMVNQVLAGTQCVCTAEALAFSVARGLVAMDVYEWISSSRGASWMWSNRGHHMVTGDFSPLSATTIFIKDMNIVVSEARRLGLPSVCSSMAQQLFILSAAAGHSKDDDSSVVKVWEKACGIKTY",
    "product": "hypothetical protein"
   },
   {
    "start": 4008,
    "end": 5471,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001839",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001839</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001839</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001839-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,008 - 5,471,\n (total: 1464 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 140.6; E-value: 1.2e-42)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001839 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00067.25 (Cytochrome P450): [34:426](score: 139.2, e-value: 1.8e-40)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001839 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen<br>\n  \n   PF00067.25: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001839\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001839-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001839\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGCTTTCGGCATCTTGTCATTGGCAGGTTTTACAACCGGATATCTAGTCTGGAGGTTTCTTACCAGATTACCAGCAGGAATCCCGAATGCAGTGGGTAGATTGCCAGTTGTCGGCGCCGCCCAGGAATTAGGGGAAGATCCCATTGGATTTCTAACCAAGCATCGCCGAAAATTAGGAGATGTTTTCTCCGTAGACGTCATCTTTTTCCGCATTGTATTTGTGCTGGGTAATACTTCGGTGAGTCAATTCCTCAAGAATAAGGAAAAGGACTTTAGCTTTTGGGATGCGGTTGCCAAGGCACAGCCATTATTAGGTCCATCAGTACGCGATGTGGCATGGAAGGAAAAGATCCTCACCATCATTCCCGCAGCTCTTAGAAATAACGATCGCTTAGTGGATTTTGGAAGCGTGATTGCCCAAATTACTTCCGAGCATTACTTGGAATGGTCCAAGCAGCCTTCAGTACCGCTTTTGGAATCCGTGATCGATATGCAGGTATCATGTTTTATCGCTGCTTTCTTTGGGATTGATTTTCTAAAAGAGCAGGGAGAGGAGTTGAAGAAGAACATGTTAATGTACGACATATTGTCCTCGAATCCCGCGCTTCGCCTTCTTCCATATCGACTTTGTTCATCAGGGCGGCGGTGCATTAAGACTTTTAAGAACATGGACGATATCATCAGCAACGAAATTCAAAAGCGGCTGACAAACTCTGAAAAACATGCCGGGAAAACTGATTATTTACAGCAGGTGCTGACTATGGTAAACGGCAAACACCTCGAGCATATTCCAGCTCATATGTTCGCAATGGCATTAGCGGGTAAAGCAAATACTGTTGGCACATTTATATGGACATTTTTGCATATTAAATGCAGACCAGAGTTACTAGAACCCTACTTGGAGGAATTATCCTCTGTACGCCCTGATTCGAATGGGCTCTACCCCTTTGATGAGATGCCATTTGGGCATGCTTGCATGCGTGAAACAAACCGAATGTACACGAATCTAATGTCTATGGCAAGAATATGTAAAAAGAGCATTGCGATTCAAGATACCATGGGGAATAAGCTAGAATTACCAGCAGGCACTATGACAATTGCTTCGCCCTTGGTCACTTCTCGAGACGAAGAAATTTTTCCAGATCCACATCACTACGATCCGTTTCGATTTCTTGATACGAAAAGCATTGACGTCTTGTACAGAGATTTCAAGATCAACACATTTGGTGCTGGTCCACATAAGTGTCTGGGAGAAAAGCTTGCGCAGATCGTGCTTCGGGGTATTGGTTGGCCTGTGCTGTTTGCAAACTACAACGTTGATATAGTCTCTGGCTTGCAGGAAGGGAAGGGAACGGACGGAGTCGGTGTTGAGTCGCAATGGATGAAGTACAACAATGGAACACCAGTGTATGATGATTTGAAGTATAATGTACAAATAACTGTCACGAGGAAGAAATAA",
    "translation": "MAAFGILSLAGFTTGYLVWRFLTRLPAGIPNAVGRLPVVGAAQELGEDPIGFLTKHRRKLGDVFSVDVIFFRIVFVLGNTSVSQFLKNKEKDFSFWDAVAKAQPLLGPSVRDVAWKEKILTIIPAALRNNDRLVDFGSVIAQITSEHYLEWSKQPSVPLLESVIDMQVSCFIAAFFGIDFLKEQGEELKKNMLMYDILSSNPALRLLPYRLCSSGRRCIKTFKNMDDIISNEIQKRLTNSEKHAGKTDYLQQVLTMVNGKHLEHIPAHMFAMALAGKANTVGTFIWTFLHIKCRPELLEPYLEELSSVRPDSNGLYPFDEMPFGHACMRETNRMYTNLMSMARICKKSIAIQDTMGNKLELPAGTMTIASPLVTSRDEEIFPDPHHYDPFRFLDTKSIDVLYRDFKINTFGAGPHKCLGEKLAQIVLRGIGWPVLFANYNVDIVSGLQEGKGTDGVGVESQWMKYNNGTPVYDDLKYNVQITVTRKK",
    "product": "hypothetical protein"
   },
   {
    "start": 5649,
    "end": 8699,
    "strand": 1,
    "locus_tag": "MARS19BIN38_001840",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001840</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001840</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001840-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,649 - 8,699,\n (total: 3051 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 125.3; E-value: 4e-38)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001840 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [24:321](score: 125.8, e-value: 1.8e-36)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [536:606](score: 31.7, e-value: 1.5e-07)<br>\n \n  PF07993.15 (Male sterility protein): [657:891](score: 143.6, e-value: 6.5e-42)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001840 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [654:1015](score: 213.5, e-value: 1.2e-63)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001840\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001840-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001840\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTTTTCTTAGTGTGAATGAGCTGTTGGATGCTCGAGCACGCGATGACGGGGATGTTGATATCATCAACGATCCGGACTCGAATTTCAACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGATGGCAGAATCAAGGAGATGGTGTTTTGGAGCTTGTCGTACTTGATGGTTGGCCGTCCAAGGTTTTGACCAACAATGCTGACGGTTCGTACTCTTCGAAAGATTTATTTATCTGCCACCCTACTATCCCACAAGCCTTCAAATGCATTGGAAGATTAGACGATATTATTACGATGGTGACTGGCGAGAAGACCAACCCAATAGCCACAGAATTGCGACTCCGAGAGTCGCCGCTCATATCGGAAGCCATCATGTTTGGAATAGGTAAAGCTGCATGTGGCGTCCTAATTCTGCCATCTTACGTGGAAAATAGAGGTTTAAGCTCCTTGTCCGAAAGCGAGCTGGTTGACATGATTTTCCCAGAAGTACAAAGGGTGAATCGTTACATCGAGAGTCATGCACAAATTTCGAGAGACATGGTAAGAGTGCTTTCTCCTGATGCCATATTACCGCGAGCAGACAAAGGAAGCATATTGAGACCGGCAGTGTGTCGAATGTTTGCAAAGCTTATTGAAGACACGTACATTGCTGCGGAAAGCAGCAGTGGTTTCAAAGCAAAAATATCACAGTCAGATCTGCGGGTGTATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATTCATGGTCTTGGTAACGGTATGACTATTGACGATCAAGACGAAGAGAAGAAAATGTTTGATTTGGTTAATAAATACTCTACTTTTCCAAAAAGCCGGGCTGTTGAGCACGAACTGGAACCATCTCAGCACTCACCTAAATTGCACCACATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATTTGTGATTTAACTTTCAGCAGTCCTCAACCTGTCGAAGGCAATCCTATGTGGCACGTAGTGAGTCCCCATACTTCTACATCCTGGAAGCAAATTCTCGGGTATTTGGCGCAGAGTGGTCTGAAGTTCAAAGAGGTTGACCAGTGGACTTGGTTGGTTAGATTATCAGTGTCCGAGCCTGATCCGATACGAAACCCTTCAATAAAACTGTTGGGTTTTTATCAAAACAAGTATGGCGCGAAGGAGCCACGAGTGAGCAAAATCTACGGTACCCAAAGAGTGCAGCAGGACTCAAAAACATTCAGGCAAATTGCTGCTATTGATGGATCATTAGTCGGAAAGTTTGTGTCTGCATGGAAGGAGGTGGGGTTTTTGTCATGA",
    "translation": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSVSEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
    "product": "hypothetical protein"
   },
   {
    "start": 8704,
    "end": 10566,
    "strand": -1,
    "locus_tag": "MARS19BIN38_001841",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_001841</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_001841</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_001841-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,704 - 10,566,\n (total: 1863 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_001841 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00172.21 (Fungal Zn(2)-Cys(6) binuclear cluster domain): [13:45](score: 37.8, e-value: 1.6e-09)<br>\n \n  PF04082.21 (Fungal specific transcription factor domain): [159:385](score: 91.6, e-value: 4.4e-26)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_001841 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF00172.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n   PF04082.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_001841\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_001841-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_001841\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "AAGCCTCGCTTATGCGAAGATGCGAGGGTGCGGGTAACCCGTGCGTGTGATGCGTGCAAGAGGAAGAAAGTGCGCTGTGACGGGACAGCACCGTGCGGCAGGTGTATCAGCCATAATGTCGTTTGCCGGTACGAAGCACCATACCTGCGTCGGAAGCAGTCTCACATCAGCACGGAGGTGGAGAAGCGCGAAGATGATGAGTCTATGCAGCCCAGCAGAAGCAGTAGCAGTGGCCGGGAGTATCATGATACAAATGTCAAGAGGGAATGCAATATTGGAGAAAAGTCATTGCGAGATCCTGACGACATGGAAGACATTGGGGGGAGTTCCTCGATTGCGTTTCTCAATCGCGCTCGTCGGAGATTGGAGAGGTATCGAGCTTCTGCACGCTTTTCATTCGGCGATTCTCAAATCCCAGATTTTGATGCTGCCAGTTTTGTGCTTCCGTCCGTGGATGAAGCTCGGCATCTTGTGGCCTACTACTTTGATTACATTGCTTCAACTCATCGTTTCCTTCATCGTCCGACTATTGAGTCTCAACTGGAATCCTTCTACTCTGACCGTAATCTAATTATGTGTGGAAGATCACTCGACAGATGCATCTGTGCCTCGCTATTTACGATATTTGCACAAGCTTCTTTGTACCTTCATCCATGTCCCGACTCTGGCGTATCGTACTATCTGGCGGCAGAGCGACAGGTGGAATCCCAGCAAGGTACAAAACTGGAATCCGTGCAGGCCAGACTTCTCATGGTATTGTATTTGCTAATGTCGTCTCGCTTTAATCGAGCTTGGTCATTACTTGGTACTACGATACGAATGGCACAAGTACTTGGGCTACATAGAAAGCATGACAGAAAACAAGGAAATGTTGTCGAGATGGAGTCTAGCAAACGCACATTCTGGACATGCTATGTTGTCGATCGTACGCTCAGTGTCCTGCTCGGAAGACCATGTGCTATCCATGATCTGGATGTCGATCAGGACCTGCCGCGTCTTGTAGACGATGACGATCTCCACCTCCGTCTCAATGAGGATGGCCATATCACCTGCCCTCTTTCTATTTCAAATCAGACTTTGATAGGGGCATCTTGTGAACACATCAAGCTCTCACAGATCGTCTCTGCGATTTTATCTGATTTCTATAGCGCGAAAAAAGTGGTCCGTGAATGTTTAGCTGAGAATCATCTATACCGTCTTTCGATGTGGAAAGGAAATTTGCCACCTTTCTTGGACGCAGAGAAACCTGAACCAGACACGTTGGTACCGATAATCAAGCGTGCAAGGATTACATTACAGTTTGCCTATCATCACGCGATGATGCTCGTCTACCGTCCTTTCCTTCTTGCATCCCCAAACGAATTCTCACCAGCATGGGTGGAGACTGCGACTTCGGAGTGCCTTCGTCTTTCTGGCCTCCTTGTATCATTTACAACCAATCTTGCTCAGCAGGGTATGCTGACTGGCGCCTTTTGGTTCAGTATCTACAATGCATTCAATGCTATCTTGATTGTCTACGTGCACACAATTCAAAACGTGTTTCCAGGCATGGTACCCTCTGATATCTTTAGCATTGCAGAAAACTGTGAGGAAACTTTGAATGCTCACACGCAAGGAAATGTATTGGCACAGAGATACCTCGCAGTGCTGCAAGAACTAAGAAGCGAGATAAAGGAGCAGATGTCCTCTTGTGATTCTGCAAATGCTGGACTGGACCTTCTGCTGGAGGCACCAAACTTGGCAGCACGTCCACAGAATAGCGATTGGTATGCATTTGACACCTTCTTGATGGATACTTTGACGGGACAGCTCTTTGAGTCAGATCCACAGACGCAACTGGCACAATCACAAATAGCCTTGTAA",
    "translation": "MPRLCEDARVRVTRACDACKRKKVRCDGTAPCGRCISHNVVCRYEAPYLRRKQSHISTEVEKREDDESMQPSRSSSSGREYHDTNVKRECNIGEKSLRDPDDMEDIGGSSSIAFLNRARRRLERYRASARFSFGDSQIPDFDAASFVLPSVDEARHLVAYYFDYIASTHRFLHRPTIESQLESFYSDRNLIMCGRSLDRCICASLFTIFAQASLYLHPCPDSGVSYYLAAERQVESQQGTKLESVQARLLMVLYLLMSSRFNRAWSLLGTTIRMAQVLGLHRKHDRKQGNVVEMESSKRTFWTCYVVDRTLSVLLGRPCAIHDLDVDQDLPRLVDDDDLHLRLNEDGHITCPLSISNQTLIGASCEHIKLSQIVSAILSDFYSAKKVVRECLAENHLYRLSMWKGNLPPFLDAEKPEPDTLVPIIKRARITLQFAYHHAMMLVYRPFLLASPNEFSPAWVETATSECLRLSGLLVSFTTNLAQQGMLTGAFWFSIYNAFNAILIVYVHTIQNVFPGMVPSDIFSIAENCEETLNAHTQGNVLAQRYLAVLQELRSEIKEQMSSCDSANAGLDLLLEAPNLAARPQNSDWYAFDTFLMDTLTGQLFESDPQTQLAQSQIAL",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 5648,
    "end": 8699,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 12202,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r181c1"
 },
 "r419c1": {
  "start": 1,
  "end": 7247,
  "idx": 1,
  "orfs": [
   {
    "start": 130,
    "end": 1434,
    "strand": -1,
    "locus_tag": "MARS19BIN38_003094",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003094</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003094</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003094-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 130 - 1,434,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003094 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003094\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003094\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCAGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTTCAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCAATCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCAACAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTGCGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
    "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGSGGSAINPYASGNEIGQGAGGMGQPAAFSGEIRSAPTSHGGSPNTSPPLLSDHAPVIQSTLSPFARDSGMSASSTPTGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLATPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
    "product": "hypothetical protein"
   },
   {
    "start": 1704,
    "end": 2735,
    "strand": -1,
    "locus_tag": "MARS19BIN38_003095",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003095</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003095</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003095-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704 - 2,735,\n (total: 1032 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003095 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [27:235](score: 122.2, e-value: 2.5e-35)<br>\n \n  PF03129.23 (Anticodon binding domain): [255:302](score: 21.1, e-value: 0.00029)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003095 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003095\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003095\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCCTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTTCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
    "translation": "MTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSEFISRDLEFGTDRNGDQHPKKKDTK",
    "product": "hypothetical protein"
   },
   {
    "start": 2998,
    "end": 4977,
    "strand": 1,
    "locus_tag": "MARS19BIN38_003096",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003096</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003096</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003096-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,998 - 4,977,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003096 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003096 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003096\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003096\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCCCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCGTCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTTCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCATGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
    "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
    "product": "hypothetical protein"
   },
   {
    "start": 5816,
    "end": 6996,
    "strand": 1,
    "locus_tag": "MARS19BIN38_003097",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003097</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003097</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003097-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,816 - 6,996,\n (total: 1125 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [1:270](score: 108.6, e-value: 4.1e-31)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [0:312](score: 354.6, e-value: 1.2e-106)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003097 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003097\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_003097-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003097\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTATAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTAGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTGTATGCATTTTCTCAGAGGCATCTAATTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
    "translation": "MLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACAVCIFSEASNYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 5815,
    "end": 6996,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 7247,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r419c1"
 },
 "r463c1": {
  "start": 1,
  "end": 6779,
  "idx": 1,
  "orfs": [
   {
    "start": 67,
    "end": 1401,
    "strand": -1,
    "locus_tag": "MARS19BIN38_003267",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003267</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003267</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003267-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 67 - 1,401,\n (total: 1335 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [134:418](score: 159.4, e-value: 1.3e-46)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03462 (CarR_dom_SF: lycopene cyclase domain): [1:74](score: 53.4, e-value: 6.7e-15)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS19BIN38_003267 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003267\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003267\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTATGGTACCTTGGAGGAGCGTATATCATCCGCCGTTGGCGGACTACCTTTGGAGTAATTCTACCAGCTACTCTGTATTTCTGTTTAGTCGATACTTTTGCGATTCGACGTGGCATTTGGCAAATATCAAGCCATACAAGCTTAGACGTGCATGTCTGGGATGGCCTTCCAGTAGAAGAAGCGTCCTTTTTTTTTGTTACAACTTTCTTGGTTGTTTGCGGATCCGCATGTTTTGAAAAGGCTTTTATTATTCTGCATACGTTGTCCAATTTTCGAGGCACCGAATCTTCTGTTGGCGGGGTAAGCTTTTCTTATTTCACGGACTTGCTAGGTGGTCTACTGCAGAACAGCGTTGTACCACTGAGCGTGATTGAAGACATCAGCAGCTGCATCGATACTTTGAAGCAAGCAAGTTCTTCATTCTACTCTGCTAGTTTTCTTTTCCCTCCCAACGTGCGACAGGATCTTTGTGTATTATATGCATTTTGTCGAGTGTCAGATGATGTCGTCGATGAGTCTAATGGCAAAAGCCAGTCCTGGAAACGTCAGCAATTGAATGAGATGAGATCATTCATTGATGAGCACTTTTTACCTGCAGAGGATTTTGGACGTGGACCCCCTCGGTTACTGAAAAGCAAAATGTGTAGGCATGCTTTTGCATCCCATCGCGCGCTGGTCTATTCGCTTTCGCACAAGGTCCCACGTGGCCCATTTATGGAACTTCTTAGAGGTTATGACTATGATCTGCGCAGCGAAGAGAATGATCCCCAGAGTGAGATTCAAAACGAGAGTGACTTAAGAGCATATTGTGCCAACGTTGCCAGCAGTGTTGCGGAGATGTGCTTGTGGCTTATGTGTGATTCTCGGCATTGGGAAAGGACGATAGAGAGTACTTCATTTACTCTAGTGAAGATCAAAGCAAGAGAAATGGGAGAAGTCTTGCAATTAGTCAATATCACTCGGGACGTTCTTTCAGATGCTCTTATTGGGCGTGTTTATATACCATCGAACCACTTCAGGTCCAAGTCCGATCGCAGCAAACTTGTCGCGTTGGGTCGTAGCAGTACAAAAGATACCATAGGGGAGGCTACCTCAATGTTGGACCTCGAAAGTTGCGCTTTAATGCTTTTGAGGATGGCTGAAATTATGTATGAGCCGGCACGAGAGGCTATTCAACACCTGCCACGAGAATGTCGCCCGGGTGTACGAGCAGCGACTGATGCGTATTGGCATATGGGGCGTAAATTGAAAGTGGAATTGTGTAAAGTAACTCCACTGCTCCTGAGCAGTAAAAAGTACGAAAATAACGAAAATACTTGGAGTCGCGCCTAA",
    "translation": "MLWYLGGAYIIRRWRTTFGVILPATLYFCLVDTFAIRRGIWQISSHTSLDVHVWDGLPVEEASFFFVTTFLVVCGSACFEKAFIILHTLSNFRGTESSVGGVSFSYFTDLLGGLLQNSVVPLSVIEDISSCIDTLKQASSSFYSASFLFPPNVRQDLCVLYAFCRVSDDVVDESNGKSQSWKRQQLNEMRSFIDEHFLPAEDFGRGPPRLLKSKMCRHAFASHRALVYSLSHKVPRGPFMELLRGYDYDLRSEENDPQSEIQNESDLRAYCANVASSVAEMCLWLMCDSRHWERTIESTSFTLVKIKAREMGEVLQLVNITRDVLSDALIGRVYIPSNHFRSKSDRSKLVALGRSSTKDTIGEATSMLDLESCALMLLRMAEIMYEPAREAIQHLPRECRPGVRAATDAYWHMGRKLKVELCKVTPLLLSSKKYENNENTWSRA",
    "product": "hypothetical protein"
   },
   {
    "start": 2085,
    "end": 3722,
    "strand": -1,
    "locus_tag": "MARS19BIN38_003268",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003268</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003268</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003268-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,085 - 3,722,\n (total: 1638 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003268 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF07534.19 (TLD): [305:491](score: 61.0, e-value: 1.5e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003268\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003268\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTCAAGGCCACAGTTCAACCCCACAAAACCAAGAAGATGTGGGGCTGCTTTTTGCTCACAGATGTGCCAAGTTGGCATTGAAGGAAGTTGAACTTTACACATTCAAAAGGAACTTTGCTGAACTGGCGGATGAAACAGACGGATTACTATATTGGCCTGCACCTACATTTTTGAGATTTCTTGGGATCCCGGATATTTTTGACGTGGGAGAGATACTTTTTTCTTCTGCTTCATACATTGCAGCGTTTCCTTTTCCCCACAGCCTAGCTCCATCACCTTTAACACTGGAAAATTTACTGAAAGTCATCGTTATTTTTACAGGCCGCCTTCATCTGGTTGTTAAAAGCCAAGATAATATAACAAAGCTCTTGTTTGACTCGTTTGCCGTCTTTGATCGCTCGGCAGAGAGGGCATCTGAAGAACAGACTGAAGAATTCGATCTAAAAACTTTAGAGTCCTTGGATGAGATACAAGTACTGCATTTACACGACAAGGTGGAGATGGGTACAATTCCTGTATCCACTTTTCGAAAGCTATTGGTTTTTCTTCTCGCCATTCGACATCAAAAGCCCAACGAACCGCTTGCGGCACATATAGTTCGGTTTACGTCGGCAAATGTTGCAGATTTGCAGAAAATTGCTGACGGCATTATTGCAGCTCTTGTTGGAGAAGAGAATGAAATGATAAATTTTCCGGCCTTCAAAACTTATTTTGAACGATCTATGCCATTTCTTTTTGAGCCGATGGGAGCCCTATTTGGACGCTTCTTCTATTCGCAGAAGGATTTACAAATCCCGAAAAGTGTCACCTCCAATGAACATTCTCACACAGAGGGAGCCATGGGTGCAAGTGTTTCGGCGCTTTTGGCTCTCTTCCTACCTGCTACTAGACTTGCGAAAGCTAATAATGTGTTGTATATTGGAAGTCGGGATGGGTTCTCCATGAACAGCTTTGAATCCCACGTATTCAAATACAACGCACCTACCTTGCTTTTAATTAGAGGTCGTCGGTTTGCGTTTGAAGGAAAGTCAAAACAAGAGGAAGACTTCCTAGCCAGTTTGCCGACAAGAAGATATCAATCAGGCTATGGTACTGGAGAGGACCTGCTATTTGGTGCGTTAATCAATACGGCATGGAATCATACTACACACGGTACAATTGGTGATAAGAGATCCCTCTTATTCCAATTGCGCCCTCACTTTGAAGTTTATCCTGCTTCGTCTGTACAAAAATACGTTTACTTCTCCAAAACGCTGGGAATTGGCTTTGGCCATGAACCATACCAGCCCAAAAAATATACAACTGATGGCCTCGGTCCACTTTCCCTATATCTAACTTCTTCGTTGGATTATGGGGTATTTCGTCACCTTGGGCCGGGTGGTGGATATGTAGCCTCCGAGTCCAGAAGGAGACATGAGAACATAGAGGAGATATTTGAAATACTAGAGTTGACGGTCTATGGGATTGGTAGCGAGGAAGACGGCCAAAAGCAGAAAGAAGCTTGGGAATGGGAGGCGAATGAAGCCGAAAAACGGCGGCATGTTAATTTGGGTGGGGATCTCGAAGAAAACAGGAGTCTGTTAGAACTAGTGGGAATATTGGATACCGACAGGCGTAGCGGGGGCAGCGTTTGA",
    "translation": "MGQGHSSTPQNQEDVGLLFAHRCAKLALKEVELYTFKRNFAELADETDGLLYWPAPTFLRFLGIPDIFDVGEILFSSASYIAAFPFPHSLAPSPLTLENLLKVIVIFTGRLHLVVKSQDNITKLLFDSFAVFDRSAERASEEQTEEFDLKTLESLDEIQVLHLHDKVEMGTIPVSTFRKLLVFLLAIRHQKPNEPLAAHIVRFTSANVADLQKIADGIIAALVGEENEMINFPAFKTYFERSMPFLFEPMGALFGRFFYSQKDLQIPKSVTSNEHSHTEGAMGASVSALLALFLPATRLAKANNVLYIGSRDGFSMNSFESHVFKYNAPTLLLIRGRRFAFEGKSKQEEDFLASLPTRRYQSGYGTGEDLLFGALINTAWNHTTHGTIGDKRSLLFQLRPHFEVYPASSVQKYVYFSKTLGIGFGHEPYQPKKYTTDGLGPLSLYLTSSLDYGVFRHLGPGGGYVASESRRRHENIEEIFEILELTVYGIGSEEDGQKQKEAWEWEANEAEKRRHVNLGGDLEENRSLLELVGILDTDRRSGGSV",
    "product": "hypothetical protein"
   },
   {
    "start": 4636,
    "end": 6388,
    "strand": -1,
    "locus_tag": "MARS19BIN38_003269",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS19BIN38_003269</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS19BIN38_003269</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS19BIN38_003269-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,636 - 6,388,\n (total: 1719 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PALP<br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 75; E-value: 7.4e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00291.28 (Pyridoxal-phosphate dependent enzyme): [79:372](score: 259.6, e-value: 4.1e-77)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [385:476](score: 57.5, e-value: 9.6e-16)<br>\n \n  PF00585.21 (C-terminal regulatory domain of Threonine dehydratase): [487:569](score: 72.0, e-value: 2.8e-20)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS19BIN38_003269 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01124 (ilvA_2Cterm: threonine ammonia-lyase, biosynthetic): [65:568](score: 666.0, e-value: 7.5e-201)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS19BIN38_003269\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS19BIN38_003269-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS19BIN38_003269\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGGCGATTCGCATCAATCGTAGCAATGGTCCTTCGAACGGGACGACTACACAGAGCCCTGGTGCAAGCTACGACATTGGTTCCCCGCCAACGGTCAGTGCTCTGACGGAGTACGGCACTTCTCCGCAGCCGGACGAAACTACGAATGAAGCAATTCTACCATCATCTCTACTGTCACCGTCGGGATATCCCGACTATCTTCGACTCATTCTGACTTCAAAGATCTACGAAGTATGTGAAGAAACACCTCTGACACACGCCATCAATCTCAGCAATCGCTTGGGCTGCAAGGTGATCCTTAAGCGTGAAGACCTACAACCAGTCTTCTCCTTTAAGATACGTGGGGCGTATAACAGAATCGCACACATTCCAGCTGAAGAGCGTTGGAAAGGCGTGATTGCCTGCTCTGCAGGTAATCATGCACAAGGGGTCGCCTTTGCTGCCCAGCACCTAAAAATCCCGGCCACAATCGTAATGCCAGAAGGTACGCCATCCATCAAGCATAAAAACGTTTCGCGAATGGGGGCCAAAGTCGTGCTGTATGGTCCTGATTTTGATGCTGCCAAGGAGGAGTGTGCGAGACTGGAGAAAGTGCATGGTCTCATCAATATCCCGCCATACGACGACCCCTATGTTATTGCCGGGCAAGGAACCATCGGAATGGAAATCTTAAGGCAGACCAAAATTAAAGAACTGGAGGCAATATTTTGTTGTGTAGGAGGCGGCGGTCTGGTTGGAGGTATAGCAGCATACGTGAAACGTATTGCACCGCACGTCAAAATATATGGAGTGGAAACATTTGACGCCTGTGCCATGAAGAAAAGTATGTGCCAAAAAAGACGAGTCGTTCTTGATGAGGTGGGCTTGTTCGCAGATGGGGCTGCGGTTAAAGTAGTAGGTGAAGAGCCATTCAGACTATGTCAAGCATATTTGGATGACATAATATTGGTGACAACTGATGAGGTTTGTGCTGCCATAAAAGACGTTTTTGAAGATACGCGCAGTATTGTTGAACCTGCAGGCGCTTTAGCAGTCGCCGGTCTTAAGAAATTTTTACATTTAAAAAAGGAACCCCCAACATCATCATCGAATTCGTATTGTGCGATTCTCTCAGGTGCGAATATGAACTTCGATAGGTTAAGATTTGTAGCAGAAAGAGCTGCTCTTGGTGAACAGAAGGAAGCTTTCATGTTGGCTATGATCCCTGAGAGGCCGGGAAGTTTCCTACAACTGATTTCCGTGATCTCACCTCGTGCAGTAACTGAATTCAGCTATCGATACAGTGCAAAAAGTAGCGACGCTGCTGTATACATATCCTTCGCTGTCAATGATATCGAAGTAGAGGTTCCTGCAATCATAGACCAGCTTCGTGACCTCAATATGACTGCAGAAGATTTAAGCGAAAACGAACTGGCGAAAAGCCATGCCAGATACATGGCTGGCGGAAGACAAGTTGTGCCCAATGAACGTCTTTTTCGGTTCGAATTCCCAGAGCGACCATTCGCCCTCTTCAAGTTTCTCTCCAATCTTAAAGTTGGGTGGAATATAACCCTTTTTCATTACAGGAATCATGGCTCGGATATTGGCCAAATTCTGTGTGCAATTCAAGTAAGCTCTTCCGACGAAGCTGTACTTCAAAAATTCCTCAAGAATCTCGGATATCCATGGAAGGAAGAGACGTCAAACTCTGTGTACCGCAACCTCATGTCTGTCTGA",
    "translation": "MAAIRINRSNGPSNGTTTQSPGASYDIGSPPTVSALTEYGTSPQPDETTNEAILPSSLLSPSGYPDYLRLILTSKIYEVCEETPLTHAINLSNRLGCKVILKREDLQPVFSFKIRGAYNRIAHIPAEERWKGVIACSAGNHAQGVAFAAQHLKIPATIVMPEGTPSIKHKNVSRMGAKVVLYGPDFDAAKEECARLEKVHGLINIPPYDDPYVIAGQGTIGMEILRQTKIKELEAIFCCVGGGGLVGGIAAYVKRIAPHVKIYGVETFDACAMKKSMCQKRRVVLDEVGLFADGAAVKVVGEEPFRLCQAYLDDIILVTTDEVCAAIKDVFEDTRSIVEPAGALAVAGLKKFLHLKKEPPTSSSNSYCAILSGANMNFDRLRFVAERAALGEQKEAFMLAMIPERPGSFLQLISVISPRAVTEFSYRYSAKSSDAAVYISFAVNDIEVEVPAIIDQLRDLNMTAEDLSENELAKSHARYMAGGRQVVPNERLFRFEFPERPFALFKFLSNLKVGWNITLFHYRNHGSDIGQILCAIQVSSSDEAVLQKFLKNLGYPWKEETSNSVYRNLMSV",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 66,
    "end": 1401,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 6779,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r463c1"
 }
};
var details_data = {
 "nrpspks": {
  "r106c1": {
   "id": "r106c1",
   "orfs": [
    {
     "id": "MARS19BIN38_001268",
     "sequence": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNEIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSLTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVIVSASIHQRKEFHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 223,
       "end": 688,
       "predictions": [
        [
         "substrate consensus",
         "Aad"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQTIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRYLPSGQVECSGRADSQVKIR",
       "dna_sequence": "TTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTAATTGATCCGTCGTATCCCCCTGAGAGACAGACTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCTGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTCCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATACCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 821,
       "end": 888,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEID",
       "dna_sequence": "GCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 944,
       "end": 1194,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEIDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCASGKAKSLTFVSTTSVLDCEYYTELSDKILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYIIREASKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNITPVDFVAKVI",
       "dna_sequence": "CTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAATCGACGTCGTGATTCACAACGGGGCGCAAGTTCATTGGGTATATCCGTACGCAAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTTCTGGCAAAGCCAAAAGCTTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAAAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATCATCCGTGAAGCTAGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCACCCCCGTGGATTTTGTAGCCAAAGTTATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 223,
       "end": 1194,
       "complete": true,
       "iterative": false,
       "monomer": "Aad",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r181c1": {
   "id": "r181c1",
   "orfs": [
    {
     "id": "MARS19BIN38_001840",
     "sequence": "MSFLSVNELLDARARDDGDVDIINDPDSNFNYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVRWQNQGDGVLELVVLDGWPSKVLTNNADGSYSSKDLFICHPTIPQAFKCIGRLDDIITMVTGEKTNPIATELRLRESPLISEAIMFGIGKAACGVLILPSYVENRGLSSLSESELVDMIFPEVQRVNRYIESHAQISRDMVRVLSPDAILPRADKGSILRPAVCRMFAKLIEDTYIAAESSSGFKAKISQSDLRVYLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFIHGLGNGMTIDDQDEEKKMFDLVNKYSTFPKSRAVEHELEPSQHSPKLHHIILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKIICDLTFSSPQPVEGNPMWHVVSPHTSTSWKQILGYLAQSGLKFKEVDQWTWLVRLSVSEPDPIRNPSIKLLGFYQNKYGAKEPRVSKIYGTQRVQQDSKTFRQIAAIDGSLVGKFVSAWKEVGFLS",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 30,
       "end": 341,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "NYRRYTYNSLLGIASGLAADYEQRGIVPVDDANVIGILSKSGFHYIVNVLALLRLGWCVLYLSPNNSSAALAHLINTTKASRLLIQPSFSKAAEDANLLLEADRLPTVAVALIEEKENWEVCAYYQPKYSPQQESKRAAFIIHSSGSTGFPKPITISHSASTYNFAQNFDKTGIVTLPLYHAHGHCTFFRALHSKKRLCMYPSSLPLTCENLLHVIGDVQPQAFYAVPFVIKLLAERDSGIQALASMDLVTFGGAPCPDELGDILVNKGVNLVGHYGMTEVGQIMTSARDYEKDKGWNWVRLPKHVQPYVR",
       "dna_sequence": "AACTATAGAAGATATACATATAATAGTCTTCTGGGCATCGCATCTGGACTGGCCGCAGATTATGAGCAGCGAGGTATCGTTCCAGTGGATGATGCCAATGTCATTGGAATTCTAAGTAAGAGTGGGTTCCATTATATTGTCAACGTCTTAGCACTTCTTCGCCTGGGCTGGTGTGTTCTTTATCTATCTCCAAACAATTCATCTGCAGCTTTAGCCCATCTTATCAACACAACCAAAGCCAGTCGTTTGCTAATACAACCAAGCTTCAGCAAAGCTGCAGAGGATGCAAATTTACTATTGGAAGCTGATCGATTGCCGACAGTCGCCGTTGCTCTGATTGAAGAGAAGGAAAACTGGGAAGTATGCGCTTACTATCAACCAAAGTATTCTCCACAACAAGAAAGCAAGCGAGCAGCGTTCATTATACATTCTAGCGGAAGTACGGGCTTTCCGAAGCCAATAACTATTTCGCATTCCGCGTCAACGTATAATTTTGCACAGAACTTCGACAAAACAGGAATCGTCACTCTACCCCTCTATCACGCTCATGGCCATTGTACTTTCTTTCGGGCCCTGCACTCCAAGAAACGGTTATGCATGTACCCTTCATCTCTTCCTCTTACATGCGAAAATTTACTCCATGTAATTGGAGATGTGCAACCTCAAGCATTTTATGCCGTTCCTTTTGTTATCAAACTACTAGCGGAGCGTGACTCCGGTATCCAGGCTCTGGCGAGCATGGATCTAGTGACTTTTGGTGGAGCACCTTGTCCCGATGAATTAGGAGACATCCTGGTCAACAAAGGAGTCAACCTTGTAGGACATTATGGGATGACTGAAGTTGGTCAAATCATGACTTCAGCGCGCGATTATGAGAAGGATAAAGGTTGGAACTGGGTACGACTTCCAAAGCACGTCCAACCCTATGTGCGA",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 535,
       "end": 606,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "YLKQLILEVMSNPSQARSLQFDDDLFAFGVDSLQSVRIRNAIQKHVELGGTLLGQNMIYENPSIDRMAAFI",
       "dna_sequence": "TATCTGAAACAACTGATACTCGAAGTCATGAGCAACCCAAGTCAGGCCAGATCTCTTCAGTTTGATGACGATCTATTTGCTTTTGGTGTCGACTCACTTCAAAGTGTTCGCATCCGTAATGCTATCCAGAAACATGTGGAGCTCGGCGGCACATTGTTGGGACAAAATATGATATATGAAAACCCTTCAATTGATCGGATGGCCGCATTCATT",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "TD",
       "start": 655,
       "end": 891,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IILTGATGSLGAHILTQLLQRPSVQKVYCLCRAKDDREAMQRVQNSLSTRKLVIDEVRVVVLSSSLGHSQLGLTPQRYEFLAKNATMVIHNAWAVNFNISTESFEADHIRGVHNLLRLCLKTGAEFFFSSSISATVGLATPNVYEQNYESPSAAQGMGYARSKWVAERIVNNYSQATGLRAGVLRIGQLVGDSRNGIWNQTEAISLIIKSAETTGCLPVLDESPNWLPVDLAAKII",
       "dna_sequence": "ATTATTCTGACTGGTGCAACGGGTTCTCTTGGTGCACATATTCTTACACAATTATTGCAGAGGCCATCCGTGCAAAAGGTTTATTGTCTATGCCGTGCAAAAGATGATAGGGAAGCAATGCAACGGGTACAAAATTCACTATCAACTCGCAAACTGGTCATTGACGAGGTTCGTGTTGTGGTACTCTCATCATCTCTTGGACATTCGCAACTCGGATTGACTCCTCAAAGATATGAATTCTTAGCTAAAAATGCAACAATGGTCATACACAATGCCTGGGCAGTCAACTTCAACATTAGCACGGAATCGTTTGAGGCCGATCACATCAGAGGGGTACACAATCTTCTACGCCTATGTCTTAAAACCGGAGCTGAATTTTTCTTTTCTTCATCCATCTCAGCGACTGTTGGGCTTGCCACTCCGAATGTATATGAGCAGAATTACGAAAGCCCAAGTGCAGCACAAGGCATGGGATACGCAAGGTCAAAGTGGGTAGCCGAACGTATAGTCAATAATTATTCACAAGCAACAGGCCTTCGAGCAGGCGTTTTGCGCATTGGTCAGCTCGTAGGCGACAGCCGAAATGGGATCTGGAACCAAACAGAAGCAATATCTTTGATCATCAAAAGCGCCGAGACTACCGGTTGCCTTCCTGTACTTGATGAATCTCCAAATTGGCTACCTGTCGATCTTGCAGCAAAAATTATT",
       "abbreviation": "TD",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 30,
       "end": 891,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r37c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "ANIA_01592",
         "query_loc": 1911,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "ctg1_orf003",
         "query_loc": 1911,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "PbGGS",
         "query_loc": 1911,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "sre2",
         "query_loc": 1911,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "PCH_Pc20g10860",
         "query_loc": 1911,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "MAA_07498",
         "query_loc": 1911,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "paxG",
         "query_loc": 1911,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "aspC",
         "query_loc": 1911,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        }
       ]
      },
      "BGC0002603: 0-17042": {
       "start": 0,
       "end": 17042,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "cle6",
         "query_loc": 1911,
         "subject_loc": 15140
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cle1",
         "start": 0,
         "end": 5488,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "cle2",
         "start": 6016,
         "end": 7840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle3",
         "start": 8160,
         "end": 9796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle4",
         "start": 10463,
         "end": 12174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle5",
         "start": 12298,
         "end": 13388,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle6",
         "start": 14479,
         "end": 15802,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "cle7",
         "start": 16259,
         "end": 17042,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001776: 15-68182": {
       "start": 15,
       "end": 68182,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "janG",
         "query_loc": 1911,
         "subject_loc": 25660
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGZ20477.1",
         "start": 37970,
         "end": 39783,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20479.1",
         "start": 55985,
         "end": 56864,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20481.1",
         "start": 8038,
         "end": 10182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20482.1",
         "start": 11347,
         "end": 12946,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20483.1",
         "start": 15,
         "end": 7575,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20484.1",
         "start": 13487,
         "end": 14403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20485.1",
         "start": 15278,
         "end": 19054,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20486.1",
         "start": 21161,
         "end": 23932,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20489.1",
         "start": 50327,
         "end": 51298,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20490.1",
         "start": 54127,
         "end": 55251,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20491.1",
         "start": 60609,
         "end": 62903,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20492.1",
         "start": 63320,
         "end": 64772,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20493.1",
         "start": 65225,
         "end": 68182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janA",
         "start": 27459,
         "end": 28569,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janB",
         "start": 31349,
         "end": 32144,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janC",
         "start": 33286,
         "end": 34406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janD",
         "start": 44432,
         "end": 45819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janG",
         "start": 25022,
         "end": 26299,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "janM",
         "start": 29235,
         "end": 30817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janO",
         "start": 46882,
         "end": 48450,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janP",
         "start": 34798,
         "end": 36641,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janQ",
         "start": 40479,
         "end": 42545,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "ANIA_01592",
         "query_loc": 1911,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "ctg1_orf003",
         "query_loc": 1911,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "PbGGS",
         "query_loc": 1911,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "sre2",
         "query_loc": 1911,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "PCH_Pc20g10860",
         "query_loc": 1911,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "MAA_07498",
         "query_loc": 1911,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "paxG",
         "query_loc": 1911,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "aspC",
         "query_loc": 1911,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        }
       ]
      },
      "BGC0002603: 0-17042": {
       "start": 0,
       "end": 17042,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "cle6",
         "query_loc": 1911,
         "subject_loc": 15140
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cle1",
         "start": 0,
         "end": 5488,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "cle2",
         "start": 6016,
         "end": 7840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle3",
         "start": 8160,
         "end": 9796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle4",
         "start": 10463,
         "end": 12174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle5",
         "start": 12298,
         "end": 13388,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle6",
         "start": 14479,
         "end": 15802,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "cle7",
         "start": 16259,
         "end": 17042,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001776: 15-68182": {
       "start": 15,
       "end": 68182,
       "links": [
        {
         "query": "MARS19BIN38_000557",
         "subject": "janG",
         "query_loc": 1911,
         "subject_loc": 25660
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGZ20477.1",
         "start": 37970,
         "end": 39783,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20479.1",
         "start": 55985,
         "end": 56864,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20481.1",
         "start": 8038,
         "end": 10182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20482.1",
         "start": 11347,
         "end": 12946,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20483.1",
         "start": 15,
         "end": 7575,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20484.1",
         "start": 13487,
         "end": 14403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20485.1",
         "start": 15278,
         "end": 19054,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20486.1",
         "start": 21161,
         "end": 23932,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20489.1",
         "start": 50327,
         "end": 51298,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20490.1",
         "start": 54127,
         "end": 55251,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20491.1",
         "start": 60609,
         "end": 62903,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20492.1",
         "start": 63320,
         "end": 64772,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20493.1",
         "start": 65225,
         "end": 68182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janA",
         "start": 27459,
         "end": 28569,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janB",
         "start": 31349,
         "end": 32144,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janC",
         "start": 33286,
         "end": 34406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janD",
         "start": 44432,
         "end": 45819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janG",
         "start": 25022,
         "end": 26299,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_000557"
         }
        },
        {
         "locus_tag": "janM",
         "start": 29235,
         "end": 30817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janO",
         "start": 46882,
         "end": 48450,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janP",
         "start": 34798,
         "end": 36641,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janQ",
         "start": 40479,
         "end": 42545,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_000556": {
     "functions": []
    },
    "MARS19BIN38_000557": {
     "functions": [
      {
       "description": "fung_ggpps",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_000558": {
     "functions": []
    },
    "MARS19BIN38_000559": {
     "functions": []
    },
    "MARS19BIN38_000560": {
     "functions": []
    },
    "MARS19BIN38_000561": {
     "functions": []
    },
    "MARS19BIN38_000562": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_000556",
      "seqLength": 286,
      "domains": [
       {
        "start": 208,
        "end": 272,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GST_C_6",
        "accession": "PF17171",
        "description": "Glutathione S-transferase, C-terminal domain",
        "evalue": "1.3e-12",
        "score": "47.5"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000557",
      "seqLength": 333,
      "domains": [
       {
        "start": 42,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "1.1e-66",
        "score": "224.6"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000558",
      "seqLength": 241,
      "domains": [
       {
        "start": 0,
        "end": 38,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "3.8e-07",
        "score": "29.6"
       },
       {
        "start": 39,
        "end": 235,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "1.5e-56",
        "score": "191.7"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000559",
      "seqLength": 739,
      "domains": [
       {
        "start": 59,
        "end": 242,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "HAD",
        "accession": "PF12710",
        "description": "haloacid dehalogenase-like hydrolase",
        "evalue": "2.4e-24",
        "score": "87.0"
       },
       {
        "start": 379,
        "end": 630,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "GCV_T",
        "accession": "PF01571",
        "description": "Aminomethyltransferase folate-binding domain",
        "evalue": "1.7e-87",
        "score": "293.1"
       },
       {
        "start": 656,
        "end": 733,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "GCV_T_C",
        "accession": "PF08669",
        "description": "Glycine cleavage T-protein C-terminal barrel domain",
        "evalue": "2.1e-18",
        "score": "66.1"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000560",
      "seqLength": 945,
      "domains": [
       {
        "start": 2,
        "end": 66,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "C2",
        "accession": "PF00168",
        "description": "C2 domain",
        "evalue": "7e-11",
        "score": "42.5"
       },
       {
        "start": 161,
        "end": 259,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "C2",
        "accession": "PF00168",
        "description": "C2 domain",
        "evalue": "1e-16",
        "score": "61.2"
       },
       {
        "start": 691,
        "end": 899,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004609' target='_blank'>GO:0004609</a>: phosphatidylserine decarboxylase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008654' target='_blank'>GO:0008654</a>: phospholipid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "PS_Dcarbxylase",
        "accession": "PF02666",
        "description": "Phosphatidylserine decarboxylase",
        "evalue": "1.2e-57",
        "score": "194.8"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000561",
      "seqLength": 404,
      "domains": [
       {
        "start": 109,
        "end": 400,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0007059' target='_blank'>GO:0007059</a>: chromosome segregation",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051301' target='_blank'>GO:0051301</a>: cell division",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000444' target='_blank'>GO:0000444</a>: MIS12/MIND type complex"
        ],
        "html_class": "generic-type-other",
        "name": "MIS13",
        "accession": "PF08202",
        "description": "Mis12-Mtw1 protein family",
        "evalue": "2.3e-48",
        "score": "165.2"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000562",
      "seqLength": 93,
      "domains": [
       {
        "start": 0,
        "end": 86,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Thiamine_BP",
        "accession": "PF01910",
        "description": "Thiamine-binding protein",
        "evalue": "8.8e-24",
        "score": "83.4"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_000559",
      "seqLength": 739,
      "domains": [
       {
        "start": 375,
        "end": 734,
        "name": "TIGR00528",
        "description": "gcvT: glycine cleavage system T protein",
        "accession": "TIGR00528",
        "evalue": "3.9e-114",
        "score": "379.3",
        "html_class": "generic-type-other"
       },
       {
        "start": 57,
        "end": 251,
        "name": "TIGR01489",
        "description": "DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase",
        "accession": "TIGR01489",
        "evalue": "5.1e-27",
        "score": "93.1",
        "html_class": "generic-type-other"
       },
       {
        "start": 58,
        "end": 242,
        "name": "TIGR01488",
        "description": "HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB",
        "accession": "TIGR01488",
        "evalue": "7.4e-18",
        "score": "63.1",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000560",
      "seqLength": 945,
      "domains": [
       {
        "start": 685,
        "end": 890,
        "name": "TIGR00163",
        "description": "PS_decarb: phosphatidylserine decarboxylase",
        "accession": "TIGR00163",
        "evalue": "1.9e-36",
        "score": "123.4",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS19BIN38_000562",
      "seqLength": 93,
      "domains": [
       {
        "start": 0,
        "end": 88,
        "name": "TIGR00106",
        "description": "TIGR00106: uncharacterized protein, MTH1187 family",
        "accession": "TIGR00106",
        "evalue": "4.8e-25",
        "score": "86.0",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r106c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "perA",
         "query_loc": 12724,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "icoS",
         "query_loc": 12724,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "XNC1_2022",
         "query_loc": 12724,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "plu3123",
         "query_loc": 12724,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "plu3263",
         "query_loc": 12724,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "PLU_RS13235",
         "query_loc": 12724,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "X797_010654",
         "query_loc": 12724,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "AN5318.2",
         "query_loc": 12724,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 12724,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "BO96DRAFT_451379",
         "query_loc": 12724,
         "subject_loc": 6032
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "perA",
         "query_loc": 12724,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "icoS",
         "query_loc": 12724,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "XNC1_2022",
         "query_loc": 12724,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "plu3123",
         "query_loc": 12724,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "plu3263",
         "query_loc": 12724,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "PLU_RS13235",
         "query_loc": 12724,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "X797_010654",
         "query_loc": 12724,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "AN5318.2",
         "query_loc": 12724,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 12724,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS19BIN38_001268",
         "subject": "BO96DRAFT_451379",
         "query_loc": 12724,
         "subject_loc": 6032
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001268"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001268",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 223,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001268",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 821,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001268",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 944,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Aad"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_001263": {
     "functions": []
    },
    "MARS19BIN38_001264": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS19BIN38_001265": {
     "functions": []
    },
    "MARS19BIN38_001266": {
     "functions": []
    },
    "MARS19BIN38_001267": {
     "functions": []
    },
    "MARS19BIN38_001268": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_001269": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_001263",
      "seqLength": 196,
      "domains": [
       {
        "start": 120,
        "end": 193,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0035091' target='_blank'>GO:0035091</a>: phosphatidylinositol binding"
        ],
        "html_class": "generic-type-other",
        "name": "PX",
        "accession": "PF00787",
        "description": "PX domain",
        "evalue": "1.8e-15",
        "score": "57.5"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001264",
      "seqLength": 702,
      "domains": [
       {
        "start": 1,
        "end": 249,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004834' target='_blank'>GO:0004834</a>: tryptophan synthase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006568' target='_blank'>GO:0006568</a>: tryptophan metabolic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Trp_syntA",
        "accession": "PF00290",
        "description": "Tryptophan synthase alpha chain",
        "evalue": "3.6e-88",
        "score": "294.9"
       },
       {
        "start": 352,
        "end": 676,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "8.3e-49",
        "score": "166.7"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001265",
      "seqLength": 494,
      "domains": [
       {
        "start": 158,
        "end": 220,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "4.6e-14",
        "score": "52.1"
       },
       {
        "start": 253,
        "end": 318,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "4.1e-15",
        "score": "55.5"
       },
       {
        "start": 343,
        "end": 409,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding"
        ],
        "html_class": "generic-type-other",
        "name": "KH_1",
        "accession": "PF00013",
        "description": "KH domain",
        "evalue": "3e-15",
        "score": "55.9"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001266",
      "seqLength": 893,
      "domains": [
       {
        "start": 631,
        "end": 761,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity"
        ],
        "html_class": "generic-type-other",
        "name": "AAA",
        "accession": "PF00004",
        "description": "ATPase family associated with various cellular activities (AAA)",
        "evalue": "3.1e-40",
        "score": "137.8"
       },
       {
        "start": 784,
        "end": 819,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_lid_3",
        "accession": "PF17862",
        "description": "AAA+ lid domain",
        "evalue": "4.3e-07",
        "score": "29.8"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001268",
      "seqLength": 1355,
      "domains": [
       {
        "start": 223,
        "end": 688,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.2e-65",
        "score": "221.9"
       },
       {
        "start": 822,
        "end": 887,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "2.9e-12",
        "score": "46.8"
       },
       {
        "start": 944,
        "end": 1194,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "1.5e-76",
        "score": "257.1"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001269",
      "seqLength": 181,
      "domains": [
       {
        "start": 0,
        "end": 39,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab",
        "accession": "PF00006",
        "description": "ATP synthase alpha/beta family, nucleotide-binding domain",
        "evalue": "3.4e-08",
        "score": "33.5"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_001264",
      "seqLength": 702,
      "domains": [
       {
        "start": 306,
        "end": 688,
        "name": "TIGR00263",
        "description": "trpB: tryptophan synthase, beta subunit",
        "accession": "TIGR00263",
        "evalue": "2.8e-174",
        "score": "577.6",
        "html_class": "generic-type-other"
       },
       {
        "start": 1,
        "end": 249,
        "name": "TIGR00262",
        "description": "trpA: tryptophan synthase, alpha subunit",
        "accession": "TIGR00262",
        "evalue": "8.5e-67",
        "score": "222.7",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001268",
      "seqLength": 1355,
      "domains": [
       {
        "start": 6,
        "end": 1350,
        "name": "TIGR03443",
        "description": "alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase",
        "accession": "TIGR03443",
        "evalue": "0",
        "score": "1899.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 253,
        "end": 711,
        "name": "TIGR01733",
        "description": "AA-adenyl-dom: amino acid adenylation domain",
        "accession": "TIGR01733",
        "evalue": "5.1e-114",
        "score": "379.2",
        "html_class": "generic-type-other"
       },
       {
        "start": 941,
        "end": 1317,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "1.8e-104",
        "score": "347.9",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r176c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78746.1",
         "query_loc": 2675,
         "subject_loc": 38460
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78731.1",
         "query_loc": 2675,
         "subject_loc": 40302
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78732.1",
         "query_loc": 11854,
         "subject_loc": 42474
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78811.1",
         "query_loc": 2675,
         "subject_loc": 37915
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78812.1",
         "query_loc": 11854,
         "subject_loc": 40037
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78758.1",
         "query_loc": 2675,
         "subject_loc": 34368
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78759.1",
         "query_loc": 11854,
         "subject_loc": 36503
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "AQM37586.1",
         "query_loc": 2675,
         "subject_loc": 34794
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "AQM37587.1",
         "query_loc": 11854,
         "subject_loc": 36959
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78771.1",
         "query_loc": 2675,
         "subject_loc": 37337
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78772.1",
         "query_loc": 11854,
         "subject_loc": 39493
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78797.1",
         "query_loc": 2675,
         "subject_loc": 37336
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78798.1",
         "query_loc": 11854,
         "subject_loc": 39510
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78784.1",
         "query_loc": 2675,
         "subject_loc": 37336
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78785.1",
         "query_loc": 11854,
         "subject_loc": 39492
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000615: 0-35080": {
       "start": 0,
       "end": 35080,
       "links": [
        {
         "query": "MARS19BIN38_001810",
         "subject": "tpa10",
         "query_loc": 11854,
         "subject_loc": 32747
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "tpa1",
         "start": 0,
         "end": 429,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa10",
         "start": 31691,
         "end": 33803,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "tpa11",
         "start": 33886,
         "end": 35080,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tpa2",
         "start": 517,
         "end": 1195,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa3",
         "start": 1602,
         "end": 2130,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa4",
         "start": 2226,
         "end": 2616,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa5",
         "start": 3354,
         "end": 6822,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa6",
         "start": 6856,
         "end": 10735,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa7",
         "start": 10851,
         "end": 14034,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa8",
         "start": 30798,
         "end": 31170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa9",
         "start": 31172,
         "end": 31643,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaA",
         "start": 14404,
         "end": 14551,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaB",
         "start": 14688,
         "end": 15756,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaC",
         "start": 15805,
         "end": 17152,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaD",
         "start": 17179,
         "end": 17782,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaE",
         "start": 17793,
         "end": 19434,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaF",
         "start": 19423,
         "end": 20125,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaG",
         "start": 20216,
         "end": 22031,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaH",
         "start": 22027,
         "end": 23893,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaI",
         "start": 24007,
         "end": 24817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaJ",
         "start": 24878,
         "end": 26093,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaK",
         "start": 26672,
         "end": 29462,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaL",
         "start": 29496,
         "end": 30369,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaX",
         "start": 26462,
         "end": 26609,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002363: 0-22640": {
       "start": 0,
       "end": 22640,
       "links": [
        {
         "query": "MARS19BIN38_001810",
         "subject": "QVN25644.1",
         "query_loc": 11854,
         "subject_loc": 1948
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QVN25642.1",
         "start": 0,
         "end": 372,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25643.1",
         "start": 374,
         "end": 845,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25644.1",
         "start": 883,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "QVN25645.1",
         "start": 3160,
         "end": 4354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25646.1",
         "start": 4555,
         "end": 5257,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25647.1",
         "start": 5253,
         "end": 6882,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25648.1",
         "start": 6897,
         "end": 7509,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25649.1",
         "start": 7532,
         "end": 8879,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25650.1",
         "start": 8925,
         "end": 10125,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25651.1",
         "start": 10198,
         "end": 10342,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25652.1",
         "start": 10665,
         "end": 13323,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25653.1",
         "start": 13300,
         "end": 14260,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25654.1",
         "start": 14380,
         "end": 15583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25655.1",
         "start": 15790,
         "end": 16252,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25656.1",
         "start": 16704,
         "end": 17415,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25657.1",
         "start": 17509,
         "end": 19588,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25658.1",
         "start": 19743,
         "end": 21228,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25659.1",
         "start": 21494,
         "end": 22640,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78746.1",
         "query_loc": 2675,
         "subject_loc": 38460
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78731.1",
         "query_loc": 2675,
         "subject_loc": 40302
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78732.1",
         "query_loc": 11854,
         "subject_loc": 42474
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78811.1",
         "query_loc": 2675,
         "subject_loc": 37915
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78812.1",
         "query_loc": 11854,
         "subject_loc": 40037
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78758.1",
         "query_loc": 2675,
         "subject_loc": 34368
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78759.1",
         "query_loc": 11854,
         "subject_loc": 36503
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "AQM37586.1",
         "query_loc": 2675,
         "subject_loc": 34794
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "AQM37587.1",
         "query_loc": 11854,
         "subject_loc": 36959
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78771.1",
         "query_loc": 2675,
         "subject_loc": 37337
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78772.1",
         "query_loc": 11854,
         "subject_loc": 39493
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78797.1",
         "query_loc": 2675,
         "subject_loc": 37336
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78798.1",
         "query_loc": 11854,
         "subject_loc": 39510
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS19BIN38_001802",
         "subject": "APZ78784.1",
         "query_loc": 2675,
         "subject_loc": 37336
        },
        {
         "query": "MARS19BIN38_001810",
         "subject": "APZ78785.1",
         "query_loc": 11854,
         "subject_loc": 39492
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS19BIN38_001802"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000615: 0-35080": {
       "start": 0,
       "end": 35080,
       "links": [
        {
         "query": "MARS19BIN38_001810",
         "subject": "tpa10",
         "query_loc": 11854,
         "subject_loc": 32747
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "tpa1",
         "start": 0,
         "end": 429,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa10",
         "start": 31691,
         "end": 33803,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "tpa11",
         "start": 33886,
         "end": 35080,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "tpa2",
         "start": 517,
         "end": 1195,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa3",
         "start": 1602,
         "end": 2130,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa4",
         "start": 2226,
         "end": 2616,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa5",
         "start": 3354,
         "end": 6822,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa6",
         "start": 6856,
         "end": 10735,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa7",
         "start": 10851,
         "end": 14034,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa8",
         "start": 30798,
         "end": 31170,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpa9",
         "start": 31172,
         "end": 31643,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaA",
         "start": 14404,
         "end": 14551,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaB",
         "start": 14688,
         "end": 15756,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaC",
         "start": 15805,
         "end": 17152,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaD",
         "start": 17179,
         "end": 17782,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaE",
         "start": 17793,
         "end": 19434,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaF",
         "start": 19423,
         "end": 20125,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaG",
         "start": 20216,
         "end": 22031,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaH",
         "start": 22027,
         "end": 23893,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaI",
         "start": 24007,
         "end": 24817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaJ",
         "start": 24878,
         "end": 26093,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "tpaK",
         "start": 26672,
         "end": 29462,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaL",
         "start": 29496,
         "end": 30369,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "tpaX",
         "start": 26462,
         "end": 26609,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002363: 0-22640": {
       "start": 0,
       "end": 22640,
       "links": [
        {
         "query": "MARS19BIN38_001810",
         "subject": "QVN25644.1",
         "query_loc": 11854,
         "subject_loc": 1948
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "QVN25642.1",
         "start": 0,
         "end": 372,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25643.1",
         "start": 374,
         "end": 845,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25644.1",
         "start": 883,
         "end": 3013,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001810"
         }
        },
        {
         "locus_tag": "QVN25645.1",
         "start": 3160,
         "end": 4354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25646.1",
         "start": 4555,
         "end": 5257,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25647.1",
         "start": 5253,
         "end": 6882,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25648.1",
         "start": 6897,
         "end": 7509,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25649.1",
         "start": 7532,
         "end": 8879,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25650.1",
         "start": 8925,
         "end": 10125,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25651.1",
         "start": 10198,
         "end": 10342,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25652.1",
         "start": 10665,
         "end": 13323,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25653.1",
         "start": 13300,
         "end": 14260,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25654.1",
         "start": 14380,
         "end": 15583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25655.1",
         "start": 15790,
         "end": 16252,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "QVN25656.1",
         "start": 16704,
         "end": 17415,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25657.1",
         "start": 17509,
         "end": 19588,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "QVN25658.1",
         "start": 19743,
         "end": 21228,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "QVN25659.1",
         "start": 21494,
         "end": 22640,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_001801": {
     "functions": []
    },
    "MARS19BIN38_001802": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_001803": {
     "functions": []
    },
    "MARS19BIN38_001804": {
     "functions": []
    },
    "MARS19BIN38_001805": {
     "functions": []
    },
    "MARS19BIN38_001806": {
     "functions": []
    },
    "MARS19BIN38_001807": {
     "functions": []
    },
    "MARS19BIN38_001808": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS19BIN38_001809": {
     "functions": []
    },
    "MARS19BIN38_001810": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_001801",
      "seqLength": 507,
      "domains": [
       {
        "start": 114,
        "end": 140,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "0.00011",
        "score": "22.3"
       },
       {
        "start": 142,
        "end": 182,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "7.4e-11",
        "score": "41.8"
       },
       {
        "start": 184,
        "end": 223,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "3.1e-07",
        "score": "30.3"
       },
       {
        "start": 224,
        "end": 264,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "3.2e-13",
        "score": "49.4"
       },
       {
        "start": 279,
        "end": 308,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "4.1e-05",
        "score": "23.6"
       },
       {
        "start": 313,
        "end": 348,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "4.9e-05",
        "score": "23.4"
       },
       {
        "start": 354,
        "end": 391,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "Arm",
        "accession": "PF00514",
        "description": "Armadillo/beta-catenin-like repeat",
        "evalue": "1.1e-07",
        "score": "31.8"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001802",
      "seqLength": 434,
      "domains": [
       {
        "start": 38,
        "end": 209,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "DEAD",
        "accession": "PF00270",
        "description": "DEAD/DEAH box helicase",
        "evalue": "1e-42",
        "score": "146.0"
       },
       {
        "start": 253,
        "end": 362,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "3.1e-27",
        "score": "95.3"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001804",
      "seqLength": 340,
      "domains": [
       {
        "start": 57,
        "end": 300,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PP2C",
        "accession": "PF00481",
        "description": "Protein phosphatase 2C",
        "evalue": "2.9e-67",
        "score": "227.2"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001805",
      "seqLength": 233,
      "domains": [
       {
        "start": 68,
        "end": 221,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TRAPP",
        "accession": "PF04051",
        "description": "Transport protein particle (TRAPP) component",
        "evalue": "2.3e-43",
        "score": "147.6"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001806",
      "seqLength": 349,
      "domains": [
       {
        "start": 109,
        "end": 313,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MFAP1",
        "accession": "PF06991",
        "description": "Microfibril-associated/Pre-mRNA processing",
        "evalue": "2.7e-61",
        "score": "207.4"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001807",
      "seqLength": 174,
      "domains": [
       {
        "start": 1,
        "end": 68,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation"
        ],
        "html_class": "generic-type-other",
        "name": "IF3_N",
        "accession": "PF05198",
        "description": "Translation initiation factor IF-3, N-terminal domain",
        "evalue": "1.4e-08",
        "score": "35.0"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001808",
      "seqLength": 298,
      "domains": [
       {
        "start": 24,
        "end": 280,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "8.4e-51",
        "score": "173.1"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001809",
      "seqLength": 313,
      "domains": [
       {
        "start": 9,
        "end": 99,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.6e-14",
        "score": "54.4"
       },
       {
        "start": 214,
        "end": 306,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.1e-16",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001810",
      "seqLength": 289,
      "domains": [
       {
        "start": 18,
        "end": 251,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GTP_EFTU",
        "accession": "PF00009",
        "description": "Elongation factor Tu GTP binding domain",
        "evalue": "1e-58",
        "score": "198.3"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_001810",
      "seqLength": 289,
      "domains": [
       {
        "start": 19,
        "end": 165,
        "name": "TIGR00231",
        "description": "small_GTP: small GTP-binding protein domain",
        "accession": "TIGR00231",
        "evalue": "5.1e-15",
        "score": "53.6",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r181c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ADH01663.1",
         "query_loc": 7173,
         "subject_loc": 4052
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        }
       ]
      },
      "BGC0002212: 0-24132": {
       "start": 0,
       "end": 24132,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "Moror_6830",
         "query_loc": 7173,
         "subject_loc": 6315
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Moror_6828",
         "start": 0,
         "end": 1829,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6829",
         "start": 2868,
         "end": 3953,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6830",
         "start": 4555,
         "end": 8076,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "Moror_6831",
         "start": 9066,
         "end": 10354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6832",
         "start": 11230,
         "end": 13677,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6833",
         "start": 15289,
         "end": 22320,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6834",
         "start": 23263,
         "end": 24132,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001722: 0-18441": {
       "start": 0,
       "end": 18441,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ANIA_03230",
         "query_loc": 7173,
         "subject_loc": 3390
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_03225",
         "start": 16613,
         "end": 18441,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03226",
         "start": 14468,
         "end": 15491,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03227",
         "start": 12261,
         "end": 13862,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03228",
         "start": 10381,
         "end": 11311,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03229",
         "start": 7702,
         "end": 9641,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03230",
         "start": 0,
         "end": 6781,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        }
       ]
      },
      "BGC0001390: 100-19645": {
       "start": 100,
       "end": 19645,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "stbB",
         "query_loc": 7173,
         "subject_loc": 13908
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "stbA",
         "start": 100,
         "end": 6880,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "stbB",
         "start": 12255,
         "end": 15561,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "stbC",
         "start": 18643,
         "end": 19645,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002248: 5-21557": {
       "start": 5,
       "end": 21557,
       "links": [
        {
         "query": "MARS19BIN38_001839",
         "subject": "G4B84_005463",
         "query_loc": 4739,
         "subject_loc": 7079
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "G4B84_005461",
         "start": 5,
         "end": 2555,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005462",
         "start": 3433,
         "end": 4507,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005463",
         "start": 4857,
         "end": 9302,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001839"
         }
        },
        {
         "locus_tag": "G4B84_005464",
         "start": 9906,
         "end": 11079,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005465",
         "start": 12403,
         "end": 13702,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005466",
         "start": 14789,
         "end": 15960,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005467",
         "start": 16880,
         "end": 17417,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005468",
         "start": 18341,
         "end": 21557,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001976: 11125-46899": {
       "start": 11125,
       "end": 46899,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "eupA",
         "query_loc": 7173,
         "subject_loc": 24157
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "eupA",
         "start": 20000,
         "end": 28315,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "eupB",
         "start": 17784,
         "end": 19488,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupC",
         "start": 11125,
         "end": 12244,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupD",
         "start": 40545,
         "end": 41515,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupE",
         "start": 33124,
         "end": 34264,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupF",
         "start": 29086,
         "end": 30142,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupG",
         "start": 12806,
         "end": 13757,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupH",
         "start": 37654,
         "end": 38947,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupM",
         "start": 14891,
         "end": 16926,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "eupR",
         "start": 35560,
         "end": 36798,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupT",
         "start": 42116,
         "end": 46899,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001923: 495-32413": {
       "start": 495,
       "end": 32413,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ascB",
         "query_loc": 7173,
         "subject_loc": 5735
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ascA",
         "start": 2460,
         "end": 3471,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascB",
         "start": 4041,
         "end": 7429,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "ascC",
         "start": 8442,
         "end": 14991,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ascD",
         "start": 21832,
         "end": 23695,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascE",
         "start": 24090,
         "end": 27475,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascF",
         "start": 29468,
         "end": 30340,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ascG",
         "start": 30761,
         "end": 32413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascR",
         "start": 495,
         "end": 2085,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001338: 273-42813": {
       "start": 273,
       "end": 42813,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "citS",
         "query_loc": 7173,
         "subject_loc": 16732
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "citA",
         "start": 10333,
         "end": 11119,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "citB",
         "start": 8844,
         "end": 9834,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citC",
         "start": 273,
         "end": 2190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "citD",
         "start": 4815,
         "end": 6321,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citE",
         "start": 2399,
         "end": 3342,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citS",
         "start": 12813,
         "end": 20651,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "mrl3",
         "start": 6673,
         "end": 8390,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrl5",
         "start": 3862,
         "end": 4371,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr1",
         "start": 20911,
         "end": 22589,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mrr2",
         "start": 25049,
         "end": 26171,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr3",
         "start": 27028,
         "end": 28619,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr4",
         "start": 29782,
         "end": 32025,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr5",
         "start": 34867,
         "end": 35533,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr6",
         "start": 37003,
         "end": 37706,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr7",
         "start": 38451,
         "end": 39771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mrr8",
         "start": 40649,
         "end": 42813,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001242: 200-22183": {
       "start": 200,
       "end": 22183,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "fsr1",
         "query_loc": 7173,
         "subject_loc": 6292
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FF_03983",
         "start": 200,
         "end": 1988,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FF_03990",
         "start": 21002,
         "end": 22183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr1",
         "start": 2756,
         "end": 9828,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "fsr2",
         "start": 10365,
         "end": 11577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr3",
         "start": 11979,
         "end": 13642,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "fsr4",
         "start": 14540,
         "end": 15660,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr5",
         "start": 16277,
         "end": 17074,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr6",
         "start": 18534,
         "end": 19551,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000154: 266-31301": {
       "start": 266,
       "end": 31301,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "TSTA_117750",
         "query_loc": 7173,
         "subject_loc": 11891
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "TSTA_117720",
         "start": 266,
         "end": 1319,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730",
         "start": 2958,
         "end": 4856,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730_rename1",
         "start": 2958,
         "end": 4392,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117740",
         "start": 5779,
         "end": 7202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117750",
         "start": 7861,
         "end": 15921,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "TSTA_117760",
         "start": 16374,
         "end": 17254,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117760_rename1",
         "start": 16374,
         "end": 16965,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117770",
         "start": 17890,
         "end": 19546,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117780",
         "start": 20154,
         "end": 21134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117790",
         "start": 21843,
         "end": 23432,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117800",
         "start": 24056,
         "end": 25227,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810_rename1",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117820",
         "start": 30394,
         "end": 31301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ADH01663.1",
         "query_loc": 7173,
         "subject_loc": 4052
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        }
       ]
      },
      "BGC0002212: 0-24132": {
       "start": 0,
       "end": 24132,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "Moror_6830",
         "query_loc": 7173,
         "subject_loc": 6315
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "Moror_6828",
         "start": 0,
         "end": 1829,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6829",
         "start": 2868,
         "end": 3953,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6830",
         "start": 4555,
         "end": 8076,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "Moror_6831",
         "start": 9066,
         "end": 10354,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6832",
         "start": 11230,
         "end": 13677,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6833",
         "start": 15289,
         "end": 22320,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "Moror_6834",
         "start": 23263,
         "end": 24132,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001722: 0-18441": {
       "start": 0,
       "end": 18441,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ANIA_03230",
         "query_loc": 7173,
         "subject_loc": 3390
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_03225",
         "start": 16613,
         "end": 18441,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03226",
         "start": 14468,
         "end": 15491,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03227",
         "start": 12261,
         "end": 13862,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03228",
         "start": 10381,
         "end": 11311,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03229",
         "start": 7702,
         "end": 9641,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_03230",
         "start": 0,
         "end": 6781,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        }
       ]
      },
      "BGC0001390: 100-19645": {
       "start": 100,
       "end": 19645,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "stbB",
         "query_loc": 7173,
         "subject_loc": 13908
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "stbA",
         "start": 100,
         "end": 6880,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "stbB",
         "start": 12255,
         "end": 15561,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "stbC",
         "start": 18643,
         "end": 19645,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002248: 5-21557": {
       "start": 5,
       "end": 21557,
       "links": [
        {
         "query": "MARS19BIN38_001839",
         "subject": "G4B84_005463",
         "query_loc": 4739,
         "subject_loc": 7079
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "G4B84_005461",
         "start": 5,
         "end": 2555,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005462",
         "start": 3433,
         "end": 4507,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005463",
         "start": 4857,
         "end": 9302,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS19BIN38_001839"
         }
        },
        {
         "locus_tag": "G4B84_005464",
         "start": 9906,
         "end": 11079,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005465",
         "start": 12403,
         "end": 13702,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005466",
         "start": 14789,
         "end": 15960,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005467",
         "start": 16880,
         "end": 17417,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "G4B84_005468",
         "start": 18341,
         "end": 21557,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001976: 11125-46899": {
       "start": 11125,
       "end": 46899,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "eupA",
         "query_loc": 7173,
         "subject_loc": 24157
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "eupA",
         "start": 20000,
         "end": 28315,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "eupB",
         "start": 17784,
         "end": 19488,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupC",
         "start": 11125,
         "end": 12244,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupD",
         "start": 40545,
         "end": 41515,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupE",
         "start": 33124,
         "end": 34264,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupF",
         "start": 29086,
         "end": 30142,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupG",
         "start": 12806,
         "end": 13757,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "eupH",
         "start": 37654,
         "end": 38947,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupM",
         "start": 14891,
         "end": 16926,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "eupR",
         "start": 35560,
         "end": 36798,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "eupT",
         "start": 42116,
         "end": 46899,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0001923: 495-32413": {
       "start": 495,
       "end": 32413,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "ascB",
         "query_loc": 7173,
         "subject_loc": 5735
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ascA",
         "start": 2460,
         "end": 3471,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascB",
         "start": 4041,
         "end": 7429,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "ascC",
         "start": 8442,
         "end": 14991,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "ascD",
         "start": 21832,
         "end": 23695,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascE",
         "start": 24090,
         "end": 27475,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascF",
         "start": 29468,
         "end": 30340,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ascG",
         "start": 30761,
         "end": 32413,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ascR",
         "start": 495,
         "end": 2085,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001338: 273-42813": {
       "start": 273,
       "end": 42813,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "citS",
         "query_loc": 7173,
         "subject_loc": 16732
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "citA",
         "start": 10333,
         "end": 11119,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "citB",
         "start": 8844,
         "end": 9834,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citC",
         "start": 273,
         "end": 2190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "citD",
         "start": 4815,
         "end": 6321,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citE",
         "start": 2399,
         "end": 3342,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "citS",
         "start": 12813,
         "end": 20651,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "mrl3",
         "start": 6673,
         "end": 8390,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrl5",
         "start": 3862,
         "end": 4371,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr1",
         "start": 20911,
         "end": 22589,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mrr2",
         "start": 25049,
         "end": 26171,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr3",
         "start": 27028,
         "end": 28619,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr4",
         "start": 29782,
         "end": 32025,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr5",
         "start": 34867,
         "end": 35533,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr6",
         "start": 37003,
         "end": 37706,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mrr7",
         "start": 38451,
         "end": 39771,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mrr8",
         "start": 40649,
         "end": 42813,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001242: 200-22183": {
       "start": 200,
       "end": 22183,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "fsr1",
         "query_loc": 7173,
         "subject_loc": 6292
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "FF_03983",
         "start": 200,
         "end": 1988,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "FF_03990",
         "start": 21002,
         "end": 22183,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr1",
         "start": 2756,
         "end": 9828,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "fsr2",
         "start": 10365,
         "end": 11577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr3",
         "start": 11979,
         "end": 13642,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "fsr4",
         "start": 14540,
         "end": 15660,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr5",
         "start": 16277,
         "end": 17074,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "fsr6",
         "start": 18534,
         "end": 19551,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000154: 266-31301": {
       "start": 266,
       "end": 31301,
       "links": [
        {
         "query": "MARS19BIN38_001840",
         "subject": "TSTA_117750",
         "query_loc": 7173,
         "subject_loc": 11891
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "TSTA_117720",
         "start": 266,
         "end": 1319,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730",
         "start": 2958,
         "end": 4856,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117730_rename1",
         "start": 2958,
         "end": 4392,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117740",
         "start": 5779,
         "end": 7202,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117750",
         "start": 7861,
         "end": 15921,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_001840"
         }
        },
        {
         "locus_tag": "TSTA_117760",
         "start": 16374,
         "end": 17254,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117760_rename1",
         "start": 16374,
         "end": 16965,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117770",
         "start": 17890,
         "end": 19546,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117780",
         "start": 20154,
         "end": 21134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117790",
         "start": 21843,
         "end": 23432,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117800",
         "start": 24056,
         "end": 25227,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117810_rename1",
         "start": 25987,
         "end": 27964,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "TSTA_117820",
         "start": 30394,
         "end": 31301,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001840",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 30,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001840",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 535,
        "terminalDocking": ""
       },
       {
        "name": "TD",
        "description": "TD",
        "modifier": false,
        "special": false,
        "cds": "MARS19BIN38_001840",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 655,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_001837": {
     "functions": []
    },
    "MARS19BIN38_001838": {
     "functions": [
      {
       "description": "SMCOG1100:3-hydroxyisobutyrate dehydrogenase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_001839": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1034:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_001840": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS19BIN38_001841": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_001838",
      "seqLength": 429,
      "domains": [
       {
        "start": 7,
        "end": 104,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding"
        ],
        "html_class": "generic-type-other",
        "name": "NAD_binding_11",
        "accession": "PF14833",
        "description": "NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase",
        "evalue": "7.3e-12",
        "score": "45.7"
       },
       {
        "start": 133,
        "end": 287,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050661' target='_blank'>GO:0050661</a>: NADP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "NAD_binding_2",
        "accession": "PF03446",
        "description": "NAD binding domain of 6-phosphogluconate dehydrogenase",
        "evalue": "6.2e-34",
        "score": "117.6"
       },
       {
        "start": 299,
        "end": 420,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0051287' target='_blank'>GO:0051287</a>: NAD binding"
        ],
        "html_class": "generic-type-other",
        "name": "NAD_binding_11",
        "accession": "PF14833",
        "description": "NAD-binding of NADP-dependent 3-hydroxyisobutyrate dehydrogenase",
        "evalue": "2.3e-26",
        "score": "92.5"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001839",
      "seqLength": 487,
      "domains": [
       {
        "start": 34,
        "end": 426,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004497' target='_blank'>GO:0004497</a>: monooxygenase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005506' target='_blank'>GO:0005506</a>: iron ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016705' target='_blank'>GO:0016705</a>: oxidoreductase activity, acting on paired donors, with incorporation or reduction of molecular oxygen",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0020037' target='_blank'>GO:0020037</a>: heme binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "p450",
        "accession": "PF00067",
        "description": "Cytochrome P450",
        "evalue": "1.8e-40",
        "score": "139.2"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001840",
      "seqLength": 1016,
      "domains": [
       {
        "start": 24,
        "end": 321,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "1.8e-36",
        "score": "125.8"
       },
       {
        "start": 536,
        "end": 606,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.5e-07",
        "score": "31.7"
       },
       {
        "start": 657,
        "end": 891,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "6.5e-42",
        "score": "143.6"
       }
      ]
     },
     {
      "id": "MARS19BIN38_001841",
      "seqLength": 620,
      "domains": [
       {
        "start": 13,
        "end": 45,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000981' target='_blank'>GO:0000981</a>: DNA-binding transcription factor activity, RNA polymerase II-specific",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "Zn_clus",
        "accession": "PF00172",
        "description": "Fungal Zn(2)-Cys(6) binuclear cluster domain",
        "evalue": "1.6e-09",
        "score": "37.8"
       },
       {
        "start": 159,
        "end": 385,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006351' target='_blank'>GO:0006351</a>: DNA-templated transcription"
        ],
        "html_class": "generic-type-regulatory",
        "name": "Fungal_trans",
        "accession": "PF04082",
        "description": "Fungal specific transcription factor domain",
        "evalue": "4.4e-26",
        "score": "91.6"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_001840",
      "seqLength": 1016,
      "domains": [
       {
        "start": 654,
        "end": 1015,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "1.2e-63",
        "score": "213.5",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r419c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS19BIN38_003097",
         "subject": "gene2",
         "query_loc": 6405,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_003097"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS19BIN38_003097",
         "subject": "gene2",
         "query_loc": 6405,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS19BIN38_003097"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_003094": {
     "functions": []
    },
    "MARS19BIN38_003095": {
     "functions": []
    },
    "MARS19BIN38_003096": {
     "functions": []
    },
    "MARS19BIN38_003097": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_003094",
      "seqLength": 434,
      "domains": [
       {
        "start": 23,
        "end": 46,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00041",
        "score": "20.8"
       },
       {
        "start": 52,
        "end": 76,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00088",
        "score": "19.7"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003095",
      "seqLength": 343,
      "domains": [
       {
        "start": 27,
        "end": 235,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation"
        ],
        "html_class": "generic-type-other",
        "name": "tRNA-synt_2b",
        "accession": "PF00587",
        "description": "tRNA synthetase class II core domain (G, H, P, S and T)",
        "evalue": "2.5e-35",
        "score": "122.2"
       },
       {
        "start": 255,
        "end": 302,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "HGTP_anticodon",
        "accession": "PF03129",
        "description": "Anticodon binding domain",
        "evalue": "0.00029",
        "score": "21.1"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003096",
      "seqLength": 659,
      "domains": [
       {
        "start": 90,
        "end": 406,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GCP_N_terminal",
        "accession": "PF17681",
        "description": "Gamma tubulin complex component N-terminal",
        "evalue": "1e-60",
        "score": "206.1"
       },
       {
        "start": 410,
        "end": 657,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding"
        ],
        "html_class": "generic-type-other",
        "name": "GCP_C_terminal",
        "accession": "PF04130",
        "description": "Gamma tubulin complex component C-terminal",
        "evalue": "2.8e-50",
        "score": "171.6"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003097",
      "seqLength": 374,
      "domains": [
       {
        "start": 1,
        "end": 270,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "4.1e-31",
        "score": "108.6"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_003097",
      "seqLength": 374,
      "domains": [
       {
        "start": 0,
        "end": 312,
        "name": "TIGR01559",
        "description": "squal_synth: farnesyl-diphosphate farnesyltransferase",
        "accession": "TIGR01559",
        "evalue": "1.2e-106",
        "score": "354.6",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r463c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {}
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS19BIN38_003267": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS19BIN38_003268": {
     "functions": []
    },
    "MARS19BIN38_003269": {
     "functions": [
      {
       "description": "PALP",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1081:cysteine synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS19BIN38_003267",
      "seqLength": 444,
      "domains": [
       {
        "start": 134,
        "end": 418,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "1.3e-46",
        "score": "159.4"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003268",
      "seqLength": 545,
      "domains": [
       {
        "start": 305,
        "end": 491,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TLD",
        "accession": "PF07534",
        "description": "TLD",
        "evalue": "1.5e-16",
        "score": "61.0"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003269",
      "seqLength": 572,
      "domains": [
       {
        "start": 79,
        "end": 372,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PALP",
        "accession": "PF00291",
        "description": "Pyridoxal-phosphate dependent enzyme",
        "evalue": "4.1e-77",
        "score": "259.6"
       },
       {
        "start": 385,
        "end": 476,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "9.6e-16",
        "score": "57.5"
       },
       {
        "start": 487,
        "end": 569,
        "go_terms": [],
        "html_class": "generic-type-regulatory",
        "name": "Thr_dehydrat_C",
        "accession": "PF00585",
        "description": "C-terminal regulatory domain of Threonine dehydratase",
        "evalue": "2.8e-20",
        "score": "72.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS19BIN38_003267",
      "seqLength": 444,
      "domains": [
       {
        "start": 1,
        "end": 74,
        "name": "TIGR03462",
        "description": "CarR_dom_SF: lycopene cyclase domain",
        "accession": "TIGR03462",
        "evalue": "6.7e-15",
        "score": "53.4",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS19BIN38_003269",
      "seqLength": 572,
      "domains": [
       {
        "start": 65,
        "end": 568,
        "name": "TIGR01124",
        "description": "ilvA_2Cterm: threonine ammonia-lyase, biosynthetic",
        "accession": "TIGR01124",
        "evalue": "7.5e-201",
        "score": "666.0",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};

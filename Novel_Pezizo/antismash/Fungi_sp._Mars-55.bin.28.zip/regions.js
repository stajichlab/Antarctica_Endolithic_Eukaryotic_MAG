var recordData = [
 {
  "length": 67882,
  "seq_id": "scaffold_1",
  "regions": []
 },
 {
  "length": 63502,
  "seq_id": "scaffold_2",
  "regions": []
 },
 {
  "length": 59611,
  "seq_id": "scaffold_3",
  "regions": []
 },
 {
  "length": 55995,
  "seq_id": "scaffold_4",
  "regions": []
 },
 {
  "length": 55214,
  "seq_id": "scaffold_5",
  "regions": []
 },
 {
  "length": 54868,
  "seq_id": "scaffold_6",
  "regions": []
 },
 {
  "length": 54533,
  "seq_id": "scaffold_7",
  "regions": []
 },
 {
  "length": 54533,
  "seq_id": "scaffold_8",
  "regions": []
 },
 {
  "length": 54399,
  "seq_id": "scaffold_9",
  "regions": []
 },
 {
  "length": 52364,
  "seq_id": "scaffold_10",
  "regions": []
 },
 {
  "length": 52300,
  "seq_id": "scaffold_11",
  "regions": []
 },
 {
  "length": 51449,
  "seq_id": "scaffold_12",
  "regions": []
 },
 {
  "length": 51409,
  "seq_id": "scaffold_13",
  "regions": []
 },
 {
  "length": 50184,
  "seq_id": "scaffold_14",
  "regions": []
 },
 {
  "length": 49086,
  "seq_id": "scaffold_15",
  "regions": []
 },
 {
  "length": 48697,
  "seq_id": "scaffold_16",
  "regions": []
 },
 {
  "length": 48513,
  "seq_id": "scaffold_17",
  "regions": []
 },
 {
  "length": 48061,
  "seq_id": "scaffold_18",
  "regions": []
 },
 {
  "length": 47989,
  "seq_id": "scaffold_19",
  "regions": []
 },
 {
  "length": 46917,
  "seq_id": "scaffold_20",
  "regions": []
 },
 {
  "length": 46402,
  "seq_id": "scaffold_21",
  "regions": []
 },
 {
  "length": 45414,
  "seq_id": "scaffold_22",
  "regions": []
 },
 {
  "length": 45152,
  "seq_id": "scaffold_23",
  "regions": []
 },
 {
  "length": 44775,
  "seq_id": "scaffold_24",
  "regions": []
 },
 {
  "length": 44693,
  "seq_id": "scaffold_25",
  "regions": []
 },
 {
  "length": 44688,
  "seq_id": "scaffold_26",
  "regions": []
 },
 {
  "length": 44591,
  "seq_id": "scaffold_27",
  "regions": []
 },
 {
  "length": 44243,
  "seq_id": "scaffold_28",
  "regions": []
 },
 {
  "length": 44058,
  "seq_id": "scaffold_29",
  "regions": []
 },
 {
  "length": 42197,
  "seq_id": "scaffold_30",
  "regions": []
 },
 {
  "length": 41686,
  "seq_id": "scaffold_31",
  "regions": []
 },
 {
  "length": 41552,
  "seq_id": "scaffold_32",
  "regions": []
 },
 {
  "length": 41409,
  "seq_id": "scaffold_33",
  "regions": []
 },
 {
  "length": 40201,
  "seq_id": "scaffold_34",
  "regions": []
 },
 {
  "length": 39958,
  "seq_id": "scaffold_35",
  "regions": []
 },
 {
  "length": 38927,
  "seq_id": "scaffold_36",
  "regions": []
 },
 {
  "length": 37791,
  "seq_id": "scaffold_37",
  "regions": []
 },
 {
  "length": 36474,
  "seq_id": "scaffold_38",
  "regions": []
 },
 {
  "length": 36373,
  "seq_id": "scaffold_39",
  "regions": []
 },
 {
  "length": 36350,
  "seq_id": "scaffold_40",
  "regions": []
 },
 {
  "length": 36236,
  "seq_id": "scaffold_41",
  "regions": []
 },
 {
  "length": 36224,
  "seq_id": "scaffold_42",
  "regions": []
 },
 {
  "length": 36211,
  "seq_id": "scaffold_43",
  "regions": []
 },
 {
  "length": 35908,
  "seq_id": "scaffold_44",
  "regions": [
   {
    "start": 14054,
    "end": 35908,
    "idx": 1,
    "orfs": [
     {
      "start": 14935,
      "end": 15291,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001111",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001111</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001111</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001111-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,935 - 15,291,\n (total: 357 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001111\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACAAACAGGGATTCCTGTCTGGCTACCTACTGCCAGCGCTGTTCCGGAGCAGCGCCCGGACTCTCCAGCCCCAGCCCCAGCCCCAGCCCCAGCCCCAGCCCGCAGTCCAGCAGCAGCAGCAGCGGTCCCTAGGCAGCAGCGCCACGAGCACCACTACTACACCCGCCACAGCAGAGCAGACGACGTCGGCACACGCAAGGCAGCGGCGCGACTCCACCGGCAGCACGGGGAGCGAGGGCAGCACGGGCGGCTACGTGGCTGCGGGGGCTGGGACGTGGTACATTGGGGGGCGCAATGCGGACGGGCAGGAGCGGTTCTACCAGCTGCACGCAGGGCGGAAGTTTCGGTCGTAG",
      "translation": "MHKQGFLSGYLLPALFRSSARTLQPQPQPQPQPQPAVQQQQQRSLGSSATSTTTTPATAEQTTSAHARQRRDSTGSTGSEGSTGGYVAAGAGTWYIGGRNADGQERFYQLHAGRKFRS",
      "product": "hypothetical protein"
     },
     {
      "start": 15712,
      "end": 17280,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001112",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001112</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001112</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001112-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,712 - 17,280,\n (total: 1569 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001112\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTCGTTCATTGGCGATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACTGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAGGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACGATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATCCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
      "translation": "MSRSLAMNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRLRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYRNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIRWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIASCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
      "product": "hypothetical protein"
     },
     {
      "start": 17290,
      "end": 17964,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001113",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001113</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001113</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001113-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,290 - 17,964,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001113\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCCATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
      "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
      "product": "hypothetical protein"
     },
     {
      "start": 18037,
      "end": 18942,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001114",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001114</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001114</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001114-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,037 - 18,942,\n (total: 906 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001114 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [1:110](score: 51.3, e-value: 1.1e-13)<br>\n \n  PF03473.20 (MOSC domain): [159:288](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001114 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001114\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATACCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGAGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAAAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTCGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTGGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
      "translation": "MHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDTEELVLAFDGIEQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
      "product": "hypothetical protein"
     },
     {
      "start": 19154,
      "end": 20458,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001115",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001115</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001115</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001115-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,154 - 20,458,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001115 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001115\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTACGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
      "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGMGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLTTPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
      "product": "hypothetical protein"
     },
     {
      "start": 20697,
      "end": 21962,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001116",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001116</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001116</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001116-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,697 - 21,962,\n (total: 1266 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1162:threonyl-tRNA synthetase (Score: 48; E-value: 9.6e-15)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001116 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [105:313](score: 121.4, e-value: 4.3e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001116 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001116\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGATGGCGGAGAATCGTGGATGGAAGGCAGCGACTCTCTCACCATCTGCAAACCAACACCTCTCAGAGCTATGGACGAGATGGATATGGGTACCTTCAACAGGCTGGCTTCGTTCGGGCGACTGGGTCTGCTGGGCTGGTTCAATTGCTTCCACTGGGACAGCGTGTGGTAGATAAGATCACAGGCATTATTCACCGTGAGTTGAATGCAATTGGAGCACTAAGACTCTCCATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCCTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
      "translation": "MRWRRIVDGRQRLSHHLQTNTSQSYGRDGYGYLQQAGFVRATGSAGLVQLLPLGQRVVDKITGIIHRELNAIGALRLSMTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
      "product": "hypothetical protein"
     },
     {
      "start": 21991,
      "end": 23970,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001117",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001117</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001117</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001117-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,991 - 23,970,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001117 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001117 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001117\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCTCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTCCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
      "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
      "product": "hypothetical protein"
     },
     {
      "start": 24054,
      "end": 25989,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001118",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001118</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001118</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001118-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,054 - 25,989,\n (total: 1407 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [65:356](score: 128.6, e-value: 3.2e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [56:406](score: 426.2, e-value: 2e-128)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001118\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_001118-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCTCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTACAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTTTGATGATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
      "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACALMMQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
      "product": "hypothetical protein"
     },
     {
      "start": 26450,
      "end": 28342,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001119",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001119</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001119</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001119-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,450 - 28,342,\n (total: 1893 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 56.2; E-value: 4.1e-17)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001119 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [124:159](score: 23.4, e-value: 8.4e-05)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001119 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001119\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGAGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGTGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGCTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGTGAATAG",
      "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKSRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQSE",
      "product": "hypothetical protein"
     },
     {
      "start": 28742,
      "end": 30282,
      "strand": 1,
      "locus_tag": "MARS55BIN28_001120",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001120</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001120</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001120-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,742 - 30,282,\n (total: 876 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001120 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [133:257](score: 118.5, e-value: 2.2e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001120 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001120\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGCGCTTCCGAAGTGCCGCGAATCCCACCTGGCCCTTCGGGATCGTCCTTTGCACAGTCGCTCGGCCACCCGCAACCGACCACCCCGCTGGACATGTCTGAGTTCCCGGCTTTGGGGGGAGGTAATGCTGGGATGAATGCTGGTGCAAGTGCGAATCCATCGCATAGCTCCGCAGGACCAATATCAGCGAATACCGGCTCGATGAATAATGCTGGCAGCTATGCGTTCAGAGCGGCCACTGCGTCACCGGGACAAGGGTTACGGCAGGCGTCAGGGTCTTTGGGCACGCTGCATTCACGCGGTGTAGAGGAAGATGATGGGACTATGAATGACTTTCCTGCTCTTCCAGCAGACCCGGACAAGATCGCCAGCTCGTCGTCCGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAACAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
      "translation": "MGASEVPRIPPGPSGSSFAQSLGHPQPTTPLDMSEFPALGGGNAGMNAGASANPSHSSAGPISANTGSMNNAGSYAFRAATASPGQGLRQASGSLGTLHSRGVEEDDGTMNDFPALPADPDKIASSSSDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
      "product": "hypothetical protein"
     },
     {
      "start": 30381,
      "end": 31129,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001121",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001121</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001121</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001121-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,381 - 31,129,\n (total: 711 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001121 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [30:233](score: 294.3, e-value: 4.8e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001121 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001121\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGCGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGACATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
      "translation": "MKTLATTSLALSLCLVCGVVAQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
      "product": "hypothetical protein"
     },
     {
      "start": 31244,
      "end": 32491,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001122",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001122</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001122</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001122-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,244 - 32,491,\n (total: 1173 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001122 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:353](score: 69.2, e-value: 3.9e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001122 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001122\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCGGTCTCGCCTGAAATCGCCAAACGTGTCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACGTTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTCGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAATTCTCTACGTCGAACCACGCTCGAGACTTTCGGGCGAAGGTTGTGTCTCTTGTACCCAAGGAGCCCAGAGCATCCAGCAGCCCGGCCAAACAGGGCCCGCCATCCCCAATCACCAACCCCACCACCACGGCGCAGGAGGACGCGTCGAGCAAAGACTAA",
      "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRVEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKFSTSNHARDFRAKVVSLVPKEPRASSSPAKQGPPSPITNPTTTAQEDASSKD",
      "product": "hypothetical protein"
     },
     {
      "start": 32603,
      "end": 35589,
      "strand": -1,
      "locus_tag": "MARS55BIN28_001123",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001123</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001123</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001123-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,603 - 35,589,\n (total: 2640 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001123 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [33:181](score: 108.3, e-value: 3.5e-31)<br>\n \n  PF00106.28 (short chain dehydrogenase): [299:482](score: 146.2, e-value: 8.7e-43)<br>\n \n  PF01575.22 (MaoC like domain): [755:865](score: 113.0, e-value: 6.6e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001123\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_001123-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCGAGGGTGGGTCGCATGTTTGCCAGCTTCGGCTTAGGGGGCGTGCTCAATATCTACACTCGCACATTCTGTCTGGAGAAGCTGACGGAGAACGATGAGGAGCTGCAACATGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCGTGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGCATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGCAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCCCTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAAAAGACTCAGAAAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTGTTGAAAATATAAGTAATCGTTCCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTGTTTGAAGGCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTGAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
      "translation": "MARVGRMFASFGLGGVLNIYTRTFCLEKLTENDEELQHAADLVVDEIKKAGGRAVADYNNVQNGDQIIETAVKAFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQKMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIVENISNRSGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEGSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 24053,
      "end": 25989,
      "tool": "rule-based-clusters",
      "neighbouring_start": 14053,
      "neighbouring_end": 35908,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r44c1"
   }
  ]
 },
 {
  "length": 35656,
  "seq_id": "scaffold_45",
  "regions": []
 },
 {
  "length": 35585,
  "seq_id": "scaffold_46",
  "regions": []
 },
 {
  "length": 35559,
  "seq_id": "scaffold_47",
  "regions": []
 },
 {
  "length": 35338,
  "seq_id": "scaffold_48",
  "regions": []
 },
 {
  "length": 34635,
  "seq_id": "scaffold_49",
  "regions": []
 },
 {
  "length": 34615,
  "seq_id": "scaffold_50",
  "regions": []
 },
 {
  "length": 34566,
  "seq_id": "scaffold_51",
  "regions": []
 },
 {
  "length": 33911,
  "seq_id": "scaffold_52",
  "regions": []
 },
 {
  "length": 33632,
  "seq_id": "scaffold_53",
  "regions": []
 },
 {
  "length": 33318,
  "seq_id": "scaffold_54",
  "regions": []
 },
 {
  "length": 32081,
  "seq_id": "scaffold_55",
  "regions": []
 },
 {
  "length": 31454,
  "seq_id": "scaffold_56",
  "regions": []
 },
 {
  "length": 31330,
  "seq_id": "scaffold_57",
  "regions": []
 },
 {
  "length": 30845,
  "seq_id": "scaffold_58",
  "regions": []
 },
 {
  "length": 30828,
  "seq_id": "scaffold_59",
  "regions": []
 },
 {
  "length": 30418,
  "seq_id": "scaffold_60",
  "regions": []
 },
 {
  "length": 30237,
  "seq_id": "scaffold_61",
  "regions": []
 },
 {
  "length": 30039,
  "seq_id": "scaffold_62",
  "regions": []
 },
 {
  "length": 29845,
  "seq_id": "scaffold_63",
  "regions": []
 },
 {
  "length": 29608,
  "seq_id": "scaffold_64",
  "regions": []
 },
 {
  "length": 29604,
  "seq_id": "scaffold_65",
  "regions": []
 },
 {
  "length": 29359,
  "seq_id": "scaffold_66",
  "regions": []
 },
 {
  "length": 29336,
  "seq_id": "scaffold_67",
  "regions": []
 },
 {
  "length": 29299,
  "seq_id": "scaffold_68",
  "regions": []
 },
 {
  "length": 29166,
  "seq_id": "scaffold_69",
  "regions": []
 },
 {
  "length": 29088,
  "seq_id": "scaffold_70",
  "regions": []
 },
 {
  "length": 28901,
  "seq_id": "scaffold_71",
  "regions": []
 },
 {
  "length": 28852,
  "seq_id": "scaffold_72",
  "regions": []
 },
 {
  "length": 28332,
  "seq_id": "scaffold_73",
  "regions": []
 },
 {
  "length": 28262,
  "seq_id": "scaffold_74",
  "regions": []
 },
 {
  "length": 28213,
  "seq_id": "scaffold_75",
  "regions": []
 },
 {
  "length": 27717,
  "seq_id": "scaffold_76",
  "regions": []
 },
 {
  "length": 27695,
  "seq_id": "scaffold_77",
  "regions": []
 },
 {
  "length": 27597,
  "seq_id": "scaffold_78",
  "regions": []
 },
 {
  "length": 27301,
  "seq_id": "scaffold_79",
  "regions": []
 },
 {
  "length": 26956,
  "seq_id": "scaffold_80",
  "regions": []
 },
 {
  "length": 26830,
  "seq_id": "scaffold_81",
  "regions": []
 },
 {
  "length": 26781,
  "seq_id": "scaffold_82",
  "regions": []
 },
 {
  "length": 26729,
  "seq_id": "scaffold_83",
  "regions": []
 },
 {
  "length": 26687,
  "seq_id": "scaffold_84",
  "regions": []
 },
 {
  "length": 26493,
  "seq_id": "scaffold_85",
  "regions": []
 },
 {
  "length": 26491,
  "seq_id": "scaffold_86",
  "regions": []
 },
 {
  "length": 26271,
  "seq_id": "scaffold_87",
  "regions": []
 },
 {
  "length": 26263,
  "seq_id": "scaffold_88",
  "regions": []
 },
 {
  "length": 26143,
  "seq_id": "scaffold_89",
  "regions": []
 },
 {
  "length": 26093,
  "seq_id": "scaffold_90",
  "regions": []
 },
 {
  "length": 26015,
  "seq_id": "scaffold_91",
  "regions": []
 },
 {
  "length": 25733,
  "seq_id": "scaffold_92",
  "regions": []
 },
 {
  "length": 25427,
  "seq_id": "scaffold_93",
  "regions": []
 },
 {
  "length": 25369,
  "seq_id": "scaffold_94",
  "regions": []
 },
 {
  "length": 24997,
  "seq_id": "scaffold_95",
  "regions": []
 },
 {
  "length": 24949,
  "seq_id": "scaffold_96",
  "regions": []
 },
 {
  "length": 24910,
  "seq_id": "scaffold_97",
  "regions": []
 },
 {
  "length": 24756,
  "seq_id": "scaffold_98",
  "regions": []
 },
 {
  "length": 24565,
  "seq_id": "scaffold_99",
  "regions": []
 },
 {
  "length": 24514,
  "seq_id": "scaffold_100",
  "regions": []
 },
 {
  "length": 24295,
  "seq_id": "scaffold_101",
  "regions": []
 },
 {
  "length": 24204,
  "seq_id": "scaffold_102",
  "regions": []
 },
 {
  "length": 24019,
  "seq_id": "scaffold_103",
  "regions": []
 },
 {
  "length": 23990,
  "seq_id": "scaffold_104",
  "regions": []
 },
 {
  "length": 23750,
  "seq_id": "scaffold_105",
  "regions": []
 },
 {
  "length": 23564,
  "seq_id": "scaffold_106",
  "regions": []
 },
 {
  "length": 23501,
  "seq_id": "scaffold_107",
  "regions": []
 },
 {
  "length": 23497,
  "seq_id": "scaffold_108",
  "regions": []
 },
 {
  "length": 23477,
  "seq_id": "scaffold_109",
  "regions": []
 },
 {
  "length": 23352,
  "seq_id": "scaffold_110",
  "regions": []
 },
 {
  "length": 23259,
  "seq_id": "scaffold_111",
  "regions": []
 },
 {
  "length": 23242,
  "seq_id": "scaffold_112",
  "regions": []
 },
 {
  "length": 23136,
  "seq_id": "scaffold_113",
  "regions": []
 },
 {
  "length": 22943,
  "seq_id": "scaffold_114",
  "regions": []
 },
 {
  "length": 22755,
  "seq_id": "scaffold_115",
  "regions": []
 },
 {
  "length": 22725,
  "seq_id": "scaffold_116",
  "regions": []
 },
 {
  "length": 22632,
  "seq_id": "scaffold_117",
  "regions": []
 },
 {
  "length": 22603,
  "seq_id": "scaffold_118",
  "regions": []
 },
 {
  "length": 22578,
  "seq_id": "scaffold_119",
  "regions": []
 },
 {
  "length": 22173,
  "seq_id": "scaffold_120",
  "regions": []
 },
 {
  "length": 22134,
  "seq_id": "scaffold_121",
  "regions": []
 },
 {
  "length": 21883,
  "seq_id": "scaffold_122",
  "regions": []
 },
 {
  "length": 21755,
  "seq_id": "scaffold_123",
  "regions": []
 },
 {
  "length": 21678,
  "seq_id": "scaffold_124",
  "regions": []
 },
 {
  "length": 21359,
  "seq_id": "scaffold_125",
  "regions": []
 },
 {
  "length": 21319,
  "seq_id": "scaffold_126",
  "regions": []
 },
 {
  "length": 21280,
  "seq_id": "scaffold_127",
  "regions": []
 },
 {
  "length": 21259,
  "seq_id": "scaffold_128",
  "regions": []
 },
 {
  "length": 21255,
  "seq_id": "scaffold_129",
  "regions": []
 },
 {
  "length": 21229,
  "seq_id": "scaffold_130",
  "regions": []
 },
 {
  "length": 21163,
  "seq_id": "scaffold_131",
  "regions": []
 },
 {
  "length": 21044,
  "seq_id": "scaffold_132",
  "regions": []
 },
 {
  "length": 20948,
  "seq_id": "scaffold_133",
  "regions": []
 },
 {
  "length": 20849,
  "seq_id": "scaffold_134",
  "regions": []
 },
 {
  "length": 20745,
  "seq_id": "scaffold_135",
  "regions": []
 },
 {
  "length": 20717,
  "seq_id": "scaffold_136",
  "regions": []
 },
 {
  "length": 20667,
  "seq_id": "scaffold_137",
  "regions": []
 },
 {
  "length": 20663,
  "seq_id": "scaffold_138",
  "regions": []
 },
 {
  "length": 20619,
  "seq_id": "scaffold_139",
  "regions": []
 },
 {
  "length": 20612,
  "seq_id": "scaffold_140",
  "regions": []
 },
 {
  "length": 20546,
  "seq_id": "scaffold_141",
  "regions": []
 },
 {
  "length": 20522,
  "seq_id": "scaffold_142",
  "regions": []
 },
 {
  "length": 20473,
  "seq_id": "scaffold_143",
  "regions": []
 },
 {
  "length": 20282,
  "seq_id": "scaffold_144",
  "regions": []
 },
 {
  "length": 20200,
  "seq_id": "scaffold_145",
  "regions": []
 },
 {
  "length": 20167,
  "seq_id": "scaffold_146",
  "regions": []
 },
 {
  "length": 20166,
  "seq_id": "scaffold_147",
  "regions": []
 },
 {
  "length": 19986,
  "seq_id": "scaffold_148",
  "regions": []
 },
 {
  "length": 19981,
  "seq_id": "scaffold_149",
  "regions": []
 },
 {
  "length": 19670,
  "seq_id": "scaffold_150",
  "regions": []
 },
 {
  "length": 19445,
  "seq_id": "scaffold_151",
  "regions": []
 },
 {
  "length": 19419,
  "seq_id": "scaffold_152",
  "regions": []
 },
 {
  "length": 19248,
  "seq_id": "scaffold_153",
  "regions": []
 },
 {
  "length": 19219,
  "seq_id": "scaffold_154",
  "regions": []
 },
 {
  "length": 19102,
  "seq_id": "scaffold_155",
  "regions": []
 },
 {
  "length": 18999,
  "seq_id": "scaffold_156",
  "regions": []
 },
 {
  "length": 18955,
  "seq_id": "scaffold_157",
  "regions": []
 },
 {
  "length": 18950,
  "seq_id": "scaffold_158",
  "regions": []
 },
 {
  "length": 18932,
  "seq_id": "scaffold_159",
  "regions": []
 },
 {
  "length": 18670,
  "seq_id": "scaffold_160",
  "regions": []
 },
 {
  "length": 18641,
  "seq_id": "scaffold_161",
  "regions": []
 },
 {
  "length": 18626,
  "seq_id": "scaffold_162",
  "regions": []
 },
 {
  "length": 18449,
  "seq_id": "scaffold_163",
  "regions": []
 },
 {
  "length": 18433,
  "seq_id": "scaffold_164",
  "regions": []
 },
 {
  "length": 18400,
  "seq_id": "scaffold_165",
  "regions": [
   {
    "start": 1,
    "end": 18228,
    "idx": 1,
    "orfs": [
     {
      "start": 155,
      "end": 2867,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002826",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002826</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002826</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002826-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 155 - 2,867,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002826 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.3e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 53.7, e-value: 1.9e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002826\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACGATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGTTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTAAGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTTGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGGATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAAGCAGCCAGATTTAGGCTCTGCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCAGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGTGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAAATATTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTGCACATATTGGAAAGCTCTATGTCGGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAAGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAACCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCACGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAGTTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
      "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKKQPDLGSALLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVVMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKKYFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKSVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATTLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSSFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
      "product": "hypothetical protein"
     },
     {
      "start": 2968,
      "end": 6234,
      "strand": -1,
      "locus_tag": "MARS55BIN28_002827",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002827</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002827</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002827-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,968 - 6,234,\n (total: 3132 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:355](score: 195.3, e-value: 8e-58)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [574:638](score: 28.3, e-value: 1.4e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [908:989](score: 50.2, e-value: 2.1e-13)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 49.9, e-value: 6.9e-14)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002827\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATTGAGCTCATAACCAGAGAAATTCTGACAATCAGGGACCCAATAAAAATAGATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTTAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGAAGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCCAGCGTTGGAATGAATCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAATCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCGTAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAAAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTATTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCATTCTGTCTGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTGGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTCATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
      "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPIELITREILTIRDPIKIDKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEEAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQSDPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSVSGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLIADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSILSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
      "product": "hypothetical protein"
     },
     {
      "start": 6304,
      "end": 7245,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002828",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002828</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002828</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002828-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,304 - 7,245,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002828 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.0, e-value: 2.1e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002828\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGGACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGAGAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
      "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKDEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVRGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
      "product": "hypothetical protein"
     },
     {
      "start": 7299,
      "end": 8228,
      "strand": -1,
      "locus_tag": "MARS55BIN28_002829",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002829</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002829</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002829-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,299 - 8,228,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002829 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002829 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002829\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
      "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
      "product": "hypothetical protein"
     },
     {
      "start": 8593,
      "end": 9117,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002830",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002830</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002830</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002830-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,593 - 9,117,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002830 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.7, e-value: 8.6e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002830 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002830\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGAGGACATAAAGTGTAATGAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAACGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
      "translation": "MDEDIKCNEVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
      "product": "hypothetical protein"
     },
     {
      "start": 9730,
      "end": 10779,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002831",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002831</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002831</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002831-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,730 - 10,779,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002831 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 208.0, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002831\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCTCGAGGAAGCTCCGGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGATGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACGCAGGCGAGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
      "translation": "MSSRKLRSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDAGESSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
      "product": "hypothetical protein"
     },
     {
      "start": 10821,
      "end": 11531,
      "strand": -1,
      "locus_tag": "MARS55BIN28_002832",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002832</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002832</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002832-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,821 - 11,531,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002832 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [71:224](score: 148.8, e-value: 9.9e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002832\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCATTGATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGCCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
      "translation": "MALMTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEAKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
      "product": "hypothetical protein"
     },
     {
      "start": 12049,
      "end": 13071,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002833",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002833</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002833</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002833-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,049 - 13,071,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002833 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002833\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCGGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACAGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
      "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
      "product": "hypothetical protein"
     },
     {
      "start": 13126,
      "end": 13566,
      "strand": -1,
      "locus_tag": "MARS55BIN28_002834",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002834</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002834</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002834-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,126 - 13,566,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002834\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
      "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
      "product": "hypothetical protein"
     },
     {
      "start": 14338,
      "end": 15642,
      "strand": 1,
      "locus_tag": "MARS55BIN28_002835",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002835</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002835</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002835-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,338 - 15,642,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325; E-value: 1.4e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002835 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.8, e-value: 2.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002835 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002835\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_002835-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAGATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGTAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCATGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
      "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTVEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVMAMDKEQVKRKRKLRAG",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 7298,
      "end": 8228,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 18228,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r165c1"
   }
  ]
 },
 {
  "length": 18340,
  "seq_id": "scaffold_166",
  "regions": []
 },
 {
  "length": 18302,
  "seq_id": "scaffold_167",
  "regions": []
 },
 {
  "length": 18239,
  "seq_id": "scaffold_168",
  "regions": []
 },
 {
  "length": 18186,
  "seq_id": "scaffold_169",
  "regions": []
 },
 {
  "length": 18091,
  "seq_id": "scaffold_170",
  "regions": []
 },
 {
  "length": 17908,
  "seq_id": "scaffold_171",
  "regions": []
 },
 {
  "length": 17836,
  "seq_id": "scaffold_172",
  "regions": []
 },
 {
  "length": 17825,
  "seq_id": "scaffold_173",
  "regions": []
 },
 {
  "length": 17801,
  "seq_id": "scaffold_174",
  "regions": []
 },
 {
  "length": 17662,
  "seq_id": "scaffold_175",
  "regions": []
 },
 {
  "length": 17549,
  "seq_id": "scaffold_176",
  "regions": []
 },
 {
  "length": 17523,
  "seq_id": "scaffold_177",
  "regions": []
 },
 {
  "length": 17507,
  "seq_id": "scaffold_178",
  "regions": []
 },
 {
  "length": 17466,
  "seq_id": "scaffold_179",
  "regions": []
 },
 {
  "length": 17382,
  "seq_id": "scaffold_180",
  "regions": []
 },
 {
  "length": 17296,
  "seq_id": "scaffold_181",
  "regions": []
 },
 {
  "length": 16918,
  "seq_id": "scaffold_182",
  "regions": []
 },
 {
  "length": 16904,
  "seq_id": "scaffold_183",
  "regions": []
 },
 {
  "length": 16658,
  "seq_id": "scaffold_184",
  "regions": []
 },
 {
  "length": 16624,
  "seq_id": "scaffold_185",
  "regions": []
 },
 {
  "length": 16622,
  "seq_id": "scaffold_186",
  "regions": []
 },
 {
  "length": 16552,
  "seq_id": "scaffold_187",
  "regions": []
 },
 {
  "length": 16542,
  "seq_id": "scaffold_188",
  "regions": []
 },
 {
  "length": 16519,
  "seq_id": "scaffold_189",
  "regions": []
 },
 {
  "length": 16502,
  "seq_id": "scaffold_190",
  "regions": []
 },
 {
  "length": 16483,
  "seq_id": "scaffold_191",
  "regions": []
 },
 {
  "length": 16462,
  "seq_id": "scaffold_192",
  "regions": []
 },
 {
  "length": 16424,
  "seq_id": "scaffold_193",
  "regions": []
 },
 {
  "length": 16218,
  "seq_id": "scaffold_194",
  "regions": []
 },
 {
  "length": 16179,
  "seq_id": "scaffold_195",
  "regions": []
 },
 {
  "length": 16177,
  "seq_id": "scaffold_196",
  "regions": []
 },
 {
  "length": 16103,
  "seq_id": "scaffold_197",
  "regions": []
 },
 {
  "length": 16098,
  "seq_id": "scaffold_198",
  "regions": []
 },
 {
  "length": 16078,
  "seq_id": "scaffold_199",
  "regions": []
 },
 {
  "length": 15945,
  "seq_id": "scaffold_200",
  "regions": []
 },
 {
  "length": 15937,
  "seq_id": "scaffold_201",
  "regions": []
 },
 {
  "length": 15793,
  "seq_id": "scaffold_202",
  "regions": []
 },
 {
  "length": 15784,
  "seq_id": "scaffold_203",
  "regions": []
 },
 {
  "length": 15760,
  "seq_id": "scaffold_204",
  "regions": []
 },
 {
  "length": 15638,
  "seq_id": "scaffold_205",
  "regions": []
 },
 {
  "length": 15619,
  "seq_id": "scaffold_206",
  "regions": []
 },
 {
  "length": 15569,
  "seq_id": "scaffold_207",
  "regions": []
 },
 {
  "length": 15531,
  "seq_id": "scaffold_208",
  "regions": []
 },
 {
  "length": 15372,
  "seq_id": "scaffold_209",
  "regions": []
 },
 {
  "length": 15350,
  "seq_id": "scaffold_210",
  "regions": []
 },
 {
  "length": 15345,
  "seq_id": "scaffold_211",
  "regions": []
 },
 {
  "length": 15314,
  "seq_id": "scaffold_212",
  "regions": []
 },
 {
  "length": 15248,
  "seq_id": "scaffold_213",
  "regions": []
 },
 {
  "length": 15233,
  "seq_id": "scaffold_214",
  "regions": []
 },
 {
  "length": 15146,
  "seq_id": "scaffold_215",
  "regions": []
 },
 {
  "length": 15108,
  "seq_id": "scaffold_216",
  "regions": []
 },
 {
  "length": 15023,
  "seq_id": "scaffold_217",
  "regions": []
 },
 {
  "length": 14988,
  "seq_id": "scaffold_218",
  "regions": []
 },
 {
  "length": 14985,
  "seq_id": "scaffold_219",
  "regions": []
 },
 {
  "length": 14926,
  "seq_id": "scaffold_220",
  "regions": []
 },
 {
  "length": 14923,
  "seq_id": "scaffold_221",
  "regions": []
 },
 {
  "length": 14849,
  "seq_id": "scaffold_222",
  "regions": []
 },
 {
  "length": 14815,
  "seq_id": "scaffold_223",
  "regions": []
 },
 {
  "length": 14688,
  "seq_id": "scaffold_224",
  "regions": []
 },
 {
  "length": 14665,
  "seq_id": "scaffold_225",
  "regions": []
 },
 {
  "length": 14629,
  "seq_id": "scaffold_226",
  "regions": []
 },
 {
  "length": 14587,
  "seq_id": "scaffold_227",
  "regions": []
 },
 {
  "length": 14575,
  "seq_id": "scaffold_228",
  "regions": []
 },
 {
  "length": 14530,
  "seq_id": "scaffold_229",
  "regions": []
 },
 {
  "length": 14524,
  "seq_id": "scaffold_230",
  "regions": []
 },
 {
  "length": 14512,
  "seq_id": "scaffold_231",
  "regions": []
 },
 {
  "length": 14489,
  "seq_id": "scaffold_232",
  "regions": []
 },
 {
  "length": 14487,
  "seq_id": "scaffold_233",
  "regions": []
 },
 {
  "length": 14292,
  "seq_id": "scaffold_234",
  "regions": []
 },
 {
  "length": 14110,
  "seq_id": "scaffold_235",
  "regions": []
 },
 {
  "length": 14109,
  "seq_id": "scaffold_236",
  "regions": []
 },
 {
  "length": 14092,
  "seq_id": "scaffold_237",
  "regions": []
 },
 {
  "length": 14076,
  "seq_id": "scaffold_238",
  "regions": []
 },
 {
  "length": 14047,
  "seq_id": "scaffold_239",
  "regions": []
 },
 {
  "length": 14039,
  "seq_id": "scaffold_240",
  "regions": []
 },
 {
  "length": 13928,
  "seq_id": "scaffold_241",
  "regions": []
 },
 {
  "length": 13885,
  "seq_id": "scaffold_242",
  "regions": []
 },
 {
  "length": 13877,
  "seq_id": "scaffold_243",
  "regions": []
 },
 {
  "length": 13843,
  "seq_id": "scaffold_244",
  "regions": []
 },
 {
  "length": 13761,
  "seq_id": "scaffold_245",
  "regions": []
 },
 {
  "length": 13744,
  "seq_id": "scaffold_246",
  "regions": []
 },
 {
  "length": 13741,
  "seq_id": "scaffold_247",
  "regions": []
 },
 {
  "length": 13684,
  "seq_id": "scaffold_248",
  "regions": []
 },
 {
  "length": 13563,
  "seq_id": "scaffold_249",
  "regions": []
 },
 {
  "length": 13533,
  "seq_id": "scaffold_250",
  "regions": []
 },
 {
  "length": 13418,
  "seq_id": "scaffold_251",
  "regions": []
 },
 {
  "length": 13410,
  "seq_id": "scaffold_252",
  "regions": []
 },
 {
  "length": 13316,
  "seq_id": "scaffold_253",
  "regions": []
 },
 {
  "length": 13254,
  "seq_id": "scaffold_254",
  "regions": []
 },
 {
  "length": 13188,
  "seq_id": "scaffold_255",
  "regions": []
 },
 {
  "length": 13107,
  "seq_id": "scaffold_256",
  "regions": []
 },
 {
  "length": 13062,
  "seq_id": "scaffold_257",
  "regions": []
 },
 {
  "length": 12818,
  "seq_id": "scaffold_258",
  "regions": []
 },
 {
  "length": 12800,
  "seq_id": "scaffold_259",
  "regions": []
 },
 {
  "length": 12773,
  "seq_id": "scaffold_260",
  "regions": []
 },
 {
  "length": 12756,
  "seq_id": "scaffold_261",
  "regions": []
 },
 {
  "length": 12705,
  "seq_id": "scaffold_262",
  "regions": []
 },
 {
  "length": 12680,
  "seq_id": "scaffold_263",
  "regions": []
 },
 {
  "length": 12680,
  "seq_id": "scaffold_264",
  "regions": []
 },
 {
  "length": 12562,
  "seq_id": "scaffold_265",
  "regions": []
 },
 {
  "length": 12542,
  "seq_id": "scaffold_266",
  "regions": []
 },
 {
  "length": 12534,
  "seq_id": "scaffold_267",
  "regions": []
 },
 {
  "length": 12528,
  "seq_id": "scaffold_268",
  "regions": []
 },
 {
  "length": 12490,
  "seq_id": "scaffold_269",
  "regions": []
 },
 {
  "length": 12451,
  "seq_id": "scaffold_270",
  "regions": []
 },
 {
  "length": 12381,
  "seq_id": "scaffold_271",
  "regions": []
 },
 {
  "length": 12369,
  "seq_id": "scaffold_272",
  "regions": []
 },
 {
  "length": 12368,
  "seq_id": "scaffold_273",
  "regions": []
 },
 {
  "length": 12352,
  "seq_id": "scaffold_274",
  "regions": []
 },
 {
  "length": 12314,
  "seq_id": "scaffold_275",
  "regions": []
 },
 {
  "length": 12296,
  "seq_id": "scaffold_276",
  "regions": []
 },
 {
  "length": 12265,
  "seq_id": "scaffold_277",
  "regions": []
 },
 {
  "length": 12263,
  "seq_id": "scaffold_278",
  "regions": []
 },
 {
  "length": 12209,
  "seq_id": "scaffold_279",
  "regions": []
 },
 {
  "length": 12141,
  "seq_id": "scaffold_280",
  "regions": []
 },
 {
  "length": 12136,
  "seq_id": "scaffold_281",
  "regions": []
 },
 {
  "length": 12134,
  "seq_id": "scaffold_282",
  "regions": []
 },
 {
  "length": 12091,
  "seq_id": "scaffold_283",
  "regions": []
 },
 {
  "length": 11991,
  "seq_id": "scaffold_284",
  "regions": []
 },
 {
  "length": 11861,
  "seq_id": "scaffold_285",
  "regions": []
 },
 {
  "length": 11857,
  "seq_id": "scaffold_286",
  "regions": []
 },
 {
  "length": 11853,
  "seq_id": "scaffold_287",
  "regions": []
 },
 {
  "length": 11846,
  "seq_id": "scaffold_288",
  "regions": []
 },
 {
  "length": 11776,
  "seq_id": "scaffold_289",
  "regions": []
 },
 {
  "length": 11755,
  "seq_id": "scaffold_290",
  "regions": []
 },
 {
  "length": 11747,
  "seq_id": "scaffold_291",
  "regions": []
 },
 {
  "length": 11707,
  "seq_id": "scaffold_292",
  "regions": []
 },
 {
  "length": 11656,
  "seq_id": "scaffold_293",
  "regions": []
 },
 {
  "length": 11652,
  "seq_id": "scaffold_294",
  "regions": []
 },
 {
  "length": 11632,
  "seq_id": "scaffold_295",
  "regions": []
 },
 {
  "length": 11574,
  "seq_id": "scaffold_296",
  "regions": []
 },
 {
  "length": 11562,
  "seq_id": "scaffold_297",
  "regions": []
 },
 {
  "length": 11541,
  "seq_id": "scaffold_298",
  "regions": []
 },
 {
  "length": 11535,
  "seq_id": "scaffold_299",
  "regions": []
 },
 {
  "length": 11518,
  "seq_id": "scaffold_300",
  "regions": []
 },
 {
  "length": 11494,
  "seq_id": "scaffold_301",
  "regions": []
 },
 {
  "length": 11482,
  "seq_id": "scaffold_302",
  "regions": []
 },
 {
  "length": 11449,
  "seq_id": "scaffold_303",
  "regions": []
 },
 {
  "length": 11444,
  "seq_id": "scaffold_304",
  "regions": []
 },
 {
  "length": 11432,
  "seq_id": "scaffold_305",
  "regions": []
 },
 {
  "length": 11402,
  "seq_id": "scaffold_306",
  "regions": []
 },
 {
  "length": 11370,
  "seq_id": "scaffold_307",
  "regions": []
 },
 {
  "length": 11269,
  "seq_id": "scaffold_308",
  "regions": []
 },
 {
  "length": 11265,
  "seq_id": "scaffold_309",
  "regions": []
 },
 {
  "length": 11227,
  "seq_id": "scaffold_310",
  "regions": []
 },
 {
  "length": 11191,
  "seq_id": "scaffold_311",
  "regions": []
 },
 {
  "length": 11025,
  "seq_id": "scaffold_312",
  "regions": []
 },
 {
  "length": 11020,
  "seq_id": "scaffold_313",
  "regions": []
 },
 {
  "length": 11019,
  "seq_id": "scaffold_314",
  "regions": []
 },
 {
  "length": 10990,
  "seq_id": "scaffold_315",
  "regions": []
 },
 {
  "length": 10984,
  "seq_id": "scaffold_316",
  "regions": []
 },
 {
  "length": 10953,
  "seq_id": "scaffold_317",
  "regions": [
   {
    "start": 1,
    "end": 10953,
    "idx": 1,
    "orfs": [
     {
      "start": 16,
      "end": 1706,
      "strand": 1,
      "locus_tag": "MARS55BIN28_003967",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003967</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003967</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003967-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16 - 1,706,\n (total: 1656 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003967 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [313:443](score: 138.9, e-value: 1.4e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [466:501](score: 30.6, e-value: 2.4e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_003967 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003967\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003967-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ACCCCTGCAGACGTGATTTCGAAAGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAACGGTTTGGGGATTTTCTGA",
      "translation": "MPADVISKEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDANGLGIF",
      "product": "hypothetical protein"
     },
     {
      "start": 1763,
      "end": 3094,
      "strand": -1,
      "locus_tag": "MARS55BIN28_003968",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003968</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003968</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003968-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,763 - 3,094,\n (total: 1332 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003968\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAAAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCATCTCTATATTTGCTTCAAAGTTGCACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGGGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
      "translation": "MPSLIPRCPIYTFHDTDTTSSTDELEVIAVWKKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLGRLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
      "product": "hypothetical protein"
     },
     {
      "start": 3526,
      "end": 7593,
      "strand": 1,
      "locus_tag": "MARS55BIN28_003969",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003969</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003969</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003969-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,526 - 7,593,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 241.3; E-value: 2.7e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003969 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.0, e-value: 2.3e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 253.3, e-value: 2.2e-75)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003969 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1895.0, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 375.7, e-value: 6e-113)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 339.8, e-value: 5.3e-102)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003969\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003969-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCGGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACTTTCCTAGATCACACCAATGGGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGATTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTTCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGAAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATCGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAGTCGACGTCGTAATTCACAACGGGGCCCAAGTTCATTGGGTATATCCGTACGCTAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTGCTGGCAAAGCCAAAAGCGTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAGAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATGATCCGTGAAGCTGGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAACTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAACTAAGTACAATTGGAGGACGCGGAGGAAATAAGATAGAATCAGGCTAG",
      "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQIIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSSTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEVDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCAAGKAKSVTFVSTTSVLDCEYYTELSDRILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYMIREAGKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
      "product": "hypothetical protein"
     },
     {
      "start": 7607,
      "end": 9267,
      "strand": -1,
      "locus_tag": "MARS55BIN28_003970",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003970</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003970</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003970-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,607 - 9,267,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 962.1, e-value: 8.8e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003970\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003970-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAGAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
      "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDRGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
      "product": "hypothetical protein"
     },
     {
      "start": 9376,
      "end": 9663,
      "strand": 1,
      "locus_tag": "MARS55BIN28_003971",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003971</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003971</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003971-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,376 - 9,663,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003971 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13259.9 (Protein of unknown function (DUF4050)): [35:84](score: 40.6, e-value: 3.5e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003971\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGGAGAGCTGGAACGAGGGGCTGAAGCACTGGAAAGCGCAAAGGGCGCGCTGGACACGCTCGGATGGGGAGAAAGTGCAGGCTTCGCAAGGCCGCCTGGATCAGATGCGCGCGAAGCTGAATGCACGCGATTTTTTGACAATCCACACGGCCTTGGTTGTACAAGGGAAGAAGCCCAAAAGGCGCCTGAACCTTGCGTTGGTGGTGAAGAGTCTTATTTGCGGGTGGAAGGAGGATGGCACCTGGCCCCAGAACAGTCAATCTGCTCCGGATGGCCGTGGATGA",
      "translation": "MEESWNEGLKHWKAQRARWTRSDGEKVQASQGRLDQMRAKLNARDFLTIHTALVVQGKKPKRRLNLALVVKSLICGWKEDGTWPQNSQSAPDGRG",
      "product": "hypothetical protein"
     },
     {
      "start": 9753,
      "end": 10724,
      "strand": -1,
      "locus_tag": "MARS55BIN28_003972",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003972</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003972</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003972-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,753 - 10,724,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003972 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:270](score: 203.7, e-value: 3e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003972\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003972-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTTAACAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGCATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTGGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGCCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
      "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 3525,
      "end": 7593,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 10953,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r317c1"
   }
  ]
 },
 {
  "length": 10866,
  "seq_id": "scaffold_318",
  "regions": []
 },
 {
  "length": 10856,
  "seq_id": "scaffold_319",
  "regions": []
 },
 {
  "length": 10837,
  "seq_id": "scaffold_320",
  "regions": []
 },
 {
  "length": 10737,
  "seq_id": "scaffold_321",
  "regions": []
 },
 {
  "length": 10682,
  "seq_id": "scaffold_322",
  "regions": []
 },
 {
  "length": 10643,
  "seq_id": "scaffold_323",
  "regions": []
 },
 {
  "length": 10629,
  "seq_id": "scaffold_324",
  "regions": []
 },
 {
  "length": 10627,
  "seq_id": "scaffold_325",
  "regions": []
 },
 {
  "length": 10582,
  "seq_id": "scaffold_326",
  "regions": []
 },
 {
  "length": 10557,
  "seq_id": "scaffold_327",
  "regions": []
 },
 {
  "length": 10540,
  "seq_id": "scaffold_328",
  "regions": []
 },
 {
  "length": 10458,
  "seq_id": "scaffold_329",
  "regions": []
 },
 {
  "length": 10434,
  "seq_id": "scaffold_330",
  "regions": []
 },
 {
  "length": 10324,
  "seq_id": "scaffold_331",
  "regions": []
 },
 {
  "length": 10296,
  "seq_id": "scaffold_332",
  "regions": []
 },
 {
  "length": 10235,
  "seq_id": "scaffold_333",
  "regions": []
 },
 {
  "length": 10208,
  "seq_id": "scaffold_334",
  "regions": []
 },
 {
  "length": 10173,
  "seq_id": "scaffold_335",
  "regions": []
 },
 {
  "length": 10171,
  "seq_id": "scaffold_336",
  "regions": []
 },
 {
  "length": 10150,
  "seq_id": "scaffold_337",
  "regions": []
 },
 {
  "length": 10051,
  "seq_id": "scaffold_338",
  "regions": []
 },
 {
  "length": 10010,
  "seq_id": "scaffold_339",
  "regions": []
 },
 {
  "length": 10006,
  "seq_id": "scaffold_340",
  "regions": []
 },
 {
  "length": 10000,
  "seq_id": "scaffold_341",
  "regions": []
 },
 {
  "length": 10000,
  "seq_id": "scaffold_342",
  "regions": []
 },
 {
  "length": 9981,
  "seq_id": "scaffold_343",
  "regions": []
 },
 {
  "length": 9962,
  "seq_id": "scaffold_344",
  "regions": []
 },
 {
  "length": 9951,
  "seq_id": "scaffold_345",
  "regions": []
 },
 {
  "length": 9904,
  "seq_id": "scaffold_346",
  "regions": []
 },
 {
  "length": 9903,
  "seq_id": "scaffold_347",
  "regions": []
 },
 {
  "length": 9843,
  "seq_id": "scaffold_348",
  "regions": []
 },
 {
  "length": 9838,
  "seq_id": "scaffold_349",
  "regions": []
 },
 {
  "length": 9832,
  "seq_id": "scaffold_350",
  "regions": []
 },
 {
  "length": 9815,
  "seq_id": "scaffold_351",
  "regions": []
 },
 {
  "length": 9810,
  "seq_id": "scaffold_352",
  "regions": []
 },
 {
  "length": 9790,
  "seq_id": "scaffold_353",
  "regions": []
 },
 {
  "length": 9785,
  "seq_id": "scaffold_354",
  "regions": []
 },
 {
  "length": 9783,
  "seq_id": "scaffold_355",
  "regions": []
 },
 {
  "length": 9759,
  "seq_id": "scaffold_356",
  "regions": []
 },
 {
  "length": 9717,
  "seq_id": "scaffold_357",
  "regions": []
 },
 {
  "length": 9657,
  "seq_id": "scaffold_358",
  "regions": []
 },
 {
  "length": 9645,
  "seq_id": "scaffold_359",
  "regions": []
 },
 {
  "length": 9642,
  "seq_id": "scaffold_360",
  "regions": []
 },
 {
  "length": 9641,
  "seq_id": "scaffold_361",
  "regions": []
 },
 {
  "length": 9611,
  "seq_id": "scaffold_362",
  "regions": []
 },
 {
  "length": 9547,
  "seq_id": "scaffold_363",
  "regions": []
 },
 {
  "length": 9534,
  "seq_id": "scaffold_364",
  "regions": []
 },
 {
  "length": 9516,
  "seq_id": "scaffold_365",
  "regions": []
 },
 {
  "length": 9482,
  "seq_id": "scaffold_366",
  "regions": []
 },
 {
  "length": 9476,
  "seq_id": "scaffold_367",
  "regions": []
 },
 {
  "length": 9444,
  "seq_id": "scaffold_368",
  "regions": []
 },
 {
  "length": 9436,
  "seq_id": "scaffold_369",
  "regions": []
 },
 {
  "length": 9434,
  "seq_id": "scaffold_370",
  "regions": []
 },
 {
  "length": 9403,
  "seq_id": "scaffold_371",
  "regions": []
 },
 {
  "length": 9395,
  "seq_id": "scaffold_372",
  "regions": []
 },
 {
  "length": 9395,
  "seq_id": "scaffold_373",
  "regions": []
 },
 {
  "length": 9392,
  "seq_id": "scaffold_374",
  "regions": []
 },
 {
  "length": 9382,
  "seq_id": "scaffold_375",
  "regions": []
 },
 {
  "length": 9313,
  "seq_id": "scaffold_376",
  "regions": []
 },
 {
  "length": 9241,
  "seq_id": "scaffold_377",
  "regions": []
 },
 {
  "length": 9203,
  "seq_id": "scaffold_378",
  "regions": []
 },
 {
  "length": 9193,
  "seq_id": "scaffold_379",
  "regions": []
 },
 {
  "length": 9175,
  "seq_id": "scaffold_380",
  "regions": []
 },
 {
  "length": 9167,
  "seq_id": "scaffold_381",
  "regions": []
 },
 {
  "length": 9134,
  "seq_id": "scaffold_382",
  "regions": []
 },
 {
  "length": 9129,
  "seq_id": "scaffold_383",
  "regions": []
 },
 {
  "length": 9086,
  "seq_id": "scaffold_384",
  "regions": []
 },
 {
  "length": 9076,
  "seq_id": "scaffold_385",
  "regions": []
 },
 {
  "length": 9072,
  "seq_id": "scaffold_386",
  "regions": []
 },
 {
  "length": 9034,
  "seq_id": "scaffold_387",
  "regions": []
 },
 {
  "length": 9024,
  "seq_id": "scaffold_388",
  "regions": []
 },
 {
  "length": 8988,
  "seq_id": "scaffold_389",
  "regions": []
 },
 {
  "length": 8937,
  "seq_id": "scaffold_390",
  "regions": []
 },
 {
  "length": 8907,
  "seq_id": "scaffold_391",
  "regions": []
 },
 {
  "length": 8902,
  "seq_id": "scaffold_392",
  "regions": []
 },
 {
  "length": 8874,
  "seq_id": "scaffold_393",
  "regions": []
 },
 {
  "length": 8866,
  "seq_id": "scaffold_394",
  "regions": []
 },
 {
  "length": 8861,
  "seq_id": "scaffold_395",
  "regions": []
 },
 {
  "length": 8838,
  "seq_id": "scaffold_396",
  "regions": []
 },
 {
  "length": 8746,
  "seq_id": "scaffold_397",
  "regions": []
 },
 {
  "length": 8745,
  "seq_id": "scaffold_398",
  "regions": []
 },
 {
  "length": 8730,
  "seq_id": "scaffold_399",
  "regions": []
 },
 {
  "length": 8675,
  "seq_id": "scaffold_400",
  "regions": []
 },
 {
  "length": 8642,
  "seq_id": "scaffold_401",
  "regions": []
 },
 {
  "length": 8594,
  "seq_id": "scaffold_402",
  "regions": []
 },
 {
  "length": 8587,
  "seq_id": "scaffold_403",
  "regions": []
 },
 {
  "length": 8555,
  "seq_id": "scaffold_404",
  "regions": []
 },
 {
  "length": 8509,
  "seq_id": "scaffold_405",
  "regions": []
 },
 {
  "length": 8466,
  "seq_id": "scaffold_406",
  "regions": []
 },
 {
  "length": 8454,
  "seq_id": "scaffold_407",
  "regions": []
 },
 {
  "length": 8437,
  "seq_id": "scaffold_408",
  "regions": []
 },
 {
  "length": 8429,
  "seq_id": "scaffold_409",
  "regions": []
 },
 {
  "length": 8333,
  "seq_id": "scaffold_410",
  "regions": []
 },
 {
  "length": 8286,
  "seq_id": "scaffold_411",
  "regions": []
 },
 {
  "length": 8286,
  "seq_id": "scaffold_412",
  "regions": []
 },
 {
  "length": 8273,
  "seq_id": "scaffold_413",
  "regions": []
 },
 {
  "length": 8257,
  "seq_id": "scaffold_414",
  "regions": []
 },
 {
  "length": 8249,
  "seq_id": "scaffold_415",
  "regions": []
 },
 {
  "length": 8194,
  "seq_id": "scaffold_416",
  "regions": []
 },
 {
  "length": 8135,
  "seq_id": "scaffold_417",
  "regions": []
 },
 {
  "length": 8133,
  "seq_id": "scaffold_418",
  "regions": []
 },
 {
  "length": 8033,
  "seq_id": "scaffold_419",
  "regions": []
 },
 {
  "length": 7987,
  "seq_id": "scaffold_420",
  "regions": []
 },
 {
  "length": 7942,
  "seq_id": "scaffold_421",
  "regions": [
   {
    "start": 1,
    "end": 7942,
    "idx": 1,
    "orfs": [
     {
      "start": 1340,
      "end": 4744,
      "strand": 1,
      "locus_tag": "MARS55BIN28_004502",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004502</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004502</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004502-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,340 - 4,744,\n (total: 3036 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: itr_KS<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 93.3; E-value: 2.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004502 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16073.8 (Starter unit:ACP transacylase in aflatoxin biosynthesis): [10:248](score: 75.9, e-value: 3.8e-21)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [401:608](score: 199.8, e-value: 5.8e-59)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [649:755](score: 96.0, e-value: 1.6e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004502\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004502-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCGCGTTGACAGAACACTGTCTGGTGTTGTTTGGAGGCCAGGGGTCGCCGTCCATTTTCTCGCCTAGTGCGGCCGCGACTGCAGAGGAAGATGCTCGATCAGCGAGCGCCGGCAGCATCCTTCTGTCGAGGTGCCATGCGGCTTTCTTGCAAGAGATAGCGAGTCTAGACGCCCGCTCGCAACATCTTCTCGCCATCGATCCCGCCCTGTTCTCCTTCCCACGTGACTTGCTCAAGCCGGTCGCACAATATCACACACACGCAGTGCTCCAGGCGACCACCATCTACCTCTGCCAGCTGCTACATTATCTGGCTGAGACACAGCGTATCGACGGACCATTCGAGGACTCGTTTGACCGACTTCGAGAGACAGCGGGCTTCTCTTCGGGTTTGCTCCCGGCTACGGTAGTTGCACGCTCGCGCAGCTTGGACGACTTTGTGACATCTGGAATCGAAGGGTTCCGCCTTGCCTTTTGGATTGCATGTCGCAGTCTCTTCTGGAGCCTCAACCCCAATGCAAGCGACCCCGTTGGCGATGGCGTCGACTCAGAAGCGACATCGTCCCTTGTGATTCGTGGTCTTTCCCCAAGCCAGGTCGAAGAGAGATTATTACAGCACTTCGCGGCGCAGGGGCCGGGCCCTTTATCCCAGCAACCGCCTCGACGACTCCAGGTATCTACCATCTCCAATTCTAGTGTTGTGTCTGTATCTGGCCCTAGAGTGGATCTCAGTGCGTTCAGGGTGCAGGCTGTCCCCGATCTTGCAACAACCTTCGCGCATGTACATGGATGGTATCATGGAGGAGATCAACTTGAAGGTGTTGTCCACGAAGTTCTTGAAGATTTGCGGCGTCGGGCCGTCTCCTTCCCCTCTTTCTCCACGCTTACAAAACCCATTCGTTCAACCTTTGACGGCACGTTATTCGATGCTTCAAACACCGATGCTCCAGAGTTGCTTGGGTGGTTAGTTCGGCACTTGTTGCTACACTGTGTAAATTGGAGCGACACAGCTCATGAGATCGCAGCAAGTGTTAGGGCGTTATTGGAACGGGAGCCCGCAACAGTCGTGAAGCTCCTTTCCTTCGGACCAGGCTCCGGCTCCCTATTCCCAAACTTTCAGCCTCTTGATCCTAGAATAGAACTTCTGGATCTCTCGCCATTTAGAGCTAGCAGGAAATCTCGGTTGTCTTGTAACCACCAGGATAGCATCGCCATTGTTGGGCTGAGCGTGCATCTCCCCAAAGGGAATGGCACCGAAGAGCTATGGGAAACGCTGTCCCAAGGGTTGAATGCCGTGCAAGAGATCCCTGAGTCCAGGTTCAAAGTCTCGGACTATTATTCAGAGGAGGATTCGCATAAGCCGCGCTCGATGCCCACGAAGCACGGCGCATTCCTGGACGATCCCTTCTCCTTTGATAATGCCTATTTCAATATTTCCCCTCGAGAAGCAAAATCTATGGATCCTCAGCAGCGAATTTTATTGCATGCAGCCCAGGAAGCCTTTGAAGATGCTGGCTATGTAGGGGATTCATCACCATCTTTCCAAAGAGCTTCCATCGGATGCTACATTGGCCTTGCTACTGGGGATTACACAGACAACCTTCGCAATGATATTGATGTCTTCTACCCCCCCGGGACACTACGAGCATTTCATAGTGGAAGGATATCTTACTTTTATGGGCTCAGTGGCCCATCCATTGTGACTGATACTGCATGTTCGTCCTCAATTGTCTCCGTGTACCAGGCATGCCGAGCCCTACAACGTGGCGATTGCACAGCAGCTATCGCGGGCGGCGCCAATGTGATTTCCAGCCCCGATCCCGAGGCCACTTCCTCAGTCCAACCGGAGGCTGCAAACCCTTCGATGCAGCAGCTGACGGATATTGTCGGGCTGAAGGGTGTGTTCTCTTTGTTCTCAAACGATTGTCTGATGCTATCGCGGAAAACGATCACATACACGGCGTTATCAGGAACTCAAACACAAATCGACCTGTTCCAGCGACTGCTCCAACAAACGAATGTCGATCCTGGATCCATTGGTGTCGTAGAAGCACACGGGACAGGCACACAGGCCGGAGATGCACGCGAAATTGAAAGCTTGCAAACTATCTTTGGCCCACATCACTCAATGGTGAACCCCCTTGTGGTCAGTTCTATCAAGGGTAATAACATAGGCCATTGTGAATCCGCGTCTGGAGCAGCTGGTTTGGCTAAATTATTGCTCATGCTTCGCGAGAAAATAATCCCAGTACAAGTCGGATTTAAGGACGTCAATCCACGTTTCGCGGACCTGGAAAGCTCTGGCTTCATTATACCAAGGCAGACTACAGCATGGATCCACTCGCAAAGAGCCCCAAGGAGAGCTATGCTGAATAATTTCGGGGCTGCTGGCTCAAATACGTCTCTCCTCCTAGAAGAGTGGGTTGAGCCACCAAATACCCAGCCCAGGCACCAGGAGCGATCAGCGTATGTCTTTGCACTTTCTGCAAAATCAAAAACTGCATTGCAAACGGCTGTACATCGACACCTCCGATTCCTGGGGAAAGTAGATCGTCGGCCATCGTTGAAAGACATCTGTTATACCGCAACTGCGCGGCGTCAGATTCATGATCACCGCATCTCCGTGGTATGCACCACTATTGATGATCTACGGACAAGGTTAGAACATTGCAAAGCTGTCAACTCCATTCCCGCTCAGGGTATCTCAGCCACTGTTTTTGTCTTCTCTGGACAAGGCGGTTTGTATCACGGTATGGGAGAAGAATTAAAGTACACATTCCCTCTTTTCAAAGAGGTTATCATGAGTTGCGATGGCATCATCCAAGGATTGGGATACCCAAGCATTCTCAGTATCTTATGCAAAGATCGAGGCGGAGTAAAGGCATTAGACGGCGCTGAGCAGTTTATCGCATCACAATGTGCGTGCGTCGCACTAGAATATGCGCTCGCGAAAATGTTCATGTTGTGGGGGATTATGCCCGAATATGTTATGGGTCATAGGTACTTCAGCACCCCAGAGGTCTTCATCTACTAA",
      "translation": "MPALTEHCLVLFGGQGSPSIFSPSAAATAEEDARSASAGSILLSRCHAAFLQEIASLDARSQHLLAIDPALFSFPRDLLKPVAQYHTHAVLQATTIYLCQLLHYLAETQRIDGPFEDSFDRLRETAGFSSGLLPATVVARSRSLDDFVTSGIEGFRLAFWIACRSLFWSLNPNASDPVGDGVDSEATSSLVIRGLSPSQVEERLLQHFAAQGPGPLSQQPPRRLQVSTISNSSVVSVSGPRVDLSAFRVQAVPDLATTFAHVHGWYHGGDQLEGVVHEVLEDLRRRAVSFPSFSTLTKPIRSTFDGTLFDASNTDAPELLGWLVRHLLLHCVNWSDTAHEIAASVRALLEREPATVVKLLSFGPGSGSLFPNFQPLDPRIELLDLSPFRASRKSRLSCNHQDSIAIVGLSVHLPKGNGTEELWETLSQGLNAVQEIPESRFKVSDYYSEEDSHKPRSMPTKHGAFLDDPFSFDNAYFNISPREAKSMDPQQRILLHAAQEAFEDAGYVGDSSPSFQRASIGCYIGLATGDYTDNLRNDIDVFYPPGTLRAFHSGRISYFYGLSGPSIVTDTACSSSIVSVYQACRALQRGDCTAAIAGGANVISSPDPEATSSVQPEAANPSMQQLTDIVGLKGVFSLFSNDCLMLSRKTITYTALSGTQTQIDLFQRLLQQTNVDPGSIGVVEAHGTGTQAGDAREIESLQTIFGPHHSMVNPLVVSSIKGNNIGHCESASGAAGLAKLLLMLREKIIPVQVGFKDVNPRFADLESSGFIIPRQTTAWIHSQRAPRRAMLNNFGAAGSNTSLLLEEWVEPPNTQPRHQERSAYVFALSAKSKTALQTAVHRHLRFLGKVDRRPSLKDICYTATARRQIHDHRISVVCTTIDDLRTRLEHCKAVNSIPAQGISATVFVFSGQGGLYHGMGEELKYTFPLFKEVIMSCDGIIQGLGYPSILSILCKDRGGVKALDGAEQFIASQCACVALEYALAKMFMLWGIMPEYVMGHRYFSTPEVFIY",
      "product": "hypothetical protein"
     },
     {
      "start": 4847,
      "end": 7757,
      "strand": 1,
      "locus_tag": "MARS55BIN28_004503",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004503</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004503</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004503-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,847 - 7,757,\n (total: 2865 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00698.24 (Acyl transferase domain): [9:189](score: 53.4, e-value: 2.9e-14)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [266:554](score: 63.3, e-value: 2.3e-17)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [614:678](score: 25.8, e-value: 1.1e-05)<br>\n \n  PF00975.23 (Thioesterase domain): [737:952](score: 79.7, e-value: 3.6e-22)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR04532 (PT_fungal_PKS: polyketide product template domain): [266:563](score: 180.4, e-value: 1.4e-53)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004503\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004503-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGACAATTGTGTGGCTAACGCGTCTGGGATGCTGGCGTGCAAGTTATCCCCCGAAAAGGCCGAGGAATTGATATTGGAAAACTCGGGCGTGTCCCAGCTGACCGTGGCATGCCTGAATGGCATTGGTGACTGTGTCGTTGGTGGACCGCTGGGCCAAATCGATATATTTCAGAAGGATTGCAAGACCCGGAAGATCAAGGTGAAGTTGATGGACGTCGCCTACGCCTTCCACTCACCAGCTATGGATCCAATCCTGGAACCCCTGCAAGCCCTGGGGCGCTCAATCAGGTTCGCACGACCTACGATTCCCGTCATCTCTAATGTGTTTGGGCGATTATTTGAAGAGGAAGACTTTTCTAGTGACTACTTCGCGCTTCACGCGAGGCAGCCAGTGCGCTTTACCGAATGTCTGCTTAATTTACAATCAAGAGAACTGCTCGACGGTGCTGTCTTCCTTGAGATAGGCCCACAACCTACAACAATACCAATGCTACGGAGCTCGATTCATTCAGACTCTTGTACCTACCTTAGTACCTTACAAAAGGGCCAAGATGCATGGACCTCGATTAGTTTAACACTGGCCGCGATATCATTGCTCAAATTTCCAGTCAACTGGCGCGAGGTTTTTATTGGGACGTCTGCGAAAGTGATAGGCTTACCAGGCCATCTATTGGAGGGCTCGACCTATATGATACCTTACCAGGAACCTCGTCAGGTTGTCAATTCCCTTGAGCAGTATTCGGTGGAGCTCCGCACCAGGACCGGGTTTAAGCTGCTACCATGGCTGAAGACTCAGGCGTCTTCGAACGAGGAATTTGTGCTTGAGACAACATTAGCAATTCTTGGGCCATTGATCACAGGGCATGAGGTTGGCGGGACTTCCATCTGCCCAGCGTCAGTATTCCATGAGCTCGCCTTGGAAGGAGCACACACTATGCTTGAGCCTCACGAGGGCCAACTATTGGTCGTCACCGGGATGAGCTTTACCAGTCCACTAATATATGTACCGTCACAGGAAGCAGATGTTGTGACTGTGTACATCACAAAATATGATTTAGCTTCCGGGGCAGACTTTAAAATTACCTCATGCTCGACCAAAGATCTTACGGAGAATATAAACTGTACCGGTAGTGTCTCCCTGCAAAACTTCCAGATCAACGCATCCCACTGGATAAAGGATGCGGCAATTGTGACGAGGCAAAGTCATTACTTCTCTGGTGTCGGGAAAAGTTACATCAGTACTTTCCGAACTAAAGTCCTTTATGAGGCTATCTTTACACGTGTTGTCAGGTATTCCCCAGAGTACCAAAGCTTGGTGTATTTGAGTGTGACCAACTCCAATCTCGAAGGTATTGGCTCGTTCAAACTACCGTCTAGTTCTCAGACCGGTTACCTTGCACCCCCTGTCTTTACAGACACACTTCTGCATGCTGCAGGTTTCATTGCAAATCTTGCTGTAAGGTCCGACGAAGTAGGCATTTGCGCCCGCGTCGAGTCGGTCGAGATATCTTACCGTGATATCGATTACGCGGATTCTTTCACAGTTTACTGCAGCTTGCTCGAAATCAAAGGTGCAATTCTAGCAGACGCAATTGCCTTGAATGCTTTCGGGAAAGTCGTCGCCGTCGTTCGGGACATGGAATTTAAAAGACTCCAATTGTCTGCTTTCCAGCAAGTGTTGTCTCGCAAGTCCACTGCCATTGAGCCTCGGAATTTTCCTGTGGAGCAAAAGAAACCGCAGCTATCAACTGGTTTGGACACTCCTCCCACAAGTGGCGAGGTCATAGATACTCCCATCGAGTCTCGTGGTAGTCTTCCTCATGACGTAAGGATAGCACTGAAGAATATCGTCATGGAATTTGGTGGTTTCTCCGAGCAAGATATGGATTACACGAATTCACTAGATGAACTTGGGATCCATTCTCTTATGCAAATTGAGATTATCTCGAAACTGATACGCACATTTCCCGGTCAAGCTGGGCTGGACCACCATGCTTTGTCAGAATGCGAAACTCTCGAGTCCTTGGAAAGCACTCTGGCATCCATTCTGCAATCCTCGGTGGAAATCACTTCGCTTGTTGGGGCTCCCATATCCGCCAGTCAGCGAGATTCACGTCAGTCTACTCTTGTTCCTTCAGACTTTTCTTCATCTGATGGCATGCAGAAGAATCCAGTAGCGCTACATGTTTCACACGAAGAGGTAGCACCGCTCTGCCTATTTCATGACGGGAGTGGGCAGGTCAGCATGTATGCACGGCTGCGTGATCACGACCGCAGTGCATACGCCTTCTTCGACCCGCATTTTGGGAGTGACAAGCGACCTCACAGCAGCATAAATCAGATGACCGAGTACTATGTCTCGCTCCTCTCAAGATCTAAACTATCTCCCTTGATAGTGAGTGGTTGGTCTTTTGGCGGAATAGTGGCCTTCGAGGCGGCTCAACAGCTCATGGCCAATGGATTCGAGGTAAAGGGCCTCATATTGATCGACTCTCCAAATCCCATTGATCACGAACCTCTTCCGAATGAAGTCATTGCCAACATTATCAAATCGAGCGGTCAGACTCATGCGTTGAACAACAATGCTGCACTAAGGGAAGAATTCCAATTCCACGCATCTCTACTAGGAAGTTACAAGGCAGTATCCTTTTCCAAAACGAATAGACTGAGACTGAAGACGGTCATGTTGAGAAGCCAGAACGTCTTCGATACTGAAAGTCTTTGCGGGGTTCGCTATGACTGGCTCAGTAACCAGGATGCTCGAGCTGCTGCTATCGTCGCCTGGGAAGGATTGGTCGGTGGTTATGTCAAGGTTCTGCCAATCCCTGGAAACCATTTCGAGGCCTTCTCACAGAAAAAC",
      "translation": "MTDNCVANASGMLACKLSPEKAEELILENSGVSQLTVACLNGIGDCVVGGPLGQIDIFQKDCKTRKIKVKLMDVAYAFHSPAMDPILEPLQALGRSIRFARPTIPVISNVFGRLFEEEDFSSDYFALHARQPVRFTECLLNLQSRELLDGAVFLEIGPQPTTIPMLRSSIHSDSCTYLSTLQKGQDAWTSISLTLAAISLLKFPVNWREVFIGTSAKVIGLPGHLLEGSTYMIPYQEPRQVVNSLEQYSVELRTRTGFKLLPWLKTQASSNEEFVLETTLAILGPLITGHEVGGTSICPASVFHELALEGAHTMLEPHEGQLLVVTGMSFTSPLIYVPSQEADVVTVYITKYDLASGADFKITSCSTKDLTENINCTGSVSLQNFQINASHWIKDAAIVTRQSHYFSGVGKSYISTFRTKVLYEAIFTRVVRYSPEYQSLVYLSVTNSNLEGIGSFKLPSSSQTGYLAPPVFTDTLLHAAGFIANLAVRSDEVGICARVESVEISYRDIDYADSFTVYCSLLEIKGAILADAIALNAFGKVVAVVRDMEFKRLQLSAFQQVLSRKSTAIEPRNFPVEQKKPQLSTGLDTPPTSGEVIDTPIESRGSLPHDVRIALKNIVMEFGGFSEQDMDYTNSLDELGIHSLMQIEIISKLIRTFPGQAGLDHHALSECETLESLESTLASILQSSVEITSLVGAPISASQRDSRQSTLVPSDFSSSDGMQKNPVALHVSHEEVAPLCLFHDGSGQVSMYARLRDHDRSAYAFFDPHFGSDKRPHSSINQMTEYYVSLLSRSKLSPLIVSGWSFGGIVAFEAAQQLMANGFEVKGLILIDSPNPIDHEPLPNEVIANIIKSSGQTHALNNNAALREEFQFHASLLGSYKAVSFSKTNRLRLKTVMLRSQNVFDTESLCGVRYDWLSNQDARAAAIVAWEGLVGGYVKVLPIPGNHFEAFSQKN",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 1339,
      "end": 4744,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 7942,
      "product": "T1PKS",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "T1PKS",
    "products": [
     "T1PKS"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS T1PKS",
    "anchor": "r421c1"
   }
  ]
 },
 {
  "length": 7895,
  "seq_id": "scaffold_422",
  "regions": []
 },
 {
  "length": 7876,
  "seq_id": "scaffold_423",
  "regions": []
 },
 {
  "length": 7863,
  "seq_id": "scaffold_424",
  "regions": []
 },
 {
  "length": 7860,
  "seq_id": "scaffold_425",
  "regions": []
 },
 {
  "length": 7834,
  "seq_id": "scaffold_426",
  "regions": []
 },
 {
  "length": 7819,
  "seq_id": "scaffold_427",
  "regions": []
 },
 {
  "length": 7770,
  "seq_id": "scaffold_428",
  "regions": []
 },
 {
  "length": 7761,
  "seq_id": "scaffold_429",
  "regions": []
 },
 {
  "length": 7755,
  "seq_id": "scaffold_430",
  "regions": []
 },
 {
  "length": 7728,
  "seq_id": "scaffold_431",
  "regions": []
 },
 {
  "length": 7711,
  "seq_id": "scaffold_432",
  "regions": []
 },
 {
  "length": 7652,
  "seq_id": "scaffold_433",
  "regions": []
 },
 {
  "length": 7643,
  "seq_id": "scaffold_434",
  "regions": []
 },
 {
  "length": 7641,
  "seq_id": "scaffold_435",
  "regions": []
 },
 {
  "length": 7622,
  "seq_id": "scaffold_436",
  "regions": []
 },
 {
  "length": 7612,
  "seq_id": "scaffold_437",
  "regions": []
 },
 {
  "length": 7565,
  "seq_id": "scaffold_438",
  "regions": []
 },
 {
  "length": 7536,
  "seq_id": "scaffold_439",
  "regions": []
 },
 {
  "length": 7534,
  "seq_id": "scaffold_440",
  "regions": []
 },
 {
  "length": 7512,
  "seq_id": "scaffold_441",
  "regions": []
 },
 {
  "length": 7491,
  "seq_id": "scaffold_442",
  "regions": []
 },
 {
  "length": 7483,
  "seq_id": "scaffold_443",
  "regions": []
 },
 {
  "length": 7477,
  "seq_id": "scaffold_444",
  "regions": []
 },
 {
  "length": 7454,
  "seq_id": "scaffold_445",
  "regions": []
 },
 {
  "length": 7423,
  "seq_id": "scaffold_446",
  "regions": []
 },
 {
  "length": 7381,
  "seq_id": "scaffold_447",
  "regions": []
 },
 {
  "length": 7323,
  "seq_id": "scaffold_448",
  "regions": []
 },
 {
  "length": 7318,
  "seq_id": "scaffold_449",
  "regions": []
 },
 {
  "length": 7246,
  "seq_id": "scaffold_450",
  "regions": []
 },
 {
  "length": 7245,
  "seq_id": "scaffold_451",
  "regions": []
 },
 {
  "length": 7234,
  "seq_id": "scaffold_452",
  "regions": []
 },
 {
  "length": 7233,
  "seq_id": "scaffold_453",
  "regions": []
 },
 {
  "length": 7231,
  "seq_id": "scaffold_454",
  "regions": []
 },
 {
  "length": 7189,
  "seq_id": "scaffold_455",
  "regions": []
 },
 {
  "length": 7139,
  "seq_id": "scaffold_456",
  "regions": []
 },
 {
  "length": 7135,
  "seq_id": "scaffold_457",
  "regions": []
 },
 {
  "length": 6970,
  "seq_id": "scaffold_458",
  "regions": []
 },
 {
  "length": 6969,
  "seq_id": "scaffold_459",
  "regions": []
 },
 {
  "length": 6945,
  "seq_id": "scaffold_460",
  "regions": []
 },
 {
  "length": 6914,
  "seq_id": "scaffold_461",
  "regions": []
 },
 {
  "length": 6914,
  "seq_id": "scaffold_462",
  "regions": []
 },
 {
  "length": 6902,
  "seq_id": "scaffold_463",
  "regions": []
 },
 {
  "length": 6845,
  "seq_id": "scaffold_464",
  "regions": []
 },
 {
  "length": 6826,
  "seq_id": "scaffold_465",
  "regions": []
 },
 {
  "length": 6805,
  "seq_id": "scaffold_466",
  "regions": []
 },
 {
  "length": 6761,
  "seq_id": "scaffold_467",
  "regions": []
 },
 {
  "length": 6758,
  "seq_id": "scaffold_468",
  "regions": []
 },
 {
  "length": 6735,
  "seq_id": "scaffold_469",
  "regions": []
 },
 {
  "length": 6707,
  "seq_id": "scaffold_470",
  "regions": []
 },
 {
  "length": 6695,
  "seq_id": "scaffold_471",
  "regions": []
 },
 {
  "length": 6677,
  "seq_id": "scaffold_472",
  "regions": []
 },
 {
  "length": 6671,
  "seq_id": "scaffold_473",
  "regions": []
 },
 {
  "length": 6671,
  "seq_id": "scaffold_474",
  "regions": []
 },
 {
  "length": 6635,
  "seq_id": "scaffold_475",
  "regions": []
 },
 {
  "length": 6611,
  "seq_id": "scaffold_476",
  "regions": []
 },
 {
  "length": 6609,
  "seq_id": "scaffold_477",
  "regions": []
 },
 {
  "length": 6593,
  "seq_id": "scaffold_478",
  "regions": []
 },
 {
  "length": 6531,
  "seq_id": "scaffold_479",
  "regions": []
 },
 {
  "length": 6494,
  "seq_id": "scaffold_480",
  "regions": []
 },
 {
  "length": 6493,
  "seq_id": "scaffold_481",
  "regions": []
 },
 {
  "length": 6441,
  "seq_id": "scaffold_482",
  "regions": []
 },
 {
  "length": 6407,
  "seq_id": "scaffold_483",
  "regions": []
 },
 {
  "length": 6336,
  "seq_id": "scaffold_484",
  "regions": []
 },
 {
  "length": 6305,
  "seq_id": "scaffold_485",
  "regions": []
 },
 {
  "length": 6283,
  "seq_id": "scaffold_486",
  "regions": []
 },
 {
  "length": 6204,
  "seq_id": "scaffold_487",
  "regions": []
 },
 {
  "length": 6195,
  "seq_id": "scaffold_488",
  "regions": []
 },
 {
  "length": 6189,
  "seq_id": "scaffold_489",
  "regions": []
 },
 {
  "length": 6168,
  "seq_id": "scaffold_490",
  "regions": []
 },
 {
  "length": 6139,
  "seq_id": "scaffold_491",
  "regions": []
 },
 {
  "length": 6129,
  "seq_id": "scaffold_492",
  "regions": []
 },
 {
  "length": 6079,
  "seq_id": "scaffold_493",
  "regions": []
 },
 {
  "length": 6041,
  "seq_id": "scaffold_494",
  "regions": []
 },
 {
  "length": 6024,
  "seq_id": "scaffold_495",
  "regions": []
 },
 {
  "length": 5998,
  "seq_id": "scaffold_496",
  "regions": []
 },
 {
  "length": 5980,
  "seq_id": "scaffold_497",
  "regions": []
 },
 {
  "length": 5969,
  "seq_id": "scaffold_498",
  "regions": []
 },
 {
  "length": 5956,
  "seq_id": "scaffold_499",
  "regions": []
 },
 {
  "length": 5918,
  "seq_id": "scaffold_500",
  "regions": []
 },
 {
  "length": 5904,
  "seq_id": "scaffold_501",
  "regions": []
 },
 {
  "length": 5896,
  "seq_id": "scaffold_502",
  "regions": []
 },
 {
  "length": 5893,
  "seq_id": "scaffold_503",
  "regions": []
 },
 {
  "length": 5808,
  "seq_id": "scaffold_504",
  "regions": []
 },
 {
  "length": 5779,
  "seq_id": "scaffold_505",
  "regions": []
 },
 {
  "length": 5657,
  "seq_id": "scaffold_506",
  "regions": []
 },
 {
  "length": 5621,
  "seq_id": "scaffold_507",
  "regions": []
 },
 {
  "length": 5594,
  "seq_id": "scaffold_508",
  "regions": []
 },
 {
  "length": 5536,
  "seq_id": "scaffold_509",
  "regions": []
 },
 {
  "length": 5530,
  "seq_id": "scaffold_510",
  "regions": []
 },
 {
  "length": 5528,
  "seq_id": "scaffold_511",
  "regions": []
 },
 {
  "length": 5522,
  "seq_id": "scaffold_512",
  "regions": []
 },
 {
  "length": 5510,
  "seq_id": "scaffold_513",
  "regions": []
 },
 {
  "length": 5505,
  "seq_id": "scaffold_514",
  "regions": []
 },
 {
  "length": 5501,
  "seq_id": "scaffold_515",
  "regions": []
 },
 {
  "length": 5495,
  "seq_id": "scaffold_516",
  "regions": []
 },
 {
  "length": 5489,
  "seq_id": "scaffold_517",
  "regions": []
 },
 {
  "length": 5461,
  "seq_id": "scaffold_518",
  "regions": []
 },
 {
  "length": 5430,
  "seq_id": "scaffold_519",
  "regions": []
 },
 {
  "length": 5416,
  "seq_id": "scaffold_520",
  "regions": []
 },
 {
  "length": 5400,
  "seq_id": "scaffold_521",
  "regions": []
 },
 {
  "length": 5398,
  "seq_id": "scaffold_522",
  "regions": []
 },
 {
  "length": 5389,
  "seq_id": "scaffold_523",
  "regions": []
 },
 {
  "length": 5387,
  "seq_id": "scaffold_524",
  "regions": []
 },
 {
  "length": 5357,
  "seq_id": "scaffold_525",
  "regions": []
 },
 {
  "length": 5314,
  "seq_id": "scaffold_526",
  "regions": []
 },
 {
  "length": 5261,
  "seq_id": "scaffold_527",
  "regions": []
 },
 {
  "length": 5261,
  "seq_id": "scaffold_528",
  "regions": []
 },
 {
  "length": 5233,
  "seq_id": "scaffold_529",
  "regions": []
 },
 {
  "length": 5229,
  "seq_id": "scaffold_530",
  "regions": []
 },
 {
  "length": 5227,
  "seq_id": "scaffold_531",
  "regions": [
   {
    "start": 1,
    "end": 5227,
    "idx": 1,
    "orfs": [
     {
      "start": 38,
      "end": 977,
      "strand": -1,
      "locus_tag": "MARS55BIN28_004872",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004872</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004872</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004872-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38 - 977,\n (total: 940 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 233.3; E-value: 5.5e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004872 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 223.8, e-value: 2e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_004872 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004872\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004872-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGAACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGTCTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAG",
      "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNVWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLG",
      "product": "hypothetical protein"
     },
     {
      "start": 1092,
      "end": 1817,
      "strand": 1,
      "locus_tag": "MARS55BIN28_004873",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004873</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004873</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004873-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,092 - 1,817,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004873 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.3, e-value: 4.7e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004873\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCGCCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
      "translation": "MERLIISALEELSSYDASAVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
      "product": "hypothetical protein"
     },
     {
      "start": 3118,
      "end": 5224,
      "strand": 1,
      "locus_tag": "MARS55BIN28_004874",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004874</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004874</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004874-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,118 - 5,224,\n (total: 1860 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 87.5, e-value: 1.7e-24)<br>\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [353:604](score: 293.6, e-value: 1.2e-87)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [349:618](score: 302.9, e-value: 6.4e-91)<br>\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 93.6, e-value: 3.7e-27)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 63.5, e-value: 5.3e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004874\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004874-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATCTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCCAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGACGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGATTCCTGAGGGAACCGTCGCGGATATCGGTGATTATCGAAGGCAGATAGGTACATGCAAGATGATGAGACGGTACGCCACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACG",
      "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMIPEGTVADIGDYRRQIGTCKMMRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQT",
      "product": "hypothetical protein"
     }
    ],
    "clusters": [
     {
      "start": 37,
      "end": 977,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5227,
      "product": "terpene",
      "category": "terpene",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "terpene",
    "products": [
     "terpene"
    ],
    "product_categories": [
     "terpene"
    ],
    "cssClass": "terpene terpene",
    "anchor": "r531c1"
   }
  ]
 },
 {
  "length": 5200,
  "seq_id": "scaffold_532",
  "regions": []
 },
 {
  "length": 5134,
  "seq_id": "scaffold_533",
  "regions": []
 },
 {
  "length": 5118,
  "seq_id": "scaffold_534",
  "regions": []
 },
 {
  "length": 5115,
  "seq_id": "scaffold_535",
  "regions": []
 },
 {
  "length": 5107,
  "seq_id": "scaffold_536",
  "regions": []
 },
 {
  "length": 5103,
  "seq_id": "scaffold_537",
  "regions": []
 },
 {
  "length": 5050,
  "seq_id": "scaffold_538",
  "regions": []
 },
 {
  "length": 5041,
  "seq_id": "scaffold_539",
  "regions": []
 },
 {
  "length": 5023,
  "seq_id": "scaffold_540",
  "regions": []
 },
 {
  "length": 4994,
  "seq_id": "scaffold_541",
  "regions": []
 },
 {
  "length": 4976,
  "seq_id": "scaffold_542",
  "regions": []
 },
 {
  "length": 4941,
  "seq_id": "scaffold_543",
  "regions": []
 },
 {
  "length": 4921,
  "seq_id": "scaffold_544",
  "regions": []
 },
 {
  "length": 4898,
  "seq_id": "scaffold_545",
  "regions": []
 },
 {
  "length": 4882,
  "seq_id": "scaffold_546",
  "regions": []
 },
 {
  "length": 4844,
  "seq_id": "scaffold_547",
  "regions": []
 },
 {
  "length": 4783,
  "seq_id": "scaffold_548",
  "regions": []
 },
 {
  "length": 4768,
  "seq_id": "scaffold_549",
  "regions": []
 },
 {
  "length": 4720,
  "seq_id": "scaffold_550",
  "regions": []
 },
 {
  "length": 4706,
  "seq_id": "scaffold_551",
  "regions": []
 },
 {
  "length": 4690,
  "seq_id": "scaffold_552",
  "regions": []
 },
 {
  "length": 4672,
  "seq_id": "scaffold_553",
  "regions": []
 },
 {
  "length": 4631,
  "seq_id": "scaffold_554",
  "regions": []
 },
 {
  "length": 4589,
  "seq_id": "scaffold_555",
  "regions": []
 },
 {
  "length": 4576,
  "seq_id": "scaffold_556",
  "regions": []
 },
 {
  "length": 4512,
  "seq_id": "scaffold_557",
  "regions": []
 },
 {
  "length": 4506,
  "seq_id": "scaffold_558",
  "regions": []
 },
 {
  "length": 4493,
  "seq_id": "scaffold_559",
  "regions": []
 },
 {
  "length": 4483,
  "seq_id": "scaffold_560",
  "regions": []
 },
 {
  "length": 4479,
  "seq_id": "scaffold_561",
  "regions": []
 },
 {
  "length": 4457,
  "seq_id": "scaffold_562",
  "regions": []
 },
 {
  "length": 4449,
  "seq_id": "scaffold_563",
  "regions": []
 },
 {
  "length": 4438,
  "seq_id": "scaffold_564",
  "regions": []
 },
 {
  "length": 4437,
  "seq_id": "scaffold_565",
  "regions": []
 },
 {
  "length": 4426,
  "seq_id": "scaffold_566",
  "regions": []
 },
 {
  "length": 4420,
  "seq_id": "scaffold_567",
  "regions": []
 },
 {
  "length": 4375,
  "seq_id": "scaffold_568",
  "regions": []
 },
 {
  "length": 4361,
  "seq_id": "scaffold_569",
  "regions": []
 },
 {
  "length": 4360,
  "seq_id": "scaffold_570",
  "regions": []
 },
 {
  "length": 4360,
  "seq_id": "scaffold_571",
  "regions": []
 },
 {
  "length": 4352,
  "seq_id": "scaffold_572",
  "regions": []
 },
 {
  "length": 4342,
  "seq_id": "scaffold_573",
  "regions": []
 },
 {
  "length": 4262,
  "seq_id": "scaffold_574",
  "regions": []
 },
 {
  "length": 4253,
  "seq_id": "scaffold_575",
  "regions": []
 },
 {
  "length": 4240,
  "seq_id": "scaffold_576",
  "regions": []
 },
 {
  "length": 4120,
  "seq_id": "scaffold_577",
  "regions": []
 },
 {
  "length": 4064,
  "seq_id": "scaffold_578",
  "regions": []
 },
 {
  "length": 3984,
  "seq_id": "scaffold_579",
  "regions": []
 },
 {
  "length": 3981,
  "seq_id": "scaffold_580",
  "regions": []
 },
 {
  "length": 3918,
  "seq_id": "scaffold_581",
  "regions": []
 },
 {
  "length": 3909,
  "seq_id": "scaffold_582",
  "regions": []
 },
 {
  "length": 3877,
  "seq_id": "scaffold_583",
  "regions": []
 },
 {
  "length": 3876,
  "seq_id": "scaffold_584",
  "regions": []
 },
 {
  "length": 3841,
  "seq_id": "scaffold_585",
  "regions": []
 },
 {
  "length": 3841,
  "seq_id": "scaffold_586",
  "regions": []
 },
 {
  "length": 3825,
  "seq_id": "scaffold_587",
  "regions": []
 },
 {
  "length": 3783,
  "seq_id": "scaffold_588",
  "regions": []
 },
 {
  "length": 3780,
  "seq_id": "scaffold_589",
  "regions": []
 },
 {
  "length": 3716,
  "seq_id": "scaffold_590",
  "regions": []
 },
 {
  "length": 3635,
  "seq_id": "scaffold_591",
  "regions": []
 },
 {
  "length": 3632,
  "seq_id": "scaffold_592",
  "regions": []
 },
 {
  "length": 3589,
  "seq_id": "scaffold_593",
  "regions": []
 },
 {
  "length": 3571,
  "seq_id": "scaffold_594",
  "regions": []
 },
 {
  "length": 3570,
  "seq_id": "scaffold_595",
  "regions": []
 },
 {
  "length": 3547,
  "seq_id": "scaffold_596",
  "regions": []
 },
 {
  "length": 3539,
  "seq_id": "scaffold_597",
  "regions": []
 },
 {
  "length": 3536,
  "seq_id": "scaffold_598",
  "regions": []
 },
 {
  "length": 3529,
  "seq_id": "scaffold_599",
  "regions": []
 },
 {
  "length": 3486,
  "seq_id": "scaffold_600",
  "regions": []
 },
 {
  "length": 3459,
  "seq_id": "scaffold_601",
  "regions": []
 },
 {
  "length": 3436,
  "seq_id": "scaffold_602",
  "regions": []
 },
 {
  "length": 3417,
  "seq_id": "scaffold_603",
  "regions": []
 },
 {
  "length": 3352,
  "seq_id": "scaffold_604",
  "regions": []
 },
 {
  "length": 3306,
  "seq_id": "scaffold_605",
  "regions": []
 },
 {
  "length": 3298,
  "seq_id": "scaffold_606",
  "regions": []
 },
 {
  "length": 3279,
  "seq_id": "scaffold_607",
  "regions": []
 },
 {
  "length": 3244,
  "seq_id": "scaffold_608",
  "regions": []
 },
 {
  "length": 3231,
  "seq_id": "scaffold_609",
  "regions": []
 },
 {
  "length": 3212,
  "seq_id": "scaffold_610",
  "regions": []
 },
 {
  "length": 3163,
  "seq_id": "scaffold_611",
  "regions": []
 },
 {
  "length": 3134,
  "seq_id": "scaffold_612",
  "regions": []
 },
 {
  "length": 3094,
  "seq_id": "scaffold_613",
  "regions": []
 },
 {
  "length": 3043,
  "seq_id": "scaffold_614",
  "regions": []
 },
 {
  "length": 2965,
  "seq_id": "scaffold_615",
  "regions": []
 },
 {
  "length": 2943,
  "seq_id": "scaffold_616",
  "regions": []
 },
 {
  "length": 2901,
  "seq_id": "scaffold_617",
  "regions": []
 },
 {
  "length": 2839,
  "seq_id": "scaffold_618",
  "regions": []
 },
 {
  "length": 2779,
  "seq_id": "scaffold_619",
  "regions": []
 },
 {
  "length": 2662,
  "seq_id": "scaffold_620",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r44c1",
  "r165c1",
  "r317c1",
  "r421c1",
  "r531c1"
 ],
 "r44c1": {
  "start": 14054,
  "end": 35908,
  "idx": 1,
  "orfs": [
   {
    "start": 14935,
    "end": 15291,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001111",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001111</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001111</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001111-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,935 - 15,291,\n (total: 357 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001111\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001111\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACAAACAGGGATTCCTGTCTGGCTACCTACTGCCAGCGCTGTTCCGGAGCAGCGCCCGGACTCTCCAGCCCCAGCCCCAGCCCCAGCCCCAGCCCCAGCCCGCAGTCCAGCAGCAGCAGCAGCGGTCCCTAGGCAGCAGCGCCACGAGCACCACTACTACACCCGCCACAGCAGAGCAGACGACGTCGGCACACGCAAGGCAGCGGCGCGACTCCACCGGCAGCACGGGGAGCGAGGGCAGCACGGGCGGCTACGTGGCTGCGGGGGCTGGGACGTGGTACATTGGGGGGCGCAATGCGGACGGGCAGGAGCGGTTCTACCAGCTGCACGCAGGGCGGAAGTTTCGGTCGTAG",
    "translation": "MHKQGFLSGYLLPALFRSSARTLQPQPQPQPQPQPAVQQQQQRSLGSSATSTTTTPATAEQTTSAHARQRRDSTGSTGSEGSTGGYVAAGAGTWYIGGRNADGQERFYQLHAGRKFRS",
    "product": "hypothetical protein"
   },
   {
    "start": 15712,
    "end": 17280,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001112",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001112</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001112</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001112-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,712 - 17,280,\n (total: 1569 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001112\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001112\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTCGTTCATTGGCGATGAACCGCGACGTGGAATGCCTGCATCGCCGCTTTCCACGGGCGGAGAAGGCATACATCGAGCATGTCCTCTCCATGTACCACCACGACCGGCTGGGACGCGCGGGCAGGAAGCTGGAACGGCAGGGCTACCCGCTCCAGGAGACGAGTACGAATGAGGTTCTGCTTCAGCTGAATGAAATATGGCCTCTTGCTACAGCCTCTGCACTACGCTCGGCCATCGTCATGTTCCCCTTTGATCGACTGCGGCAAACGACAGAGTATCTCTTGACCCATCCCCCGTCCGGCAAACGCCAACGACCACGTGGCGCCTTTGGACGGCTTGAGCCCTGGGAGATGTTTCGCAGCGAGCAGTATACAATGGCAACCAAATACCTCTTGTACAAGGACTTCAAGATGCTCTACCGCTCCACCATACGCGCCGTGATGGCAGAGAACAACAGCGACTATGCCCGATCCTACAAGTCCTTGAAAGACCTCGAGCAGAAGTCTTGGTGGCCATGGTCATGGCCGTTGCGGTGGAATCTATCCTTCAAGAATGATGATCTGCATGGAATCTCATGCAACGAACTAGAAGACGAAGTGCGACGGCTCAGACCCTCGCATGAACTAGCCGACGAGCAAATGGCACGGAATGTCAACTACGACGAGTACAGGAATGGCCATGCTCTCCTGGATTGTCAGGTGTGCTACGGGTCGTTTGCATGGGAAGATCTCGTGGCTTGCACAAAGGGACACTTTGTCTGCAGATCCTGTGTAGAGCGCTATGTCAAGGAAGGCATTTTCGGTCAGGGGGGGCTACGAGCAAAGACCGCTGTGCGCTGTCTTTCTTCAGAGGAAGAATGCAGCGCCATCATTCCATATGCCCTGGTGGAGCGAAGTGTTTCTGCAGAGCTTCGGGCTGCTTGGCGCGACACGTGTGTGGATACGATACGATGGAGTGGGCTCGATTTAGTGCAATGTCCATTTTGTTACTATGCCGAATTCAAACCATCTGTCAAGCGACGGACGAGCTTACTCTTTGTCTTGCTATTTACGCCTCTTCTTCCTATCATACTATTGATCTACCTCACGCGCTTCATACTCGGCCAATACCTTGCAACGGAGGTGGAGCAGCCTCGACAAGAGATGTTTCGGTGTAGGAATAGTGAGTGTGGAATCGCATCCTGTCTTCTTTGCCGTGAGGAGTTCCTACCGTTTCATAGGTGCCACGCAGACAAGAAGGATGGCATGCGTCGCTACATGGAGGCAGCCATGGCAGACGCCGTCAAGCGAACTTGCCCCCAGTGCAAACTGTCCTTTATCAAGGCTGATGGCTGCAACAAGCTAATCTGCCCGTGCGGCTACGTGATGTGCTATGTTTGTCGAAGAGATATACGTGATGAGGGCTACAAGCACTTTTGCGAGCACTTCCGCCAGCAGCCTGGTCAACCGTGCGACGAGTGCACGAAATGTGACCTCTACAAGGTTGAGACAGATGTGGTAGCCATTGAGCGAGCGGCAAAACGGGCGCAGGAGGAGTACATTTCGATTTCCGAGGGTTGGAAGTGA",
    "translation": "MSRSLAMNRDVECLHRRFPRAEKAYIEHVLSMYHHDRLGRAGRKLERQGYPLQETSTNEVLLQLNEIWPLATASALRSAIVMFPFDRLRQTTEYLLTHPPSGKRQRPRGAFGRLEPWEMFRSEQYTMATKYLLYKDFKMLYRSTIRAVMAENNSDYARSYKSLKDLEQKSWWPWSWPLRWNLSFKNDDLHGISCNELEDEVRRLRPSHELADEQMARNVNYDEYRNGHALLDCQVCYGSFAWEDLVACTKGHFVCRSCVERYVKEGIFGQGGLRAKTAVRCLSSEEECSAIIPYALVERSVSAELRAAWRDTCVDTIRWSGLDLVQCPFCYYAEFKPSVKRRTSLLFVLLFTPLLPIILLIYLTRFILGQYLATEVEQPRQEMFRCRNSECGIASCLLCREEFLPFHRCHADKKDGMRRYMEAAMADAVKRTCPQCKLSFIKADGCNKLICPCGYVMCYVCRRDIRDEGYKHFCEHFRQQPGQPCDECTKCDLYKVETDVVAIERAAKRAQEEYISISEGWK",
    "product": "hypothetical protein"
   },
   {
    "start": 17290,
    "end": 17964,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001113",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001113</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001113</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001113-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,290 - 17,964,\n (total: 675 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001113\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001113\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAACGCTCGGCGGCAGAGTTGCTCGCCTCGCCTGCCCTTCCCACCGCCACCGTCCTGGACAGCAGCTTGCTCCAAGGCGGCCTTCCGAGGGGAAAGCTGACAGAGATATGTGGTCCGCCTGGGGCTGGGAAAACACGGCTTGCAAAGCACGTTGCACACGCACTCACTGCAAGGAAGGAACGAGTCATTTGGGTGGACACAAAGTCACAGACATCACTTCCCATAAACGAACTGCATGCCTATGTCTACCTCCCGACCCTATTGCATCTCCTGGCCTGGTGCCAAACGGAGGTCGTGGAAGCAGATCTCCTCGTCCTCGACGATATCTCCACACCGTTTGCAATCTATCCCTGGACAAAAGGGAACGTGAAGCGGGGCTACCAATGTAAGCGGCGTGCGCAGACGCGTGTATTTCATGAGCTGGCGGCAGTGGCTGTGAAGCACAACATGGCTGTTCTGATGCTCTCGCAAATGACCACCAGCTTCAAGGAGTTTGGAAGCAGTCCCGACGGGGCTCGCAGAGCCATGCTGGAGGCGGCTGTGCAAGGCGAATGTGTGGATATGATTGCCCAACGTCTCACGCTTCTCCGCAGACATAAAGATCGGATTGTGGTGTCACGCGGTGAACAAGTCGAGCTGGATCCATCCTTGTTCCTCCCAGCTCCGGCATGA",
    "translation": "MKRSAAELLASPALPTATVLDSSLLQGGLPRGKLTEICGPPGAGKTRLAKHVAHALTARKERVIWVDTKSQTSLPINELHAYVYLPTLLHLLAWCQTEVVEADLLVLDDISTPFAIYPWTKGNVKRGYQCKRRAQTRVFHELAAVAVKHNMAVLMLSQMTTSFKEFGSSPDGARRAMLEAAVQGECVDMIAQRLTLLRRHKDRIVVSRGEQVELDPSLFLPAPA",
    "product": "hypothetical protein"
   },
   {
    "start": 18037,
    "end": 18942,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001114",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001114</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001114</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001114-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,037 - 18,942,\n (total: 906 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001114 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF03476.19 (MOSC N-terminal beta barrel domain): [1:110](score: 51.3, e-value: 1.1e-13)<br>\n \n  PF03473.20 (MOSC domain): [159:288](score: 87.1, e-value: 1.2e-24)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001114 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding<br>\n  \n   PF03473.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001114\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001114\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACGTAGAGCAACTCTTCATCTACCCTGTGAAATCACTGCATGGCATCAAAGTAGACGCTGCACAGCTATGCGAGACAGGATTCCAGCACGATCGTCTGTACATGTTTGCATTGACACAACCAGACGCCCCTGCAAAGTTCCTTACACAGCGCGAGCTGGCGCGATTGGTCCTGGTCGTCCCGCGCATAGATACCGAGGAGCTCGTCCTCGCCTTTGACGGCATCGAGCAGCGTCTCCCGCTTCGTCTCCCCGCCTCCCTCCGAACCTCCCTCCCGAAGATGGAGGTGACGATATGGAAGCAAACCATTGCAGCACTGGACGCCACCAGCCTCTTTGATCAAAAGAAGCTGCAGCGCTTAGCGTCCTTCATTCAAGTCCCCCACTCTCAACTTGCATTTCTCGCAGCGGCTGATCTGCGACATGTGAAGCGCAATGCGCCAACAGCAGCGCAGATCGGACGAGAGCCCATGTGTGGTTTTGCAGACTACTACCCTGTGCACCTCCTGCAACGAAGCTCCTTCCAGGATCTCGCTCAGAGGGTTCCCTCCACGACAGGTCCAATCGCCATCGAGCGCTTCCGCATGAATGTGGTCGTGGCAGGCGGGGCCGCGTTTGACGAGGATACATGGAAGGAAGTATGCGTAGGCACGAATGCCAAATGGTACATTGCCTGTCGAAATGTGCGGTGTAGCGTGCCGGACGTCAATCCAAGCACGGGCGAGAAGGATGCACATGGGGGTGTGTATAAGACCATGCAGACGTATCGGCGTGTCGACCCAGGCGCAAAGTATCAGCCGTGCTTGGGGACAAATGCTGTGCCGCTTTCGTTGCATGGACAGGTGGCTATTGGGGATGAGATCAAAGTGCTTGCTCGCGGAGAGCATGTCTATATCCCAATCTGA",
    "translation": "MHVEQLFIYPVKSLHGIKVDAAQLCETGFQHDRLYMFALTQPDAPAKFLTQRELARLVLVVPRIDTEELVLAFDGIEQRLPLRLPASLRTSLPKMEVTIWKQTIAALDATSLFDQKKLQRLASFIQVPHSQLAFLAAADLRHVKRNAPTAAQIGREPMCGFADYYPVHLLQRSSFQDLAQRVPSTTGPIAIERFRMNVVVAGGAAFDEDTWKEVCVGTNAKWYIACRNVRCSVPDVNPSTGEKDAHGGVYKTMQTYRRVDPGAKYQPCLGTNAVPLSLHGQVAIGDEIKVLARGEHVYIPI",
    "product": "hypothetical protein"
   },
   {
    "start": 19154,
    "end": 20458,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001115",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001115</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001115</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001115-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,154 - 20,458,\n (total: 1305 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001115 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00096.29 (Zinc finger, C2H2 type): [23:46](score: 20.8, e-value: 0.00041)<br>\n \n  PF00096.29 (Zinc finger, C2H2 type): [52:76](score: 19.7, e-value: 0.00088)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001115\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001115\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGACGAGGATGGGAGCGGCATGATGTCGGGCATTGGCCCCGGCAAACAGGAACTTCCCCGACCCTACAAATGCCCCATGTGCGATAAGGCCTTCCACCGGCTCGAGCACCAAACACGACACATTCGCACGCACACAGGAGAGAAACCGCATGCGTGCACCTTTCCTGGCTGCCAAAAACGATTTTCTCGCAGCGACGAACTGACGAGGCATGCGCGCATCCATTCCAATCCAAATTCACGAAGAAACAACAAGCCCTACCCTCTTGTGGGGCAGATACCTGGCGGTGGTGGAAGCGCTATCAATCCCTATGCGAGTGGAAATGAAATTGGGCAAGGGGCCGGAGGAATGGGCCAACCAGCTGCGTACAGCGGCGAAATAAGGTCTGCGCCGACAAGCCACGGTGGGTCCCCGAACACATCGCCCCCGCTTCTTTCGGACCATGCACCAGTGATCCATTCGACATTGTCACCGTTTGCGAGGGACAGCGGGATGTCTGCATCGTCGACGCCATCAGGCAGTTCTGCAAACATGTATTCCAATCACTACACCAACCAGTACACAGGACAGTATGGGAATCAGAATCAAGTTGGAATCTCGTCTGGGAGGGGTCCGACGCCTCCGGGAAACGGTACCGGTGATGTGCCAAATGATATGCGTATGTTGGCAGCTGCTGCTACGCACGAGCTTGACAGAGAAAAGAGCCAAAAGCATTGGAATGGTCATCCATATGCTGCCGCACATTACCATCATCACAAACAAACACCAATATCTCCTTTTCCACACCACAACCTGCCGACAAACACGCATCCCTTTTTGCACGAGGGCTCTGCACGCCACGACGAGGATCCTCAACGGGCAAAAAAAAGTCGGCCGGGGTCGCCAGAAAGCCCGGTGCCTTCATCCCCTAGCTTTTCGCTGGATGGGAATTCGCCGACACCAGATCACACTCCGCTTACGACCCCGGCGCACTCTCCACGGATCCACCCTCGCGAACTTGAAGCCCTCAACGGCGTTCATCTCCCCTCCATCCGGTCCCTTTCGATCCGCCAGCACCCGCCTGCTCTGACGGCTCTCGAAATCGACCCCTACGCAACCAGCCCTTCCGGCCAGAGCCACTACCCGCATGGAAGCTCGTCGGCCCCGCAGCCCTCTCAGGGCTTTCGCCTGAGCGACATTCTGGATTCGAGGGAAGGAACGCACCGGAAGCTGCCGGTGCCGCGCGTCGGCGAGGGAGTCACGTCGTCTACTTCGTCGGCGAATGTTAGCGTGGCTGGAGATCTGGATCCACGACTTATTTAA",
    "translation": "MGDEDGSGMMSGIGPGKQELPRPYKCPMCDKAFHRLEHQTRHIRTHTGEKPHACTFPGCQKRFSRSDELTRHARIHSNPNSRRNNKPYPLVGQIPGGGGSAINPYASGNEIGQGAGGMGQPAAYSGEIRSAPTSHGGSPNTSPPLLSDHAPVIHSTLSPFARDSGMSASSTPSGSSANMYSNHYTNQYTGQYGNQNQVGISSGRGPTPPGNGTGDVPNDMRMLAAAATHELDREKSQKHWNGHPYAAAHYHHHKQTPISPFPHHNLPTNTHPFLHEGSARHDEDPQRAKKSRPGSPESPVPSSPSFSLDGNSPTPDHTPLTTPAHSPRIHPRELEALNGVHLPSIRSLSIRQHPPALTALEIDPYATSPSGQSHYPHGSSSAPQPSQGFRLSDILDSREGTHRKLPVPRVGEGVTSSTSSANVSVAGDLDPRLI",
    "product": "hypothetical protein"
   },
   {
    "start": 20697,
    "end": 21962,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001116",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001116</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001116</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001116-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,697 - 21,962,\n (total: 1266 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1162:threonyl-tRNA synthetase (Score: 48; E-value: 9.6e-15)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001116 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00587.28 (tRNA synthetase class II core domain (G, H, P, S and T)): [105:313](score: 121.4, e-value: 4.3e-35)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001116 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00587.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001116\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001116\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGATGGCGGAGAATCGTGGATGGAAGGCAGCGACTCTCTCACCATCTGCAAACCAACACCTCTCAGAGCTATGGACGAGATGGATATGGGTACCTTCAACAGGCTGGCTTCGTTCGGGCGACTGGGTCTGCTGGGCTGGTTCAATTGCTTCCACTGGGACAGCGTGTGGTAGATAAGATCACAGGCATTATTCACCGTGAGTTGAATGCAATTGGAGCACTAAGACTCTCCATGACTGGACTTGTTCCGTCTTCACTTTGGAGGCAGTCTGGTAGACTGTCCTCGGAGAGGTCCCAGGCGAGTGAAGAATTATTCCACGTAAATGACCGCCGCCAGGGGGAATTCCTCTTGGCACCGACTCACGAAGAGGACATCACGGCGTTGGTAGGAAGAGAAGTAAGAAGTTGGCGAGATCTTCCACTGCGGCTCTACCAGACGTCCACCAAATGGCGGGATGAAGCCAGACCAAGAGGCGGCCTCTTGCGAGGGAGAGAATTCATCATGAATGATTTATACACATTTGATGGGGACGAATCGTCTGCGATGGTGACGTACGAGGAGGTTACTGGCGCATATGGAAAGATATTCAACGCTATTGGGCTGCCGTATCTTAGGGCACGTGCAACAAGTGGCGCCATGGGAGGGAGCCTTTCGCATGAGTATCATTTTCCAAGTCCCGCTGGTGAAGATGTGATGTGCACGTGCGCTTGTGGTGAGGTCTATAATACCGAGCTGCCGGCGTGTTCTGCATGTGGCGAAGCACTTGGGATGGACAGGGTGCGCACGATTGAAGTAGGCCATACCTTCCATCTTGGCACGAGGTACACGGAGCCGTTTGATGTCCGTGTCTTGGATCGAGGGCAGGTGCGGTGCACTGTGCAGGCAGGGTGTCATGGTATTGGGGTTAGCAGGCTGCTTGGGGCCATTGCCGAGACCAAAGACACGAGGTGGCCGAGAAGTGTGGCCCCATATGAGGCAGTCATCCTCCAGGCGGAAGGCAAGGAGGAAGAATCCGCCTCATGGTACGACCAATTGCTGGCAGTAGGGGTGGATGCAGTGCTGGATGACCGGCTCACCAAGAGCATGGCCTGGAAGCTGAAAGATGCCTCGCTTCTGGGCTACCCCTTTGTCCTCATCCCGCACTCCCCCACGACTACAGAGGTCAACGGACATCTATCCAGCTCTGAGTCCATATCACGTGATCTTGAGTTCGGCACGGATCGGAACGGGGACCAGCACCCGAAGAAGAAAGATACCAAATGA",
    "translation": "MRWRRIVDGRQRLSHHLQTNTSQSYGRDGYGYLQQAGFVRATGSAGLVQLLPLGQRVVDKITGIIHRELNAIGALRLSMTGLVPSSLWRQSGRLSSERSQASEELFHVNDRRQGEFLLAPTHEEDITALVGREVRSWRDLPLRLYQTSTKWRDEARPRGGLLRGREFIMNDLYTFDGDESSAMVTYEEVTGAYGKIFNAIGLPYLRARATSGAMGGSLSHEYHFPSPAGEDVMCTCACGEVYNTELPACSACGEALGMDRVRTIEVGHTFHLGTRYTEPFDVRVLDRGQVRCTVQAGCHGIGVSRLLGAIAETKDTRWPRSVAPYEAVILQAEGKEEESASWYDQLLAVGVDAVLDDRLTKSMAWKLKDASLLGYPFVLIPHSPTTTEVNGHLSSSESISRDLEFGTDRNGDQHPKKKDTK",
    "product": "hypothetical protein"
   },
   {
    "start": 21991,
    "end": 23970,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001117",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001117</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001117</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001117-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,991 - 23,970,\n (total: 1980 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001117 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF17681.4 (Gamma tubulin complex component N-terminal): [90:406](score: 206.1, e-value: 1e-60)<br>\n \n  PF04130.16 (Gamma tubulin complex component C-terminal): [410:657](score: 171.6, e-value: 2.8e-50)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001117 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04130.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001117\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001117\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAAACCACAACACCAGCGCCATCGGTCAAGAGAAAGAGAGGCAGACCATCGGTCGAGAAACAAAGAGCCAGATGCTGCGCGAACAAAGGCGAAGGGTTCAGATAGTGGTCTTGGGGATTGGCAGCCTCTAATCTCGCTAGTGGAAGGGTTAAGTCCTTCGGGTTGTCGTGTAAGCTCTTTACCGATGGCTGGCGACATTCCGGCTAGTTTACGCCGAGGAATCTCTCTTGATAAAATGACTGTGGAAGTGCAAGAAGCTGCTATTGTGAATGATATATTACACGTCCTAAGGGGCTCAGAAGGAAGGTATATTCGGTTCGAGACTCGCCGCAGCAGCTCGCTTCAAAATTACAAACTAGCGAGTGGATTATTCCCAGCCTTTCGTGAAATCACAAACACTCTCACGTTAAGTGCAACAAATTTCCACTTCATTCGGGGCTTTATACACACCCGCTCAAAGACAGAATTTGGCAGCATAAATCACGCCCTTTGTGCATCTTTGTCTCGGATTTTACATGAGTACACAGAGGCGATAGCTATCCTGGAACTCGCCTACAACACTGATCCTGACTTTTCCCTCCGTAATCTTTATAGCCGACTCCTTCCCAACTCTACAACTCTTGCTCACATATTTTCACTATGCCAGCGTATATGCAAAGAAGACCTACAAGAATCTGCTGATGATTCTGATGAACTAGAAAAACTCTTGGAGCCAGTAATGGGGCCGACGAGCCGGTTCGCCAAAGGTGCCGTGATACTACGAATCTTGACGGACAAGATTGCCCATTTACGAGGGAATGAGCATGCACGAAAGCTCTTCACTCACCTCTTAACTTGCACATCGCGACCGTACATGGACATGCTTAATCAATGGCTACACCGAGGGGACCTATGGGATCCGTACGATGAATTTATCATTCGCGAACAACAAACCATTAATAAAGACCGACTAGATGAGGACTATACCGACGAGTACTGGGATAAAAGGTATACAATTCGTGCGGATGACATTCCCACTCAGCTTGTTGGAGTTGCCGACAAGGTGCTCCTTGCAGGAAAGTACCTCAATGTTGTCCGAGAATGTGGTGGGGATTGCAAACGACCGTCCAACGAGCCTGTGACATGGCCAGAATCGTTTCAGGATGAGAAGTTTCTGGAAAATATCCACTCGGCTTACGCTCATGCAAATCGAACTCTCCTCGAACTCTTAGTCAGTCGCCATGATCTTGTCGGGAGGCTACAAAGTCTAAAGTATTATTTACTCCTCGACCGATCAGACTATTTGTTGCACTTCCTAGATGTTGCAGCCCACGAATTGCGGAAGCCAGTCCGTGCTGTCTCTACTACGAAATTGCAGTCATTGCTAGATCTAGTACTTTCGCACCCAGGAAGTATTGCGGCTGTTGAGCCTTTCAAGGAAGATGTTGTCGTTCAAATGAATGAAATCGGGCTCACGGATTGGCTGATGCGGATTTTCAGTGTTGTAGATGATACTGCCGAAGACAAGGAACACGAGAGTGAGGAAGGGGAGAAAGAGCGAGTGACTGGAATTGATGCCTTGCAGCTGGACTACAAAATCCCCTTTCCCCTCTCCTTGGTGATTTCTCGGAAGACTGTTCTACGGTACCAGCTTCTCTTCCGGCACCTTTTACAACTCAAGCACGTTGAGTCTATGTTGTCAAGCGCATGGATTGATCACGCGAAAACTCTCTCATGGCACGCAAGAAGTAGCTTTCCACGTCTCGAAATGTGGAAGCACCGTGTCTGGACTTTACGCGCTCGAATGCTCTCTTCCATACAGGAGTTAATGTACTATTGCACCAGCGAAGTCATTGAGCCTAATTTTTTAAAACTCTTGGGTAAATTTGAACGTGGAATCGCGACTGTGGATGAGGTTATGCAGAATCATGTGGACTTTCTGGATACTTGTCTTAAAGAGTGCATGCTCACAAATTCTAGTCTGCTCAAGGTATAA",
    "translation": "MEKPQHQRHRSREREADHRSRNKEPDAARTKAKGSDSGLGDWQPLISLVEGLSPSGCRVSSLPMAGDIPASLRRGISLDKMTVEVQEAAIVNDILHVLRGSEGRYIRFETRRSSSLQNYKLASGLFPAFREITNTLTLSATNFHFIRGFIHTRSKTEFGSINHALCASLSRILHEYTEAIAILELAYNTDPDFSLRNLYSRLLPNSTTLAHIFSLCQRICKEDLQESADDSDELEKLLEPVMGPTSRFAKGAVILRILTDKIAHLRGNEHARKLFTHLLTCTSRPYMDMLNQWLHRGDLWDPYDEFIIREQQTINKDRLDEDYTDEYWDKRYTIRADDIPTQLVGVADKVLLAGKYLNVVRECGGDCKRPSNEPVTWPESFQDEKFLENIHSAYAHANRTLLELLVSRHDLVGRLQSLKYYLLLDRSDYLLHFLDVAAHELRKPVRAVSTTKLQSLLDLVLSHPGSIAAVEPFKEDVVVQMNEIGLTDWLMRIFSVVDDTAEDKEHESEEGEKERVTGIDALQLDYKIPFPLSLVISRKTVLRYQLLFRHLLQLKHVESMLSSAWIDHAKTLSWHARSSFPRLEMWKHRVWTLRARMLSSIQELMYYCTSEVIEPNFLKLLGKFERGIATVDEVMQNHVDFLDTCLKECMLTNSSLLKV",
    "product": "hypothetical protein"
   },
   {
    "start": 24054,
    "end": 25989,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001118",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001118</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001118</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001118-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,054 - 25,989,\n (total: 1407 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [65:356](score: 128.6, e-value: 3.2e-37)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01559 (squal_synth: farnesyl-diphosphate farnesyltransferase): [56:406](score: 426.2, e-value: 2e-128)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001118 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001118\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_001118-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001118\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCACGATCACTGGGATCTGTGGAGGATGCTTTGAACGAAGGGAGTGGTGACACTGATGAGGCCCAAGGAAGAATGAAGAAGTTGGAAGACGGTTTAGAGAGGTACGAAGAAAACTTCCGACATCACCTCAGTGTCTTTATGGATTCCATGAATTATTTTGCCGCTGTTGAAACCTGCTATATTTTCTTAGAGGAGACCTCTCGGTCCTTTTCTCCGGTGATTCAGGAGCTCAAACCTGAGTTGCGCGATCCCGTCATGCTTTTCTACTTGATTCTGCGCGCGCTCGACACGATAGAAGACGATATGACTATTCCTTATTCGCAGAAAGTCGAGTATCTCAAAGAGTTTCCGGACGACGTGACAAAGCCAGGGTGGACATTTGATAAGTGTATGATCTATTTACTCCCTCTATTGGCTAACCTTTTAGCTGGTCCAAATGAAAAAGATCGTCATCTTTTGCAGCAGTTTGATGTTGTCATCGAAGAGTTCCTTGCTATCAAGCCTGTCTACCGATCTATCATCGTCGACAAGACACGTCGCATGGCTGATGGCATGGCCGAATACTGTGGCGATCAAGACAAGTTTATTGGCATCAAAACTAGTCAGGACTACAACCAGTACTGCTATTATGTTGGTGGGTTGGTGGGTCTGGGACTCACTGACCTCTTTGTCGAGTCGGGACTCGGCAATCCCGGTCTGAAGGAACGTCCATGGCTTCATCGCTCTATGGGGCTTTTCCTTCAAAAGACAAACATCATCCGAGACATCCGAGAGGATTTCGATGATAAACGGTTGTTCTGGCCTGAAGAAGTCTGGAAGAAGTACGTGGACTCCTTTGACATGCTCTTGGAACCTCAAAATAGCAGTATCGCCTTACGCTGCTCTTCTGAAATGGTCGCAGATGCACTGGAGCATGCCAGTGATTGCATCATGTACCTCGCTGGTCTCCGCGAGCAATCCGTGTTCAATTTCTGTGCTATCCCTCAGGTGATGGCCATGGCTACGTTGCACCTTGTCTTCCGTAATCCTGCAATGTTCCAGCGAAATGTGAAAATCACCAAAGGCGAAGCTTGCGCTTTGATGATGCAAGTCGGCTCGTTGCGAAGCACTTCAGACATATTTCTCCAGTACGTGCGTAAGATCCACGCCAAGAATAGTCCCGAAGACCCAGTTTATCTACGTATTAGCATTGCGTGCTGCAAGCTGGAGCAGTTCATTGAGAGCATCTTCCCCAAAACACCAATGCCCAAAATGATTGCTGGGACAGCGCAGGCTCGAAGACAGATAGCTAAAGCTAAAGAAGCCGATGGTAAAGGAGAGGCTTTCCTGATTGTTGGGACTGTTGCAGCCATGCTGATATTACTGGGCGGTCTGATGGTTGGTGTCTGCCATGCTTTCTTCTAA",
    "translation": "MSRSLGSVEDALNEGSGDTDEAQGRMKKLEDGLERYEENFRHHLSVFMDSMNYFAAVETCYIFLEETSRSFSPVIQELKPELRDPVMLFYLILRALDTIEDDMTIPYSQKVEYLKEFPDDVTKPGWTFDKCMIYLLPLLANLLAGPNEKDRHLLQQFDVVIEEFLAIKPVYRSIIVDKTRRMADGMAEYCGDQDKFIGIKTSQDYNQYCYYVGGLVGLGLTDLFVESGLGNPGLKERPWLHRSMGLFLQKTNIIRDIREDFDDKRLFWPEEVWKKYVDSFDMLLEPQNSSIALRCSSEMVADALEHASDCIMYLAGLREQSVFNFCAIPQVMAMATLHLVFRNPAMFQRNVKITKGEACALMMQVGSLRSTSDIFLQYVRKIHAKNSPEDPVYLRISIACCKLEQFIESIFPKTPMPKMIAGTAQARRQIAKAKEADGKGEAFLIVGTVAAMLILLGGLMVGVCHAFF",
    "product": "hypothetical protein"
   },
   {
    "start": 26450,
    "end": 28342,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001119",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001119</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001119</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001119-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,450 - 28,342,\n (total: 1893 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1173:WD-40 repeat-containing protein (Score: 56.2; E-value: 4.1e-17)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001119 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00400.35 (WD domain, G-beta repeat): [124:159](score: 23.4, e-value: 8.4e-05)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001119 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00400.35: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001119\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001119\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGCACTCACTGTCTGTCCATACTCTTCCACGATGACAATGCACCAATCTACTCTGCCCATTTTGAGCCCGACCGGCCCGGGAGCAAGAGCCGGCTAGCTACAGGTGGCGGTGACAACAATGTCAGGATATGGGCGGTGGAGCGTCAAGCCGTCGGCGCGCCCCAATTGACATACTTGTCCACCCTCGCTCGGCATACCCAAGCAGTCAATGTTGTCCGCTTCTGTCCGCGAGGAGAAGCTCTTGCCTCGGCAGGTGATGACGGGACTGTTTTATTATGGGTTCCAGACGAAAAGAAAGAGCATGGTGGAGGAGCAAGTGGCACGTATGGTGGAGAGGACAAGGAAGAGAAGGAGAGCTGGCGTGTTCAGCGGACCTGCCGCTCCGTCAGCAATAGTGAAATCTACGACCTCGCGTGGTCGCCGGACGGACAGTATCTCATCACTGGTTCCATGGACAACATTGCCAGAATCTTTCACGAAGATGGGAATTGCATCCGTCAGATTGTCGAGCACAGCCATTACGTCCAAGGTGTTAGTTGGGATCCATTGAACGAGTTTGTTGCCACGCAGAGTAGCGATCGCTCCGTGCACATTTACTCCCTCAAGACAAGAGACGGACAGCTCGCCCTCCATCAGCATGGCAAGATCACAAAAATGGAGATGGATTCGTCCAGAAGATCTTCAGGGTCTCCGGCCCCGTCGGAATACTCCTTTCGAGCCGCTTCGACTGCCAGCAACCATGAGTACGCGATTGCCTCGCCTGTGTCGTCAGCACCGGGTACACCCATACTACCAATGAACCCACCCATGATAACAACTCCAAGGCGGTCGTCTTTTGGCAACTCCCCGTCTCGTCATCGCTCTCCGTCTCCGTCTTCAAGTATACCACTGCCAGCAGTCAAGCATCTGGAGTCCCCGAAACCAGCCGGGGCCTCCAAGTCTGCGAACCTTTATCATAACGAATCAATGACAAGCTTTTTCAGGAGGCTTACATTCACCCCAGATGGCTCTCTGTTGATTACTCCTGCTGGTGAATTCAAGACTCCAGGGCATGAGAGAGACGAATCTGCAAACACAATTTATATTTATACTCGCGCGGGACTCAATAAGCCGCCAGTAGCGCATCTTCCAGGGCATAAAAAGCCGGCCATAGCTGTCAAGTGCTCATCTATCCTTTACAAGCTGCGTGAGAAAGCGAAAACTACCCAACACATCACCATCGACACGAGCTCAGCAGAATCTTCCATTAGCTCTCTACCTCCACCTATTACTGCATACAAAAGCGTGACGGAGCAGCCGTCTTCTGCAGTCTTTAACCTCCCATACAGGATTGTTTACGCGGTTGCAACACAAGATTGTGTGCTGGTCTATGACACGCAGCAGCAGGTCCCCTTGTGTATTGTCAGCAACCTTCACTATGCGACATTTACAGATCTGACTTGGTCTGCTGACGGCTGCACGCTTATCATGACCTCGACCGATGGATTTTGCTCATGCATTGAATTTGATGATGGAGAGTTGGGCGAAGTCTATCATGACTCAGTTAAGCTGACGACTGCAGGCGCAAGACATCACTCGGGCAACTTGCATGTCCGTGGATCTCCAATCATAAGGCCCCCCTCACCTTCCCGTTCAAACTCTTCGTCATCCATGCCACATGTCGGTGGTGCTGCGCACGGCCTGGTTCCTACAATGACAAATCTTCCTGGTGTCACAGCAGGCACTAGTCACATAAGTACGCCTCCACACACACCACTCTCCAGCAATCCGAGTCCGGTGCCGGAATCGCAGCCTGGCACCAAGAGGAGTGGTCAGGAGGAGGAGGAGAGCAGGAAGAAACGGCGCATTGCCCCGACTCTCGTGGAGCCAGAGCTCCCCCAAAGTGAATAG",
    "translation": "MRTHCLSILFHDDNAPIYSAHFEPDRPGSKSRLATGGGDNNVRIWAVERQAVGAPQLTYLSTLARHTQAVNVVRFCPRGEALASAGDDGTVLLWVPDEKKEHGGGASGTYGGEDKEEKESWRVQRTCRSVSNSEIYDLAWSPDGQYLITGSMDNIARIFHEDGNCIRQIVEHSHYVQGVSWDPLNEFVATQSSDRSVHIYSLKTRDGQLALHQHGKITKMEMDSSRRSSGSPAPSEYSFRAASTASNHEYAIASPVSSAPGTPILPMNPPMITTPRRSSFGNSPSRHRSPSPSSSIPLPAVKHLESPKPAGASKSANLYHNESMTSFFRRLTFTPDGSLLITPAGEFKTPGHERDESANTIYIYTRAGLNKPPVAHLPGHKKPAIAVKCSSILYKLREKAKTTQHITIDTSSAESSISSLPPPITAYKSVTEQPSSAVFNLPYRIVYAVATQDCVLVYDTQQQVPLCIVSNLHYATFTDLTWSADGCTLIMTSTDGFCSCIEFDDGELGEVYHDSVKLTTAGARHHSGNLHVRGSPIIRPPSPSRSNSSSSMPHVGGAAHGLVPTMTNLPGVTAGTSHISTPPHTPLSSNPSPVPESQPGTKRSGQEEEESRKKRRIAPTLVEPELPQSE",
    "product": "hypothetical protein"
   },
   {
    "start": 28742,
    "end": 30282,
    "strand": 1,
    "locus_tag": "MARS55BIN28_001120",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001120</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001120</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001120-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,742 - 30,282,\n (total: 876 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001120 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04153.21 (NOT2 / NOT3 / NOT5 family): [133:257](score: 118.5, e-value: 2.2e-34)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001120 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF04153.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001120\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001120\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGCGCTTCCGAAGTGCCGCGAATCCCACCTGGCCCTTCGGGATCGTCCTTTGCACAGTCGCTCGGCCACCCGCAACCGACCACCCCGCTGGACATGTCTGAGTTCCCGGCTTTGGGGGGAGGTAATGCTGGGATGAATGCTGGTGCAAGTGCGAATCCATCGCATAGCTCCGCAGGACCAATATCAGCGAATACCGGCTCGATGAATAATGCTGGCAGCTATGCGTTCAGAGCGGCCACTGCGTCACCGGGACAAGGGTTACGGCAGGCGTCAGGGTCTTTGGGCACGCTGCATTCACGCGGTGTAGAGGAAGATGATGGGACTATGAATGACTTTCCTGCTCTTCCAGCAGACCCGGACAAGATCGCCAGCTCGTCGTCCGACCAGCCCCTCTACCAAACTTTTCAGAGCCCGTGGATTGAAACGATGAATTCAAAGGCAGCCATTGAACCAGATTTCCGAATACCCGCTTGTTACAATGCGCAGCCACCTCCACCGGCGCGAGGCAGAATGCAGAGTTTTTCGGACGAGACGCTCTTCTACATATTCTATTCCATGCCGCGTGATATCATGCAGGAAATGGCGGCCCAGGAACTGACGAATCGCAATTGGCGGTGGCACAAGGAGTTTCGGTTGTGGTTGACCAAGGAGCCCGGCTCAGAACTCCTCATGCGAACTGAGCACTATGAGCGTGGCGTGTATATCTTTTTCGATCCAGCGAATTGGGAACGCGTGAAGCGAGAGTTCACGCTGTCGTATGACGCGCTGGATGGACGGGCACCGGAGGCGGGTATCAACGCGCGAGGACAACAGCTGCCGCAGAACCCAATCGGGTCGTCTAGGGGCTCGGTGTTGGCGAATGGGGGGTTATGA",
    "translation": "MGASEVPRIPPGPSGSSFAQSLGHPQPTTPLDMSEFPALGGGNAGMNAGASANPSHSSAGPISANTGSMNNAGSYAFRAATASPGQGLRQASGSLGTLHSRGVEEDDGTMNDFPALPADPDKIASSSSDQPLYQTFQSPWIETMNSKAAIEPDFRIPACYNAQPPPPARGRMQSFSDETLFYIFYSMPRDIMQEMAAQELTNRNWRWHKEFRLWLTKEPGSELLMRTEHYERGVYIFFDPANWERVKREFTLSYDALDGRAPEAGINARGQQLPQNPIGSSRGSVLANGGL",
    "product": "hypothetical protein"
   },
   {
    "start": 30381,
    "end": 31129,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001121",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001121</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001121</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001121-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,381 - 31,129,\n (total: 711 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001121 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF10681.12 (Chaperone for protein-folding within the ER, fungal): [30:233](score: 294.3, e-value: 4.8e-88)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001121 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding<br>\n  \n   PF10681.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001121\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001121\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGACCCTCGCCACCACGTCCCTCGCTCTCTCGCTCTGCCTCGTCTGCGGCGTCGTGGCGCAGACGGCGAGTAGAGACGCAGCATCACTGACCGGCACATGGAGCTCCAAGAGTCACGCCGTATTCACGGGCCCCGGGTTCTACAACCCCGTGGAGGACTACCTCATCGAACCCAGCCTGACCGGCTCCTCCTACTCCTTCACCGCCGACGGCTTCTTTGAGGAAGCGCTCTACTTTGTCGTGTCGAATCCTACGGCCCCTTCGTGTCCTATGGCGCTGATGCAGTGGCAGCACGGTACCTTCGTGCTGGCGTCGAATGGATCGCTTGTTCTGCATCCGCTGGAAGTCGACGGCCGACAGCTGCACTCGAATCCATGCCGATCGGCAACGCCAGATTACACGCGGTACAACGTCACGGAAGTCTTCTCCAAATGGGAAGTTGTTTTGGATGCGTATCATGGGCAATACCGCCTCAATCTGTTCCAATGGGACGGAACCCCGGCGAACCCCATGTACTTGGCCTATCGACCTCCTGAAATGCTGCCCACCACCGTCTTGAACCCAGTCAACACGACGGGGAGCAACACAAAGAGGAAGCGCGACATCCTTCTGGACAGCACCCGACATGCCTCGGGGAAAGAGCGGAGCGTCATGTGGATTGGCCTTGGTTTGATTCTTTGCGGAGGGATAGCATACGCTGCATCGTAG",
    "translation": "MKTLATTSLALSLCLVCGVVAQTASRDAASLTGTWSSKSHAVFTGPGFYNPVEDYLIEPSLTGSSYSFTADGFFEEALYFVVSNPTAPSCPMALMQWQHGTFVLASNGSLVLHPLEVDGRQLHSNPCRSATPDYTRYNVTEVFSKWEVVLDAYHGQYRLNLFQWDGTPANPMYLAYRPPEMLPTTVLNPVNTTGSNTKRKRDILLDSTRHASGKERSVMWIGLGLILCGGIAYAAS",
    "product": "hypothetical protein"
   },
   {
    "start": 31244,
    "end": 32491,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001122",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001122</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001122</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001122-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,244 - 32,491,\n (total: 1173 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001122 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00638.21 (RanBP1 domain): [235:353](score: 69.2, e-value: 3.9e-19)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_001122 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00638.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001122\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001122\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGGCGATACAAAGGGCGAGGATGAACACGAGTCCACTGAACCTTCCATCGCCGGAAAAGATTTCACCGCTGTTGGGAACGCAGATGACGTAGAAAAGTCACTAGCTGAGCAGGGTGACGAGGGAAAGGTTGAGAAGAGGCTCGCGGACACGCAGATCCGAGAGCAAAACGACGCGCCGGTGGTGAGCGAGGACCAGCCTTCCTTTGAGAAGAAACGAACGCACGAAGAGACAGAGCACGAGAGTCTGCGAGAGCCGGTCTCGCCTGAAATCGCCAAACGTGTCGAAGAGAGACCTAAATCGCCGCTGAAGAAGAGCAATGTCTCAACGTTAAAAGCTACCTTTGGGACCATGGGCAGCTCTGCGGCGTCGCCGTTTGCGTCACTGGCCTCCTCGTCGTCGCCTTTTGCCTCTGTCCAGCCATCGACGGAAGAGGTGAAGCATGCAGCTCTGAAAAGCACGTTTGGAGCTGGATTCAGCGGGTCGTCGTTTGGCTCGCTTGCGTCTCCTGCCAAAAAGCCGCGGACGCAGGGGCATGAAGGGGAAGAGGGCCAGGATGCGGATGATGGCGAGGCAGAGGAAGCGCGCAATGACGCTAGCAAGCAAAAGGCGTTCGGAAACATGCTGGAGAAGGAGGATGAGGGCACAAGTAGTGAACAGCAGTATGTGCAAGTGAGCCAGCCGTTGGTGGAGCAGGATCATGTCACGGGCGAAGAGACGGAAGCGACGGTGCATTCCATCCGCGCGAAACTGTTCGTCGCCCGAAAGGAGGGGTGGAAGGAGCGAGGGGTCGGACAGGTCCGGATTAATATCGCCAAGGAGGAGAAAATGCTTGCGCCGCGACTGGTCATGCGTGCAGACGCCGTCTTCAAGCTGCTCCTCAATGCACCGCTCTTCCCGGGCATGGAGGTACAAGGCAGTGGGGACAACAGCGACGAAGGCCTCTCCAGCGACAGATTTGTCCGCATGGTTGTGTTTGAGGAGAGCAAGCCGGTGACGATTGCGTTCAAATTCTCTACGTCGAACCACGCTCGAGACTTTCGGGCGAAGGTTGTGTCTCTTGTACCCAAGGAGCCCAGAGCATCCAGCAGCCCGGCCAAACAGGGCCCGCCATCCCCAATCACCAACCCCACCACCACGGCGCAGGAGGACGCGTCGAGCAAAGACTAA",
    "translation": "MKGDTKGEDEHESTEPSIAGKDFTAVGNADDVEKSLAEQGDEGKVEKRLADTQIREQNDAPVVSEDQPSFEKKRTHEETEHESLREPVSPEIAKRVEERPKSPLKKSNVSTLKATFGTMGSSAASPFASLASSSSPFASVQPSTEEVKHAALKSTFGAGFSGSSFGSLASPAKKPRTQGHEGEEGQDADDGEAEEARNDASKQKAFGNMLEKEDEGTSSEQQYVQVSQPLVEQDHVTGEETEATVHSIRAKLFVARKEGWKERGVGQVRINIAKEEKMLAPRLVMRADAVFKLLLNAPLFPGMEVQGSGDNSDEGLSSDRFVRMVVFEESKPVTIAFKFSTSNHARDFRAKVVSLVPKEPRASSSPAKQGPPSPITNPTTTAQEDASSKD",
    "product": "hypothetical protein"
   },
   {
    "start": 32603,
    "end": 35589,
    "strand": -1,
    "locus_tag": "MARS55BIN28_001123",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_001123</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_001123</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_001123-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,603 - 35,589,\n (total: 2640 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_001123 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00106.28 (short chain dehydrogenase): [33:181](score: 108.3, e-value: 3.5e-31)<br>\n \n  PF00106.28 (short chain dehydrogenase): [299:482](score: 146.2, e-value: 8.7e-43)<br>\n \n  PF01575.22 (MaoC like domain): [755:865](score: 113.0, e-value: 6.6e-33)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_001123\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_001123-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_001123\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCGAGGGTGGGTCGCATGTTTGCCAGCTTCGGCTTAGGGGGCGTGCTCAATATCTACACTCGCACATTCTGTCTGGAGAAGCTGACGGAGAACGATGAGGAGCTGCAACATGCTGCTGACCTTGTTGTTGACGAGATAAAAAAGGCTGGCGGCCGTGCTGTGGCTGACTACAACAATGTCCAGAATGGAGATCAAATCATAGAGACCGCTGTCAAGGCATTTGGTGCAGTGCACATTCTCATCAACAATGCTGGAATCCTCCGGGATGTGTCTTTCAAGAACATGAAAGATGCGGACTGGGATCTAATTACTGCTGTACATGTGAAAGGCACCTACAAATGCACTCATGCGGCGTGGCCAATATTTCGGAAGCAGAAGTTTGGTAGAATAATCAATACAGCTTCTGCTGCCGGTCTTTATGGCAATTACGGTCAGTCTAACTATTCTGCCGCAAAACTCGGTATGGTTGGGTTCACCGAAACTTTAGCAAAGGAAGGGGTGAAATACAACATTCTTAGTAATGTAGTGGTGCCGCTTGCTGCATCACGAATGACCGCAACTGTGATGCCAGAGGAAATGCTGGCTAACCTAAAGCCTGATTGGATCTTTCCTGTGGTTGGTGTGCTTGCGCATGAATCAAATACCAAAAATAACGGTGGCATCTACGAAATGGCAGCTGGGTTTGTAGCCAAAGTCAGATGGGAACGAGCCAAAGGGGCCCTCTTCAAACCGGACGATTCTTTTACTCCTTCGGCTATTCTCAAACGTTTCGATGAAGTGAATAATTTTGAGGGCGCTTCTTACCCGGATCGGACGTCGGATTATTCGTCATTACTTGAAAAGACTCAGAAAATGGGACCAAATACACAAGGAGAAAAGATTGATGTGTCGGAAAAGGTCGTACTTGTAACTGGAGCTGGGGGTGGTCTCGGCCGTGCATACGCCCTACTGTTTGCCAAGTTTGGGGCCAAGGTGGTCGTCAATGACGTTGTCAGTCCTGATAATGTAGTCGAGGAAATTAAAAAGGCTGGCGGGACGGCTGTTGGCGATAAGCATGATGTGAATGATGGAGAGGCTGTTGTTAAGACTTGTCTGGATAGCTTTGGCGCAATCCACATCATCGTTAACAATGCAGGTATTCTTCGGGACAAGTCATTTGGTTCCATGACAGATCAACAATGGGACGACGTAATACGTGTCCATGCGCGAGGGACATACAAGGTTACAAAGGCTGCATGGCCGCATCTACTGAAGCAAAAGTACGGGCGGATTATAAATACCTGTTCAACGTCCGGTATATATGGGAGTTTTGGCCAGGCAAATTATTCGGCTGCCAAATGCATGATTCTCGGTCTCAGTCGATCCCTCGCCCTGGAGGGAGTAAAGTACAACATACTTGTAAACACCATTGCTCCCAATGCTGGAACGCAGATGACTGCTACCATATTACCAGACGAGTTAGTGCAAGCATTCAAACCAGAATACGTGGCTCCTTTTGTGGTATTACTTGCTTCGGAGAAAGTGCCTACAACTGGGCATCTCTTTGAGGTTGGGTCAGGCTGGATAGGGCGAGCTCGGTGGCAGCGGGCCGGAGGAGTCGGATTTCCAATAGACCAAATTCTTACTCCGGAAGCTGTTCTTGACAAATGGAAGGTGATAACAGATTTTGAAGACGGTCGAGCTACCCACCCAGAAACTTCACAAGAGAGCCTTCAAGCTATTGTTGAAAATATAAGTAATCGTTCCGGGAACAGTGGAGAAGGCGGAAACAGCGCAGTGGAGAAGGCGGTCAAATCTACCTATGACTCTACAGAATACAACTATGACGACAAGGATGTGATTTTGTATAATCTCGGACTGGGTGCAAAGCGGACTGATTTAAAATGGGTGTTTGAAGGCAGCGATAACTTCGAAGTCTTGCCATCATTTGGCGTCATACCTGCTTTTCCCACCGTTCATGCAGTTCCTTTTGATAGGTTTTTGCCCAACTTCAATCCCATGATGCTTTTGCATGGCGAGCAGTACCTTGAGATTAGGAAGTGGCCAATTCCGACTTCTGGAAAACTCGTGAACACACCGACCATTCTTGAGGTACTCGATAAAGGCAAAGCTGCCACGGTCATTAGCAGGACAGAGACTAAGGATGTGAGGACAAAAGAGCTAGTGTTTGTCAATGAGTCTACAACGTTCATACGTGGGAGCGGAGGGTTTGGTGGACAGAGCAGAGGCAAGGATCGAGGTGCAGCCACAGCGGCCAATGCTCTACCCAAAAGAGATCCGGATGCATTTGCGGAGGAAAAGACCACCGAGGAGCAAGCCGCTCTGTATCGCTTGTCTGGAGACAGGAACCCACTCCACATCGACCCTGAATTTGCCGCTGTCGGCAGGTTCCCCAAACCTATACTGCATGGACTTGCTAGTTTTGGGATCAGTGCCAAGCACCTCTACGTCACGTACGGCCCCTACAAGAATATCAAAGTGCGCTTCACCGGCCACGTCTTCCCGGGCGAGACGCTGCGAACGGAGATGTGGAAGGAGGGTAACCGGGTTGTGTTTCAGACTGTGGTTGCCGAACGAAAGACAGTGGCCATCTCCGCAGCCGCTGCAGAGCTGCAAAGCATGTCCTCCAAGCTGTAG",
    "translation": "MARVGRMFASFGLGGVLNIYTRTFCLEKLTENDEELQHAADLVVDEIKKAGGRAVADYNNVQNGDQIIETAVKAFGAVHILINNAGILRDVSFKNMKDADWDLITAVHVKGTYKCTHAAWPIFRKQKFGRIINTASAAGLYGNYGQSNYSAAKLGMVGFTETLAKEGVKYNILSNVVVPLAASRMTATVMPEEMLANLKPDWIFPVVGVLAHESNTKNNGGIYEMAAGFVAKVRWERAKGALFKPDDSFTPSAILKRFDEVNNFEGASYPDRTSDYSSLLEKTQKMGPNTQGEKIDVSEKVVLVTGAGGGLGRAYALLFAKFGAKVVVNDVVSPDNVVEEIKKAGGTAVGDKHDVNDGEAVVKTCLDSFGAIHIIVNNAGILRDKSFGSMTDQQWDDVIRVHARGTYKVTKAAWPHLLKQKYGRIINTCSTSGIYGSFGQANYSAAKCMILGLSRSLALEGVKYNILVNTIAPNAGTQMTATILPDELVQAFKPEYVAPFVVLLASEKVPTTGHLFEVGSGWIGRARWQRAGGVGFPIDQILTPEAVLDKWKVITDFEDGRATHPETSQESLQAIVENISNRSGNSGEGGNSAVEKAVKSTYDSTEYNYDDKDVILYNLGLGAKRTDLKWVFEGSDNFEVLPSFGVIPAFPTVHAVPFDRFLPNFNPMMLLHGEQYLEIRKWPIPTSGKLVNTPTILEVLDKGKAATVISRTETKDVRTKELVFVNESTTFIRGSGGFGGQSRGKDRGAATAANALPKRDPDAFAEEKTTEEQAALYRLSGDRNPLHIDPEFAAVGRFPKPILHGLASFGISAKHLYVTYGPYKNIKVRFTGHVFPGETLRTEMWKEGNRVVFQTVVAERKTVAISAAAAELQSMSSKL",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 24053,
    "end": 25989,
    "tool": "rule-based-clusters",
    "neighbouring_start": 14053,
    "neighbouring_end": 35908,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r44c1"
 },
 "r165c1": {
  "start": 1,
  "end": 18228,
  "idx": 1,
  "orfs": [
   {
    "start": 155,
    "end": 2867,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002826",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002826</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002826</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002826-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 155 - 2,867,\n (total: 2682 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002826 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00350.26 (Dynamin family): [228:403](score: 143.2, e-value: 8.3e-42)<br>\n \n  PF01031.23 (Dynamin central region): [410:541](score: 53.7, e-value: 1.9e-14)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002826\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002826\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTTCCCCCATCAAAAGACGGCTGGTCAATTTAAAAGATACACCTGCAAGTCAGTGGACGAAGTCTTATACAGCATCTACGATCAGGCGCAATGTCACGCATGAAATACAGCGCCAAGAGTGGTCGTTGCTCACCAACCAAGTCAGGCCCAAAGCATGTCAGTGGCAAGGCCTGCCGCTGGTAAGGAGACGACATATGGGGTTCTCAGCTGGGCCTAAATTACTTTTAAAAGCTTTTCGACTCCCTGCTGCGTTTGGTAGTGCAGCGATAGCTGCGCTAGCGTACGCGAATTATAAAGTCCAGGAAGCCGCGAATTATACAAAAGGGATTTTCTCTAGTATCTCTGGCTGGTGTATGCAATCGACTATATCAACAAAAGAACAACTGGACAGCATATGGAATAATAATTTCAGCGGGTTCTTTAATCGAGTACGTGAGGAATCGAGACCTAGCAAGGATGACTCAAGCCCAGATCCATCGAGCAGCCAAAGTGAGAAAAAGCAGCCAGATTTAGGCTCTGCACTCCTTTCTACTGCTGTAGGGGTCTCCGCGGCTTCCAAGGAAGAAGACAGTAAAGAAGATGCCGGTGATGGCATGATGATGACCTTGACGAAGAAAATGATCGAGATCAGAAACATCTTACAAAAGGCAAGTATTCCGGAGGCAGTACAGCTGCCTTCGATTGTTGTGATCGGTTCTCAGAGTTCTGGTAAGTCATCAGTTTTGGAAGCCATTGTTGGTCACGAATTCTTGCCGAAGGGTGGGAACATGGTCACTCGACGGCCGATTGAACTGACCCTCATAAACACACCGGGAACCTTAGACGAATACGGCGAGTTCTCTGATTTGGAAAATGGCAGAGTATCAGACTTCTCTGGAATCCAGAAAACACTAATGGACTTGAACCTTGCAGTATCCGAGGCAGAGTGTGTTTCAGATGATCCAATCCGGCTTAAGATATACTCTCCTAACATTCCAGATCTGAGTCTTATCGACTTACCAGGATATATCCAAGTAAGTGCAAAAGACCAGCCACAGTCGTTGAAAGCGAAAATTGCTTCTTTATGTGACAAATACATTCAAGAGCCGAATATTATTCTGGCAATCTCAGCTGCTGATGTGGACCTTGCAAATTCAACAGCCTTGCTAGCTAGTCGAAAGGTGGACCCTAATGGTCGGCGGACAATCGGGGTCGTGACAAAAATCGATCTCGTCGAGCCTGATAGGGCAGTAGTGATGCTACAAGACAAAAACTATCCGCTCCATTTGGGATACGTCGGGGTCGTCTGTAGGGTCCCTAATAGCACGATTTTTAGCCGCAACTCGAGCATTCTCAGTGCGGTCGCAAGGAACGAGAAGAAATATTTTGCGACACATCCCCAGTTTTCATCGGGGGAGGGTTGTACGGTTGGAACTACGGCTCTCCGCCAGAAGCTTGTGCACATATTGGAAAGCTCTATGTCGGGGAGCCTAAAAAGGACCACCGAAGCCATTCATGATGAGTTAGAGGAAGCAAATTACCAGTTTAAAGTCGAGTTCAATGATCGTCCTTTGACTCCGGAGACATTTCTGGCCGAGTCCCTCGACACTTTCAAGCATCTGTTTAAGGATTTTTCGAATAAGTTTGGGCGAGCGCAGGTGCGAGAAATTCTGAAAGGAGAGTTCGAGCAAAAGCTTTTGGATATTCTGGCCCATCGATACTGGAACAAACCCTTGACTGGAAACAAAAGCGTGTCCATCTTTTCGTTGCCGTTGTCTAGTACGGATGATCTCTACTGGCAGCGAAAGCTTGATGCATCTACGTCTGCGCTTACTAAACTTGGAGTCGGGCGGCTCGCAACAACCTTACTTGTAAGCTCTTTGACTTTGCAGGTAGATTCGCTGGTAACCAATTCCCCGTTCAGAAATCATCCATTTGCAAGGGAAATAATACTACAGGGGGCACGAGAAATCCTCGACAAAGGATTTCTCAGTACGTCTGATCAAGTTGAAAACTGCATCAAGCCCTTTAAATTCGACATCGAAGTCGACGATCGCGAATGGGCGAGTGGACGGGAACAAGTGGCGCAACTTCTATCCACCGAGATGAAGCAATGCGAAGTAGCCTATCTGAAGCTGGCACAGAAAGTAGGAGAGAAAAGGTTGAATAAGGCCGTCGCATCTGTAAATCAAGAGCGACATCGAGGGGCAATCGAAATTCAAGACGGGCAAGACGGGCAAGACGGCTTTGTGATGAATCAAAGCTTGCTTCGCCAAGGTAAGTACTCGGCTCTGAAGCTGCAGCTAACTCACAAAGGTGAACAAGCATTATTTTTGCGGGAGCGACTAGAGATTCTTAAATTGCGGCAGTTGGCAATACGATCAAAGCAATGTCGCTCAAAAGAGAACAAACATTACTGTCCGGAAATCTTTCTCGAGGTCGTCGCAGAAAAGCTTACTACAACATCTGTTCTCTTTTTGAATGTGGAACTACTTTCGAGTTTTTATTATACTCTTCCTCGGGAACTTGACATACGGCTAAGCCACGATCTTACTGCCCGTCAGATGCAAGAGATTGCAACAGAAGATCCGAAAATCAGAAGACACGTCGTTTTACAGCAGCGGCGTGAGCTTCTAGAGCTTGCACTGCGGAAATTAGAGAGTATATCTCAGCTTGAAAATAATAGGGCTCTGGTGTGA",
    "translation": "MTSPIKRRLVNLKDTPASQWTKSYTASTIRRNVTHEIQRQEWSLLTNQVRPKACQWQGLPLVRRRHMGFSAGPKLLLKAFRLPAAFGSAAIAALAYANYKVQEAANYTKGIFSSISGWCMQSTISTKEQLDSIWNNNFSGFFNRVREESRPSKDDSSPDPSSSQSEKKQPDLGSALLSTAVGVSAASKEEDSKEDAGDGMMMTLTKKMIEIRNILQKASIPEAVQLPSIVVIGSQSSGKSSVLEAIVGHEFLPKGGNMVTRRPIELTLINTPGTLDEYGEFSDLENGRVSDFSGIQKTLMDLNLAVSEAECVSDDPIRLKIYSPNIPDLSLIDLPGYIQVSAKDQPQSLKAKIASLCDKYIQEPNIILAISAADVDLANSTALLASRKVDPNGRRTIGVVTKIDLVEPDRAVVMLQDKNYPLHLGYVGVVCRVPNSTIFSRNSSILSAVARNEKKYFATHPQFSSGEGCTVGTTALRQKLVHILESSMSGSLKRTTEAIHDELEEANYQFKVEFNDRPLTPETFLAESLDTFKHLFKDFSNKFGRAQVREILKGEFEQKLLDILAHRYWNKPLTGNKSVSIFSLPLSSTDDLYWQRKLDASTSALTKLGVGRLATTLLVSSLTLQVDSLVTNSPFRNHPFAREIILQGAREILDKGFLSTSDQVENCIKPFKFDIEVDDREWASGREQVAQLLSTEMKQCEVAYLKLAQKVGEKRLNKAVASVNQERHRGAIEIQDGQDGQDGFVMNQSLLRQGKYSALKLQLTHKGEQALFLRERLEILKLRQLAIRSKQCRSKENKHYCPEIFLEVVAEKLTTTSVLFLNVELLSSFYYTLPRELDIRLSHDLTARQMQEIATEDPKIRRHVVLQQRRELLELALRKLESISQLENNRALV",
    "product": "hypothetical protein"
   },
   {
    "start": 2968,
    "end": 6234,
    "strand": -1,
    "locus_tag": "MARS55BIN28_002827",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002827</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002827</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002827-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,968 - 6,234,\n (total: 3132 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00009.30 (Elongation factor Tu GTP binding domain): [18:355](score: 195.3, e-value: 8e-58)<br>\n \n  PF14492.9 (Elongation Factor G, domain III): [574:638](score: 28.3, e-value: 1.4e-06)<br>\n \n  PF00679.27 (Elongation factor G C-terminus): [908:989](score: 50.2, e-value: 2.1e-13)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00231 (small_GTP: small GTP-binding protein domain): [19:165](score: 49.9, e-value: 6.9e-14)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002827 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity<br>\n  \n   PF00009.30: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002827\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002827\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCAGCAGTACCGCATGAACAGCTCGTTCGTCTGCAGGAGAGGACAGAGTGTCTGCGAAACATCTGTATTCTAGCCCACGTCGACCATGGCAAGACGAGTCTTAGTGATTGCCTGCTCGCATCGAATGGGATTATATCGCCAAAGTCCGCCGGAAAGATTCGATTTCTTGACTCGAGAGAGGATGAGCAAAGCAGAGGGATCACTATGGAGTCTAGTGCCATCTCTCTCTACTGTAAAATGAGGACTTCATCTCACAATTCTTCAGTTGAGACCACTACGGGAGAGCAAGAGTACTTGGTTAATCTGATTGACTCCCCTGGACACGTGGACTTCTCTTCAGAAGTATCCACTGCGTCACGCCTTTGTGATGGTGCTCTTGTACTTGTGGATGTGGTGGAAGGTGTCTGCTCTCAGACGGTGACAGTTCTTCAAGAAGTCTGGAGGGAGAACCTGAAGCCTATTTTGATCTTCAATAAGATGGATAGGCTCATCACGGAGTTACGGCTTTCGCCTTCTGAAGCCTACAGCCATCTTAGTCGCCTCCTCGAGCAGGTCAATGCTGTCCTTGGAGGATTCTTTGCTGGTGATCGGATGAAGGACGATCTGTTATGGCGAGAAGCGCAAGAGCAGAAGCTTGAGAATGATGATGTCGTGAAAGCTTTCGAAGAAAAGGACGATGAGGAGCTCTACTTTCTGCCCGAGAGAGGAAATGTAGTTTTTGGAAGTGCTGTCAATGGATGGGCATTCACGATCTCTCAATTTGCGGAGTTCTACGAGAAAAAACTGGGTCTAAAGACAGAACTTTTGAATAAAGTGCTTTGGGGCGACTTTTACTTGGACGCGAAATCTAAACGAGTCTTTCAGAGTAAGCATGTCAAAGGCAAGGTGGTCAAGCCAATTGAGCTCATAACCAGAGAAATTCTGACAATCAGGGACCCAATAAAAATAGATAAGATTGTCGAAGCACTTGGCCTTCGTATTCTACCTCGAGATCTGAGGAGCAAAGATAGTAAGGCTGTGTTATGGTCGATATTTTCACAGTGGTTGCCGCTTTCTGCGACGGTCCTTCTGTCTGTAATTCAGCATATACCTTCACCGAAAGCCTCGCAGGCAAGTCGTACCGGTTTGCTTATCAAAGAGTCTCCATCTGGTGCGTCCATCCCGGATTCTGTGCGAGACAGTATGTCGCAATGTGACTTTCACTCCGTCTTCTCCCTCGCATACGTCAGCAAAATGGTTTCAATTCCGACTTCTGATCTACCCAAATTTCTTAAAAAACGTCTCACGGCTGATGAAATGCGAGAGCGTGGGCGACAACTCAGAGAGAAGTCAAATCGAGACGGCTTAAACGAGGAAGCTGCAATCGGCTGCAGTACTACAGGCGATACAGACGCGGACACCGACAATATTCATAAAGAGAACGACTCAAGAGATCAATCCTTAGTGGGGTTTGCAAGGCTATATAGTGGTTCAATAAGTGTTGGCGACGAGCTCTTGGTCCTTAGTCCTAAATTCAATCCTCACAAACCTGCAGAGTTTATCGCTAAATTTATCGTTTCAGAGCTCTATATGTTCATGGGGCGTGACTTGGTCTCGCTTGATCGAGTGCCAGCCGGAAATATCTTCGGGGTTGGTGGGGCGGAAAAGAGCATATTGAAGAACGCTACAATATGCAGTAGCCTACCAGCACCCAATTTGGCCAGCGTTGGAATGAATCTTGACCCCATTGTCCGTGTGGCCGTAGAGCCTACAAATCCTAGAGAAGTTCAATTACTGGAAAGAGGCTTGAGACTTTTAAACCAATCAGACCCGTGCGTTCAAGTGCTTCTTCAAGAGAATGGTGAAATGATTATGCTCACAGCTGGCGAATTACATTTAGAGAGATGCATAAAAGATTTGAGAGAACGGTTTGCAAAAATTGACATTCAATCTTCGGAGCCAGTTGTTCCATTTCGTGAGACCATTGTTCAGACTCCAGCGCTGCACATTATGAATGACGGAAATTCGAACATGGAGGAGTTAGGCAAAGCTGACATTGCCTTTGTGGGGGCAAACTTGACTCTTCAGATCAGGGTAAGGCCTCTTCCAGAGGAACTTTCATCGGCGCTGGAACGCATCACCAATTACATGAGGAAAAGCGTAAGCGGCAACCAGACCAGCAACAGCAACCTGACAACAAACATTGCTGAAACGGCTGCCTTTGGGACCGATTTTTCAGAAGATGGATTTCACGAAAGATTCCTAAGGATTTTAAGTCAAGAGGTAGAAAATATTTCCGAGTTTACAGAGCTTTATGGAGATCTTATTGCAGATACATGTTCCCTGGGCCCTCGAAAATTGGGCCCAAACTTGCTTATTGACAGGACTGGCTTAATGTCTCAAAGAGTATTTTCCGAAAAAGGAATTTCCACCCGGGAGGGAACACCTCCGTCACCAGAGACGAAGTCCGCTTTTCGCGCTATTGAGGATGCTATTGTCGGAGGGTTTCAGTTGGCAACTCAACAAGGGCCGTTATGTAACGAGCCTTTATATGGTGTAGCTTGCATATTAGAAAACGTGTCTACAATTGATGACTTGGAAGGCAAAGAGGCGGATTACCCTGAGGTACGGCGAGAATCAACACTGAAAAATTATAGCATTCTGTCTGGACAGATCATAACTTTGATGCGAGATTCTATTCGCCAGTGTTTCTTGGCCTGGTCATCGCGACTGATGCTCGCCATGTATTCGTGTGAGATTCAGGCATCAACTGACGTTCTTGGGAAAGTGTACTCTGTTGTTGCACGAAGAAAGGGACGCATTGTGGCTGAGGAAATGAGGGAGGGTACCCCTTATTTCTCTGTCCAGGCAGTCATTCCAGCTTATGAATCATTTGGATTTGCAGACGACATCAGAAAAAGAACTTCTGGGGCTGCAAGTCCGCAATTGATTTTTGCTGGATTTGAGATCCTTAGTCAGGATCCATTTTGGGTACCCTCAACTACTGAAGAATTGGAAGATCTCGGTGAAGTTTCGGATCGTGAAAATTTGGCTCTCAAGTATGTAAATGATATCCGGCGCCGAAAAGGACTTGTTGGCCTAAAGCAGACTGCACGAGGCGCAGAGAAGCAACGGACGCTGAAAAAATAA",
    "translation": "MPAVPHEQLVRLQERTECLRNICILAHVDHGKTSLSDCLLASNGIISPKSAGKIRFLDSREDEQSRGITMESSAISLYCKMRTSSHNSSVETTTGEQEYLVNLIDSPGHVDFSSEVSTASRLCDGALVLVDVVEGVCSQTVTVLQEVWRENLKPILIFNKMDRLITELRLSPSEAYSHLSRLLEQVNAVLGGFFAGDRMKDDLLWREAQEQKLENDDVVKAFEEKDDEELYFLPERGNVVFGSAVNGWAFTISQFAEFYEKKLGLKTELLNKVLWGDFYLDAKSKRVFQSKHVKGKVVKPIELITREILTIRDPIKIDKIVEALGLRILPRDLRSKDSKAVLWSIFSQWLPLSATVLLSVIQHIPSPKASQASRTGLLIKESPSGASIPDSVRDSMSQCDFHSVFSLAYVSKMVSIPTSDLPKFLKKRLTADEMRERGRQLREKSNRDGLNEEAAIGCSTTGDTDADTDNIHKENDSRDQSLVGFARLYSGSISVGDELLVLSPKFNPHKPAEFIAKFIVSELYMFMGRDLVSLDRVPAGNIFGVGGAEKSILKNATICSSLPAPNLASVGMNLDPIVRVAVEPTNPREVQLLERGLRLLNQSDPCVQVLLQENGEMIMLTAGELHLERCIKDLRERFAKIDIQSSEPVVPFRETIVQTPALHIMNDGNSNMEELGKADIAFVGANLTLQIRVRPLPEELSSALERITNYMRKSVSGNQTSNSNLTTNIAETAAFGTDFSEDGFHERFLRILSQEVENISEFTELYGDLIADTCSLGPRKLGPNLLIDRTGLMSQRVFSEKGISTREGTPPSPETKSAFRAIEDAIVGGFQLATQQGPLCNEPLYGVACILENVSTIDDLEGKEADYPEVRRESTLKNYSILSGQIITLMRDSIRQCFLAWSSRLMLAMYSCEIQASTDVLGKVYSVVARRKGRIVAEEMREGTPYFSVQAVIPAYESFGFADDIRKRTSGAASPQLIFAGFEILSQDPFWVPSTTEELEDLGEVSDRENLALKYVNDIRRRKGLVGLKQTARGAEKQRTLKK",
    "product": "hypothetical protein"
   },
   {
    "start": 6304,
    "end": 7245,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002828",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002828</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002828</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002828-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,304 - 7,245,\n (total: 942 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002828 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00169.32 (PH domain): [9:99](score: 54.0, e-value: 2.1e-14)<br>\n \n  PF00169.32 (PH domain): [214:306](score: 61.4, e-value: 1.1e-16)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002828\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002828\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACAGAGTGGAATACGAGATATGGAAGGCTGGCTGGCTCTCCAAGCGGGGCAAGCGCAGACGGTACAACAGGCGGTGGTTTGTGCTGAGGAAGGACTCGATGGCGTACTACAAGGACGAGAAGGAGTACAAGAGCTGCAAGATCATCCAGGTCCAAGACATCAACGTGTGCGCACTGGTCTCCAGTCGCAAGCATGGCGGTGCGTTTGCAGTCTTCACGCCCAGTAGGACATATCGCCTTGTGGCCGACACAATCGCAGACGCCCAGGACTGGGTGGATGCCATCGGCAAGGCAGCAGCGACCTGTTCCCAGTCGGAAGAGGAGGATGCGTACAACATGCGGAACCCCTCCCAACACGAATGCCACGAAGCTTCACAGGACACCGACACGGTCATGTCTACAGACTTGTCTGCGGTAAATTCCCCAGTTATTCCGCACAGATTCTCAAAGACGCCGTCGTTTGCTGGAGACTTTTCTGGGCCGGAAAATGAATCGGCTTCTTCTCTCTATTCCGAAGCCGATCCGTACAGAGCTACTTATGCTTCTCCAGCAGAGCCTGGAATACCTGATCACTCACGAGATCAAGAGATTGTGAGAGGAATGCCCACCGACGGTGATGACACCATTGTCGCCATGTTCGGGTACCTATATGTGCTCAACAAGGGTCTCAGGCAATGGCGAAAGAGATGGGTTGTATTACGTTCGAACACACTCGTCCTCTACAAATCGGAAGAAGAGTATGAGCCTCTGAAAGTCATTCCTATACGGTCTATCATTGATGTCATTGACATCGACGCCTTATCGAAAACAAAAGTACATTGTATGCGGATGATCTTACACGACAGATCTTATCGCTTTTGCGCTCCATCTGAAGAAGCACTGACACAGTGGGTAGGCTCATTCAAATCAAACCTTTCCAGGCTAAAGGGTGTGCCTTGA",
    "translation": "MDRVEYEIWKAGWLSKRGKRRRYNRRWFVLRKDSMAYYKDEKEYKSCKIIQVQDINVCALVSSRKHGGAFAVFTPSRTYRLVADTIADAQDWVDAIGKAAATCSQSEEEDAYNMRNPSQHECHEASQDTDTVMSTDLSAVNSPVIPHRFSKTPSFAGDFSGPENESASSLYSEADPYRATYASPAEPGIPDHSRDQEIVRGMPTDGDDTIVAMFGYLYVLNKGLRQWRKRWVVLRSNTLVLYKSEEEYEPLKVIPIRSIIDVIDIDALSKTKVHCMRMILHDRSYRFCAPSEEALTQWVGSFKSNLSRLKGVP",
    "product": "hypothetical protein"
   },
   {
    "start": 7299,
    "end": 8228,
    "strand": -1,
    "locus_tag": "MARS55BIN28_002829",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002829</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002829</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002829-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,299 - 8,228,\n (total: 897 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: phytoene_synt<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002829 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00494.22 (Squalene/phytoene synthase): [24:280](score: 173.1, e-value: 8.4e-51)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002829 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00494.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002829\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002829\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCTTCTTCTGCCTTTGTAAACCAGGACAAGGTGAACGCAGCTCGTCAAGCGTGCAAGAGCCTTGTTGAGCAAAGTGACAGGAATGCCTATATACTGAATGCCTTCCTGCCCCCTACCGGCCGAGATGCACACTTGGCGTTACGAGCTTTCAATATCCAGACCGCTCAGGTAGCAGACCAAGTGAGTAATGCATCGTTGGGTAGGAGGCGGCTCCAGTATTGGAAGGACGCCATTGAAGGGCTGTATACTGACCGTGGCTCCCCGGAGCCATCGATGATACTCCTGGCGGCGCTCTCATCGCGTGGCATACGCTTCACCAAACAGATGCTAGCTCGTATTCCCGCTGCAAGAGGCAAATATCTCGGGAACAAGCCATTCCCTAGTATGGCAGCACTAGAAGGGTACAGTGAAAACACATACTCGACACTTATGTACCTCACGCTGGAAGGCATGAATATCCGGTCTGAGCCTCTCGATCACGTTGCCTCACACATCGGAATGGCGACTGGCATCACTGCCATCTTGCGAGCTGTTCCATTTATGGCCTCGAAAGGCAACGTCATTCTTCCTGTGGATATTTGTGCAGAAGAAGGTGTCAGACAAGAGGACGTAAAAAGACACGGAGCGTATGCTTCTAGTGTACAAAACGCAATTTTTGCAATTGCCACCAAAGCAAATGACCACATGATGACTGCGAGAAAGATGATCACGGAGATGACGCCAATGAAACAAGCTCCGGGTTTTCCTGTGCTTTTGGAGAGTGTTCCTACTTCACTTTATTTGGAAAGGCTCGAAAAGGTGAACTTTGATGTGTTCCATCCATCCTTAAGTCGACGCGAGTGGAAGCTACCTTATCGCGCTTATAAGGCTTATGCATTTCGCCGAATATGA",
    "translation": "MSSSSAFVNQDKVNAARQACKSLVEQSDRNAYILNAFLPPTGRDAHLALRAFNIQTAQVADQVSNASLGRRRLQYWKDAIEGLYTDRGSPEPSMILLAALSSRGIRFTKQMLARIPAARGKYLGNKPFPSMAALEGYSENTYSTLMYLTLEGMNIRSEPLDHVASHIGMATGITAILRAVPFMASKGNVILPVDICAEEGVRQEDVKRHGAYASSVQNAIFAIATKANDHMMTARKMITEMTPMKQAPGFPVLLESVPTSLYLERLEKVNFDVFHPSLSRREWKLPYRAYKAYAFRRI",
    "product": "hypothetical protein"
   },
   {
    "start": 8593,
    "end": 9117,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002830",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002830</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002830</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002830-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,593 - 9,117,\n (total: 525 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002830 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF05198.19 (Translation initiation factor IF-3, N-terminal domain): [1:68](score: 35.7, e-value: 8.6e-09)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002830 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity<br>\n  \n   PF05198.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002830\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002830\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGAGGACATAAAGTGTAATGAAGTCAAATTCGTGGATGCCAATGGCAAATTCCACGGAATCGTTAGCCTGAGGAGTCTCCTGAGCTCCTACGACAGGAGCCAGTTCCACTTGATAAACGTCACACCGGGTGCCGAGGTGCCCACGTGTAAGATTCAAAGCAAAAAGCAATTGCAAGATGCTGAACGTCGACAGCGGGAGCTCAGGAAGGAGAGACGCAATCCGGCGTTCGCCCCGGCAAAAGAGTTTGAAGTAAGCTGGGGGATTGCACCTCACGACCTCACTCATCGCGTGGCCAACATGAGTGGCGCGCTGGCTCGCGGCTACCGCATTGAGGTACATTGCGGGAGCCGTAAAGGCTCTCGCAGAGTCGACCAGGAGACAAGACAAAACCTCATACAGCAACTGCGCGTAGAGCTGAACAAAGTGGCAAAGGAGTGGAGATTAATGGTGGGCACGAAGGATCTGACTGTTCTCTATTTCCAAAAAATAGCAGACACCAATCGCACTTCGGAGACCTGA",
    "translation": "MDEDIKCNEVKFVDANGKFHGIVSLRSLLSSYDRSQFHLINVTPGAEVPTCKIQSKKQLQDAERRQRELRKERRNPAFAPAKEFEVSWGIAPHDLTHRVANMSGALARGYRIEVHCGSRKGSRRVDQETRQNLIQQLRVELNKVAKEWRLMVGTKDLTVLYFQKIADTNRTSET",
    "product": "hypothetical protein"
   },
   {
    "start": 9730,
    "end": 10779,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002831",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002831</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002831</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002831-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,730 - 10,779,\n (total: 1050 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002831 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06991.14 (Microfibril-associated/Pre-mRNA processing): [109:313](score: 208.0, e-value: 1.7e-61)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002831\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002831\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCTCGAGGAAGCTCCGGTCCAACCCCGTCAAACCCAGGAGATACTTTCCCCAGAGCAGAGCGCGACCAGCCAGACACAGCGATGGGAGCAGCGAGGAGGAGGAGGATGACGAGGATGATGTTCAGGTAGAGGAGAAGGAGGTGGAGGCAGACCAGGCGAGACCAGCCAATGTGCCCGTGTTTGAGCTCAAAGATGAAAACCTAGACGACAGGTTTGCTCGAGAGCGGGCGGCAGAAGCAGCCGACAAAAGTAGCATCCCACATGACGCAGGCGAGTCCTCGCACTCTGAAAGTGAAAGCGAGTCTTCAACAGGCCTGCAGGAGAGCGAGGAGGAGGCCCCACCTCGAAGGGTCCTACCCCGCCCGGTGTTTGTTGGGAAACAAGAACGTCAATCGGCAGCTTTGGAAGATACCCCGGAAGCAGAATTGGAGCGACGAAAGTCCAATTCCCGACTGCTCATTCAGGAGCGAATAAAGCGTGAACAAGCTGGCCAGCAATCGGACGACGGGGTGGATGACACCGTCGACGATACCGACGATTTGGATCCGTCCGTGGAACGTGCAGCGTGGAAGCTTCGGGAGCTGCTGAGAGTGCGTAGGGAGCGGCAGAGTCTTGAGGAACGCGAGGCCGAACGAGTGGAGCTTGAGCGTCGCCGGAACTTAGGGGAAGAGGAGAAAGCTGCCGAGGATGCGGAATACCTCGACAAGCAGAAAGAGGAGAAGGAGGCAACACGGGGGGAAATGCGATTCCTACAAAAGTACTATCATAAGGGCGCATTCTACCAGGAAGACGACATCCTTCGTCGCAACTTCAACCTGGCCAAGGAAGACGACATTCTCAGCAAGGAGCTGCTGCCCAAAGTCATGCAGGTCCGAGGCGATGACTTTGGGAAGCGCGGCCGCACCAAGTGGACGCACCTTTCCGCAGAAGACACGAGCAGAGACGCGCAGTCCGCCTGGTTTGATGCAGGCAGTTCCATTCATAAGAGACAGCTGTCGAAGCTCGGTGGGTTGCCCGAAGCTGAAAGCAAGAAGCAGAAGAAGTAA",
    "translation": "MSSRKLRSNPVKPRRYFPQSRARPARHSDGSSEEEEDDEDDVQVEEKEVEADQARPANVPVFELKDENLDDRFARERAAEAADKSSIPHDAGESSHSESESESSTGLQESEEEAPPRRVLPRPVFVGKQERQSAALEDTPEAELERRKSNSRLLIQERIKREQAGQQSDDGVDDTVDDTDDLDPSVERAAWKLRELLRVRRERQSLEEREAERVELERRRNLGEEEKAAEDAEYLDKQKEEKEATRGEMRFLQKYYHKGAFYQEDDILRRNFNLAKEDDILSKELLPKVMQVRGDDFGKRGRTKWTHLSAEDTSRDAQSAWFDAGSSIHKRQLSKLGGLPEAESKKQKK",
    "product": "hypothetical protein"
   },
   {
    "start": 10821,
    "end": 11531,
    "strand": -1,
    "locus_tag": "MARS55BIN28_002832",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002832</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002832</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002832-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,821 - 11,531,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002832 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF04051.19 (Transport protein particle (TRAPP) component): [71:224](score: 148.8, e-value: 9.9e-44)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002832\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002832\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCATTGATGACGGAACGCGACAGGAGCAGCCAGCAACAGCAGCCGCAGCAGCTGTTCACGCCCTTCAGCCCCCTGCAGTCTGTGCCTCTGCTGCCCGCCAACCGCCCCCAGCCCATTGCACCTGCCTCCGCCGCCTATGCCAAGCGCAGCAACATCTACGACCGCAACCTCAACCGGACCCGCGGCACGGACTCGGCGTCGCAGTCGTCCTTTGCCTTCCTCTTTAGCGAGATGGTGCGGTATGCCCAAAAGAGCTCGGCCGAGATTGCAGAGCTGGAGGCCAAGCTGAGCAGCTTTGGGTACCGCGTCGGCCACAGGTGCCTTGAGCTCTACACGCTGCGCGACCAGCGGAACGCGAAGAGGGAGACGCGCATCCTCGGCATCCTGCAGTACATCTACTCGCCCTTTTGGAAGAGCCTGTTTGGTCGCGCGGCGGACGCATTGGAACGGTCTCGGGACCATGAGGATGAGTATATGATCTACGACAACGACCCCATGGTCAACACCTTCATCTCCGTCCCCAAAGAAATGGCGCAGCTCAACTGTGCAGCCTTTGTGGCTGGGATGATCGAGGCCGTGCTGGACGACGCCCTGTTTCCTTCGCGCGTCACTGCACACACTGTCGCTATCGATGGCTATCCCAACCGGACCGTCTACCTCATCAAGCTCGATGAGACTGTCTCGGAACGAGAGATGTACCTGAAGTAG",
    "translation": "MALMTERDRSSQQQQPQQLFTPFSPLQSVPLLPANRPQPIAPASAAYAKRSNIYDRNLNRTRGTDSASQSSFAFLFSEMVRYAQKSSAEIAELEAKLSSFGYRVGHRCLELYTLRDQRNAKRETRILGILQYIYSPFWKSLFGRAADALERSRDHEDEYMIYDNDPMVNTFISVPKEMAQLNCAAFVAGMIEAVLDDALFPSRVTAHTVAIDGYPNRTVYLIKLDETVSEREMYLK",
    "product": "hypothetical protein"
   },
   {
    "start": 12049,
    "end": 13071,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002833",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002833</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002833</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002833-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,049 - 13,071,\n (total: 1023 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002833 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00481.24 (Protein phosphatase 2C): [57:300](score: 227.2, e-value: 2.9e-67)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002833\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002833\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCCGTTTGCAAATCTAAGAGATGCTTCCGGACACAACTCGGGGGAAAGCAATGCTACAGAACATGGGCGCTCCGTATCCGGGAAGAGGAGTAAGCGCGGCAAGTCCTCGACGGCCAGTGGAAACGCAGCTGGAGAGAGCCGACCATCGGCAAACACCACATTCAATGTGGGTGTGACGGAGGAACGAGGCCCGCGCAGGACGATGGAGGATACGCACTCCTACGTATACGATTTTGCGGGCGTCGAAGATCAAGGGTACTTTGCAATTTTCGACGGTCATGCCGGCAAGCAGGCTGCCGATTGGTGCGGCAAGAAGGTCCATCATGTCTTCGAACAAGCCATGAAACAGAGCCCCGACACAGGGGTCCCTGATCTCTGGGACAAGACGTACATGCACTGCGATGGAATGTTGGCTGATCTCACGCAACGAAATTCAGGCTGCACAGCGGTCACTGCTCTGTTGGCTTGGGAACAAAGGGACGGCGTGCGTCAACGCGTCCTATACACGGCCAATGTGGGAGACGCACGCATTGTCCTATGCCGAAAGGGAAAGGCCTTTCGGCTCTCCTACGACCACAAGGGCTCTGATGAGAATGAGGGGAAGCGGATCGCTGAGGCGGGGGGTTTGATTTTAAATAACAGGGTGAATGGAGTTTTGGCAGTAACTCGCGCCCTGGGCGACTCGTACATGAAGGATCTCATCACCGGACATCCCTTCACTACCGAAACGGTCCTCACACTGCAACACGATGAGTTCATCATTCTAGCTTGTGACGGGCTGTGGGATGTTTGTACAGATCAAGAGGCAGTCGACCTTGTCCGGGATATACACGATCCACAAGAAGCCTCCAGACTGCTTTGCGAGCATGCATTAAAACACTACTCCACAGACAATCTCAGTTGCATGATTGTCCGGCTCGATCCGATCGGGACCACAGCTGAGGCCAAAACTCCGGCAACAAGCCTCTCAACACATAGCGAGGCGGTACCTTCCAGTAGTAGTGAACCCGCGGTGTAG",
    "translation": "MNPFANLRDASGHNSGESNATEHGRSVSGKRSKRGKSSTASGNAAGESRPSANTTFNVGVTEERGPRRTMEDTHSYVYDFAGVEDQGYFAIFDGHAGKQAADWCGKKVHHVFEQAMKQSPDTGVPDLWDKTYMHCDGMLADLTQRNSGCTAVTALLAWEQRDGVRQRVLYTANVGDARIVLCRKGKAFRLSYDHKGSDENEGKRIAEAGGLILNNRVNGVLAVTRALGDSYMKDLITGHPFTTETVLTLQHDEFIILACDGLWDVCTDQEAVDLVRDIHDPQEASRLLCEHALKHYSTDNLSCMIVRLDPIGTTAEAKTPATSLSTHSEAVPSSSSEPAV",
    "product": "hypothetical protein"
   },
   {
    "start": 13126,
    "end": 13566,
    "strand": -1,
    "locus_tag": "MARS55BIN28_002834",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002834</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002834</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002834-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,126 - 13,566,\n (total: 441 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002834\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002834\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACCACACCTCCATCAAGTCTGCCTCGGACACGCTCGTCGAGAGCTTGAATGAAGTCTTCTGGAGCGTTGGAGATCTGATTGAGGCAGTCAGAAATGCGTCGGCCACAGTGGAGTTAAAGCAGAGGATAGAGAGGCAAAGGCTCGAGTACGATGCCGCACTTGATACGATAGAGATCCACATCATACAGACAATCAACGCGTTAAAACGTAGTGAGCGTACGCAAGAGTCGCCAAAGAAGGAGGAGGATGAGGGTATGGCGGATGTAGCTGCTGATGGTGATGTTGACGCTGATTTGGGTCACTCTGGAGGGGAGCGAGAACTGGCTTCTCCAGGTAAAGAGGCAGCAGAAGGACAGGAAGAGGACGGCGAGCACGCTGACGTACTTAACCCCGAAGCCGTGGGCTTGTTTGACGACGACTTTGATTTTGCGACGTAA",
    "translation": "MDHTSIKSASDTLVESLNEVFWSVGDLIEAVRNASATVELKQRIERQRLEYDAALDTIEIHIIQTINALKRSERTQESPKKEEDEGMADVAADGDVDADLGHSGGERELASPGKEAAEGQEEDGEHADVLNPEAVGLFDDDFDFAT",
    "product": "hypothetical protein"
   },
   {
    "start": 14338,
    "end": 15642,
    "strand": 1,
    "locus_tag": "MARS55BIN28_002835",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_002835</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_002835</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_002835-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,338 - 15,642,\n (total: 1305 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1122:ATP-dependent RNA helicase (Score: 325; E-value: 1.4e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_002835 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00270.32 (DEAD/DEAH box helicase): [38:209](score: 146.0, e-value: 1e-42)<br>\n \n  PF00271.34 (Helicase conserved C-terminal domain): [253:362](score: 95.8, e-value: 2.1e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_002835 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding<br>\n  \n   PF00270.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_002835\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_002835-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_002835\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAAGAACCACCACCACCAACAGAATCCGTGGACAAGCCACACAGCTTTGAGCAGCTGGGAGTCTGCACATGGCTCGTGGATGCAGTAAATGCAATGCGAATCACCGCGCCTACTCCTATACAAGTGTCTTGCATTCCACCCATCCTGGAGGGTCGGAATTGCATTGGCGGTGCCAAAACAGGGTCGGGCAAAACAATCGCCTTCGCTCTCCCCATCCTGCAGAAATGGTCACAGGATCCATACGGAGTGTTCGCACTCATCTTGACCCCGACTCGGGAGCTTGCGTTGCAAATCGACGAACAGATTGCTGCGCTCGGGGCGCCCATGAATCTCAAACACACATTGGTGGTAGGCGGATACAACATGCTCCCACAAGCACTGGACCTATCAAGGAAACCGCACATTGTCATTGCAACACCTGGCAGACTTGCAGATCACATCCAGAGTAGCGGCAGCGAGACCTGGGGCGGCCTGCAACGGGCAAAGTTCCTTGTGCTTGACGAGGCAGACCGTCTGCTTCAGGAGAGCTTCTCTCAAGACTTGGATGTCTGCATGAGCGTGCTCCCAGAACCCACTCAGCGACAAACGCTGCTCTTCACCGCGACAATCACCGACGCAGTCACTCATGTGAAAAAGCGTGCAGAAGAACAAGGCTCTGCGCACAGACCTTTCTTTCATCATATAGATGAGGGTGCGTTGGCAGTGCCAATCACGCTACAGCAATACTATCTCTTCATCCCAGCTCAAGTGAAGGAAGCATACCTTGTTACTCTTTTGCTGGCGGAGAGTAATGCTGAAAAGTCGGCGTTGGTATTCGTCAACAGAACGCACACGGTAGAGGTATTAGGCCGCGTGTTACGCTCCCTAGAAGTGCGCTCGACATCCCTACATTCACGAATGTCCCAACGCGACAGGGCTGACTCATTGGGACGCTTCCGAGCTGAAGCGGCACGTGTGCTAGTGTCTACAGACGTATCCAGCCGTGGTCTCGATATTCCTGCTGTCGAAATGATTGTGAATTTTGACCTGCCAAACGACCCAGATGATTACATACACCGTGTAGGACGTACTGCACGAGCTGGAAGGAAGGGCCAGAGTGTGAGTTTTGTGAGTCAAAGAGATGTGCTGCTCGTCGAGTCGATTGAGAAGCGTGTTGGGAAACGGATGGACGAGTACAAAGAAATCCCAGAGAGTAAAGTGATCAAGGGCGCATTACAAGAAGTCTCTACAGCCAAGCGAGAAGCAGTCATGGCGATGGATAAGGAGCAGGTCAAACGCAAGAGAAAATTACGAGCGGGCTGA",
    "translation": "MKEPPPPTESVDKPHSFEQLGVCTWLVDAVNAMRITAPTPIQVSCIPPILEGRNCIGGAKTGSGKTIAFALPILQKWSQDPYGVFALILTPTRELALQIDEQIAALGAPMNLKHTLVVGGYNMLPQALDLSRKPHIVIATPGRLADHIQSSGSETWGGLQRAKFLVLDEADRLLQESFSQDLDVCMSVLPEPTQRQTLLFTATITDAVTHVKKRAEEQGSAHRPFFHHIDEGALAVPITLQQYYLFIPAQVKEAYLVTLLLAESNAEKSALVFVNRTHTVEVLGRVLRSLEVRSTSLHSRMSQRDRADSLGRFRAEAARVLVSTDVSSRGLDIPAVEMIVNFDLPNDPDDYIHRVGRTARAGRKGQSVSFVSQRDVLLVESIEKRVGKRMDEYKEIPESKVIKGALQEVSTAKREAVMAMDKEQVKRKRKLRAG",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 7298,
    "end": 8228,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 18228,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r165c1"
 },
 "r317c1": {
  "start": 1,
  "end": 10953,
  "idx": 1,
  "orfs": [
   {
    "start": 16,
    "end": 1706,
    "strand": 1,
    "locus_tag": "MARS55BIN28_003967",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003967</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003967</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003967-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16 - 1,706,\n (total: 1656 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003967 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00004.32 (ATPase family associated with various cellular activities (AAA)): [313:443](score: 138.9, e-value: 1.4e-40)<br>\n \n  PF17862.4 (AAA+ lid domain): [466:501](score: 30.6, e-value: 2.4e-07)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_003967 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF00004.32: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003967\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003967-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003967\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ACCCCTGCAGACGTGATTTCGAAAGAGGTTTCATTAAAGCTCAGAACCCTTTTGAATGCACTCATAGATGCCAAAAAGTCTCTGTTTACGCTTGATCAAAAGACTAGGCCTGTGAGTTCGAAGACCATAGTGTATGTTCGCGAGATAAATTTACTTCAGGACGGGTCTGGCCCAGGAAGTATCGTGCTACGCGCACTTGAAACTATTTTATATGAACGAAGACGGCGGGGTGAGTCAATCATGATGGTGGGATCAGCTTCTATTTCCGCTATCCCTGAAGATTTGATTCTTGGGGAAGGATTTGTTCAAGTCAACTCCGTTGCAATGTCTAATGTCCGCAGCGTTGTGATACCGCCTCCCTCCGACAACCGATTGGCCTCTGATAACATAAAACGAATGAAGCAGATCAACTTGCGTCATCTCTCTGAGGAAATACGCAGAAGACAAAACCTTGGCCACGAAATAGAGATCATTCAAGGAATTAATCCTGAGAGTACTTGTGCACGTGTCGGTAACGGAATATGGTCTTACGATAAAGTCCAGCGCATAGTTTCTATTCTTTTAGGCCAGACCTCTGACGTGACAGTCCCCATTATAACCGAACAACTCAATGGTGCCATTCTACTGGCTGATCGAGTCAATGATTTATATCAGCAGTGGAAAGATTCCACAGAAGAAAAGGCAGAGATAGAGAGTGAGGAGCAAAGAGAAGATGCCCGAAAGATGGGAAGAGTTGTGGACACGAAAACCAGCAAATTGAATAGATATGAAAAGAAGCTGGTGCTTGGTATTGTTAGAAAGGAAGCTTTACGTGATGGGTTCTCGTCTGTTCAGGCACCAGAGAAGACGATTAAAGCATTGAAGACAATAGTGTCCTTATCATTGATACGGCCAGACGCATTCAAATATGGGATATTGGCGCGTAATCATATTTCCGGCATTCTGCTTTTTGGTCCGCCAGGTAGCGGAAAAACCCTTCTTGCAAAGGCCGTTGCAAAAGAAAGCGGAGCTAATGTCATTGAGCTCAAGGGCAGCGATATTTTTGATATGTATGTTGGCGAAGGTGAGAAGAATGTGAAAGCTATCTTCTCACTGGCACGGAAGTTGAGTCCATGTGTAATTTTTCTGGATGAAGTCGACGCAGTGTTTGGTTCGAGAAGATCAGACCATAGTAACCCAAGCCATCGTGAAGTTATCAACCAATTTATGGCCGAGTGGGATGGAATTCAGAGCCAAAACGATGGAGTTTTGCTTATGGGTGCCACTAATCGACCATTTGATCTTGACGACGCAATCATTAGGAGAATGCCTCGTCGAATACTTGTTGACCTCGCATCTGAAGCGGATCGTCGTGAGATCATTAAAATTCACCTAAGGGAGGAAACGGTCGATGCAGCGGTAGATATTGAGACGCTTGTGAAGCAGACAAACTTCTACTCGGGGTCTGATCTTCGAAATCTGGTGATCTCGGCAGCATTGAATGCTGTCAATGAAGAAAATGAAATTTATGCGACTGGAGAGACTCGTTCGCACAGAATACTTTCCCAGCGACACTTTGACATGGCACTTAACGAGATATCGCCCAGTATTAACGCCGATATGTCTGTGCTTACGGAAATTCGCAAATGGGATGCCAACGGTTTGGGGATTTTCTGA",
    "translation": "MPADVISKEVSLKLRTLLNALIDAKKSLFTLDQKTRPVSSKTIVYVREINLLQDGSGPGSIVLRALETILYERRRRGESIMMVGSASISAIPEDLILGEGFVQVNSVAMSNVRSVVIPPPSDNRLASDNIKRMKQINLRHLSEEIRRRQNLGHEIEIIQGINPESTCARVGNGIWSYDKVQRIVSILLGQTSDVTVPIITEQLNGAILLADRVNDLYQQWKDSTEEKAEIESEEQREDARKMGRVVDTKTSKLNRYEKKLVLGIVRKEALRDGFSSVQAPEKTIKALKTIVSLSLIRPDAFKYGILARNHISGILLFGPPGSGKTLLAKAVAKESGANVIELKGSDIFDMYVGEGEKNVKAIFSLARKLSPCVIFLDEVDAVFGSRRSDHSNPSHREVINQFMAEWDGIQSQNDGVLLMGATNRPFDLDDAIIRRMPRRILVDLASEADRREIIKIHLREETVDAAVDIETLVKQTNFYSGSDLRNLVISAALNAVNEENEIYATGETRSHRILSQRHFDMALNEISPSINADMSVLTEIRKWDANGLGIF",
    "product": "hypothetical protein"
   },
   {
    "start": 1763,
    "end": 3094,
    "strand": -1,
    "locus_tag": "MARS55BIN28_003968",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003968</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003968</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003968-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,763 - 3,094,\n (total: 1332 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003968\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003968\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCTTCATTAATACCACGGTGTCCCATCTATACATTCCACGATACGGACACTACTTCGTCCACTGATGAATTAGAAGTAATAGCGGTATGGAAAAAAGCGTTTTGGGCTGCAGGCTTTCGTCCCATTGTCTTGAGTACCCAAGATTCTCAAAAGCACCCAAAGTATGCAAATGTGCTTGAAAAAGTTAAAGATGAAAAGCCTCCGACCTTACTATTAAAATGGCTTGCATGGTCGGTGGTTGGAGGCGGTATATTAACGGATTGGACGGTCATTCCGTTTATGTACGAAATGAAGAATCCATCTCTATATTTGCTTCAAAGTTGCACTTTTGACGCTCTTGCTATACAGCGATACGAAAATTTTGGCGAATCAATACTCATGGGAGCCAATGGTCCAGTTGCTAATTTTCTGGGGCGGCTGCTAGCGGTAGAGGACTTCAATTCGCTAGATTTGCTTACCTTTGGTGGTGACGATTTCCAGGTCTTGGCTACTCCGTCAGATTTAGCGTACTATTCCCCAGACATCATCGTATCAAGATATGAGAATATGGAGTTGCGTCAATTGGCAGTGCTCATTAATGCTCATCTTCATCAGGCAATGCTACTTGCCTTTCCCGAAAAGATACTGGTAGTCAACCCATTTTTTGAGATATCGAAAATTTTGGTTTTCCCCGCTCTTCGCATTGCTCGCCAGCTGGCTCGCTGTCCTTCATCTCCGCTCAAGTCATCTCAATCGCCGTTGCACCAGTATGATACTCCATGTGAAGTACGCAAACACCCCGTGGCATACGCGCAAGGAATCACTAATTCTACTAAAAGTATTCAATTGCTCACAGTTGCGCATCCTCTTACTTACCTCTGGCTCAAGCAAAAACGAGCAAAGGTCCAGCCTTCCTTTGTTCGTCGCCACACGGATAGAGATTCATGGATGGTCGCTACAACACGCGACATATCTCCAGCAGGAGTTGGTGCTGAAAAGCGACTGACAATTTTAAAAAGAGCGCTGATTTCCCAAAGTGTAGCTATACTTGCTGCTACGTGGGAAGAATCATGGGATGAGAACGATGTTTCTGGTGTGTTAGGGTTCTCCCTCCCCCCCATATCTTTTGAGGATGAGATTATCGATGGGGAAGGTACGCGAAAGTATGCTGATAATGTCACTCTCCTATCAGAAGCAAAGAAGACGGTTCTAGGTTTGGACGCAGAGTCTTTACGGCAGAGAGCCTTTGTGGAAGCGTGGAATTTGGCGGACACGGGAATGTGGCGTTTTGTGCAGCTTATTGTAAAAAATGCTAATGACGAACGTCGAGCATGGGCCTTAGGGAAGTAA",
    "translation": "MPSLIPRCPIYTFHDTDTTSSTDELEVIAVWKKAFWAAGFRPIVLSTQDSQKHPKYANVLEKVKDEKPPTLLLKWLAWSVVGGGILTDWTVIPFMYEMKNPSLYLLQSCTFDALAIQRYENFGESILMGANGPVANFLGRLLAVEDFNSLDLLTFGGDDFQVLATPSDLAYYSPDIIVSRYENMELRQLAVLINAHLHQAMLLAFPEKILVVNPFFEISKILVFPALRIARQLARCPSSPLKSSQSPLHQYDTPCEVRKHPVAYAQGITNSTKSIQLLTVAHPLTYLWLKQKRAKVQPSFVRRHTDRDSWMVATTRDISPAGVGAEKRLTILKRALISQSVAILAATWEESWDENDVSGVLGFSLPPISFEDEIIDGEGTRKYADNVTLLSEAKKTVLGLDAESLRQRAFVEAWNLADTGMWRFVQLIVKNANDERRAWALGK",
    "product": "hypothetical protein"
   },
   {
    "start": 3526,
    "end": 7593,
    "strand": 1,
    "locus_tag": "MARS55BIN28_003969",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003969</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003969</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003969-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,526 - 7,593,\n (total: 4068 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: NAD_binding_4<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 241.3; E-value: 2.7e-73)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003969 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00501.31 (AMP-binding enzyme): [223:688](score: 221.0, e-value: 2.3e-65)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [822:887](score: 46.8, e-value: 2.9e-12)<br>\n \n  PF07993.15 (Male sterility protein): [944:1194](score: 253.3, e-value: 2.2e-75)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003969 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR03443 (alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase): [6:1350](score: 1895.0, e-value: 0.0)<br>\n \n  TIGR01733 (AA-adenyl-dom: amino acid adenylation domain): [253:711](score: 375.7, e-value: 6e-113)<br>\n \n  TIGR01746 (Thioester-redct: thioester reductase domain): [941:1317](score: 339.8, e-value: 5.3e-102)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003969\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003969-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003969\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTCAATTACATGGTGTCTCGCTTCCGACGGACTATACCGCTCAAGGCAATCAGATCGTTGAAAACATCTACCCGGTCCAAATAGATGATGCGACGAGGGAAGCATTCTCACAGCTTGCGATAGCTGATGGTTCGAAAGCTCATTCCCCATTTACTTTGCTGCTCTCTGCGGCAGCTATCCTCATCTACAGACTGACTGGCGATGACAATGCTTGTATCAGCTCAGATGGACGACTTTTAAAAGTCGTTATCAAAAGTGAAACTACTTTCCTAGATCACACCAATGGGATCGAGGAGAATTACTCGCATTGTGAAATTTCCGACTCCCTGGCACGAGTATCGCTTTCACAAGACACCAAAAAAAATGTCCTCGCGAATGATTTATCTATTTTTGTTGCAGGTCATCAGGATGATCTGCCTGGAAGAAGGCCTTCAGCTCCCATCCTTGGCATGACAGTAACAGTACACTACAACCAGCTTTTGTTTTCACGAGAGCGAGTACATGTTATAATGAGGCAATTGCTGTCACTCGTTCGATCGGGCGTCGCCAACCCATACGCTGCAATTGGAAGCATGCCGCTATCTAACAATAGCGAGAAGGACATTCTCCCTGACCCAACATCTGACCTTCATTGGGAAAAGTTTGGCGGTCCCATCCATGAAATATTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGATTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTTCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGTGGTTTTCGAATCGAGCTTGGCGAGATCGATACTTATTTGAGCCGTCACGATGCCATACGTGAGAATGTCACGCTACTTCGTCGCGATAAGGATGAAGAACCAACGTTAGTTTCCTATATTGTGGGAACTGACGAGTCTCTTCGAAAATTTGCAATGTCCAGCACGTCTAACAATCTCAAAGAAGTTCTACAGAGCCACATACTGCTCATCAGGGAGCTCAAGGAATTTCTCAAAAGCAAATTACCATCCTATGCTGTTCCCACCGTCATTGTTCCGCTCTCAAGAATGCCGCTAAATCCCAATGGAAAGATCGATAAGCCAAAACTGCCATTTCCAGACACTGCGGAATTGATGTCCCTAGGCGACGTTCGCGAAGGCAAAGGCCTTACAGAAGTTCAAGCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGACAGTTTACGATCAGGATTTGGCGGACGTGAGTTGAACACGTACAAACCTGAGACGAACGGCCACAGCAGTCAGCTCAATTATGCGGGTGATGCTATAGATATTTCTTCGCGCTTAGCGACATCCTACAAGTCCCCGAATATATCAGCTAGTTCATCGACTACAGTCTTTCTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAGTCGACGTCGTAATTCACAACGGGGCCCAAGTTCATTGGGTATATCCGTACGCTAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTGCTGGCAAAGCCAAAAGCGTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAGAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATGATCCGTGAAGCTGGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATTGTTTCGGCGTCGATTCATCAGCGGAAAGAACTCCACGTTGCCCAAATTACCGGCCGTCCACGATTACGATTTGTGGACTTTCTCGGCAGTTTACGAAGTTTTGGGTACGCTGTCACCAATGTCGATTACATTACTTGGCGATCAAATCTGGAAAGAAGTGTCTTGGAAAACCCTGCCGACAACGCCCTCTACCCACTCCTTCACTTTGTCTTGGATAATTTGCCTGCGAGTACCAAAGCACCCGAATTGGATGATAGTACTACGGTGGAGATCTTGAAAGCAGATGGGGCCGACGCTTCACAAGGAATGGGTATCGGAGTTCATCAAATTGGGCTTTATCTCGCCTACCTCGTAGCAATCGGATTTCTACCGCCACCTAATCTGAAGGGTATTCATCAACTTCCAGTCGCAAACTTGCCGGATGACATAAAAACAAAACTAAGTACAATTGGAGGACGCGGAGGAAATAAGATAGAATCAGGCTAG",
    "translation": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQIIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSSTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEVDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCAAGKAKSVTFVSTTSVLDCEYYTELSDRILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYMIREAGKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
    "product": "hypothetical protein"
   },
   {
    "start": 7607,
    "end": 9267,
    "strand": -1,
    "locus_tag": "MARS55BIN28_003970",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003970</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003970</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003970-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,607 - 9,267,\n (total: 1587 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF02874.26 (ATP synthase alpha/beta family, beta-barrel domain): [36:102](score: 53.9, e-value: 2.2e-14)<br>\n \n  PF00006.28 (ATP synthase alpha/beta family, nucleotide-binding domain): [158:386](score: 215.6, e-value: 6.7e-64)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR01040 (V-ATPase_V1_B: V-type ATPase, B subunit): [32:495](score: 962.1, e-value: 8.8e-291)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_003970 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00006.28: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process<br>\n  \n   PF02874.26: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003970\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003970-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003970\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCATCTGCGGACCCCAGGGTCAGCCCTCAAGCGGCAGCCCAGATCAATGCTGCTGCTGTCACGAGGAACTACTCGGTCCAGCCGAGGTTGCGCTACAACACAGTGGCTGGAGTGAATGGTCCTTTGGTCATTCTCGATAATGTCAAGTTTCCACGATACAATGAGATTGTGAATCTGACACTTCCAGACGGATCGAATCGGTTAGGTCAGGTTCTGGAAGTGAGGGGCTCGCGGGCGATTGTCCAGGTCTTTGAGGGGACATCGGGGATTGATGTTCAAAAAACCAGGGTGGAATTTACCGGGGAGTCTTTGAAGATCCCAGTATCCGAAGATATGCTTGGACGTATATTTGACGGATCTGGTCGAGCCATCGATAGAGGCCCCAAGGTGTTTGCTGAAGACCATCTCGATATCAATGGTTCTCCCATCAACCCCTACTCTCGTATCTACCCTGAGGAAATGATCTCAACCGGTATATCCACTATTGACACGATGAATTCCATTGCCCGTGGACAAAAGATACCAATCTTTTCCGCGGCTGGTCTCCCTCATAATGAAATCGCCGCTCAAATCTGTCGGCAAGCTGGTCTCGTAAAGAGACCAACCAAAGACGTCCACGATGGTCACGAGGACAACTTCTCCATCGTTTTCGCTGCAATGGGTGTCAATCTTGAAACAAGTCGCTTCTTTAAACAAGATTTCGAAGAGAATGGATCCTTAGACCGTGTCACCTTGTTTCTTAATCTTGCCAACGATCCAACTATCGAACGAATCATTACACCTCGTCTCGCGCTGACGACTGCTGAGTACTATGCCTACCAGCTCGAAAAGCATGTGCTTGTAATCCTGACCGACATGTCGTCTTATGCCGATGCATTGAGAGAAGTCTCTGCTGCGAGAGAAGAGGTTCCAGGGAGGCGAGGCTATCCAGGATACATGTACACCGATCTTTCCACCATTTACGAAAGAGCAGGGCGTGTTGAAGGCCGAAATGGCTCTATTACGCAAATCCCCATTCTTACTATGCCAAATGACGATATTACTCACCCGATTCCCGATTTAACAGGATACATCACGGAAGGACAGATCTTTGTTGACCGTCAACTATACAACAGAGGAATTTATCCACCAATAAATGTTTTACCTTCGCTCTCCCGGTTGATGAAGTCCGCTATTGGTGAGGGAATGACAAGGAAAGATCACAGCGATGTGTCGAATCAACTCTATGCAAAATACGCAATAGGCCGAGATGCTGCTGCAATGAAAGCAGTTGTCGGAGAGGAAGCTTTATCACAAGAGGACAAACTCTCCTTGGAATTTCTAGAGAAGTTTGAAAAATCTTTTGTTGCACAGGGCGCTTATGAAGCTCGCTCGATTTACGAGTCACTCGACCTTGCCTGGTCGCTTCTGCGAATCTACCCCAAAGATCTTTTGAATCGCATACCAGCCAAAATCCTGTCCGAGTACTATCAAAGAGATAGGAGAGGAAAGAAGCAGCAGGACGAGGGAGACAAGGATACGCGGGATAACGACACTAAGAAGGCAAGCAATCCGCAGGAGGGGAATTTGATTGACGATGTATAG",
    "translation": "MPSADPRVSPQAAAQINAAAVTRNYSVQPRLRYNTVAGVNGPLVILDNVKFPRYNEIVNLTLPDGSNRLGQVLEVRGSRAIVQVFEGTSGIDVQKTRVEFTGESLKIPVSEDMLGRIFDGSGRAIDRGPKVFAEDHLDINGSPINPYSRIYPEEMISTGISTIDTMNSIARGQKIPIFSAAGLPHNEIAAQICRQAGLVKRPTKDVHDGHEDNFSIVFAAMGVNLETSRFFKQDFEENGSLDRVTLFLNLANDPTIERIITPRLALTTAEYYAYQLEKHVLVILTDMSSYADALREVSAAREEVPGRRGYPGYMYTDLSTIYERAGRVEGRNGSITQIPILTMPNDDITHPIPDLTGYITEGQIFVDRQLYNRGIYPPINVLPSLSRLMKSAIGEGMTRKDHSDVSNQLYAKYAIGRDAAAMKAVVGEEALSQEDKLSLEFLEKFEKSFVAQGAYEARSIYESLDLAWSLLRIYPKDLLNRIPAKILSEYYQRDRRGKKQQDEGDKDTRDNDTKKASNPQEGNLIDDV",
    "product": "hypothetical protein"
   },
   {
    "start": 9376,
    "end": 9663,
    "strand": 1,
    "locus_tag": "MARS55BIN28_003971",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003971</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003971</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003971-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,376 - 9,663,\n (total: 288 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003971 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF13259.9 (Protein of unknown function (DUF4050)): [35:84](score: 40.6, e-value: 3.5e-10)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003971\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003971\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGGAGAGCTGGAACGAGGGGCTGAAGCACTGGAAAGCGCAAAGGGCGCGCTGGACACGCTCGGATGGGGAGAAAGTGCAGGCTTCGCAAGGCCGCCTGGATCAGATGCGCGCGAAGCTGAATGCACGCGATTTTTTGACAATCCACACGGCCTTGGTTGTACAAGGGAAGAAGCCCAAAAGGCGCCTGAACCTTGCGTTGGTGGTGAAGAGTCTTATTTGCGGGTGGAAGGAGGATGGCACCTGGCCCCAGAACAGTCAATCTGCTCCGGATGGCCGTGGATGA",
    "translation": "MEESWNEGLKHWKAQRARWTRSDGEKVQASQGRLDQMRAKLNARDFLTIHTALVVQGKKPKRRLNLALVVKSLICGWKEDGTWPQNSQSAPDGRG",
    "product": "hypothetical protein"
   },
   {
    "start": 9753,
    "end": 10724,
    "strand": -1,
    "locus_tag": "MARS55BIN28_003972",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_003972</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_003972</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_003972-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,753 - 10,724,\n (total: 972 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_003972 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF06966.15 (Protein of unknown function (DUF1295)): [27:270](score: 203.7, e-value: 3e-60)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_003972\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_003972-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_003972\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCAGGGACTGTGCATGTATTGGATGCCTATTATCTCGCAATCACAGCATTTGTGACTGTTGCCTACCAGCTCATTGGCTTTTCTATTGCATTCACCTTCAAATTCGACAAAATTACGGACCTGTTTGGTGGAACAAATTTCATCATCCTCTCCATTCTGACCCTTGCTCTTGGTGGTGTCTCTTCACCTTTGGATAATCGCCGAAACATCATTGCCAGTGTATTTGTCATGATATGGGGAGCTCGACTTTCCGGGTTCCTCCTCTTTCGCATCTTGAAGACGGGCACAGACACGCGCTTTGATGATAAGCGGGGAAACTTTTTCAAGTTCCTCGGTTTCTGGGTGTTTCAGGCTGTTTGGGTGTGGGTTGTGTCGCTTCCATTGACGATTGGAAATTCGCCTGCAGTTAACAATACTGGGGGCCATTCCTTTGGCACTGCTAGTGATATTGTGGGCATCATCATGTGGGTGATTGGCTTCTTCCTCGAGGCAGTTGGCGATATTCAGAAATTCCGCTTCAAGCAAGGCCAGCACGACAAATCGAATTTCATGCATTCAGGTGTGTGGAGCTGGAGCCGTCATCCAAACTACATGGGGGAGATCTTGCTGTGGTTTGGCATATACACGATGCTGCTAGCACCCGCGGAATTCGGAGACATCAGCACCAACCCGCGAGCTGCTGTGTATGCTTCCATCCTCGGACCGATCTTCCTTGCACTTCTTCTCCTGTTTGTTTCTGGTATCCCTCTTCAGGACAAACCTGCAGCCAAGAAACGGTTTGAGGAGGGCAACAATTACGAAGGCTACCGTGGCTATCTGGAAAGCACAAGTATACTGATACCTCTGCCGCCTCAGGTCTATCGCCCCATCCCCTCTATGATCAAGAAGTCCCTTCTACTGGATTTTCCATTCTTCAACTTTCATCCAAACAGCTCCATGCAAGGTTCACATGGTAGCGAACAAGCTTAA",
    "translation": "MAGTVHVLDAYYLAITAFVTVAYQLIGFSIAFTFKFDKITDLFGGTNFIILSILTLALGGVSSPLDNRRNIIASVFVMIWGARLSGFLLFRILKTGTDTRFDDKRGNFFKFLGFWVFQAVWVWVVSLPLTIGNSPAVNNTGGHSFGTASDIVGIIMWVIGFFLEAVGDIQKFRFKQGQHDKSNFMHSGVWSWSRHPNYMGEILLWFGIYTMLLAPAEFGDISTNPRAAVYASILGPIFLALLLLFVSGIPLQDKPAAKKRFEEGNNYEGYRGYLESTSILIPLPPQVYRPIPSMIKKSLLLDFPFFNFHPNSSMQGSHGSEQA",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 3525,
    "end": 7593,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 10953,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r317c1"
 },
 "r421c1": {
  "start": 1,
  "end": 7942,
  "idx": 1,
  "orfs": [
   {
    "start": 1340,
    "end": 4744,
    "strand": 1,
    "locus_tag": "MARS55BIN28_004502",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004502</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004502</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004502-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,340 - 4,744,\n (total: 3036 nt, excluding introns)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: itr_KS<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 93.3; E-value: 2.6e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004502 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF16073.8 (Starter unit:ACP transacylase in aflatoxin biosynthesis): [10:248](score: 75.9, e-value: 3.8e-21)<br>\n \n  PF00109.29 (Beta-ketoacyl synthase, N-terminal domain): [401:608](score: 199.8, e-value: 5.8e-59)<br>\n \n  PF02801.25 (Beta-ketoacyl synthase, C-terminal domain): [649:755](score: 96.0, e-value: 1.6e-27)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004502\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004502-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004502\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCGCGTTGACAGAACACTGTCTGGTGTTGTTTGGAGGCCAGGGGTCGCCGTCCATTTTCTCGCCTAGTGCGGCCGCGACTGCAGAGGAAGATGCTCGATCAGCGAGCGCCGGCAGCATCCTTCTGTCGAGGTGCCATGCGGCTTTCTTGCAAGAGATAGCGAGTCTAGACGCCCGCTCGCAACATCTTCTCGCCATCGATCCCGCCCTGTTCTCCTTCCCACGTGACTTGCTCAAGCCGGTCGCACAATATCACACACACGCAGTGCTCCAGGCGACCACCATCTACCTCTGCCAGCTGCTACATTATCTGGCTGAGACACAGCGTATCGACGGACCATTCGAGGACTCGTTTGACCGACTTCGAGAGACAGCGGGCTTCTCTTCGGGTTTGCTCCCGGCTACGGTAGTTGCACGCTCGCGCAGCTTGGACGACTTTGTGACATCTGGAATCGAAGGGTTCCGCCTTGCCTTTTGGATTGCATGTCGCAGTCTCTTCTGGAGCCTCAACCCCAATGCAAGCGACCCCGTTGGCGATGGCGTCGACTCAGAAGCGACATCGTCCCTTGTGATTCGTGGTCTTTCCCCAAGCCAGGTCGAAGAGAGATTATTACAGCACTTCGCGGCGCAGGGGCCGGGCCCTTTATCCCAGCAACCGCCTCGACGACTCCAGGTATCTACCATCTCCAATTCTAGTGTTGTGTCTGTATCTGGCCCTAGAGTGGATCTCAGTGCGTTCAGGGTGCAGGCTGTCCCCGATCTTGCAACAACCTTCGCGCATGTACATGGATGGTATCATGGAGGAGATCAACTTGAAGGTGTTGTCCACGAAGTTCTTGAAGATTTGCGGCGTCGGGCCGTCTCCTTCCCCTCTTTCTCCACGCTTACAAAACCCATTCGTTCAACCTTTGACGGCACGTTATTCGATGCTTCAAACACCGATGCTCCAGAGTTGCTTGGGTGGTTAGTTCGGCACTTGTTGCTACACTGTGTAAATTGGAGCGACACAGCTCATGAGATCGCAGCAAGTGTTAGGGCGTTATTGGAACGGGAGCCCGCAACAGTCGTGAAGCTCCTTTCCTTCGGACCAGGCTCCGGCTCCCTATTCCCAAACTTTCAGCCTCTTGATCCTAGAATAGAACTTCTGGATCTCTCGCCATTTAGAGCTAGCAGGAAATCTCGGTTGTCTTGTAACCACCAGGATAGCATCGCCATTGTTGGGCTGAGCGTGCATCTCCCCAAAGGGAATGGCACCGAAGAGCTATGGGAAACGCTGTCCCAAGGGTTGAATGCCGTGCAAGAGATCCCTGAGTCCAGGTTCAAAGTCTCGGACTATTATTCAGAGGAGGATTCGCATAAGCCGCGCTCGATGCCCACGAAGCACGGCGCATTCCTGGACGATCCCTTCTCCTTTGATAATGCCTATTTCAATATTTCCCCTCGAGAAGCAAAATCTATGGATCCTCAGCAGCGAATTTTATTGCATGCAGCCCAGGAAGCCTTTGAAGATGCTGGCTATGTAGGGGATTCATCACCATCTTTCCAAAGAGCTTCCATCGGATGCTACATTGGCCTTGCTACTGGGGATTACACAGACAACCTTCGCAATGATATTGATGTCTTCTACCCCCCCGGGACACTACGAGCATTTCATAGTGGAAGGATATCTTACTTTTATGGGCTCAGTGGCCCATCCATTGTGACTGATACTGCATGTTCGTCCTCAATTGTCTCCGTGTACCAGGCATGCCGAGCCCTACAACGTGGCGATTGCACAGCAGCTATCGCGGGCGGCGCCAATGTGATTTCCAGCCCCGATCCCGAGGCCACTTCCTCAGTCCAACCGGAGGCTGCAAACCCTTCGATGCAGCAGCTGACGGATATTGTCGGGCTGAAGGGTGTGTTCTCTTTGTTCTCAAACGATTGTCTGATGCTATCGCGGAAAACGATCACATACACGGCGTTATCAGGAACTCAAACACAAATCGACCTGTTCCAGCGACTGCTCCAACAAACGAATGTCGATCCTGGATCCATTGGTGTCGTAGAAGCACACGGGACAGGCACACAGGCCGGAGATGCACGCGAAATTGAAAGCTTGCAAACTATCTTTGGCCCACATCACTCAATGGTGAACCCCCTTGTGGTCAGTTCTATCAAGGGTAATAACATAGGCCATTGTGAATCCGCGTCTGGAGCAGCTGGTTTGGCTAAATTATTGCTCATGCTTCGCGAGAAAATAATCCCAGTACAAGTCGGATTTAAGGACGTCAATCCACGTTTCGCGGACCTGGAAAGCTCTGGCTTCATTATACCAAGGCAGACTACAGCATGGATCCACTCGCAAAGAGCCCCAAGGAGAGCTATGCTGAATAATTTCGGGGCTGCTGGCTCAAATACGTCTCTCCTCCTAGAAGAGTGGGTTGAGCCACCAAATACCCAGCCCAGGCACCAGGAGCGATCAGCGTATGTCTTTGCACTTTCTGCAAAATCAAAAACTGCATTGCAAACGGCTGTACATCGACACCTCCGATTCCTGGGGAAAGTAGATCGTCGGCCATCGTTGAAAGACATCTGTTATACCGCAACTGCGCGGCGTCAGATTCATGATCACCGCATCTCCGTGGTATGCACCACTATTGATGATCTACGGACAAGGTTAGAACATTGCAAAGCTGTCAACTCCATTCCCGCTCAGGGTATCTCAGCCACTGTTTTTGTCTTCTCTGGACAAGGCGGTTTGTATCACGGTATGGGAGAAGAATTAAAGTACACATTCCCTCTTTTCAAAGAGGTTATCATGAGTTGCGATGGCATCATCCAAGGATTGGGATACCCAAGCATTCTCAGTATCTTATGCAAAGATCGAGGCGGAGTAAAGGCATTAGACGGCGCTGAGCAGTTTATCGCATCACAATGTGCGTGCGTCGCACTAGAATATGCGCTCGCGAAAATGTTCATGTTGTGGGGGATTATGCCCGAATATGTTATGGGTCATAGGTACTTCAGCACCCCAGAGGTCTTCATCTACTAA",
    "translation": "MPALTEHCLVLFGGQGSPSIFSPSAAATAEEDARSASAGSILLSRCHAAFLQEIASLDARSQHLLAIDPALFSFPRDLLKPVAQYHTHAVLQATTIYLCQLLHYLAETQRIDGPFEDSFDRLRETAGFSSGLLPATVVARSRSLDDFVTSGIEGFRLAFWIACRSLFWSLNPNASDPVGDGVDSEATSSLVIRGLSPSQVEERLLQHFAAQGPGPLSQQPPRRLQVSTISNSSVVSVSGPRVDLSAFRVQAVPDLATTFAHVHGWYHGGDQLEGVVHEVLEDLRRRAVSFPSFSTLTKPIRSTFDGTLFDASNTDAPELLGWLVRHLLLHCVNWSDTAHEIAASVRALLEREPATVVKLLSFGPGSGSLFPNFQPLDPRIELLDLSPFRASRKSRLSCNHQDSIAIVGLSVHLPKGNGTEELWETLSQGLNAVQEIPESRFKVSDYYSEEDSHKPRSMPTKHGAFLDDPFSFDNAYFNISPREAKSMDPQQRILLHAAQEAFEDAGYVGDSSPSFQRASIGCYIGLATGDYTDNLRNDIDVFYPPGTLRAFHSGRISYFYGLSGPSIVTDTACSSSIVSVYQACRALQRGDCTAAIAGGANVISSPDPEATSSVQPEAANPSMQQLTDIVGLKGVFSLFSNDCLMLSRKTITYTALSGTQTQIDLFQRLLQQTNVDPGSIGVVEAHGTGTQAGDAREIESLQTIFGPHHSMVNPLVVSSIKGNNIGHCESASGAAGLAKLLLMLREKIIPVQVGFKDVNPRFADLESSGFIIPRQTTAWIHSQRAPRRAMLNNFGAAGSNTSLLLEEWVEPPNTQPRHQERSAYVFALSAKSKTALQTAVHRHLRFLGKVDRRPSLKDICYTATARRQIHDHRISVVCTTIDDLRTRLEHCKAVNSIPAQGISATVFVFSGQGGLYHGMGEELKYTFPLFKEVIMSCDGIIQGLGYPSILSILCKDRGGVKALDGAEQFIASQCACVALEYALAKMFMLWGIMPEYVMGHRYFSTPEVFIY",
    "product": "hypothetical protein"
   },
   {
    "start": 4847,
    "end": 7757,
    "strand": 1,
    "locus_tag": "MARS55BIN28_004503",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004503</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004503</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004503-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,847 - 7,757,\n (total: 2865 nt, excluding introns)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00698.24 (Acyl transferase domain): [9:189](score: 53.4, e-value: 2.9e-14)<br>\n \n  PF14765.9 (Polyketide synthase dehydratase): [266:554](score: 63.3, e-value: 2.3e-17)<br>\n \n  PF00550.28 (Phosphopantetheine attachment site): [614:678](score: 25.8, e-value: 1.1e-05)<br>\n \n  PF00975.23 (Thioesterase domain): [737:952](score: 79.7, e-value: 3.6e-22)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR04532 (PT_fungal_PKS: polyketide product template domain): [266:563](score: 180.4, e-value: 1.4e-53)<br>\n \n </div><br>\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_004503 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00975.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004503\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004503-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004503\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGACAATTGTGTGGCTAACGCGTCTGGGATGCTGGCGTGCAAGTTATCCCCCGAAAAGGCCGAGGAATTGATATTGGAAAACTCGGGCGTGTCCCAGCTGACCGTGGCATGCCTGAATGGCATTGGTGACTGTGTCGTTGGTGGACCGCTGGGCCAAATCGATATATTTCAGAAGGATTGCAAGACCCGGAAGATCAAGGTGAAGTTGATGGACGTCGCCTACGCCTTCCACTCACCAGCTATGGATCCAATCCTGGAACCCCTGCAAGCCCTGGGGCGCTCAATCAGGTTCGCACGACCTACGATTCCCGTCATCTCTAATGTGTTTGGGCGATTATTTGAAGAGGAAGACTTTTCTAGTGACTACTTCGCGCTTCACGCGAGGCAGCCAGTGCGCTTTACCGAATGTCTGCTTAATTTACAATCAAGAGAACTGCTCGACGGTGCTGTCTTCCTTGAGATAGGCCCACAACCTACAACAATACCAATGCTACGGAGCTCGATTCATTCAGACTCTTGTACCTACCTTAGTACCTTACAAAAGGGCCAAGATGCATGGACCTCGATTAGTTTAACACTGGCCGCGATATCATTGCTCAAATTTCCAGTCAACTGGCGCGAGGTTTTTATTGGGACGTCTGCGAAAGTGATAGGCTTACCAGGCCATCTATTGGAGGGCTCGACCTATATGATACCTTACCAGGAACCTCGTCAGGTTGTCAATTCCCTTGAGCAGTATTCGGTGGAGCTCCGCACCAGGACCGGGTTTAAGCTGCTACCATGGCTGAAGACTCAGGCGTCTTCGAACGAGGAATTTGTGCTTGAGACAACATTAGCAATTCTTGGGCCATTGATCACAGGGCATGAGGTTGGCGGGACTTCCATCTGCCCAGCGTCAGTATTCCATGAGCTCGCCTTGGAAGGAGCACACACTATGCTTGAGCCTCACGAGGGCCAACTATTGGTCGTCACCGGGATGAGCTTTACCAGTCCACTAATATATGTACCGTCACAGGAAGCAGATGTTGTGACTGTGTACATCACAAAATATGATTTAGCTTCCGGGGCAGACTTTAAAATTACCTCATGCTCGACCAAAGATCTTACGGAGAATATAAACTGTACCGGTAGTGTCTCCCTGCAAAACTTCCAGATCAACGCATCCCACTGGATAAAGGATGCGGCAATTGTGACGAGGCAAAGTCATTACTTCTCTGGTGTCGGGAAAAGTTACATCAGTACTTTCCGAACTAAAGTCCTTTATGAGGCTATCTTTACACGTGTTGTCAGGTATTCCCCAGAGTACCAAAGCTTGGTGTATTTGAGTGTGACCAACTCCAATCTCGAAGGTATTGGCTCGTTCAAACTACCGTCTAGTTCTCAGACCGGTTACCTTGCACCCCCTGTCTTTACAGACACACTTCTGCATGCTGCAGGTTTCATTGCAAATCTTGCTGTAAGGTCCGACGAAGTAGGCATTTGCGCCCGCGTCGAGTCGGTCGAGATATCTTACCGTGATATCGATTACGCGGATTCTTTCACAGTTTACTGCAGCTTGCTCGAAATCAAAGGTGCAATTCTAGCAGACGCAATTGCCTTGAATGCTTTCGGGAAAGTCGTCGCCGTCGTTCGGGACATGGAATTTAAAAGACTCCAATTGTCTGCTTTCCAGCAAGTGTTGTCTCGCAAGTCCACTGCCATTGAGCCTCGGAATTTTCCTGTGGAGCAAAAGAAACCGCAGCTATCAACTGGTTTGGACACTCCTCCCACAAGTGGCGAGGTCATAGATACTCCCATCGAGTCTCGTGGTAGTCTTCCTCATGACGTAAGGATAGCACTGAAGAATATCGTCATGGAATTTGGTGGTTTCTCCGAGCAAGATATGGATTACACGAATTCACTAGATGAACTTGGGATCCATTCTCTTATGCAAATTGAGATTATCTCGAAACTGATACGCACATTTCCCGGTCAAGCTGGGCTGGACCACCATGCTTTGTCAGAATGCGAAACTCTCGAGTCCTTGGAAAGCACTCTGGCATCCATTCTGCAATCCTCGGTGGAAATCACTTCGCTTGTTGGGGCTCCCATATCCGCCAGTCAGCGAGATTCACGTCAGTCTACTCTTGTTCCTTCAGACTTTTCTTCATCTGATGGCATGCAGAAGAATCCAGTAGCGCTACATGTTTCACACGAAGAGGTAGCACCGCTCTGCCTATTTCATGACGGGAGTGGGCAGGTCAGCATGTATGCACGGCTGCGTGATCACGACCGCAGTGCATACGCCTTCTTCGACCCGCATTTTGGGAGTGACAAGCGACCTCACAGCAGCATAAATCAGATGACCGAGTACTATGTCTCGCTCCTCTCAAGATCTAAACTATCTCCCTTGATAGTGAGTGGTTGGTCTTTTGGCGGAATAGTGGCCTTCGAGGCGGCTCAACAGCTCATGGCCAATGGATTCGAGGTAAAGGGCCTCATATTGATCGACTCTCCAAATCCCATTGATCACGAACCTCTTCCGAATGAAGTCATTGCCAACATTATCAAATCGAGCGGTCAGACTCATGCGTTGAACAACAATGCTGCACTAAGGGAAGAATTCCAATTCCACGCATCTCTACTAGGAAGTTACAAGGCAGTATCCTTTTCCAAAACGAATAGACTGAGACTGAAGACGGTCATGTTGAGAAGCCAGAACGTCTTCGATACTGAAAGTCTTTGCGGGGTTCGCTATGACTGGCTCAGTAACCAGGATGCTCGAGCTGCTGCTATCGTCGCCTGGGAAGGATTGGTCGGTGGTTATGTCAAGGTTCTGCCAATCCCTGGAAACCATTTCGAGGCCTTCTCACAGAAAAAC",
    "translation": "MTDNCVANASGMLACKLSPEKAEELILENSGVSQLTVACLNGIGDCVVGGPLGQIDIFQKDCKTRKIKVKLMDVAYAFHSPAMDPILEPLQALGRSIRFARPTIPVISNVFGRLFEEEDFSSDYFALHARQPVRFTECLLNLQSRELLDGAVFLEIGPQPTTIPMLRSSIHSDSCTYLSTLQKGQDAWTSISLTLAAISLLKFPVNWREVFIGTSAKVIGLPGHLLEGSTYMIPYQEPRQVVNSLEQYSVELRTRTGFKLLPWLKTQASSNEEFVLETTLAILGPLITGHEVGGTSICPASVFHELALEGAHTMLEPHEGQLLVVTGMSFTSPLIYVPSQEADVVTVYITKYDLASGADFKITSCSTKDLTENINCTGSVSLQNFQINASHWIKDAAIVTRQSHYFSGVGKSYISTFRTKVLYEAIFTRVVRYSPEYQSLVYLSVTNSNLEGIGSFKLPSSSQTGYLAPPVFTDTLLHAAGFIANLAVRSDEVGICARVESVEISYRDIDYADSFTVYCSLLEIKGAILADAIALNAFGKVVAVVRDMEFKRLQLSAFQQVLSRKSTAIEPRNFPVEQKKPQLSTGLDTPPTSGEVIDTPIESRGSLPHDVRIALKNIVMEFGGFSEQDMDYTNSLDELGIHSLMQIEIISKLIRTFPGQAGLDHHALSECETLESLESTLASILQSSVEITSLVGAPISASQRDSRQSTLVPSDFSSSDGMQKNPVALHVSHEEVAPLCLFHDGSGQVSMYARLRDHDRSAYAFFDPHFGSDKRPHSSINQMTEYYVSLLSRSKLSPLIVSGWSFGGIVAFEAAQQLMANGFEVKGLILIDSPNPIDHEPLPNEVIANIIKSSGQTHALNNNAALREEFQFHASLLGSYKAVSFSKTNRLRLKTVMLRSQNVFDTESLCGVRYDWLSNQDARAAAIVAWEGLVGGYVKVLPIPGNHFEAFSQKN",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 1339,
    "end": 4744,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 7942,
    "product": "T1PKS",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "T1PKS",
  "products": [
   "T1PKS"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS T1PKS",
  "anchor": "r421c1"
 },
 "r531c1": {
  "start": 1,
  "end": 5227,
  "idx": 1,
  "orfs": [
   {
    "start": 38,
    "end": 977,
    "strand": -1,
    "locus_tag": "MARS55BIN28_004872",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004872</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004872</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004872-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38 - 977,\n (total: 940 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) terpene: fung_ggpps<br>\n \n  biosynthetic-additional (smcogs) SMCOG1182:Polyprenyl synthetase (Score: 233.3; E-value: 5.5e-71)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004872 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF00348.20 (Polyprenyl synthetase): [42:281](score: 223.8, e-value: 2e-66)<br>\n \n </div><br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\">Gene Ontology terms for Pfam domains:</span><div class=\"collapser collapser-target-MARS55BIN28_004872 collapser-level-none\"> </div><div class=\"collapser-content\">\n  \n   PF00348.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process<br>\n  \n </div><br>\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004872\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004872-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004872\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAGAGTGAAAGGAAGGAGGAGCTGGACTTCAAAGTCAGCAAAGGCGAGGGCATGAATTTCGATAACACTCTGCGAGAGTTCTCAATTCCTCGAACATGGACCGCTCAAAATGAGCGTCGGATCATTGAGCCGTATCTCCATCTTTCTACGCAGCCCGGCAAGAACATCCGCGGGAAGCTTATTGAAGCGTTCAACGTCTGGCTCAAAGTGCCTGAAGAAAAGCTGTGTATTATCACGGATGTGATTGGATTGCTGCACACTGCGTCCTTGATGGTTGATGACGTGGAAGATAGTGCAACCTTGCGCAGAGGTGTCCCAGTGGCTCATAGTATCTTTGGTATTCCTCAAACCATAAACTCGGCAAATTACATCTACTTTTGTGCTCTGAAAGAGCTGTCATCATTAAATAATCCTGCCCTTCTACAGATATACACGGACGAGCTCATAAATCTACATCGAGGGCAGGGTATGGATCTTTATTGGAGGGATTCTTTGACGTGTCCGACCGAGGTCGAGTACCTTGACATGGTCAACTACAAAACCGGTGGGCTTTTCCGTTTAGCTATCAAATTGATGCAACAAGAGAGCAGACTAAACACAGACGCGGACTTTATACCTCTTGTATGTCTGATTGGCATTATGTTTCAAATACGGGATGATTATATGAATTTGAGCTCAGATTTCTATTGTACAAACAAAGGGTTTTGTGAGGACCTCACAGAGGGGAAGTTTTCATTTCCCATTATTCATGCAATCCGCTGGGATCCACAAAACACTCAGCTAATGAACATTCTCAAGCAGAAGTCGGCCGATGATGACATAAAGGCGTTTGCGCTTTCATACATGCGAGACACGACCCGCTCTCTGGAATATACGATGGAGACTCTTGAAAACCTAGATTCCCAGGCCCGCCAAGAAATACGGCGACTTGGAG",
    "translation": "MSESERKEELDFKVSKGEGMNFDNTLREFSIPRTWTAQNERRIIEPYLHLSTQPGKNIRGKLIEAFNVWLKVPEEKLCIITDVIGLLHTASLMVDDVEDSATLRRGVPVAHSIFGIPQTINSANYIYFCALKELSSLNNPALLQIYTDELINLHRGQGMDLYWRDSLTCPTEVEYLDMVNYKTGGLFRLAIKLMQQESRLNTDADFIPLVCLIGIMFQIRDDYMNLSSDFYCTNKGFCEDLTEGKFSFPIIHAIRWDPQNTQLMNILKQKSADDDIKAFALSYMRDTTRSLEYTMETLENLDSQARQEIRRLG",
    "product": "hypothetical protein"
   },
   {
    "start": 1092,
    "end": 1817,
    "strand": 1,
    "locus_tag": "MARS55BIN28_004873",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004873</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004873</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004873-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,092 - 1,817,\n (total: 726 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004873 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF08045.14 (Cell division control protein 14, SIN component): [0:38](score: 29.3, e-value: 4.7e-07)<br>\n \n  PF08045.14 (Cell division control protein 14, SIN component): [39:235](score: 192.1, e-value: 1.2e-56)<br>\n \n </div><br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004873\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004873\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAGAGACTGATAATTAGTGCGTTGGAAGAGCTTTCAAGCTACGATGCAAGCGCCGTAAGAAAGGGTATACGACACATCGAGGGCCTACTTGGCCAATTATGTTTGAAAGCTGGGCACGCGATACCCAGTGACGATGCTTTTCATGCCTTCCTCAGACTGCAGGACGACTTTCGCTACAACATGTGCACGCGACTCATCCCACTTCTCGAGAGGAAAGTGGATGGAAGCATGGATGCGGACGACAAGATAATAGCCTCCTGTCTGAATCTCCTCGGCGGGATATTACTTCTCCATCGGTCCAGCAGAGATCTCTTCTCCCAGCAATACAACATGCGAGCGCTGCTTGTTCTCTTGGACCACAACAACCCGTCGACCATCCAAATGCCCACCCTCCACGTGATTGTATGCGCCCTAGTGGACTCGCCTGTGAATATGCGCGTATTTGAGTTTCTCGATGGGCTGGCAACTGTCACGTCTCTCTTCAAGCACTCGAAAACAGCCCACGCAGTCAAGATCCAGCTGCTGGAGTTCATGTACTTTTACCTCATGCCGGAAGGGAAGCCGCTTTCGGAAGCGTGGTTGTCGAATAAGGGGCTTGGGCTTGAAAGTGGCACAAGGGTAAAATCAACGCAGGAGAAGAGTATCATGCTTGGGGAGTTTCTGCCAAATGTAAACTTCATGGTGCGAGACTTGGAGGAATCAGATTTCCAGCCTTTTGGGTAG",
    "translation": "MERLIISALEELSSYDASAVRKGIRHIEGLLGQLCLKAGHAIPSDDAFHAFLRLQDDFRYNMCTRLIPLLERKVDGSMDADDKIIASCLNLLGGILLLHRSSRDLFSQQYNMRALLVLLDHNNPSTIQMPTLHVIVCALVDSPVNMRVFEFLDGLATVTSLFKHSKTAHAVKIQLLEFMYFYLMPEGKPLSEAWLSNKGLGLESGTRVKSTQEKSIMLGEFLPNVNFMVRDLEESDFQPFG",
    "product": "hypothetical protein"
   },
   {
    "start": 3118,
    "end": 5224,
    "strand": 1,
    "locus_tag": "MARS55BIN28_004874",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MARS55BIN28_004874</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MARS55BIN28_004874</span><br>\n Protein ID: <span class=\"serif\">ncbi_MARS55BIN28_004874-T1</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,118 - 5,224,\n (total: 1860 nt, excluding introns)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">Pfam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  PF12710.10 (haloacid dehalogenase-like hydrolase): [59:242](score: 87.5, e-value: 1.7e-24)<br>\n \n  PF01571.24 (Aminomethyltransferase folate-binding domain): [353:604](score: 293.6, e-value: 1.2e-87)<br>\n \n </div><br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><div class=\"collapser collapser-target-MARS55BIN28_004874 collapser-level-none\"> </div><div class=\"collapser-content\">\n \n  TIGR00528 (gcvT: glycine cleavage system T protein): [349:618](score: 302.9, e-value: 6.4e-91)<br>\n \n  TIGR01489 (DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase): [57:251](score: 93.6, e-value: 3.7e-27)<br>\n \n  TIGR01488 (HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB): [58:242](score: 63.5, e-value: 5.3e-18)<br>\n \n </div><br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"MARS55BIN28_004874\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n  <a href=\"knownclusterblast/region1/ncbi_MARS55BIN28_004874-T1_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"MARS55BIN28_004874\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTAGCCACAAACAACCACACCAAGGCCGAAGCGAAAGAAGAGGCGAAAAATCTGATCAGTCCAAAGGACGAGATGACTGAAGTCACCGTTACGACCGAGGACCTTCGGGTCCCCAAATCCAGCGTGGTTAATCGCCACGGCAGATCGGCCTCGTTTGATCGCAGAGAGATTGTAATCTTTTCGGACTTTGATGGGACCATTTTCTTGCAAGATACTGGACATATTCTATTCGACGCGCATGGCTGTGGCTCTGAGCGAAGGAAGGTCCTTGATGAGCAGATCAAGTCTGGTGAACGGACTTTTCGGGAAGTCTCCGAAGAGATGTGGGGCTCTCTGAATGTGCCGTTTGAAGATGGTTTTGAAGTGATGAAGACCGCACTCGATATCGACCCTGACTTTCGTGAATTTCATCAATTCTGCGTGGACAACAAAATCCCCTTCAATGTCATCTCTGCTGGACTTAAACCCATTCTCCGTGCAGTCTTGGACGAGTTCCTCGGTAAAAAGAACAGTAAGAACATCGACATCATCTCCAACGATGCCGAAATTTCTCGGGATGGCTCTGAATGGAAGCCGGTTTGGAGGCACAACACCCCATTGGGACACGACAAGGCAGCTACCATCAAGGAGTACAGGAGTACCGCGTCCTCTGATTCTGAAGATGATCAGGGCCCTCTTATTGTCTTCATTGGAGATGGAGTGTCGGATCTTCCAGCGGCTCGGGAAGCTGACGTACTTTTCGCGAGGAAGGGTCTTCGACTGGAAGAGTATTGTCTTGAACACCGGCTACCGTACATCCCATTCGAGACGTTCAAGGATATTCAAAAGGATGTCACTCGAATTATGGCAGAGGACACACACAGCAAAAAGAGTACTGGCAAGGCCAAGTACCACAACCCACGGGCAAACTTCTGGAGACGGATGTCGTCCAAGCAAATGGTGCCCATGATTCCTGAGGGAACCGTCGCGGATATCGGTGATTATCGAAGGCAGATAGGTACATGCAAGATGATGAGACGGTACGCCACTTCTATCGAGAGCCTGTCTAAAACTCCATTATACGACTTCCATGTCGGGTATAACGGGAAGATGGTCCCATTTGCTGGGTACTCCATGCCGGTACAATATGCAAATACCAGCATTCACGATTCCCATACGTGGACACGCGCCAATGCTAGTCTATTTGATGTTTCCCATATGGTACAGCACCGTTTCTCTGGACGCCAGACGACCCAATTCTTAGAGACTATTACTCCGAGCGAGATATCAGCTTTGAAGCCATTCTCTAGCACACTGAGTGTGCTTATGAACGAATCTGGAGGCATTGTGGACGATACCGTCATATGCAGACACGACGACAATTCCTACTACATTGTCACAAACGCTGCTTGCAAAATCAAAGATCTAGCATATTTCAAGCGACATTTGACAAACTTCCAAGATGTTGAACACGAAGTTTTGGAGAATTGGGGTCTCCTGGCGCTGCAGGGCCCAAAATCTGCTCAGGTCTTGCAAGCCTTGACAGAGAAAGATCTCAGTACCGTTCATTTTGGAGAATCTACGTATGCGAAGTTGGGGGGAATGGAGGTGCACGTTGCCAGAGGTGGATATACCGGCGAGGACGGGTTTGAAATCTCCGTCCCCCCAGCACAGACGGCAGAGCTGGCGACTTTACTAATTGCGAACGAGACTGTAAAACTTGCGGGTCTTGGGGCGAGAGATACCTTGCGGTTGGAGGCGGGGATGTGTTTGTATGGGAATGATTTGGACGATACGACGAGCCCCGTCGAGGCTGGTCTTGCTTGGGTTATTAGCAAGGCTCGACGGAAAGCAGGGGGATTTATTGGCGACCAGACG",
    "translation": "MVATNNHTKAEAKEEAKNLISPKDEMTEVTVTTEDLRVPKSSVVNRHGRSASFDRREIVIFSDFDGTIFLQDTGHILFDAHGCGSERRKVLDEQIKSGERTFREVSEEMWGSLNVPFEDGFEVMKTALDIDPDFREFHQFCVDNKIPFNVISAGLKPILRAVLDEFLGKKNSKNIDIISNDAEISRDGSEWKPVWRHNTPLGHDKAATIKEYRSTASSDSEDDQGPLIVFIGDGVSDLPAAREADVLFARKGLRLEEYCLEHRLPYIPFETFKDIQKDVTRIMAEDTHSKKSTGKAKYHNPRANFWRRMSSKQMVPMIPEGTVADIGDYRRQIGTCKMMRRYATSIESLSKTPLYDFHVGYNGKMVPFAGYSMPVQYANTSIHDSHTWTRANASLFDVSHMVQHRFSGRQTTQFLETITPSEISALKPFSSTLSVLMNESGGIVDDTVICRHDDNSYYIVTNAACKIKDLAYFKRHLTNFQDVEHEVLENWGLLALQGPKSAQVLQALTEKDLSTVHFGESTYAKLGGMEVHVARGGYTGEDGFEISVPPAQTAELATLLIANETVKLAGLGARDTLRLEAGMCLYGNDLDDTTSPVEAGLAWVISKARRKAGGFIGDQT",
    "product": "hypothetical protein"
   }
  ],
  "clusters": [
   {
    "start": 37,
    "end": 977,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5227,
    "product": "terpene",
    "category": "terpene",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "terpene",
  "products": [
   "terpene"
  ],
  "product_categories": [
   "terpene"
  ],
  "cssClass": "terpene terpene",
  "anchor": "r531c1"
 }
};
var details_data = {
 "nrpspks": {
  "r317c1": {
   "id": "r317c1",
   "orfs": [
    {
     "id": "MARS55BIN28_003969",
     "sequence": "MSQLHGVSLPTDYTAQGNQIVENIYPVQIDDATREAFSQLAIADGSKAHSPFTLLLSAAAILIYRLTGDDNACISSDGRLLKVVIKSETTFLDHTNGIEENYSHCEISDSLARVSLSQDTKKNVLANDLSIFVAGHQDDLPGRRPSAPILGMTVTVHYNQLLFSRERVHVIMRQLLSLVRSGVANPYAAIGSMPLSNNSEKDILPDPTSDLHWEKFGGPIHEIFARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQIIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIRGFRIELGEIDTYLSRHDAIRENVTLLRRDKDEEPTLVSYIVGTDESLRKFAMSSTSNNLKEVLQSHILLIRELKEFLKSKLPSYAVPTVIVPLSRMPLNPNGKIDKPKLPFPDTAELMSLGDVREGKGLTEVQARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEIDSLRSGFGGRELNTYKPETNGHSSQLNYAGDAIDISSRLATSYKSPNISASSSTTVFLTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEVDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCAAGKAKSVTFVSTTSVLDCEYYTELSDRILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYMIREAGKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVIVSASIHQRKELHVAQITGRPRLRFVDFLGSLRSFGYAVTNVDYITWRSNLERSVLENPADNALYPLLHFVLDNLPASTKAPELDDSTTVEILKADGADASQGMGIGVHQIGLYLAYLVAIGFLPPPNLKGIHQLPVANLPDDIKTKLSTIGGRGGNKIESG",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 223,
       "end": 688,
       "predictions": [
        [
         "substrate consensus",
         "Aad"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FARNAKNHPERPCVIETPKPGHLHEGTKTYTYQQLHHASSVLAHYLISEGISRNNVVMIYAYRGVDLVVAVMGTLKAGATFSVIDPSYPPERQIIYLGVAQPRALIVLEKAGSLDVLVKDYVEKNLSLLAQVTSLQLNPKGLYGLNIGATENVFSKFFKMKDEDTGVVVGPDSTPTLSFTSGSEGIPKGVSGRHFSLTYYFPWMAKKFNLSSEDNFTMLSGIAHDPIQRDIFTPLFLGAKLIVPTAEDIATPGRLAEWMDENRATVTHLTPAMGQLLSAQANHSIPTLHHAFFVGDVLTKRDCSRLQSLARNVNIINMYGTTETQRAVSYFEVPSVNVDSVFLESQKDIIPAGQGMIDVQLLVVNRNDRRLTCGIGELGELYVRAGGLAEGYLDQHSLTSEKFVKNWFMDEEAWTSTKTVPKSIPWTEFWQGPRDRLYRTGDLGRFLPSGQVECSGRADSQVKIR",
       "dna_sequence": "TTTGCTAGAAATGCAAAGAATCACCCGGAAAGGCCATGTGTAATCGAGACACCAAAGCCCGGTCATCTTCATGAAGGAACGAAAACATACACTTACCAACAACTGCACCATGCGTCTAGTGTGTTGGCCCATTATCTTATTTCAGAAGGCATTTCTCGAAATAATGTCGTTATGATCTACGCTTACAGAGGTGTCGATCTTGTTGTGGCTGTTATGGGAACTCTCAAGGCTGGGGCAACCTTCTCAGTGATTGATCCGTCGTATCCCCCTGAGAGACAGATTATTTATCTTGGAGTGGCTCAGCCTCGTGCTTTGATAGTGCTTGAAAAAGCTGGCTCGTTAGATGTTCTCGTTAAGGACTACGTTGAGAAAAACTTATCATTACTAGCACAAGTCACGTCCCTGCAATTGAATCCAAAAGGCCTCTATGGATTAAACATCGGTGCTACAGAGAATGTGTTTAGCAAATTCTTCAAGATGAAAGACGAAGATACCGGAGTTGTTGTTGGTCCAGATTCCACGCCGACTCTTAGTTTTACCAGTGGTAGTGAGGGCATTCCTAAAGGCGTGAGCGGGCGGCACTTTTCACTTACATATTATTTCCCATGGATGGCAAAAAAGTTCAATCTCTCTAGCGAGGACAATTTTACAATGTTGAGCGGAATTGCACACGACCCTATCCAAAGGGACATCTTCACACCTCTATTTCTTGGTGCAAAACTTATTGTGCCGACGGCGGAAGATATCGCCACACCCGGGAGGTTGGCTGAGTGGATGGATGAAAATAGAGCAACTGTTACTCACCTCACCCCAGCAATGGGCCAATTGCTTTCTGCACAAGCAAATCATTCAATTCCTACACTGCATCACGCTTTCTTTGTAGGAGACGTGCTTACCAAACGGGACTGTAGTCGACTACAAAGTCTTGCTCGAAATGTCAATATTATCAACATGTATGGGACTACCGAAACTCAGAGAGCGGTATCGTACTTTGAAGTCCCATCTGTCAATGTAGATTCAGTGTTTCTGGAATCACAGAAAGATATAATTCCAGCTGGTCAAGGCATGATTGATGTTCAATTATTAGTCGTCAATAGAAATGATCGAAGACTGACATGTGGTATTGGAGAGCTGGGTGAACTATACGTTCGAGCTGGAGGACTTGCAGAAGGGTATTTAGACCAGCATTCCCTTACAAGTGAAAAGTTTGTCAAAAATTGGTTTATGGATGAGGAGGCATGGACTTCAACAAAAACTGTTCCCAAAAGTATACCGTGGACTGAGTTCTGGCAAGGACCGAGAGACAGGTTATATCGTACTGGTGATCTTGGGCGATTCCTCCCGAGTGGACAAGTCGAATGTAGCGGACGTGCAGACTCACAAGTCAAAATACGT",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 821,
       "end": 888,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ARLFTLWTSLLSIPGDFTIDDSFFDLGGHSILATRMIFEIRKEFRMDVPIGIVFQNPSIRSLSDEID",
       "dna_sequence": "GCTCGCTTATTTACTTTATGGACCAGTCTACTCTCTATTCCTGGTGACTTTACAATTGATGATAGCTTTTTCGACTTGGGTGGGCATTCAATTCTTGCTACACGCATGATCTTTGAGATACGTAAAGAATTTCGAATGGATGTGCCCATTGGCATAGTCTTTCAAAACCCGTCAATTAGATCCTTGAGTGATGAAATTGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "NAD_binding_4",
       "start": 944,
       "end": 1194,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LTGVTGFVGSFVLQDLLSRSTSKVRVIAHVRAKSQKDALSRIKTSCEAYRVWDDSWSAKIETVCGVLDKPRLGLPDDTWRRLIDEVDVVIHNGAQVHWVYPYAKLRATNVLSTAAILEMCAAGKAKSVTFVSTTSVLDCEYYTELSDRILSKGGSGVLESDDLSGSKNGLSTGYGQSKWAAEYMIREAGKRGLTGCIVRPGYILGNSTTGSTNTDDFLIRMIKGCIQISQVPEIYNTVNIAPVDLVAKVI",
       "dna_sequence": "CTTACAGGAGTCACAGGATTTGTAGGAAGTTTTGTGCTCCAAGACCTTCTTTCACGTTCAACATCAAAGGTCCGAGTAATTGCGCATGTCCGTGCGAAATCTCAAAAAGACGCACTTTCCCGCATCAAAACAAGTTGCGAAGCATATCGAGTATGGGATGATAGCTGGTCTGCAAAAATAGAGACTGTCTGTGGGGTACTAGACAAACCACGACTTGGACTTCCCGACGACACATGGCGTAGACTCATTGATGAAGTCGACGTCGTAATTCACAACGGGGCCCAAGTTCATTGGGTATATCCGTACGCTAAATTACGAGCCACCAATGTGTTGAGCACCGCAGCCATACTGGAAATGTGTGCTGCTGGCAAAGCCAAAAGCGTGACATTTGTCTCGACAACGTCAGTTCTCGACTGCGAATACTATACAGAGCTCTCCGACAGAATTTTGTCCAAAGGCGGGAGCGGAGTTCTCGAAAGCGATGATCTCTCAGGATCAAAGAATGGGTTGAGTACTGGATATGGTCAAAGCAAATGGGCCGCAGAATATATGATCCGTGAAGCTGGCAAGCGAGGCCTGACTGGTTGTATTGTCCGTCCCGGCTACATACTTGGCAATTCTACCACCGGAAGCACAAACACTGATGATTTTTTGATACGGATGATCAAAGGCTGCATTCAGATAAGCCAGGTGCCGGAAATCTACAACACTGTGAATATCGCCCCCGTGGATCTTGTAGCTAAAGTTATT",
       "abbreviation": "NAD",
       "html_class": "jsdomain-other"
      }
     ],
     "modules": [
      {
       "start": 223,
       "end": 1194,
       "complete": true,
       "iterative": false,
       "monomer": "Aad",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r421c1": {
   "id": "r421c1",
   "orfs": [
    {
     "id": "MARS55BIN28_004502",
     "sequence": "MPALTEHCLVLFGGQGSPSIFSPSAAATAEEDARSASAGSILLSRCHAAFLQEIASLDARSQHLLAIDPALFSFPRDLLKPVAQYHTHAVLQATTIYLCQLLHYLAETQRIDGPFEDSFDRLRETAGFSSGLLPATVVARSRSLDDFVTSGIEGFRLAFWIACRSLFWSLNPNASDPVGDGVDSEATSSLVIRGLSPSQVEERLLQHFAAQGPGPLSQQPPRRLQVSTISNSSVVSVSGPRVDLSAFRVQAVPDLATTFAHVHGWYHGGDQLEGVVHEVLEDLRRRAVSFPSFSTLTKPIRSTFDGTLFDASNTDAPELLGWLVRHLLLHCVNWSDTAHEIAASVRALLEREPATVVKLLSFGPGSGSLFPNFQPLDPRIELLDLSPFRASRKSRLSCNHQDSIAIVGLSVHLPKGNGTEELWETLSQGLNAVQEIPESRFKVSDYYSEEDSHKPRSMPTKHGAFLDDPFSFDNAYFNISPREAKSMDPQQRILLHAAQEAFEDAGYVGDSSPSFQRASIGCYIGLATGDYTDNLRNDIDVFYPPGTLRAFHSGRISYFYGLSGPSIVTDTACSSSIVSVYQACRALQRGDCTAAIAGGANVISSPDPEATSSVQPEAANPSMQQLTDIVGLKGVFSLFSNDCLMLSRKTITYTALSGTQTQIDLFQRLLQQTNVDPGSIGVVEAHGTGTQAGDAREIESLQTIFGPHHSMVNPLVVSSIKGNNIGHCESASGAAGLAKLLLMLREKIIPVQVGFKDVNPRFADLESSGFIIPRQTTAWIHSQRAPRRAMLNNFGAAGSNTSLLLEEWVEPPNTQPRHQERSAYVFALSAKSKTALQTAVHRHLRFLGKVDRRPSLKDICYTATARRQIHDHRISVVCTTIDDLRTRLEHCKAVNSIPAQGISATVFVFSGQGGLYHGMGEELKYTFPLFKEVIMSCDGIIQGLGYPSILSILCKDRGGVKALDGAEQFIASQCACVALEYALAKMFMLWGIMPEYVMGHRYFSTPEVFIY",
     "domains": [
      {
       "type": "SAT",
       "start": 39,
       "end": 267,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SILLSRCHAAFLQEIASLDARSQHLLAIDPALFSFPRDLLKPVAQYHTHAVLQATTIYLCQLLHYLAETQRIDGPFEDSFDRLRETAGFSSGLLPATVVARSRSLDDFVTSGIEGFRLAFWIACRSLFWSLNPNASDPVGDGVDSEATSSLVIRGLSPSQVEERLLQHFAAQGPGPLSQQPPRRLQVSTISNSSVVSVSGPRVDLSAFRVQAVPDLATTFAHVHGWYH",
       "dna_sequence": "AGCATCCTTCTGTCGAGGTGCCATGCGGCTTTCTTGCAAGAGATAGCGAGTCTAGACGCCCGCTCGCAACATCTTCTCGCCATCGATCCCGCCCTGTTCTCCTTCCCACGTGACTTGCTCAAGCCGGTCGCACAATATCACACACACGCAGTGCTCCAGGCGACCACCATCTACCTCTGCCAGCTGCTACATTATCTGGCTGAGACACAGCGTATCGACGGACCATTCGAGGACTCGTTTGACCGACTTCGAGAGACAGCGGGCTTCTCTTCGGGTTTGCTCCCGGCTACGGTAGTTGCACGCTCGCGCAGCTTGGACGACTTTGTGACATCTGGAATCGAAGGGTTCCGCCTTGCCTTTTGGATTGCATGTCGCAGTCTCTTCTGGAGCCTCAACCCCAATGCAAGCGACCCCGTTGGCGATGGCGTCGACTCAGAAGCGACATCGTCCCTTGTGATTCGTGGTCTTTCCCCAAGCCAGGTCGAAGAGAGATTATTACAGCACTTCGCGGCGCAGGGGCCGGGCCCTTTATCCCAGCAACCGCCTCGACGACTCCAGGTATCTACCATCTCCAATTCTAGTGTTGTGTCTGTATCTGGCCCTAGAGTGGATCTCAGTGCGTTCAGGGTGCAGGCTGTCCCCGATCTTGCAACAACCTTCGCGCATGTACATGGATGGTATCAT",
       "abbreviation": "SAT",
       "html_class": "jsdomain-other"
      },
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 403,
       "end": 807,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "IAIVGLSVHLPKGNGTEELWETLSQGLNAVQEIPESRFKVSDYYSEEDSHKPRSMPTKHGAFLDDPFSFDNAYFNISPREAKSMDPQQRILLHAAQEAFEDAGYVGDSSPSFQRASIGCYIGLATGDYTDNLRNDIDVFYPPGTLRAFHSGRISYFYGLSGPSIVTDTACSSSIVSVYQACRALQRGDCTAAIAGGANVISSPDPEATSSVQPEAANPSMQQLTDIVGLKGVFSLFSNDCLMLSRKTITYTALSGTQTQIDLFQRLLQQTNVDPGSIGVVEAHGTGTQAGDAREIESLQTIFGPHHSMVNPLVVSSIKGNNIGHCESASGAAGLAKLLLMLREKIIPVQVGFKDVNPRFADLESSGFIIPRQTTAWIHSQRAPRRAMLNNFGAAGSNTSLLLEE",
       "dna_sequence": "ATCGCCATTGTTGGGCTGAGCGTGCATCTCCCCAAAGGGAATGGCACCGAAGAGCTATGGGAAACGCTGTCCCAAGGGTTGAATGCCGTGCAAGAGATCCCTGAGTCCAGGTTCAAAGTCTCGGACTATTATTCAGAGGAGGATTCGCATAAGCCGCGCTCGATGCCCACGAAGCACGGCGCATTCCTGGACGATCCCTTCTCCTTTGATAATGCCTATTTCAATATTTCCCCTCGAGAAGCAAAATCTATGGATCCTCAGCAGCGAATTTTATTGCATGCAGCCCAGGAAGCCTTTGAAGATGCTGGCTATGTAGGGGATTCATCACCATCTTTCCAAAGAGCTTCCATCGGATGCTACATTGGCCTTGCTACTGGGGATTACACAGACAACCTTCGCAATGATATTGATGTCTTCTACCCCCCCGGGACACTACGAGCATTTCATAGTGGAAGGATATCTTACTTTTATGGGCTCAGTGGCCCATCCATTGTGACTGATACTGCATGTTCGTCCTCAATTGTCTCCGTGTACCAGGCATGCCGAGCCCTACAACGTGGCGATTGCACAGCAGCTATCGCGGGCGGCGCCAATGTGATTTCCAGCCCCGATCCCGAGGCCACTTCCTCAGTCCAACCGGAGGCTGCAAACCCTTCGATGCAGCAGCTGACGGATATTGTCGGGCTGAAGGGTGTGTTCTCTTTGTTCTCAAACGATTGTCTGATGCTATCGCGGAAAACGATCACATACACGGCGTTATCAGGAACTCAAACACAAATCGACCTGTTCCAGCGACTGCTCCAACAAACGAATGTCGATCCTGGATCCATTGGTGTCGTAGAAGCACACGGGACAGGCACACAGGCCGGAGATGCACGCGAAATTGAAAGCTTGCAAACTATCTTTGGCCCACATCACTCAATGGTGAACCCCCTTGTGGTCAGTTCTATCAAGGGTAATAACATAGGCCATTGTGAATCCGCGTCTGGAGCAGCTGGTTTGGCTAAATTATTGCTCATGCTTCGCGAGAAAATAATCCCAGTACAAGTCGGATTTAAGGACGTCAATCCACGTTTCGCGGACCTGGAAAGCTCTGGCTTCATTATACCAAGGCAGACTACAGCATGGATCCACTCGCAAAGAGCCCCAAGGAGAGCTATGCTGAATAATTTCGGGGCTGCTGGCTCAAATACGTCTCTCCTCCTAGAAGAG",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "MARS55BIN28_004503",
     "sequence": "MTDNCVANASGMLACKLSPEKAEELILENSGVSQLTVACLNGIGDCVVGGPLGQIDIFQKDCKTRKIKVKLMDVAYAFHSPAMDPILEPLQALGRSIRFARPTIPVISNVFGRLFEEEDFSSDYFALHARQPVRFTECLLNLQSRELLDGAVFLEIGPQPTTIPMLRSSIHSDSCTYLSTLQKGQDAWTSISLTLAAISLLKFPVNWREVFIGTSAKVIGLPGHLLEGSTYMIPYQEPRQVVNSLEQYSVELRTRTGFKLLPWLKTQASSNEEFVLETTLAILGPLITGHEVGGTSICPASVFHELALEGAHTMLEPHEGQLLVVTGMSFTSPLIYVPSQEADVVTVYITKYDLASGADFKITSCSTKDLTENINCTGSVSLQNFQINASHWIKDAAIVTRQSHYFSGVGKSYISTFRTKVLYEAIFTRVVRYSPEYQSLVYLSVTNSNLEGIGSFKLPSSSQTGYLAPPVFTDTLLHAAGFIANLAVRSDEVGICARVESVEISYRDIDYADSFTVYCSLLEIKGAILADAIALNAFGKVVAVVRDMEFKRLQLSAFQQVLSRKSTAIEPRNFPVEQKKPQLSTGLDTPPTSGEVIDTPIESRGSLPHDVRIALKNIVMEFGGFSEQDMDYTNSLDELGIHSLMQIEIISKLIRTFPGQAGLDHHALSECETLESLESTLASILQSSVEITSLVGAPISASQRDSRQSTLVPSDFSSSDGMQKNPVALHVSHEEVAPLCLFHDGSGQVSMYARLRDHDRSAYAFFDPHFGSDKRPHSSINQMTEYYVSLLSRSKLSPLIVSGWSFGGIVAFEAAQQLMANGFEVKGLILIDSPNPIDHEPLPNEVIANIIKSSGQTHALNNNAALREEFQFHASLLGSYKAVSFSKTNRLRLKTVMLRSQNVFDTESLCGVRYDWLSNQDARAAAIVAWEGLVGGYVKVLPIPGNHFEAFSQKN",
     "domains": [
      {
       "type": "PKS_AT",
       "start": 8,
       "end": 183,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "(unknown)"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "ASGMLACKLSPEKAEELILENSGVSQLTVACLNGIGDCVVGGPLGQIDIFQKDCKTRKIKVKLMDVAYAFHSPAMDPILEPLQALGRSIRFARPTIPVISNVFGRLFEEEDFSSDYFALHARQPVRFTECLLNLQSRELLDGAVFLEIGPQPTTIPMLRSSIHSDSCTYLSTLQK",
       "dna_sequence": "GCGTCTGGGATGCTGGCGTGCAAGTTATCCCCCGAAAAGGCCGAGGAATTGATATTGGAAAACTCGGGCGTGTCCCAGCTGACCGTGGCATGCCTGAATGGCATTGGTGACTGTGTCGTTGGTGGACCGCTGGGCCAAATCGATATATTTCAGAAGGATTGCAAGACCCGGAAGATCAAGGTGAAGTTGATGGACGTCGCCTACGCCTTCCACTCACCAGCTATGGATCCAATCCTGGAACCCCTGCAAGCCCTGGGGCGCTCAATCAGGTTCGCACGACCTACGATTCCCGTCATCTCTAATGTGTTTGGGCGATTATTTGAAGAGGAAGACTTTTCTAGTGACTACTTCGCGCTTCACGCGAGGCAGCCAGTGCGCTTTACCGAATGTCTGCTTAATTTACAATCAAGAGAACTGCTCGACGGTGCTGTCTTCCTTGAGATAGGCCCACAACCTACAACAATACCAATGCTACGGAGCTCGATTCATTCAGACTCTTGTACCTACCTTAGTACCTTACAAAAG",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PT",
       "start": 266,
       "end": 563,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "QASSNEEFVLETTLAILGPLITGHEVGGTSICPASVFHELALEGAHTMLEPHEGQLLVVTGMSFTSPLIYVPSQEADVVTVYITKYDLASGADFKITSCSTKDLTENINCTGSVSLQNFQINASHWIKDAAIVTRQSHYFSGVGKSYISTFRTKVLYEAIFTRVVRYSPEYQSLVYLSVTNSNLEGIGSFKLPSSSQTGYLAPPVFTDTLLHAAGFIANLAVRSDEVGICARVESVEISYRDIDYADSFTVYCSLLEIKGAILADAIALNAFGKVVAVVRDMEFKRLQLSAFQQVLS",
       "dna_sequence": "CAGGCGTCTTCGAACGAGGAATTTGTGCTTGAGACAACATTAGCAATTCTTGGGCCATTGATCACAGGGCATGAGGTTGGCGGGACTTCCATCTGCCCAGCGTCAGTATTCCATGAGCTCGCCTTGGAAGGAGCACACACTATGCTTGAGCCTCACGAGGGCCAACTATTGGTCGTCACCGGGATGAGCTTTACCAGTCCACTAATATATGTACCGTCACAGGAAGCAGATGTTGTGACTGTGTACATCACAAAATATGATTTAGCTTCCGGGGCAGACTTTAAAATTACCTCATGCTCGACCAAAGATCTTACGGAGAATATAAACTGTACCGGTAGTGTCTCCCTGCAAAACTTCCAGATCAACGCATCCCACTGGATAAAGGATGCGGCAATTGTGACGAGGCAAAGTCATTACTTCTCTGGTGTCGGGAAAAGTTACATCAGTACTTTCCGAACTAAAGTCCTTTATGAGGCTATCTTTACACGTGTTGTCAGGTATTCCCCAGAGTACCAAAGCTTGGTGTATTTGAGTGTGACCAACTCCAATCTCGAAGGTATTGGCTCGTTCAAACTACCGTCTAGTTCTCAGACCGGTTACCTTGCACCCCCTGTCTTTACAGACACACTTCTGCATGCTGCAGGTTTCATTGCAAATCTTGCTGTAAGGTCCGACGAAGTAGGCATTTGCGCCCGCGTCGAGTCGGTCGAGATATCTTACCGTGATATCGATTACGCGGATTCTTTCACAGTTTACTGCAGCTTGCTCGAAATCAAAGGTGCAATTCTAGCAGACGCAATTGCCTTGAATGCTTTCGGGAAAGTCGTCGCCGTCGTTCGGGACATGGAATTTAAAAGACTCCAATTGTCTGCTTTCCAGCAAGTGTTGTCT",
       "abbreviation": "PT",
       "html_class": "jsdomain-other"
      },
      {
       "type": "PP-binding",
       "start": 614,
       "end": 678,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "LKNIVMEFGGFSEQDMDYTNSLDELGIHSLMQIEIISKLIRTFPGQAGLDHHALSECETLESLE",
       "dna_sequence": "CTGAAGAATATCGTCATGGAATTTGGTGGTTTCTCCGAGCAAGATATGGATTACACGAATTCACTAGATGAACTTGGGATCCATTCTCTTATGCAAATTGAGATTATCTCGAAACTGATACGCACATTTCCCGGTCAAGCTGGGCTGGACCACCATGCTTTGTCAGAATGCGAAACTCTCGAGTCCTTGGAA",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "Thioesterase",
       "start": 737,
       "end": 952,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "PLCLFHDGSGQVSMYARLRDHDRSAYAFFDPHFGSDKRPHSSINQMTEYYVSLLSRSKLSPLIVSGWSFGGIVAFEAAQQLMANGFEVKGLILIDSPNPIDHEPLPNEVIANIIKSSGQTHALNNNAALREEFQFHASLLGSYKAVSFSKTNRLRLKTVMLRSQNVFDTESLCGVRYDWLSNQDARAAAIVAWEGLVGGYVKVLPIPGNHFEAFS",
       "dna_sequence": "CCGCTCTGCCTATTTCATGACGGGAGTGGGCAGGTCAGCATGTATGCACGGCTGCGTGATCACGACCGCAGTGCATACGCCTTCTTCGACCCGCATTTTGGGAGTGACAAGCGACCTCACAGCAGCATAAATCAGATGACCGAGTACTATGTCTCGCTCCTCTCAAGATCTAAACTATCTCCCTTGATAGTGAGTGGTTGGTCTTTTGGCGGAATAGTGGCCTTCGAGGCGGCTCAACAGCTCATGGCCAATGGATTCGAGGTAAAGGGCCTCATATTGATCGACTCTCCAAATCCCATTGATCACGAACCTCTTCCGAATGAAGTCATTGCCAACATTATCAAATCGAGCGGTCAGACTCATGCGTTGAACAACAATGCTGCACTAAGGGAAGAATTCCAATTCCACGCATCTCTACTAGGAAGTTACAAGGCAGTATCCTTTTCCAAAACGAATAGACTGAGACTGAAGACGGTCATGTTGAGAAGCCAGAACGTCTTCGATACTGAAAGTCTTTGCGGGGTTCGCTATGACTGGCTCAGTAACCAGGATGCTCGAGCTGCTGCTATCGTCGCCTGGGAAGGATTGGTCGGTGGTTATGTCAAGGTTCTGCCAATCCCTGGAAACCATTTCGAGGCCTTCTCA",
       "abbreviation": "TE",
       "html_class": "jsdomain-terminal"
      }
     ],
     "modules": [
      {
       "start": 8,
       "end": 952,
       "complete": true,
       "iterative": false,
       "monomer": "mal",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  }
 }
};
var resultsData = {
 "r44c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS55BIN28_001118",
         "subject": "gene2",
         "query_loc": 25021,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_001118"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS55BIN28_001118",
         "subject": "mfR6",
         "query_loc": 25021,
         "subject_loc": 67091
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_001118"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001156: 94-35670": {
       "start": 94,
       "end": 35670,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ADD83005.1",
         "query_loc": 34095,
         "subject_loc": 26454
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ADD82990.1",
         "start": 1496,
         "end": 2801,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82991.1",
         "start": 5114,
         "end": 6683,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82992.1",
         "start": 30609,
         "end": 32190,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82993.1",
         "start": 19021,
         "end": 19855,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82994.1",
         "start": 19907,
         "end": 21014,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82995.1",
         "start": 21019,
         "end": 22210,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82996.1",
         "start": 22288,
         "end": 23164,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82997.1",
         "start": 3955,
         "end": 5113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82998.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82999.1",
         "start": 14739,
         "end": 16086,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83000.1",
         "start": 16093,
         "end": 17194,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83001.1",
         "start": 17180,
         "end": 18944,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83002.1",
         "start": 94,
         "end": 859,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83003.1",
         "start": 9718,
         "end": 11044,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83004.1",
         "start": 12783,
         "end": 13626,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83005.1",
         "start": 26001,
         "end": 26907,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ADD83006.1",
         "start": 27947,
         "end": 28784,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83007.1",
         "start": 35334,
         "end": 35670,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83008.1",
         "start": 23245,
         "end": 24670,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83009.1",
         "start": 24742,
         "end": 25987,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83010.1",
         "start": 32357,
         "end": 33572,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83011.1",
         "start": 33689,
         "end": 35312,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ADD83012.1",
         "start": 26939,
         "end": 27656,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ADD83013.1",
         "start": 3554,
         "end": 3956,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83014.1",
         "start": 8795,
         "end": 9722,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83015.1",
         "start": 11043,
         "end": 12645,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83016.1",
         "start": 13693,
         "end": 14740,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83017.1",
         "start": 855,
         "end": 1419,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83018.1",
         "start": 2797,
         "end": 3508,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83019.1",
         "start": 6711,
         "end": 7782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83020.1",
         "start": 28780,
         "end": 30571,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ABC42561.1",
         "query_loc": 34095,
         "subject_loc": 27217
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001140: 97-41076": {
       "start": 97,
       "end": 41076,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ACO31293.1",
         "query_loc": 34095,
         "subject_loc": 31856
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACO31265.1",
         "start": 97,
         "end": 862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31266.1",
         "start": 858,
         "end": 1413,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31267.1",
         "start": 1499,
         "end": 2804,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31268.1",
         "start": 2800,
         "end": 3511,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31269.1",
         "start": 3556,
         "end": 3958,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31270.1",
         "start": 3957,
         "end": 5115,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31271.1",
         "start": 5116,
         "end": 6685,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31272.1",
         "start": 6713,
         "end": 7796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31273.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31274.1",
         "start": 8796,
         "end": 9723,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31275.1",
         "start": 9719,
         "end": 11042,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31276.1",
         "start": 11041,
         "end": 12643,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31277.1",
         "start": 12780,
         "end": 13638,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31278.1",
         "start": 13637,
         "end": 14804,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31279.1",
         "start": 14800,
         "end": 15730,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31280.1",
         "start": 15770,
         "end": 17063,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31281.1",
         "start": 17059,
         "end": 18127,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31282.1",
         "start": 18214,
         "end": 19057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31283.1",
         "start": 19113,
         "end": 20160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31284.1",
         "start": 20159,
         "end": 21506,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31285.1",
         "start": 21513,
         "end": 22614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31286.1",
         "start": 22600,
         "end": 24364,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31287.1",
         "start": 24441,
         "end": 25275,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31288.1",
         "start": 25326,
         "end": 26433,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31289.1",
         "start": 26438,
         "end": 27629,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31290.1",
         "start": 27687,
         "end": 28563,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31291.1",
         "start": 28648,
         "end": 30073,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31292.1",
         "start": 30144,
         "end": 31389,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31293.1",
         "start": 31403,
         "end": 32309,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ACO31294.1",
         "start": 32341,
         "end": 33058,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ACO31295.1",
         "start": 33349,
         "end": 34186,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31296.1",
         "start": 34182,
         "end": 35973,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31297.1",
         "start": 36011,
         "end": 37595,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13710.1",
         "start": 37762,
         "end": 38977,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13711.1",
         "start": 39094,
         "end": 40717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACS13712.1",
         "start": 40740,
         "end": 41076,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001839: 5117-20679": {
       "start": 5117,
       "end": 20679,
       "links": [
        {
         "query": "MARS55BIN28_001118",
         "subject": "gene2",
         "query_loc": 25021,
         "subject_loc": 10607
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "gene1",
         "start": 5117,
         "end": 6268,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene2",
         "start": 10000,
         "end": 11215,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_001118"
         }
        },
        {
         "locus_tag": "gene3",
         "start": 11974,
         "end": 13637,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene4",
         "start": 14641,
         "end": 15445,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "gene5",
         "start": 18605,
         "end": 20679,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001339: 45-69577": {
       "start": 45,
       "end": 69577,
       "links": [
        {
         "query": "MARS55BIN28_001118",
         "subject": "mfR6",
         "query_loc": 25021,
         "subject_loc": 67091
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "mfL1",
         "start": 8713,
         "end": 12825,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfL2",
         "start": 5097,
         "end": 6941,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfL3",
         "start": 45,
         "end": 4089,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM1",
         "start": 23903,
         "end": 25116,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM10",
         "start": 46181,
         "end": 48142,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM2",
         "start": 25935,
         "end": 27732,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM3",
         "start": 28230,
         "end": 29304,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM4",
         "start": 30143,
         "end": 31634,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM5",
         "start": 34453,
         "end": 34834,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM6",
         "start": 37169,
         "end": 39091,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfM7",
         "start": 40065,
         "end": 42358,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfM8",
         "start": 42511,
         "end": 43583,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfM9",
         "start": 44064,
         "end": 45803,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR1",
         "start": 57583,
         "end": 58709,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR2",
         "start": 59111,
         "end": 59993,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR3",
         "start": 60270,
         "end": 61886,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mfR4",
         "start": 62499,
         "end": 63906,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfR5",
         "start": 64257,
         "end": 66006,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "mfR6",
         "start": 66435,
         "end": 67748,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_001118"
         }
        },
        {
         "locus_tag": "mfR7",
         "start": 68573,
         "end": 69577,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "mfpks1",
         "start": 15079,
         "end": 23393,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mfpks2",
         "start": 48805,
         "end": 56980,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0001156: 94-35670": {
       "start": 94,
       "end": 35670,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ADD83005.1",
         "query_loc": 34095,
         "subject_loc": 26454
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ADD82990.1",
         "start": 1496,
         "end": 2801,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82991.1",
         "start": 5114,
         "end": 6683,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82992.1",
         "start": 30609,
         "end": 32190,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD82993.1",
         "start": 19021,
         "end": 19855,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82994.1",
         "start": 19907,
         "end": 21014,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82995.1",
         "start": 21019,
         "end": 22210,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82996.1",
         "start": 22288,
         "end": 23164,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82997.1",
         "start": 3955,
         "end": 5113,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82998.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD82999.1",
         "start": 14739,
         "end": 16086,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83000.1",
         "start": 16093,
         "end": 17194,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83001.1",
         "start": 17180,
         "end": 18944,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83002.1",
         "start": 94,
         "end": 859,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83003.1",
         "start": 9718,
         "end": 11044,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83004.1",
         "start": 12783,
         "end": 13626,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83005.1",
         "start": 26001,
         "end": 26907,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ADD83006.1",
         "start": 27947,
         "end": 28784,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83007.1",
         "start": 35334,
         "end": 35670,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83008.1",
         "start": 23245,
         "end": 24670,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83009.1",
         "start": 24742,
         "end": 25987,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83010.1",
         "start": 32357,
         "end": 33572,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83011.1",
         "start": 33689,
         "end": 35312,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ADD83012.1",
         "start": 26939,
         "end": 27656,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ADD83013.1",
         "start": 3554,
         "end": 3956,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83014.1",
         "start": 8795,
         "end": 9722,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83015.1",
         "start": 11043,
         "end": 12645,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83016.1",
         "start": 13693,
         "end": 14740,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ADD83017.1",
         "start": 855,
         "end": 1419,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83018.1",
         "start": 2797,
         "end": 3508,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83019.1",
         "start": 6711,
         "end": 7782,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ADD83020.1",
         "start": 28780,
         "end": 30571,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0000698: 2269-33779": {
       "start": 2269,
       "end": 33779,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ABC42561.1",
         "query_loc": 34095,
         "subject_loc": 27217
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ABC42538.1",
         "start": 2269,
         "end": 3397,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ABC42539.1",
         "start": 3716,
         "end": 4916,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42540.1",
         "start": 5307,
         "end": 6279,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42541.1",
         "start": 6451,
         "end": 6973,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42542.1",
         "start": 7010,
         "end": 8069,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42543.1",
         "start": 8341,
         "end": 9091,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42544.1",
         "start": 9083,
         "end": 10823,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42545.1",
         "start": 10910,
         "end": 12146,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42546.1",
         "start": 12148,
         "end": 12400,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42547.1",
         "start": 12396,
         "end": 13533,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42548.1",
         "start": 13532,
         "end": 14291,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42549.1",
         "start": 14293,
         "end": 15649,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42550.1",
         "start": 15714,
         "end": 16005,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42551.1",
         "start": 16001,
         "end": 17045,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42552.1",
         "start": 17011,
         "end": 17782,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42553.1",
         "start": 17816,
         "end": 19112,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42554.1",
         "start": 19108,
         "end": 20101,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42555.1",
         "start": 20192,
         "end": 21284,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42556.1",
         "start": 21343,
         "end": 22594,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42557.1",
         "start": 22598,
         "end": 23714,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42558.1",
         "start": 23786,
         "end": 24338,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42559.1",
         "start": 24602,
         "end": 25778,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42560.1",
         "start": 25787,
         "end": 26765,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42561.1",
         "start": 26785,
         "end": 27649,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ABC42562.1",
         "start": 27761,
         "end": 28403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42563.1",
         "start": 28422,
         "end": 29238,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ABC42564.1",
         "start": 29700,
         "end": 30906,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ABC42565.1",
         "start": 30997,
         "end": 32710,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ABC42566.1",
         "start": 32642,
         "end": 33779,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001140: 97-41076": {
       "start": 97,
       "end": 41076,
       "links": [
        {
         "query": "MARS55BIN28_001123",
         "subject": "ACO31293.1",
         "query_loc": 34095,
         "subject_loc": 31856
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ACO31265.1",
         "start": 97,
         "end": 862,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31266.1",
         "start": 858,
         "end": 1413,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31267.1",
         "start": 1499,
         "end": 2804,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31268.1",
         "start": 2800,
         "end": 3511,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31269.1",
         "start": 3556,
         "end": 3958,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31270.1",
         "start": 3957,
         "end": 5115,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31271.1",
         "start": 5116,
         "end": 6685,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31272.1",
         "start": 6713,
         "end": 7796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31273.1",
         "start": 7877,
         "end": 8732,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31274.1",
         "start": 8796,
         "end": 9723,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31275.1",
         "start": 9719,
         "end": 11042,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31276.1",
         "start": 11041,
         "end": 12643,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31277.1",
         "start": 12780,
         "end": 13638,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31278.1",
         "start": 13637,
         "end": 14804,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31279.1",
         "start": 14800,
         "end": 15730,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31280.1",
         "start": 15770,
         "end": 17063,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31281.1",
         "start": 17059,
         "end": 18127,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31282.1",
         "start": 18214,
         "end": 19057,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31283.1",
         "start": 19113,
         "end": 20160,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31284.1",
         "start": 20159,
         "end": 21506,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31285.1",
         "start": 21513,
         "end": 22614,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31286.1",
         "start": 22600,
         "end": 24364,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31287.1",
         "start": 24441,
         "end": 25275,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31288.1",
         "start": 25326,
         "end": 26433,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31289.1",
         "start": 26438,
         "end": 27629,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31290.1",
         "start": 27687,
         "end": 28563,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ACO31291.1",
         "start": 28648,
         "end": 30073,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31292.1",
         "start": 30144,
         "end": 31389,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31293.1",
         "start": 31403,
         "end": 32309,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_001123"
         }
        },
        {
         "locus_tag": "ACO31294.1",
         "start": 32341,
         "end": 33058,
         "strand": -1,
         "function": "regulatory",
         "linked": {}
        },
        {
         "locus_tag": "ACO31295.1",
         "start": 33349,
         "end": 34186,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31296.1",
         "start": 34182,
         "end": 35973,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACO31297.1",
         "start": 36011,
         "end": 37595,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13710.1",
         "start": 37762,
         "end": 38977,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ACS13711.1",
         "start": 39094,
         "end": 40717,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ACS13712.1",
         "start": 40740,
         "end": 41076,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS55BIN28_001111": {
     "functions": []
    },
    "MARS55BIN28_001112": {
     "functions": []
    },
    "MARS55BIN28_001113": {
     "functions": []
    },
    "MARS55BIN28_001114": {
     "functions": []
    },
    "MARS55BIN28_001115": {
     "functions": []
    },
    "MARS55BIN28_001116": {
     "functions": [
      {
       "description": "SMCOG1162:threonyl-tRNA synthetase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS55BIN28_001117": {
     "functions": []
    },
    "MARS55BIN28_001118": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS55BIN28_001119": {
     "functions": [
      {
       "description": "SMCOG1173:WD-40 repeat-containing protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    },
    "MARS55BIN28_001120": {
     "functions": []
    },
    "MARS55BIN28_001121": {
     "functions": []
    },
    "MARS55BIN28_001122": {
     "functions": []
    },
    "MARS55BIN28_001123": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS55BIN28_001114",
      "seqLength": 301,
      "domains": [
       {
        "start": 1,
        "end": 110,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MOSC_N",
        "accession": "PF03476",
        "description": "MOSC N-terminal beta barrel domain",
        "evalue": "1.1e-13",
        "score": "51.3"
       },
       {
        "start": 159,
        "end": 288,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030151' target='_blank'>GO:0030151</a>: molybdenum ion binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030170' target='_blank'>GO:0030170</a>: pyridoxal phosphate binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "MOSC",
        "accession": "PF03473",
        "description": "MOSC domain",
        "evalue": "1.2e-24",
        "score": "87.1"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001115",
      "seqLength": 434,
      "domains": [
       {
        "start": 23,
        "end": 46,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00041",
        "score": "20.8"
       },
       {
        "start": 52,
        "end": 76,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "zf-C2H2",
        "accession": "PF00096",
        "description": "Zinc finger, C2H2 type",
        "evalue": "0.00088",
        "score": "19.7"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001116",
      "seqLength": 421,
      "domains": [
       {
        "start": 105,
        "end": 313,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000166' target='_blank'>GO:0000166</a>: nucleotide binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004812' target='_blank'>GO:0004812</a>: aminoacyl-tRNA ligase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006418' target='_blank'>GO:0006418</a>: tRNA aminoacylation for protein translation"
        ],
        "html_class": "generic-type-other",
        "name": "tRNA-synt_2b",
        "accession": "PF00587",
        "description": "tRNA synthetase class II core domain (G, H, P, S and T)",
        "evalue": "4.3e-35",
        "score": "121.4"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001117",
      "seqLength": 659,
      "domains": [
       {
        "start": 90,
        "end": 406,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "GCP_N_terminal",
        "accession": "PF17681",
        "description": "Gamma tubulin complex component N-terminal",
        "evalue": "1e-60",
        "score": "206.1"
       },
       {
        "start": 410,
        "end": 657,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0043015' target='_blank'>GO:0043015</a>: gamma-tubulin binding"
        ],
        "html_class": "generic-type-other",
        "name": "GCP_C_terminal",
        "accession": "PF04130",
        "description": "Gamma tubulin complex component C-terminal",
        "evalue": "2.8e-50",
        "score": "171.6"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001118",
      "seqLength": 468,
      "domains": [
       {
        "start": 65,
        "end": 356,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "3.2e-37",
        "score": "128.6"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001119",
      "seqLength": 630,
      "domains": [
       {
        "start": 124,
        "end": 159,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005515' target='_blank'>GO:0005515</a>: protein binding"
        ],
        "html_class": "generic-type-other",
        "name": "WD40",
        "accession": "PF00400",
        "description": "WD domain, G-beta repeat",
        "evalue": "8.4e-05",
        "score": "23.4"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001120",
      "seqLength": 291,
      "domains": [
       {
        "start": 133,
        "end": 257,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of DNA-templated transcription"
        ],
        "html_class": "generic-type-other",
        "name": "NOT2_3_5",
        "accession": "PF04153",
        "description": "NOT2 / NOT3 / NOT5 family",
        "evalue": "2.2e-34",
        "score": "118.5"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001121",
      "seqLength": 236,
      "domains": [
       {
        "start": 30,
        "end": 233,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006458' target='_blank'>GO:0006458</a>: 'de novo' protein folding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005783' target='_blank'>GO:0005783</a>: endoplasmic reticulum"
        ],
        "html_class": "generic-type-other",
        "name": "Rot1",
        "accession": "PF10681",
        "description": "Chaperone for protein-folding within the ER, fungal",
        "evalue": "4.8e-88",
        "score": "294.3"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001122",
      "seqLength": 390,
      "domains": [
       {
        "start": 235,
        "end": 353,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046907' target='_blank'>GO:0046907</a>: intracellular transport"
        ],
        "html_class": "generic-type-other",
        "name": "Ran_BP1",
        "accession": "PF00638",
        "description": "RanBP1 domain",
        "evalue": "3.9e-19",
        "score": "69.2"
       }
      ]
     },
     {
      "id": "MARS55BIN28_001123",
      "seqLength": 879,
      "domains": [
       {
        "start": 33,
        "end": 181,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "3.5e-31",
        "score": "108.3"
       },
       {
        "start": 299,
        "end": 482,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "adh_short",
        "accession": "PF00106",
        "description": "short chain dehydrogenase",
        "evalue": "8.7e-43",
        "score": "146.2"
       },
       {
        "start": 755,
        "end": 865,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "MaoC_dehydratas",
        "accession": "PF01575",
        "description": "MaoC like domain",
        "evalue": "6.6e-33",
        "score": "113.0"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS55BIN28_001118",
      "seqLength": 468,
      "domains": [
       {
        "start": 56,
        "end": 406,
        "name": "TIGR01559",
        "description": "squal_synth: farnesyl-diphosphate farnesyltransferase",
        "accession": "TIGR01559",
        "evalue": "2e-128",
        "score": "426.2",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r165c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78746.1",
         "query_loc": 14989,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78731.1",
         "query_loc": 14989,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78758.1",
         "query_loc": 14989,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78811.1",
         "query_loc": 14989,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "AQM37586.1",
         "query_loc": 14989,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78797.1",
         "query_loc": 14989,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78771.1",
         "query_loc": 14989,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78784.1",
         "query_loc": 14989,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0001422: 0-42748": {
       "start": 0,
       "end": 42748,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78746.1",
         "query_loc": 14989,
         "subject_loc": 38460
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78736.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78737.1",
         "start": 1338,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78738.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78739.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78740.1",
         "start": 6454,
         "end": 6931,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78741.1",
         "start": 7011,
         "end": 7827,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78746.1",
         "start": 37685,
         "end": 39236,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78747.1",
         "start": 39602,
         "end": 40772,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78748.1",
         "start": 40895,
         "end": 41372,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78749.1",
         "start": 41542,
         "end": 42748,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 8152,
         "end": 14608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14604,
         "end": 23757,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23789,
         "end": 37175,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 37171,
         "end": 37636,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001421: 0-47099": {
       "start": 0,
       "end": 47099,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78731.1",
         "query_loc": 14989,
         "subject_loc": 40302
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78723.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78724.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78725.1",
         "start": 2225,
         "end": 5828,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78726.1",
         "start": 5833,
         "end": 6370,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78731.1",
         "start": 39540,
         "end": 41064,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78732.1",
         "start": 41423,
         "end": 43526,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78733.1",
         "start": 43959,
         "end": 45150,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78734.1",
         "start": 45262,
         "end": 45739,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78735.1",
         "start": 45896,
         "end": 47099,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 6885,
         "end": 13338,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13334,
         "end": 22475,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22507,
         "end": 39013,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 39009,
         "end": 39474,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001423: 0-41128": {
       "start": 0,
       "end": 41128,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78758.1",
         "query_loc": 14989,
         "subject_loc": 34368
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78750.1",
         "start": 0,
         "end": 1266,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78751.1",
         "start": 1333,
         "end": 2215,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78752.1",
         "start": 2223,
         "end": 5826,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78753.1",
         "start": 5831,
         "end": 6368,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78758.1",
         "start": 33612,
         "end": 35124,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78759.1",
         "start": 35452,
         "end": 37555,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78760.1",
         "start": 37988,
         "end": 39179,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78761.1",
         "start": 39291,
         "end": 39768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78762.1",
         "start": 39940,
         "end": 41128,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7171,
         "end": 13627,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13623,
         "end": 22764,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22796,
         "end": 33065,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33061,
         "end": 33526,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001428: 0-44682": {
       "start": 0,
       "end": 44682,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78811.1",
         "query_loc": 14989,
         "subject_loc": 37915
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78802.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78803.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78804.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78805.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78806.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78811.1",
         "start": 37171,
         "end": 38659,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78812.1",
         "start": 38983,
         "end": 41092,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78813.1",
         "start": 41529,
         "end": 42720,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78814.1",
         "start": 42838,
         "end": 43315,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78815.1",
         "start": 43485,
         "end": 44682,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14051,
         "end": 23195,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23227,
         "end": 36622,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36618,
         "end": 37086,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001424: 0-41589": {
       "start": 0,
       "end": 41589,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "AQM37586.1",
         "query_loc": 14989,
         "subject_loc": 34794
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "AQM37577.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37578.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "AQM37579.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37580.1",
         "start": 5837,
         "end": 6374,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37581.1",
         "start": 6454,
         "end": 7270,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37586.1",
         "start": 34034,
         "end": 35555,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "AQM37587.1",
         "start": 35905,
         "end": 38014,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AQM37588.1",
         "start": 38451,
         "end": 39621,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37589.1",
         "start": 39739,
         "end": 40216,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AQM37590.1",
         "start": 40386,
         "end": 41589,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7596,
         "end": 14049,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 14045,
         "end": 23186,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 23218,
         "end": 33487,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 33483,
         "end": 33948,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001427: 0-44152": {
       "start": 0,
       "end": 44152,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78797.1",
         "query_loc": 14989,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78789.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78790.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78791.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78792.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78797.1",
         "start": 36565,
         "end": 38107,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78798.1",
         "start": 38456,
         "end": 40565,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78799.1",
         "start": 40999,
         "end": 42190,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78800.1",
         "start": 42308,
         "end": 42785,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78801.1",
         "start": 42955,
         "end": 44152,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7002,
         "end": 13482,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13478,
         "end": 22625,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22657,
         "end": 36055,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36051,
         "end": 36516,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001425: 0-44135": {
       "start": 0,
       "end": 44135,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78771.1",
         "query_loc": 14989,
         "subject_loc": 37337
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78763.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78764.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78765.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78766.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78771.1",
         "start": 36584,
         "end": 38090,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78772.1",
         "start": 38439,
         "end": 40548,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78773.1",
         "start": 40982,
         "end": 42173,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78774.1",
         "start": 42291,
         "end": 42768,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78775.1",
         "start": 42938,
         "end": 44135,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7006,
         "end": 13465,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13461,
         "end": 22608,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22640,
         "end": 36038,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36034,
         "end": 36499,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001426: 0-44134": {
       "start": 0,
       "end": 44134,
       "links": [
        {
         "query": "MARS55BIN28_002835",
         "subject": "APZ78784.1",
         "query_loc": 14989,
         "subject_loc": 37336
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "APZ78776.1",
         "start": 0,
         "end": 1272,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78777.1",
         "start": 1278,
         "end": 2220,
         "strand": 1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "APZ78778.1",
         "start": 2229,
         "end": 5832,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78779.1",
         "start": 5836,
         "end": 6373,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78784.1",
         "start": 36583,
         "end": 38089,
         "strand": -1,
         "function": "other",
         "linked": {
          "1": "MARS55BIN28_002835"
         }
        },
        {
         "locus_tag": "APZ78785.1",
         "start": 38438,
         "end": 40547,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "APZ78786.1",
         "start": 40981,
         "end": 42172,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78787.1",
         "start": 42290,
         "end": 42767,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "APZ78788.1",
         "start": 42937,
         "end": 44134,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "mchA",
         "start": 7005,
         "end": 13464,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchB",
         "start": 13460,
         "end": 22607,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchC",
         "start": 22639,
         "end": 36037,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "mchD",
         "start": 36033,
         "end": 36498,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS55BIN28_002826": {
     "functions": []
    },
    "MARS55BIN28_002827": {
     "functions": []
    },
    "MARS55BIN28_002828": {
     "functions": []
    },
    "MARS55BIN28_002829": {
     "functions": [
      {
       "description": "phytoene_synt",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "MARS55BIN28_002830": {
     "functions": []
    },
    "MARS55BIN28_002831": {
     "functions": []
    },
    "MARS55BIN28_002832": {
     "functions": []
    },
    "MARS55BIN28_002833": {
     "functions": []
    },
    "MARS55BIN28_002834": {
     "functions": []
    },
    "MARS55BIN28_002835": {
     "functions": [
      {
       "description": "SMCOG1122:ATP-dependent RNA helicase ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS55BIN28_002826",
      "seqLength": 893,
      "domains": [
       {
        "start": 228,
        "end": 403,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_N",
        "accession": "PF00350",
        "description": "Dynamin family",
        "evalue": "8.3e-42",
        "score": "143.2"
       },
       {
        "start": 410,
        "end": 541,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Dynamin_M",
        "accession": "PF01031",
        "description": "Dynamin central region",
        "evalue": "1.9e-14",
        "score": "53.7"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002827",
      "seqLength": 1043,
      "domains": [
       {
        "start": 18,
        "end": 355,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003924' target='_blank'>GO:0003924</a>: GTPase activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005525' target='_blank'>GO:0005525</a>: GTP binding"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "GTP_EFTU",
        "accession": "PF00009",
        "description": "Elongation factor Tu GTP binding domain",
        "evalue": "8e-58",
        "score": "195.3"
       },
       {
        "start": 574,
        "end": 638,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_III",
        "accession": "PF14492",
        "description": "Elongation Factor G, domain III",
        "evalue": "1.4e-06",
        "score": "28.3"
       },
       {
        "start": 908,
        "end": 989,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "EFG_C",
        "accession": "PF00679",
        "description": "Elongation factor G C-terminus",
        "evalue": "2.1e-13",
        "score": "50.2"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002828",
      "seqLength": 313,
      "domains": [
       {
        "start": 9,
        "end": 99,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "2.1e-14",
        "score": "54.0"
       },
       {
        "start": 214,
        "end": 306,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PH",
        "accession": "PF00169",
        "description": "PH domain",
        "evalue": "1.1e-16",
        "score": "61.4"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002829",
      "seqLength": 298,
      "domains": [
       {
        "start": 24,
        "end": 280,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "SQS_PSY",
        "accession": "PF00494",
        "description": "Squalene/phytoene synthase",
        "evalue": "8.4e-51",
        "score": "173.1"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002830",
      "seqLength": 174,
      "domains": [
       {
        "start": 1,
        "end": 68,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003743' target='_blank'>GO:0003743</a>: translation initiation factor activity",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006413' target='_blank'>GO:0006413</a>: translational initiation"
        ],
        "html_class": "generic-type-other",
        "name": "IF3_N",
        "accession": "PF05198",
        "description": "Translation initiation factor IF-3, N-terminal domain",
        "evalue": "8.6e-09",
        "score": "35.7"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002831",
      "seqLength": 349,
      "domains": [
       {
        "start": 109,
        "end": 313,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "MFAP1",
        "accession": "PF06991",
        "description": "Microfibril-associated/Pre-mRNA processing",
        "evalue": "1.7e-61",
        "score": "208.0"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002832",
      "seqLength": 236,
      "domains": [
       {
        "start": 71,
        "end": 224,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "TRAPP",
        "accession": "PF04051",
        "description": "Transport protein particle (TRAPP) component",
        "evalue": "9.9e-44",
        "score": "148.8"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002833",
      "seqLength": 340,
      "domains": [
       {
        "start": 57,
        "end": 300,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PP2C",
        "accession": "PF00481",
        "description": "Protein phosphatase 2C",
        "evalue": "2.9e-67",
        "score": "227.2"
       }
      ]
     },
     {
      "id": "MARS55BIN28_002835",
      "seqLength": 434,
      "domains": [
       {
        "start": 38,
        "end": 209,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003676' target='_blank'>GO:0003676</a>: nucleic acid binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "DEAD",
        "accession": "PF00270",
        "description": "DEAD/DEAH box helicase",
        "evalue": "1e-42",
        "score": "146.0"
       },
       {
        "start": 253,
        "end": 362,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "Helicase_C",
        "accession": "PF00271",
        "description": "Helicase conserved C-terminal domain",
        "evalue": "2.1e-27",
        "score": "95.8"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS55BIN28_002827",
      "seqLength": 1043,
      "domains": [
       {
        "start": 19,
        "end": 165,
        "name": "TIGR00231",
        "description": "small_GTP: small GTP-binding protein domain",
        "accession": "TIGR00231",
        "evalue": "6.9e-14",
        "score": "49.9",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r317c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "perA",
         "query_loc": 5559,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "icoS",
         "query_loc": 5559,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "XNC1_2022",
         "query_loc": 5559,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "plu3123",
         "query_loc": 5559,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "plu3263",
         "query_loc": 5559,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "PLU_RS13235",
         "query_loc": 5559,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "X797_010654",
         "query_loc": 5559,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "AN5318.2",
         "query_loc": 5559,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 5559,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "BO96DRAFT_451379",
         "query_loc": 5559,
         "subject_loc": 6032
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0002164: 0-8322": {
       "start": 0,
       "end": 8322,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "perA",
         "query_loc": 5559,
         "subject_loc": 4161
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "perA",
         "start": 0,
         "end": 8322,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001833: 14964-30015": {
       "start": 14964,
       "end": 30015,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "icoS",
         "query_loc": 5559,
         "subject_loc": 22489
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "icoS",
         "start": 14964,
         "end": 30015,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001132: 0-12417": {
       "start": 0,
       "end": 12417,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "XNC1_2022",
         "query_loc": 5559,
         "subject_loc": 6208
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "XNC1_2022",
         "start": 0,
         "end": 12417,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002286: 0-16374": {
       "start": 0,
       "end": 16374,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "plu3123",
         "query_loc": 5559,
         "subject_loc": 8187
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3123",
         "start": 0,
         "end": 16374,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001128: 35-15686": {
       "start": 35,
       "end": 15686,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "plu3263",
         "query_loc": 5559,
         "subject_loc": 7860
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "plu3263",
         "start": 35,
         "end": 15686,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001641: 0-49104": {
       "start": 0,
       "end": 49104,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "PLU_RS13235",
         "query_loc": 5559,
         "subject_loc": 24552
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "PLU_RS13235",
         "start": 0,
         "end": 49104,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0001240: 0-28516": {
       "start": 0,
       "end": 28516,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "X797_010654",
         "query_loc": 5559,
         "subject_loc": 14258
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "X797_010654",
         "start": 0,
         "end": 28516,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002276: 0-3813": {
       "start": 0,
       "end": 3813,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "AN5318.2",
         "query_loc": 5559,
         "subject_loc": 1906
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AN5318.2",
         "start": 0,
         "end": 3813,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002171: 8-7317": {
       "start": 8,
       "end": 7317,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "ASPNIDRAFT_41846",
         "query_loc": 5559,
         "subject_loc": 4534
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ASPNIDRAFT_41845",
         "start": 8,
         "end": 596,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ASPNIDRAFT_41846",
         "start": 1752,
         "end": 7317,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      },
      "BGC0002275: 0-10320": {
       "start": 0,
       "end": 10320,
       "links": [
        {
         "query": "MARS55BIN28_003969",
         "subject": "BO96DRAFT_451379",
         "query_loc": 5559,
         "subject_loc": 6032
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "BO96DRAFT_417028",
         "start": 0,
         "end": 753,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "BO96DRAFT_451379",
         "start": 1744,
         "end": 10320,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_003969"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_003969",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 223,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_003969",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 821,
        "terminalDocking": ""
       },
       {
        "name": "NAD",
        "description": "NAD_binding_4",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_003969",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 944,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Aad"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS55BIN28_003967": {
     "functions": []
    },
    "MARS55BIN28_003968": {
     "functions": []
    },
    "MARS55BIN28_003969": {
     "functions": [
      {
       "description": "NAD_binding_4",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS55BIN28_003970": {
     "functions": []
    },
    "MARS55BIN28_003971": {
     "functions": []
    },
    "MARS55BIN28_003972": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS55BIN28_003967",
      "seqLength": 551,
      "domains": [
       {
        "start": 313,
        "end": 443,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016887' target='_blank'>GO:0016887</a>: ATP hydrolysis activity"
        ],
        "html_class": "generic-type-other",
        "name": "AAA",
        "accession": "PF00004",
        "description": "ATPase family associated with various cellular activities (AAA)",
        "evalue": "1.4e-40",
        "score": "138.9"
       },
       {
        "start": 466,
        "end": 501,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "AAA_lid_3",
        "accession": "PF17862",
        "description": "AAA+ lid domain",
        "evalue": "2.4e-07",
        "score": "30.6"
       }
      ]
     },
     {
      "id": "MARS55BIN28_003969",
      "seqLength": 1355,
      "domains": [
       {
        "start": 223,
        "end": 688,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "AMP-binding",
        "accession": "PF00501",
        "description": "AMP-binding enzyme",
        "evalue": "2.3e-65",
        "score": "221.0"
       },
       {
        "start": 822,
        "end": 887,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "2.9e-12",
        "score": "46.8"
       },
       {
        "start": 944,
        "end": 1194,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "NAD_binding_4",
        "accession": "PF07993",
        "description": "Male sterility protein",
        "evalue": "2.2e-75",
        "score": "253.3"
       }
      ]
     },
     {
      "id": "MARS55BIN28_003970",
      "seqLength": 528,
      "domains": [
       {
        "start": 36,
        "end": 102,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046034' target='_blank'>GO:0046034</a>: ATP metabolic process",
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:1902600' target='_blank'>GO:1902600</a>: proton transmembrane transport"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab_N",
        "accession": "PF02874",
        "description": "ATP synthase alpha/beta family, beta-barrel domain",
        "evalue": "2.2e-14",
        "score": "53.9"
       },
       {
        "start": 158,
        "end": 386,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
        ],
        "html_class": "generic-type-other",
        "name": "ATP-synt_ab",
        "accession": "PF00006",
        "description": "ATP synthase alpha/beta family, nucleotide-binding domain",
        "evalue": "6.7e-64",
        "score": "215.6"
       }
      ]
     },
     {
      "id": "MARS55BIN28_003971",
      "seqLength": 95,
      "domains": [
       {
        "start": 35,
        "end": 84,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "DUF4050",
        "accession": "PF13259",
        "description": "Protein of unknown function (DUF4050)",
        "evalue": "3.5e-10",
        "score": "40.6"
       }
      ]
     },
     {
      "id": "MARS55BIN28_003972",
      "seqLength": 323,
      "domains": [
       {
        "start": 27,
        "end": 270,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "DUF1295",
        "accession": "PF06966",
        "description": "Protein of unknown function (DUF1295)",
        "evalue": "3e-60",
        "score": "203.7"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS55BIN28_003969",
      "seqLength": 1355,
      "domains": [
       {
        "start": 6,
        "end": 1350,
        "name": "TIGR03443",
        "description": "alpha_am_amid: L-aminoadipate-semialdehyde dehydrogenase",
        "accession": "TIGR03443",
        "evalue": "0",
        "score": "1895.0",
        "html_class": "generic-type-other"
       },
       {
        "start": 253,
        "end": 711,
        "name": "TIGR01733",
        "description": "AA-adenyl-dom: amino acid adenylation domain",
        "accession": "TIGR01733",
        "evalue": "6e-113",
        "score": "375.7",
        "html_class": "generic-type-other"
       },
       {
        "start": 941,
        "end": 1317,
        "name": "TIGR01746",
        "description": "Thioester-redct: thioester reductase domain",
        "accession": "TIGR01746",
        "evalue": "5.3e-102",
        "score": "339.8",
        "html_class": "generic-type-other"
       }
      ]
     },
     {
      "id": "MARS55BIN28_003970",
      "seqLength": 528,
      "domains": [
       {
        "start": 32,
        "end": 495,
        "name": "TIGR01040",
        "description": "V-ATPase_V1_B: V-type ATPase, B subunit",
        "accession": "TIGR01040",
        "evalue": "8.8e-291",
        "score": "962.1",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r421c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000107: 144-6819": {
       "start": 144,
       "end": 6819,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_08209",
         "query_loc": 3041,
         "subject_loc": 3481
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_08209",
         "start": 144,
         "end": 6819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0000013: 0-7849": {
       "start": 0,
       "end": 7849,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_07071",
         "query_loc": 3041,
         "subject_loc": 2981
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_07070",
         "start": 6558,
         "end": 7849,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_07071",
         "start": 0,
         "end": 5963,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001284: 0-5292": {
       "start": 0,
       "end": 5292,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "AKN45693.1",
         "query_loc": 3041,
         "subject_loc": 2646
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AKN45693.1",
         "start": 0,
         "end": 5292,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0002175: 214-6865": {
       "start": 214,
       "end": 6865,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "AO090102000545",
         "query_loc": 3041,
         "subject_loc": 3539
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AO090102000545",
         "start": 214,
         "end": 6865,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0002240: 96-11225": {
       "start": 96,
       "end": 11225,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "MANI_025650",
         "query_loc": 3041,
         "subject_loc": 4763
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MANI_002819",
         "start": 10027,
         "end": 11225,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MANI_025650",
         "start": 96,
         "end": 9430,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001219: 0-23500": {
       "start": 0,
       "end": 23500,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "CHGG_08793",
         "query_loc": 3041,
         "subject_loc": 4015
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "CHGG_08793",
         "start": 0,
         "end": 8030,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        },
        {
         "locus_tag": "CHGG_08794",
         "start": 8679,
         "end": 9468,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08795",
         "start": 11271,
         "end": 12060,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08796",
         "start": 12839,
         "end": 14269,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08797",
         "start": 15673,
         "end": 17302,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08798",
         "start": 19053,
         "end": 21140,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08799",
         "start": 22009,
         "end": 23500,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ADH01663.1",
         "query_loc": 3041,
         "subject_loc": 4052
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001400: 30-15436": {
       "start": 30,
       "end": 15436,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ATEG_09617",
         "query_loc": 3041,
         "subject_loc": 5994
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_09616",
         "start": 30,
         "end": 1721,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09617",
         "start": 2232,
         "end": 9757,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        },
        {
         "locus_tag": "ATEG_09618",
         "start": 10286,
         "end": 10976,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09619",
         "start": 11183,
         "end": 12297,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09620",
         "start": 13826,
         "end": 15436,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001244: 0-5358": {
       "start": 0,
       "end": 5358,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "SNOG_00477",
         "query_loc": 3041,
         "subject_loc": 2679
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SNOG_00477",
         "start": 0,
         "end": 5358,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0000037: 0-7821": {
       "start": 0,
       "end": 7821,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_06448",
         "query_loc": 3041,
         "subject_loc": 3910
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_06448",
         "start": 0,
         "end": 7821,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000107: 144-6819": {
       "start": 144,
       "end": 6819,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_08209",
         "query_loc": 3041,
         "subject_loc": 3481
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_08209",
         "start": 144,
         "end": 6819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0000013: 0-7849": {
       "start": 0,
       "end": 7849,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_07071",
         "query_loc": 3041,
         "subject_loc": 2981
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_07070",
         "start": 6558,
         "end": 7849,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_07071",
         "start": 0,
         "end": 5963,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001284: 0-5292": {
       "start": 0,
       "end": 5292,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "AKN45693.1",
         "query_loc": 3041,
         "subject_loc": 2646
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AKN45693.1",
         "start": 0,
         "end": 5292,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0002175: 214-6865": {
       "start": 214,
       "end": 6865,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "AO090102000545",
         "query_loc": 3041,
         "subject_loc": 3539
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AO090102000545",
         "start": 214,
         "end": 6865,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0002240: 96-11225": {
       "start": 96,
       "end": 11225,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "MANI_025650",
         "query_loc": 3041,
         "subject_loc": 4763
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "MANI_002819",
         "start": 10027,
         "end": 11225,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MANI_025650",
         "start": 96,
         "end": 9430,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001219: 0-23500": {
       "start": 0,
       "end": 23500,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "CHGG_08793",
         "query_loc": 3041,
         "subject_loc": 4015
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "CHGG_08793",
         "start": 0,
         "end": 8030,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        },
        {
         "locus_tag": "CHGG_08794",
         "start": 8679,
         "end": 9468,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08795",
         "start": 11271,
         "end": 12060,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08796",
         "start": 12839,
         "end": 14269,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08797",
         "start": 15673,
         "end": 17302,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08798",
         "start": 19053,
         "end": 21140,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "CHGG_08799",
         "start": 22009,
         "end": 23500,
         "strand": -1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000099: 0-8104": {
       "start": 0,
       "end": 8104,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ADH01663.1",
         "query_loc": 3041,
         "subject_loc": 4052
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ADH01663.1",
         "start": 0,
         "end": 8104,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0001400: 30-15436": {
       "start": 30,
       "end": 15436,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ATEG_09617",
         "query_loc": 3041,
         "subject_loc": 5994
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ATEG_09616",
         "start": 30,
         "end": 1721,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09617",
         "start": 2232,
         "end": 9757,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        },
        {
         "locus_tag": "ATEG_09618",
         "start": 10286,
         "end": 10976,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09619",
         "start": 11183,
         "end": 12297,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ATEG_09620",
         "start": 13826,
         "end": 15436,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001244: 0-5358": {
       "start": 0,
       "end": 5358,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "SNOG_00477",
         "query_loc": 3041,
         "subject_loc": 2679
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "SNOG_00477",
         "start": 0,
         "end": 5358,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      },
      "BGC0000037: 0-7821": {
       "start": 0,
       "end": 7821,
       "links": [
        {
         "query": "MARS55BIN28_004502",
         "subject": "ANIA_06448",
         "query_loc": 3041,
         "subject_loc": 3910
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_06448",
         "start": 0,
         "end": 7821,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004502"
         }
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_004503",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 8,
        "terminalDocking": ""
       },
       {
        "name": "PT",
        "description": "PT",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_004503",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 266,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_004503",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 614,
        "terminalDocking": ""
       },
       {
        "name": "TE",
        "description": "Thioesterase",
        "modifier": false,
        "special": false,
        "cds": "MARS55BIN28_004503",
        "css": "jsdomain-terminal",
        "inactive": false,
        "start": 737,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "mal"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS55BIN28_004502": {
     "functions": [
      {
       "description": "PKS_AT",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "itr_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS55BIN28_004503": {
     "functions": [
      {
       "description": "PKS_AT",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS55BIN28_004502",
      "seqLength": 1011,
      "domains": [
       {
        "start": 10,
        "end": 248,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "SAT",
        "accession": "PF16073",
        "description": "Starter unit:ACP transacylase in aflatoxin biosynthesis",
        "evalue": "3.8e-21",
        "score": "75.9"
       },
       {
        "start": 401,
        "end": 608,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "ketoacyl-synt",
        "accession": "PF00109",
        "description": "Beta-ketoacyl synthase, N-terminal domain",
        "evalue": "5.8e-59",
        "score": "199.8"
       },
       {
        "start": 649,
        "end": 755,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Ketoacyl-synt_C",
        "accession": "PF02801",
        "description": "Beta-ketoacyl synthase, C-terminal domain",
        "evalue": "1.6e-27",
        "score": "96.0"
       }
      ]
     },
     {
      "id": "MARS55BIN28_004503",
      "seqLength": 955,
      "domains": [
       {
        "start": 9,
        "end": 189,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "Acyl_transf_1",
        "accession": "PF00698",
        "description": "Acyl transferase domain",
        "evalue": "2.9e-14",
        "score": "53.4"
       },
       {
        "start": 266,
        "end": 554,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "PS-DH",
        "accession": "PF14765",
        "description": "Polyketide synthase dehydratase",
        "evalue": "2.3e-17",
        "score": "63.3"
       },
       {
        "start": 614,
        "end": 678,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "PP-binding",
        "accession": "PF00550",
        "description": "Phosphopantetheine attachment site",
        "evalue": "1.1e-05",
        "score": "25.8"
       },
       {
        "start": 737,
        "end": 952,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "Thioesterase",
        "accession": "PF00975",
        "description": "Thioesterase domain",
        "evalue": "3.6e-22",
        "score": "79.7"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS55BIN28_004503",
      "seqLength": 955,
      "domains": [
       {
        "start": 266,
        "end": 563,
        "name": "TIGR04532",
        "description": "PT_fungal_PKS: polyketide product template domain",
        "accession": "TIGR04532",
        "evalue": "1.4e-53",
        "score": "180.4",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 },
 "r531c1": {
  "antismash.modules.cluster_compare": {
   "MIBiG": {
    "ProtoToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "ANIA_01592",
         "query_loc": 507,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "PbGGS",
         "query_loc": 507,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "ctg1_orf003",
         "query_loc": 507,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "sre2",
         "query_loc": 507,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "PCH_Pc20g10860",
         "query_loc": 507,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "MAA_07498",
         "query_loc": 507,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "paxG",
         "query_loc": 507,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "aspC",
         "query_loc": 507,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        }
       ]
      },
      "BGC0002603: 0-17042": {
       "start": 0,
       "end": 17042,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "cle6",
         "query_loc": 507,
         "subject_loc": 15140
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cle1",
         "start": 0,
         "end": 5488,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "cle2",
         "start": 6016,
         "end": 7840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle3",
         "start": 8160,
         "end": 9796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle4",
         "start": 10463,
         "end": 12174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle5",
         "start": 12298,
         "end": 13388,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle6",
         "start": 14479,
         "end": 15802,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "cle7",
         "start": 16259,
         "end": 17042,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001776: 15-68182": {
       "start": 15,
       "end": 68182,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "janG",
         "query_loc": 507,
         "subject_loc": 25660
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGZ20477.1",
         "start": 37970,
         "end": 39783,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20479.1",
         "start": 55985,
         "end": 56864,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20481.1",
         "start": 8038,
         "end": 10182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20482.1",
         "start": 11347,
         "end": 12946,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20483.1",
         "start": 15,
         "end": 7575,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20484.1",
         "start": 13487,
         "end": 14403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20485.1",
         "start": 15278,
         "end": 19054,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20486.1",
         "start": 21161,
         "end": 23932,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20489.1",
         "start": 50327,
         "end": 51298,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20490.1",
         "start": 54127,
         "end": 55251,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20491.1",
         "start": 60609,
         "end": 62903,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20492.1",
         "start": 63320,
         "end": 64772,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20493.1",
         "start": 65225,
         "end": 68182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janA",
         "start": 27459,
         "end": 28569,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janB",
         "start": 31349,
         "end": 32144,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janC",
         "start": 33286,
         "end": 34406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janD",
         "start": 44432,
         "end": 45819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janG",
         "start": 25022,
         "end": 26299,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "janM",
         "start": 29235,
         "end": 30817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janO",
         "start": 46882,
         "end": 48450,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janP",
         "start": 34798,
         "end": 36641,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janQ",
         "start": 40479,
         "end": 42545,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    },
    "RegionToRegion_RiQ": {
     "reference_clusters": {
      "BGC0000673: 0-9097": {
       "start": 0,
       "end": 9097,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "ANIA_01592",
         "query_loc": 507,
         "subject_loc": 5346
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ANIA_01591",
         "start": 0,
         "end": 2872,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ANIA_01592",
         "start": 4662,
         "end": 6030,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "ANIA_01593",
         "start": 7787,
         "end": 9097,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0000676: 621-14838": {
       "start": 621,
       "end": 14838,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "PbGGS",
         "query_loc": 507,
         "subject_loc": 1137
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "ACS",
         "start": 3292,
         "end": 6300,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbGGS",
         "start": 621,
         "end": 1653,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "PbP450-1",
         "start": 6698,
         "end": 8429,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbP450-2",
         "start": 11481,
         "end": 13230,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "PbTF",
         "start": 13450,
         "end": 14838,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "PbTP",
         "start": 8956,
         "end": 10846,
         "strand": -1,
         "function": "transport",
         "linked": {}
        }
       ]
      },
      "BGC0000688: 696-13661": {
       "start": 696,
       "end": 13661,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "ctg1_orf003",
         "query_loc": 507,
         "subject_loc": 5272
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "ctg1_orf000000",
         "start": 696,
         "end": 1010,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf00001",
         "start": 1118,
         "end": 1662,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf0002",
         "start": 1955,
         "end": 3975,
         "strand": -1,
         "function": "transport",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf003",
         "start": 4518,
         "end": 6026,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "ctg1_orf5",
         "start": 7912,
         "end": 12008,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orf6",
         "start": 12740,
         "end": 13661,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "ctg1_orforf04",
         "start": 6505,
         "end": 7216,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002604: 0-17897": {
       "start": 0,
       "end": 17897,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "sre2",
         "query_loc": 507,
         "subject_loc": 3093
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "sre1",
         "start": 0,
         "end": 1134,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre2",
         "start": 2465,
         "end": 3722,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "sre3",
         "start": 4584,
         "end": 5388,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre4",
         "start": 6406,
         "end": 8018,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre5",
         "start": 10608,
         "end": 11969,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "sre6",
         "start": 12313,
         "end": 17897,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        }
       ]
      },
      "BGC0002320: 3-7131": {
       "start": 3,
       "end": 7131,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "PCH_Pc20g10860",
         "query_loc": 507,
         "subject_loc": 1400
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "PCH_Pc20g10860",
         "start": 3,
         "end": 2798,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "PCH_Pc20g10870",
         "start": 5443,
         "end": 7131,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0002427: 0-21541": {
       "start": 0,
       "end": 21541,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "MAA_07498",
         "query_loc": 507,
         "subject_loc": 14238
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "MAA_07496",
         "start": 0,
         "end": 6612,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07497",
         "start": 9944,
         "end": 10466,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07498",
         "start": 13643,
         "end": 14834,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "MAA_07499",
         "start": 16076,
         "end": 17155,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "MAA_07500",
         "start": 19897,
         "end": 21541,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "MAA_11696",
         "start": 11753,
         "end": 12083,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001082: 0-18809": {
       "start": 0,
       "end": 18809,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "paxG",
         "query_loc": 507,
         "subject_loc": 647
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "paxA",
         "start": 1836,
         "end": 2967,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxB",
         "start": 5757,
         "end": 6576,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxC",
         "start": 7641,
         "end": 8718,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxD",
         "start": 17402,
         "end": 18809,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "paxG",
         "start": 0,
         "end": 1294,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "paxM",
         "start": 3719,
         "end": 5278,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "paxP",
         "start": 9257,
         "end": 11106,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "paxQ",
         "start": 13491,
         "end": 15578,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      },
      "BGC0001969: 0-7810": {
       "start": 0,
       "end": 7810,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "aspC",
         "query_loc": 507,
         "subject_loc": 6426
        }
       ],
       "reverse": true,
       "genes": [
        {
         "locus_tag": "aspA",
         "start": 0,
         "end": 1658,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspB",
         "start": 2184,
         "end": 3989,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "aspC",
         "start": 5042,
         "end": 7810,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        }
       ]
      },
      "BGC0002603: 0-17042": {
       "start": 0,
       "end": 17042,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "cle6",
         "query_loc": 507,
         "subject_loc": 15140
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "cle1",
         "start": 0,
         "end": 5488,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "cle2",
         "start": 6016,
         "end": 7840,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle3",
         "start": 8160,
         "end": 9796,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle4",
         "start": 10463,
         "end": 12174,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "cle5",
         "start": 12298,
         "end": 13388,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "cle6",
         "start": 14479,
         "end": 15802,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "cle7",
         "start": 16259,
         "end": 17042,
         "strand": 1,
         "function": "other",
         "linked": {}
        }
       ]
      },
      "BGC0001776: 15-68182": {
       "start": 15,
       "end": 68182,
       "links": [
        {
         "query": "MARS55BIN28_004872",
         "subject": "janG",
         "query_loc": 507,
         "subject_loc": 25660
        }
       ],
       "reverse": false,
       "genes": [
        {
         "locus_tag": "AGZ20477.1",
         "start": 37970,
         "end": 39783,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20479.1",
         "start": 55985,
         "end": 56864,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20481.1",
         "start": 8038,
         "end": 10182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20482.1",
         "start": 11347,
         "end": 12946,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20483.1",
         "start": 15,
         "end": 7575,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20484.1",
         "start": 13487,
         "end": 14403,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20485.1",
         "start": 15278,
         "end": 19054,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20486.1",
         "start": 21161,
         "end": 23932,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20489.1",
         "start": 50327,
         "end": 51298,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20490.1",
         "start": 54127,
         "end": 55251,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20491.1",
         "start": 60609,
         "end": 62903,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20492.1",
         "start": 63320,
         "end": 64772,
         "strand": 1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "AGZ20493.1",
         "start": 65225,
         "end": 68182,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janA",
         "start": 27459,
         "end": 28569,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janB",
         "start": 31349,
         "end": 32144,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janC",
         "start": 33286,
         "end": 34406,
         "strand": 1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janD",
         "start": 44432,
         "end": 45819,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {}
        },
        {
         "locus_tag": "janG",
         "start": 25022,
         "end": 26299,
         "strand": -1,
         "function": "biosynthetic",
         "linked": {
          "1": "MARS55BIN28_004872"
         }
        },
        {
         "locus_tag": "janM",
         "start": 29235,
         "end": 30817,
         "strand": -1,
         "function": "other",
         "linked": {}
        },
        {
         "locus_tag": "janO",
         "start": 46882,
         "end": 48450,
         "strand": 1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janP",
         "start": 34798,
         "end": 36641,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        },
        {
         "locus_tag": "janQ",
         "start": 40479,
         "end": 42545,
         "strand": -1,
         "function": "biosynthetic-additional",
         "linked": {}
        }
       ]
      }
     }
    }
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "MARS55BIN28_004872": {
     "functions": [
      {
       "description": "fung_ggpps",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1182:Polyprenyl synthetase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "MARS55BIN28_004873": {
     "functions": []
    },
    "MARS55BIN28_004874": {
     "functions": []
    }
   }
  },
  "antismash.outputs.html.visualisers.generic_domains": [
   {
    "name": "pfam",
    "data": [
     {
      "id": "MARS55BIN28_004872",
      "seqLength": 313,
      "domains": [
       {
        "start": 42,
        "end": 281,
        "go_terms": [
         "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008299' target='_blank'>GO:0008299</a>: isoprenoid biosynthetic process"
        ],
        "html_class": "generic-type-biosynthetic",
        "name": "polyprenyl_synt",
        "accession": "PF00348",
        "description": "Polyprenyl synthetase",
        "evalue": "2e-66",
        "score": "223.8"
       }
      ]
     },
     {
      "id": "MARS55BIN28_004873",
      "seqLength": 241,
      "domains": [
       {
        "start": 0,
        "end": 38,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "4.7e-07",
        "score": "29.3"
       },
       {
        "start": 39,
        "end": 235,
        "go_terms": [],
        "html_class": "generic-type-other",
        "name": "CDC14",
        "accession": "PF08045",
        "description": "Cell division control protein 14, SIN component",
        "evalue": "1.2e-56",
        "score": "192.1"
       }
      ]
     },
     {
      "id": "MARS55BIN28_004874",
      "seqLength": 620,
      "domains": [
       {
        "start": 59,
        "end": 242,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "HAD",
        "accession": "PF12710",
        "description": "haloacid dehalogenase-like hydrolase",
        "evalue": "1.7e-24",
        "score": "87.5"
       },
       {
        "start": 353,
        "end": 604,
        "go_terms": [],
        "html_class": "generic-type-biosynthetic",
        "name": "GCV_T",
        "accession": "PF01571",
        "description": "Aminomethyltransferase folate-binding domain",
        "evalue": "1.2e-87",
        "score": "293.6"
       }
      ]
     }
    ],
    "url": "https://www.ebi.ac.uk/interpro/entry/pfam/$ACCESSION"
   },
   {
    "name": "tigrfam",
    "data": [
     {
      "id": "MARS55BIN28_004874",
      "seqLength": 620,
      "domains": [
       {
        "start": 349,
        "end": 618,
        "name": "TIGR00528",
        "description": "gcvT: glycine cleavage system T protein",
        "accession": "TIGR00528",
        "evalue": "6.4e-91",
        "score": "302.9",
        "html_class": "generic-type-other"
       },
       {
        "start": 57,
        "end": 251,
        "name": "TIGR01489",
        "description": "DKMTPPase-SF: 2,3-diketo-5-methylthio-1-phosphopentane phosphatase",
        "accession": "TIGR01489",
        "evalue": "3.7e-27",
        "score": "93.6",
        "html_class": "generic-type-other"
       },
       {
        "start": 58,
        "end": 242,
        "name": "TIGR01488",
        "description": "HAD-SF-IB: HAD phosphoserine phosphatase-like hydrolase, family IB",
        "accession": "TIGR01488",
        "evalue": "5.3e-18",
        "score": "63.5",
        "html_class": "generic-type-other"
       }
      ]
     }
    ],
    "url": "https://www.ncbi.nlm.nih.gov/genome/annotation_prok/evidence/$ACCESSION"
   }
  ]
 }
};
